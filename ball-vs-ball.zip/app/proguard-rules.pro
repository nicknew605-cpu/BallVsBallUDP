# Ball vs Ball v1.0.2 Beta — Aggressive R8 Obfuscation (Debug + Release) + Firebase Safety

-optimizationpasses 5
-allowaccessmodification
-overloadaggressively
-repackageclasses 'o'
-flattenpackagehierarchy 'o'
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod,RuntimeVisibleAnnotations

# Strip verbose/debug logs in obfuscated builds while preserving Log.w/Log.e diagnostics
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
}

# Preserve Compose & Activity entry points
-keep public class * extends android.app.Activity
-keep public class * extends androidx.activity.ComponentActivity
-keep class androidx.core.content.FileProvider { *; }

# Keep Kotlin Metadata & Firestore serialization POJOs (required for toObject/set)
-keep class kotlin.Metadata { *; }
-keep @com.google.firebase.firestore.IgnoreExtraProperties class * {
    <fields>;
    <init>(...);
    *;
}
-keepclassmembers class com.example.data.cloud.** {
    <fields>;
    <init>(...);
    *;
}
-keepclassmembers class * {
    @com.google.firebase.firestore.DocumentId <fields>;
    @com.google.firebase.firestore.ServerTimestamp <fields>;
    @com.google.firebase.firestore.PropertyName <fields>;
}

# Keep Credential Manager & Google Identity
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
-dontwarn androidx.credentials.**
-dontwarn com.google.android.gms.**
-dontwarn io.grpc.**
-dontwarn okio.**
-dontwarn javax.annotation.**
