package com.example.data.cloud

import com.example.base.FirestoreEmulatorTestBase
import com.example.model.ADMIN_OWNER_EMAIL
import com.example.model.BallType
import com.example.model.OnlineRoomPhase
import com.example.model.OtaAppUpdateConfig
import com.example.model.OtaGiftCodeEntry
import com.example.model.OtaLiveConfig
import com.example.model.OtaVfxConfig
import com.example.model.UserProgress
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class CloudRepositoryRuleTest : FirestoreEmulatorTestBase() {

  private fun uniqueEmail(prefix: String): String =
    "${prefix}_${UUID.randomUUID().toString().replace("-", "").take(10)}@test.com"

  @Test
  fun userProfile_createReadUpdateAndCrossUserIsolation_enforced() = runBlocking {
    val aliceEmail = uniqueEmail("alice")
    val bobEmail = uniqueEmail("bob")
    val aliceUid = signInTestUser(aliceEmail)
    val aliceRepo = CloudGameRepository(firestore, auth)

    val loaded = withTimeout(TIMEOUT_MS) {
      aliceRepo.ensureOrLoadUserProfile(UserProgress(nickname = "AliceV102", coins = 320))
    }
    assertEquals(320, loaded.coins)

    withTimeout(TIMEOUT_MS) {
      aliceRepo.saveUserProgress(loaded.copy(coins = 777, purchasedBalls = setOf(BallType.FIRE, BallType.THUNDER)))
    }
    val updated = withTimeout(TIMEOUT_MS) { aliceRepo.observeUserProfile().first { it.coins == 777 } }
    assertTrue(BallType.THUNDER in updated.purchasedBalls)

    // Bob cannot read Alice's profile
    signInTestUser(bobEmail)
    try {
      withTimeout(TIMEOUT_MS) { firestore.collection("users").document(aliceUid).get().await() }
      fail("Expected PERMISSION_DENIED for cross-user profile read")
    } catch (e: Exception) {
      val fsEx = e.unwrapFirestoreException() ?: throw e
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
    }
  }

  @Test
  fun mailbox_deliverAndClaimOnce_worksForOwnerAndRejectsUnauthenticated() = runBlocking {
    val aliceEmail = uniqueEmail("alicemail")
    signInTestUser(aliceEmail)
    val repo = CloudGameRepository(firestore, auth)
    withTimeout(TIMEOUT_MS) { repo.ensureOrLoadUserProfile(UserProgress(nickname = "AliceMail")) }

    val mailId = "mail_${UUID.randomUUID().toString().replace("-", "").take(12)}"
    withTimeout(TIMEOUT_MS) {
      repo.sendMailboxReward(
        mailId = mailId,
        sender = "Admin",
        titleVi = "TaiDz-111",
        titleEn = "TaiDz-111",
        bodyVi = "Free Thunder Ball",
        bodyEn = "Free Thunder Ball",
        rewardCoins = 0,
        rewardBall = BallType.THUNDER,
        sourceCode = "TaiDz-111",
      )
    }

    val letters = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeMailbox().first { list -> list.any { it.id == mailId } }
    }
    assertNotNull(letters.firstOrNull { it.id == mailId && it.rewardBall == BallType.THUNDER })

    withTimeout(TIMEOUT_MS) { repo.markMailClaimed(mailId) }
    val claimedLetters = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeMailbox().first { list -> list.any { it.id == mailId && it.claimed } }
    }
    assertTrue(claimedLetters.first { it.id == mailId }.claimed)

    // Unauthenticated access must fail with PERMISSION_DENIED
    auth.signOut()
    try {
      withTimeout(FLOW_TIMEOUT_MS) { repo.observeMailbox().first() }
      fail("Expected error when unauthenticated")
    } catch (e: Exception) {
      assertTrue(e is IllegalStateException || e.unwrapFirestoreException() != null)
    }
  }

  @Test
  fun onlineRoom_createJoinPickBanAndFinish_succeeds() = runBlocking {
    val aliceEmail = uniqueEmail("alicehost")
    val bobEmail = uniqueEmail("bobguest")
    val aliceUid = signInTestUser(aliceEmail)
    val aliceRoomRepo = OnlineRoomRepository(firestore, auth)
    val roomCode = "R${UUID.randomUUID().toString().replace("-", "").take(5).uppercase()}"

    val created = withTimeout(TIMEOUT_MS) { aliceRoomRepo.createRoom("AliceHost", roomCode) }
    assertEquals(OnlineRoomPhase.WAITING, created.phase)

    signInTestUser(bobEmail)
    val bobRoomRepo = OnlineRoomRepository(firestore, auth)
    val joined = withTimeout(TIMEOUT_MS) { bobRoomRepo.joinRoom(roomCode, "BobGuest") }
    assertEquals(OnlineRoomPhase.WAITING, joined.phase)

    // Unfiltered lobby chat
    withTimeout(TIMEOUT_MS) {
      bobRoomRepo.sendChatMessage(roomCode, "BobGuest", "San sang chien FT3 chua!")
    }
    val chatMessages = withTimeout(FLOW_TIMEOUT_MS) {
      bobRoomRepo.observeRoomChat(roomCode).first { it.isNotEmpty() }
    }
    assertEquals("San sang chien FT3 chua!", chatMessages.last().text)

    // Both players click Ready -> system auto-deals 3 owned balls & moves to BAN_1
    val aliceBalls = setOf(BallType.FIRE, BallType.WATER, BallType.THUNDER, BallType.ANT)
    val bobBalls = setOf(BallType.FIRE, BallType.GROUND, BallType.ICE)
    withTimeout(TIMEOUT_MS) {
      bobRoomRepo.setReady(joined, ready = true, myOwnedBalls = bobBalls)
    }

    signInTestUser(aliceEmail)
    val afterBobReady = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRoomRepo.observeRoom(roomCode).first { it != null && it.guestReady && it.guestPicks.size == 3 }
    }!!
    withTimeout(TIMEOUT_MS) {
      aliceRoomRepo.setReady(afterBobReady, ready = true, myOwnedBalls = aliceBalls)
    }

    val inBanPhase = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRoomRepo.observeRoom(roomCode).first { it?.phase == OnlineRoomPhase.BAN_1 }
    }!!
    withTimeout(TIMEOUT_MS) { aliceRoomRepo.submitBan1(inBanPhase, inBanPhase.guestPicks.first()) }

    signInTestUser(bobEmail)
    val afterHostBan = withTimeout(FLOW_TIMEOUT_MS) {
      bobRoomRepo.observeRoom(roomCode).first { it?.hostBannedBall != null }
    }!!
    withTimeout(TIMEOUT_MS) { bobRoomRepo.submitBan1(afterHostBan, afterHostBan.hostPicks.first()) }

    val inFinalPhase = withTimeout(FLOW_TIMEOUT_MS) {
      bobRoomRepo.observeRoom(roomCode).first { it?.phase == OnlineRoomPhase.FINAL_PICK }
    }!!
    val bobFinalCandidate = inFinalPhase.guestPicks.first { it != inFinalPhase.hostBannedBall }
    withTimeout(TIMEOUT_MS) { bobRoomRepo.submitFinalBall(inFinalPhase, bobFinalCandidate) }

    signInTestUser(aliceEmail)
    val afterBobFinal = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRoomRepo.observeRoom(roomCode).first { it?.guestFinalBall != null }
    }!!
    val aliceFinalCandidate = afterBobFinal.hostPicks.first { it != afterBobFinal.guestBannedBall }
    withTimeout(TIMEOUT_MS) { aliceRoomRepo.submitFinalBall(afterBobFinal, aliceFinalCandidate) }

    val playingRoom = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRoomRepo.observeRoom(roomCode).first { it?.phase == OnlineRoomPhase.PLAYING }
    }!!
    // Synchronized aim exchange before physics launch
    withTimeout(TIMEOUT_MS) { aliceRoomRepo.submitAimAngle(roomCode, 1, -1.2) }
    signInTestUser(bobEmail)
    withTimeout(TIMEOUT_MS) { bobRoomRepo.submitAimAngle(roomCode, 1, 1.45) }
    val syncedAimRoom = withTimeout(FLOW_TIMEOUT_MS) {
      bobRoomRepo.observeRoom(roomCode).first { it?.hasBothAims() == true }
    }!!
    assertTrue(syncedAimRoom.hasBothAims())

    // Round 1 win advances to Round 2 PICK_3 (FT3: first to 3 wins), and duplicate submit is idempotent
    val reward = playingRoom.computeSpeedRewardCoins(14.0f)
    signInTestUser(aliceEmail)
    val afterRound1 = withTimeout(TIMEOUT_MS) {
      aliceRoomRepo.reportRoundFinished(roomCode, aliceUid, 14.0f, reward, expectedRound = 1)
    }!!
    // Duplicate submission for already-finished round 1 does NOT double-increment score
    val dupCheck = withTimeout(TIMEOUT_MS) {
      aliceRoomRepo.reportRoundFinished(roomCode, aliceUid, 14.0f, reward, expectedRound = 1)
    }!!
    assertEquals(1, dupCheck.hostScore)
    assertEquals(1, afterRound1.hostScore)
    assertEquals(2, afterRound1.currentRound)
    assertEquals(OnlineRoomPhase.PICK_3, afterRound1.phase)
    assertTrue(!afterRound1.hasBothAims())

    // Simulate Round 2 & Round 3 reaching 3-0 finish via submitPick3 -> ban -> final -> aim -> reportRoundFinished
    for (roundIdx in 2..3) {
      val rState = withTimeout(FLOW_TIMEOUT_MS) {
        aliceRoomRepo.observeRoom(roomCode).first { it?.currentRound == roundIdx }
      }!!
      withTimeout(TIMEOUT_MS) {
        aliceRoomRepo.submitPick3(rState, listOf(BallType.FIRE, BallType.WATER, BallType.ANT))
      }
      signInTestUser(bobEmail)
      val rBobPick = withTimeout(FLOW_TIMEOUT_MS) {
        bobRoomRepo.observeRoom(roomCode).first { it?.hostPicks?.size == 3 }
      }!!
      withTimeout(TIMEOUT_MS) {
        bobRoomRepo.submitPick3(rBobPick, listOf(BallType.FIRE, BallType.GROUND, BallType.ICE))
      }
      val rBan = withTimeout(FLOW_TIMEOUT_MS) {
        bobRoomRepo.observeRoom(roomCode).first { it?.phase == OnlineRoomPhase.BAN_1 }
      }!!
      withTimeout(TIMEOUT_MS) { bobRoomRepo.submitBan1(rBan, BallType.WATER) }
      signInTestUser(aliceEmail)
      val rHostBan = withTimeout(FLOW_TIMEOUT_MS) {
        aliceRoomRepo.observeRoom(roomCode).first { it?.guestBannedBall != null }
      }!!
      withTimeout(TIMEOUT_MS) { aliceRoomRepo.submitBan1(rHostBan, BallType.ICE) }
      val rFinal = withTimeout(FLOW_TIMEOUT_MS) {
        aliceRoomRepo.observeRoom(roomCode).first { it?.phase == OnlineRoomPhase.FINAL_PICK }
      }!!
      withTimeout(TIMEOUT_MS) { aliceRoomRepo.submitFinalBall(rFinal, BallType.ANT) }
      signInTestUser(bobEmail)
      val rBobFinal = withTimeout(FLOW_TIMEOUT_MS) {
        bobRoomRepo.observeRoom(roomCode).first { it?.hostFinalBall != null }
      }!!
      withTimeout(TIMEOUT_MS) { bobRoomRepo.submitFinalBall(rBobFinal, BallType.GROUND) }
      withTimeout(FLOW_TIMEOUT_MS) {
        bobRoomRepo.observeRoom(roomCode).first { it?.phase == OnlineRoomPhase.PLAYING && it.currentRound == roundIdx }
      }
      withTimeout(TIMEOUT_MS) { bobRoomRepo.submitAimAngle(roomCode, roundIdx, 1.1) }
      signInTestUser(aliceEmail)
      withTimeout(TIMEOUT_MS) { aliceRoomRepo.submitAimAngle(roomCode, roundIdx, -1.3) }
      withTimeout(TIMEOUT_MS) {
        aliceRoomRepo.reportRoundFinished(roomCode, aliceUid, 12.0f, 240, expectedRound = roundIdx)
      }
    }

    val finishedRoom = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRoomRepo.observeRoom(roomCode).first { it?.phase == OnlineRoomPhase.FINISHED }
    }!!
    assertEquals(3, finishedRoom.hostScore)
    assertEquals(aliceUid, finishedRoom.winnerUid)
    assertEquals(240, finishedRoom.rewardCoins)
  }

  @Test
  fun otaLiveConfig_allowsVerifiedAdminAndRejectsRegularUsers() = runBlocking {
    val nonAdminEmail = uniqueEmail("regular")
    signInTestUser(nonAdminEmail)
    try {
      withTimeout(TIMEOUT_MS) {
        firestore.collection("ota_config").document("live").set(mapOf("configVersion" to 999)).await()
      }
      fail("Expected PERMISSION_DENIED when non-admin writes ota_config/live")
    } catch (e: Exception) {
      val fsEx = e.unwrapFirestoreException() ?: throw e
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
    }

    // Verified admin (nicknew605@gmail.com) can publish live OTA config, timed notice & per-ball stats
    signInTestUser(ADMIN_OWNER_EMAIL)
    val adminRepo = CloudGameRepository(firestore, auth)
    assertTrue(adminRepo.isAdminAccount())

    val expiresAt = System.currentTimeMillis() + 3_600_000L
    val customConfig =
      OtaLiveConfig(
        configVersion = 104,
        activeCodes =
          OtaLiveConfig.defaultCodes() +
            OtaGiftCodeEntry(
              code = "TetAdmin",
              rewardCoins = 2026,
              rewardBallId = BallType.ANT.id,
              titleVi = "Tet Gift",
              titleEn = "Tet Gift",
            ),
        balance =
          com.example.model.OtaBalanceConfig()
            .withBallOverride(BallType.ANT, hp = 160, damageScale = 1.35f),
        vfx = OtaVfxConfig(particleMultiplier = 1.45f, glowIntensity = 1.40f, effectScale = 1.15f, vibrancyBoost = 1.25f),
        appUpdate =
          OtaAppUpdateConfig(
            latestVersionCode = 7,
            latestVersionName = "1.0.3 Max",
            minSupportedVersionCode = 6,
            downloadUrl = "https://github.com/hct/ballvsball/releases/download/v1.0.3/app-release.apk",
            releaseNotesVi = "Ban cap nhat 1.0.3 Max",
            releaseNotesEn = "Update 1.0.3 Max",
          ),
        adminNoticeVi = "Chao mung 1.0.2 Max!",
        adminNoticeEn = "Welcome 1.0.2 Max!",
        adminNoticeExpiresAtMillis = expiresAt,
      )

    val saved = withTimeout(TIMEOUT_MS) { adminRepo.saveOtaLiveConfig(customConfig) }
    assertTrue(saved.syncedFromCloud)

    val fetched = withTimeout(TIMEOUT_MS) { adminRepo.fetchOtaLiveConfig() }
    assertTrue(fetched.activeCodes.any { it.code == "TetAdmin" && it.rewardCoins == 2026 })
    assertEquals(1.45f, fetched.vfx.particleMultiplier, 0.01f)
    assertEquals(160f, fetched.balance.hpFor(BallType.ANT), 0.01f)
    assertEquals(1.35f, fetched.balance.damageScaleFor(BallType.ANT), 0.01f)
    assertEquals(7, fetched.appUpdate.latestVersionCode)
    assertEquals("1.0.3 Max", fetched.appUpdate.latestVersionName)
    assertTrue(fetched.appUpdate.isUpdateAvailable(6))
    assertTrue(fetched.appUpdate.isDirectApkUrl())
    assertEquals("Chao mung 1.0.2 Max!", fetched.adminNoticeVi)
    assertEquals(expiresAt, fetched.adminNoticeExpiresAtMillis)

    val observed = withTimeout(FLOW_TIMEOUT_MS) {
      adminRepo.observeOtaLiveConfig().first { it.appUpdate.latestVersionCode == 7 }
    }
    assertEquals("1.0.3 Max", observed.appUpdate.latestVersionName)
  }

  @Test
  fun friendsDirectoryTargetedGiftAndRoomInvites_workThroughSecurityRules() = runBlocking {
    val aliceEmail = uniqueEmail("alicesoc")
    val aliceUid = signInTestUser(aliceEmail)
    val aliceRepo = CloudGameRepository(firestore, auth)
    val aliceProgress = withTimeout(TIMEOUT_MS) {
      aliceRepo.ensureOrLoadUserProfile(UserProgress(nickname = "AliceSocial", playerCode = "BVB-ALICE1"))
    }
    withTimeout(TIMEOUT_MS) { aliceRepo.syncPlayerDirectory(aliceProgress) }

    // Switch to Admin account (nicknew605@gmail.com)
    val adminUid = signInTestUser(ADMIN_OWNER_EMAIL)
    val adminRepo = CloudGameRepository(firestore, auth)
    val adminProgress = withTimeout(TIMEOUT_MS) {
      adminRepo.ensureOrLoadUserProfile(UserProgress(nickname = "HCTAdmin", playerCode = "BVB-ADM999"))
    }
    withTimeout(TIMEOUT_MS) { adminRepo.syncPlayerDirectory(adminProgress) }

    val results = withTimeout(TIMEOUT_MS) { adminRepo.searchPlayers("BVB-ALICE1") }
    assertTrue(results.any { it.uid == aliceUid && it.nickname == "AliceSocial" })

    // Admin sends a 120-minute Ant Ball trial + 1000 Coins directly to Alice's mailbox
    withTimeout(TIMEOUT_MS) {
      adminRepo.sendTargetedGiftToPlayer(
        targetUid = aliceUid,
        rewardCoins = 1000,
        rewardBall = BallType.ANT,
        trialMinutes = 120,
        customMessageVi = "Tang Alice Ant Ball 2 gio",
        customMessageEn = "Gift Alice 2h Ant Ball",
      )
    }

    // Admin sends friend request & room invite to Alice
    val targetAlice = results.first { it.uid == aliceUid }
    withTimeout(TIMEOUT_MS) { adminRepo.sendFriendRequest(adminProgress, targetAlice) }
    withTimeout(TIMEOUT_MS) { adminRepo.sendRoomInvite("ROOM88", adminProgress.nickname, aliceUid) }

    // Switch back to Alice to receive mail, friend request & room invite
    signInTestUser(aliceEmail)
    val aliceMails = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRepo.observeMailbox().first { list -> list.any { it.sourceCode == "ADMIN_DIRECT_GIFT" } }
    }
    val giftMail = aliceMails.first { it.sourceCode == "ADMIN_DIRECT_GIFT" }
    assertEquals(1000, giftMail.rewardCoins)
    assertEquals(BallType.ANT, giftMail.rewardBall)
    assertEquals(120, giftMail.trialMinutes)

    val requests = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRepo.observeIncomingFriendRequests().first { it.isNotEmpty() }
    }
    val reqFromAdmin = requests.first { it.fromUid == adminUid }
    assertTrue(reqFromAdmin.fromIsAdmin)
    withTimeout(TIMEOUT_MS) { aliceRepo.respondFriendRequest(reqFromAdmin, accept = true, aliceProgress) }

    val aliceFriends = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRepo.observeFriends().first { list -> list.any { it.uid == adminUid } }
    }
    assertTrue(aliceFriends.first { it.uid == adminUid }.isAdmin)

    val invites = withTimeout(FLOW_TIMEOUT_MS) {
      aliceRepo.observeIncomingRoomInvites().first { list -> list.any { it.roomCode == "ROOM88" } }
    }
    assertTrue(invites.first().fromIsAdmin)
    withTimeout(TIMEOUT_MS) { aliceRepo.respondRoomInvite(invites.first().id, accept = true) }
  }

  @Test
  fun quickMatchmakingAndBalanceSnapshotRoundTrip_succeeds() = runBlocking {
    val customBalance =
      com.example.model.OtaBalanceConfig(
        iceShardSpawnIntervalSec = 0.68f,
        iceShardDamage = 6,
        iceFreezeDurationSec = 10.0f,
        iceFreezeRageDrainPct = 0.70f,
        icePostFreezeSlowPct = 0.40f,
        groundSkill1Damage = 12f,
        groundArmorCooldownSec = 18f,
        antRegenIntervalSec = 16f,
      )
    val roundTripped = OnlineRoomDoc.parseBalanceMap(OnlineRoomDoc.balanceToMap(customBalance))
    assertEquals(10.0f, roundTripped.iceFreezeDurationSec, 0.01f)
    assertEquals(0.70f, roundTripped.iceFreezeRageDrainPct, 0.001f)
    assertEquals(0.40f, roundTripped.icePostFreezeSlowPct, 0.001f)
    assertEquals(18.0f, roundTripped.groundArmorCooldownSec, 0.01f)
    assertEquals(16.0f, roundTripped.antRegenIntervalSec, 0.01f)

    val aliceEmail = uniqueEmail("aliceqm")
    val bobEmail = uniqueEmail("bobqm")

    signInTestUser(bobEmail)
    val bobRoomRepo = OnlineRoomRepository(firestore, auth)
    withTimeout(TIMEOUT_MS) { bobRoomRepo.enqueueWaitingTicket("BobQuick") }

    val aliceUid = signInTestUser(aliceEmail)
    val aliceRoomRepo = OnlineRoomRepository(firestore, auth)
    val createdQuickRoom = withTimeout(TIMEOUT_MS) {
      aliceRoomRepo.findAndClaimWaitingOpponent(
        myNickname = "AliceQuick",
        balanceSnapshot = customBalance,
        respectTieBreaker = false,
      )
    }
    assertNotNull("Alice must match waiting Bob and create a QM room", createdQuickRoom)
    assertTrue(createdQuickRoom!!.roomCode.startsWith("QM"))
    assertTrue(createdQuickRoom.hostReady)
    assertEquals(aliceUid, createdQuickRoom.hostUid)

    signInTestUser(bobEmail)
    val bobTicket = withTimeout(FLOW_TIMEOUT_MS) {
      bobRoomRepo.observeMyMatchmakingTicket().first { it?.status == "matched" }
    }!!
    assertEquals(createdQuickRoom.roomCode, bobTicket.roomCode)

    val joinedQuickRoom = withTimeout(TIMEOUT_MS) {
      bobRoomRepo.joinRoom(bobTicket.roomCode, "BobQuick", autoReady = true)
    }
    assertEquals(OnlineRoomPhase.PICK_3, joinedQuickRoom.phase)
    assertTrue(joinedQuickRoom.bothReady())
    withTimeout(TIMEOUT_MS) { bobRoomRepo.cancelMatchmakingTicket() }
  }

  private companion object {
    const val TIMEOUT_MS = 6000L
    const val FLOW_TIMEOUT_MS = 4000L
  }
}
