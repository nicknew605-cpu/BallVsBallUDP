package com.example

import com.example.engine.ARENA_HEIGHT
import com.example.engine.ARENA_WIDTH
import com.example.engine.ArenaPhase
import com.example.engine.BattlePhysicsEngine
import com.example.model.AiDifficulty
import com.example.model.AppLanguage
import com.example.model.BallRarity
import com.example.model.BallType
import com.example.model.DEFAULT_V103_RAW_APK_URL
import com.example.model.DailyRewardTier
import com.example.model.GameMode
import com.example.model.KillEffectType
import com.example.model.OnlineRoomPhase
import com.example.model.OnlineRoomState
import com.example.model.OtaAppUpdateConfig
import com.example.model.OtaBalanceConfig
import com.example.model.OtaLiveConfig
import com.example.model.TAN_THU_DURATION_MILLIS
import com.example.model.TRIAN_CODE
import com.example.model.TRIAN_CREATED_AT_MILLIS
import com.example.model.TRIAN_EXPIRES_AT_MILLIS
import com.example.model.UserProgress
import com.example.localization.stringsFor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BattlePhysicsAndProgressionTest {

  @Test
  fun localizationStringsLoadCleanly() {
    val vi = stringsFor(AppLanguage.VI)
    val en = stringsFor(AppLanguage.EN)
    assertEquals("Ant Ball", vi.ballName(BallType.ANT))
    assertEquals("Ant Ball", en.ballName(BallType.ANT))
    assertTrue(vi.antUltDesc.isNotBlank())
    assertTrue(en.firePassiveDesc.isNotBlank())
  }

  @Test
  fun rarityClassificationMatchesSpecification() {
    assertEquals(BallRarity.COMMON, BallType.FIRE.rarity)
    assertEquals(BallRarity.COMMON, BallType.WATER.rarity)
    assertEquals(BallRarity.COMMON, BallType.GROUND.rarity)
    assertEquals(BallRarity.UNCOMMON, BallType.THUNDER.rarity)
    assertEquals(BallRarity.UNCOMMON, BallType.ICE.rarity)
    assertEquals(BallRarity.RARE, BallType.ANT.rarity)
  }

  @Test
  fun tanThuCodeUnlocksAll6BallsForExactly24Hours() {
    val start = 1_700_000_000_000L
    val progress = UserProgress(tanThuActivatedAtMillis = start)

    assertTrue(progress.isTanThuActive(start + 1_000L))
    BallType.entries.forEach { ball ->
      assertTrue(progress.isBallAvailable(ball, start + 3_600_000L))
    }
    assertTrue(progress.isKillEffectAvailable(KillEffectType.DISSOLVE, start + 3_600_000L))

    val after24h = start + TAN_THU_DURATION_MILLIS + 1L
    assertFalse(progress.isTanThuActive(after24h))
    assertFalse(progress.isBallAvailable(BallType.THUNDER, after24h))
    assertFalse(progress.isBallAvailable(BallType.ICE, after24h))
    assertFalse(progress.isBallAvailable(BallType.ANT, after24h))
  }

  @Test
  fun dailyLoginRewardsCycleAndClaimability() {
    assertEquals(listOf(120, 220, 350, 500, 750, 1000, 1500), DailyRewardTier.weekSchedule.map { it.coins })

    val day1Ms = 20_500L * 86_400_000L + 1_000L
    val fresh = UserProgress()
    assertTrue(fresh.isDailyClaimable(day1Ms))
    assertEquals(1, fresh.nextDailyRewardTier().day)
    assertEquals(120, fresh.nextDailyRewardTier().coins)

    val afterDay1 = fresh.copy(
      dailyStreak = 1,
      lastDailyClaimEpochDay = UserProgress.currentEpochDay(day1Ms),
    )
    assertFalse(afterDay1.isDailyClaimable(day1Ms + 60_000L))
    assertEquals(2, afterDay1.nextDailyRewardTier().day)
    assertEquals(220, afterDay1.nextDailyRewardTier().coins)

    val day2Ms = day1Ms + 86_400_000L
    assertTrue(afterDay1.isDailyClaimable(day2Ms))
  }

  @Test
  fun triAnGiftcodeDelivers5000CoinsAndExpiresAfterOneWeek() {
    val triAn = OtaLiveConfig.defaultCodes().firstOrNull { it.code == TRIAN_CODE }
    assertNotNull("TriAn must exist in default OTA codes", triAn)
    assertEquals(5000, triAn!!.rewardCoins)
    assertEquals(7L * 24L * 60L * 60L * 1000L, TRIAN_EXPIRES_AT_MILLIS - TRIAN_CREATED_AT_MILLIS)

    assertFalse("TriAn must be active during 7-day window", triAn.isExpired(TRIAN_CREATED_AT_MILLIS + 60_000L))
    assertFalse("TriAn must still be valid right at boundary", triAn.isExpired(TRIAN_EXPIRES_AT_MILLIS))
    assertTrue("TriAn must expire immediately after 1 week", triAn.isExpired(TRIAN_EXPIRES_AT_MILLIS + 1_000L))
  }

  @Test
  fun timedAdminNoticeAndPerBallOtaOverridesWorkCorrectly() {
    val now = 1_750_000_000_000L
    val active = OtaLiveConfig(
      adminNoticeVi = "Su kien dac biet!",
      adminNoticeEn = "Special Event!",
      adminNoticeExpiresAtMillis = now + 60_000L,
      balance = OtaBalanceConfig().withBallOverride(BallType.ANT, hp = 180, damageScale = 1.4f),
    )
    assertEquals("Su kien dac biet!", active.activeAdminNotice(AppLanguage.VI, now))
    assertEquals("Special Event!", active.activeAdminNotice(AppLanguage.EN, now))
    assertEquals("", active.activeAdminNotice(AppLanguage.VI, now + 65_000L))

    assertEquals(180f, active.balance.hpFor(BallType.ANT), 0.01f)
    assertEquals(1.4f, active.balance.damageScaleFor(BallType.ANT), 0.01f)
  }

  @Test
  fun onlineRoomSpeedRewardsScaleCorrectly() {
    val room =
      OnlineRoomState(
        roomCode = "HCT992",
        hostUid = "u1",
        hostName = "Host",
        guestUid = "u2",
        guestName = "Guest",
        phase = OnlineRoomPhase.PLAYING,
        hostPicks = listOf(BallType.FIRE, BallType.WATER, BallType.THUNDER),
        guestPicks = listOf(BallType.GROUND, BallType.ICE, BallType.ANT),
        hostBannedBall = BallType.ICE,
        guestBannedBall = BallType.THUNDER,
        hostFinalBall = BallType.FIRE,
        guestFinalBall = BallType.ANT,
        seed = 42L,
        winnerUid = "",
        matchDurationSec = 0f,
        rewardCoins = 0,
      )
    assertEquals(240, room.computeSpeedRewardCoins(12.4f))
    assertEquals(190, room.computeSpeedRewardCoins(21.0f))
    assertEquals(150, room.computeSpeedRewardCoins(35.0f))
    assertEquals(120, room.computeSpeedRewardCoins(58.0f))
  }

  @Test
  fun fireRealmOfFireAndWaterSkillsTriggerProperly() {
    val engine =
      BattlePhysicsEngine(
        mode = GameMode.ONE_VS_ONE,
        p1BallType = BallType.FIRE,
        p2BallType = BallType.WATER,
        aiDifficulty = AiDifficulty.NORMAL,
        speedMultiplier = 1.0f,
        hitStopEnabled = false,
        seed = 101L,
        onSound = {},
      )

    var snap = engine.snapshot()
    assertEquals(125f, snap.p1.hp, 0.01f)
    assertEquals(130f, snap.p2.hp, 0.01f)
    assertEquals(ArenaPhase.AIMING_P1, snap.phase)

    engine.setAimAngle(1, -2.4f)
    engine.confirmCurrentAim()
    engine.setAimAngle(2, 0.6f)
    engine.confirmCurrentAim()

    var sawRealmOfFire = false
    var sawChips = false
    var sawLasers = false
    var sawAquaOrb = false

    repeat(460) {
      engine.stepFrame(0.016f, 0xFFFF5722) {}
      snap = engine.snapshot()
      if (snap.fireRealmTimer > 0f) sawRealmOfFire = true
      if (snap.chips.isNotEmpty()) sawChips = true
      if (snap.lasers.isNotEmpty()) sawLasers = true
      if (snap.aquaOrbs.isNotEmpty()) sawAquaOrb = true
      assertTrue(snap.p1.x in 0f..ARENA_WIDTH)
      assertTrue(snap.p1.y in 0f..ARENA_HEIGHT)
    }

    assertTrue("Fire passive Realm of Fire should ignite arena walls within 5s", sawRealmOfFire)
    assertTrue("Fire should plant Ignition chips", sawChips)
    assertTrue("Fire should fire laser web on distinct wall hit", sawLasers)
    assertTrue("Water should spawn Aqua Orb", sawAquaOrb)
  }

  @Test
  fun thunderCrashFixAndMapWideClonesWithSafeDeathbolt() {
    val engine =
      BattlePhysicsEngine(
        mode = GameMode.ONE_VS_AI,
        p1BallType = BallType.THUNDER,
        p2BallType = BallType.ICE,
        aiDifficulty = AiDifficulty.NORMAL,
        speedMultiplier = 1.0f,
        hitStopEnabled = false,
        seed = 2026L,
        otaBalance = OtaBalanceConfig(),
        onSound = {},
      )

    engine.setAimAngle(1, -1.2f)
    engine.confirmCurrentAim()

    var maxClones = 0
    var wideSpread = false
    var sawBolt = false
    var sawIceShards = false
    var sawEmojiInPopups = false

    repeat(1000) {
      engine.stepFrame(0.016f, 0xFFFFEA00) {}
      val snap = engine.snapshot()
      if (snap.afterimages.size > maxClones) maxClones = snap.afterimages.size
      if (snap.afterimages.size >= 40) {
        val minX = snap.afterimages.minOf { it.x }
        val maxX = snap.afterimages.maxOf { it.x }
        if (maxX - minX > 450f) wideSpread = true
      }
      if (snap.lightningBolts.isNotEmpty()) sawBolt = true
      if (snap.iceShards.isNotEmpty()) sawIceShards = true
      if (snap.floatingDamages.any { it.text.contains("⚡") }) sawEmojiInPopups = true
    }

    assertTrue("Thunder Sonic Dash should spawn 80-100 clones without crashing", maxClones >= 70)
    assertTrue("Thunder clones should scatter across entire arena", wideSpread)
    assertTrue("Ice passive should summon and fire shards", sawIceShards)
    assertFalse("Damage popups must never contain unsafe emoji glyphs", sawEmojiInPopups)
    assertTrue("Thunder match ran cleanly", sawBolt || engine.snapshot().phase != ArenaPhase.AIMING_P1)
  }

  @Test
  fun groundBallNerfedSpecsFissuresAndEarthArmorTriggerCleanly() {
    val balance = OtaBalanceConfig()
    assertEquals(5.0f, balance.groundSkill1CooldownSec, 0.01f)
    assertEquals(12.0f, balance.groundSkill1Damage, 0.01f)
    assertEquals(18.0f, balance.groundArmorCooldownSec, 0.01f)
    assertEquals(0.10f, balance.groundChargeReduction, 0.001f)
    assertEquals(0.30f, balance.groundArmorAllReduction, 0.001f)

    val engine =
      BattlePhysicsEngine(
        mode = GameMode.ONE_VS_AI,
        p1BallType = BallType.GROUND,
        p2BallType = BallType.FIRE,
        aiDifficulty = AiDifficulty.NORMAL,
        speedMultiplier = 1.0f,
        hitStopEnabled = false,
        seed = 777L,
        otaBalance = balance,
        onSound = {},
      )

    engine.setAimAngle(1, -1.0f)
    engine.confirmCurrentAim()

    var sawCharging = false
    var sawFissures = false
    var sawEarthArmor = false
    var sawDamage = false

    repeat(700) {
      engine.stepFrame(0.016f, 0xFFD48C3B) {}
      val snap = engine.snapshot()
      if (snap.p1.seismicChargingTimer > 0f) sawCharging = true
      if (snap.quakeFissureTimer > 0f) sawFissures = true
      if (snap.p1.earthArmorTimer > 0f) sawEarthArmor = true
      if (snap.p1.totalDamageDealt >= 10f) sawDamage = true
    }

    assertTrue("Ground Ball should enter Seismic Charge state", sawCharging)
    assertTrue("Ground Ball should trigger 2D seismic fissures", sawFissures)
    assertTrue("Ground Ball should activate 5s Earth Armor", sawEarthArmor)
    assertTrue("Ground Ball should deal quake or combat damage", sawDamage)
  }

  @Test
  fun antBallRarePassivesRegenSwarmAndOtaStatScalingWorkCleanly() {
    val customBalance = OtaBalanceConfig()
      .withBallOverride(BallType.ANT, hp = 155, damageScale = 1.3f)

    val engine =
      BattlePhysicsEngine(
        mode = GameMode.ONE_VS_AI,
        p1BallType = BallType.ANT,
        p2BallType = BallType.WATER,
        aiDifficulty = AiDifficulty.NORMAL,
        speedMultiplier = 1.0f,
        hitStopEnabled = false,
        seed = 909L,
        otaBalance = customBalance,
        onSound = {},
      )

    assertEquals(155f, engine.snapshot().p1.maxHp, 0.01f)
    engine.setAimAngle(1, -1.3f)
    engine.confirmCurrentAim()

    var sawSoldierAnts = false
    var sawCompanionAntBall = false

    // Step ~18s (1150 frames * 0.016s = 18.4s) to cover both 8s swarm and 15s Ant Cell Regeneration
    repeat(1150) {
      engine.stepFrame(0.016f, 0xFFE63946) {}
      val snap = engine.snapshot()
      if (snap.soldierAnts.isNotEmpty()) sawSoldierAnts = true
      if (snap.companionAnts.isNotEmpty() || snap.p1.antRegensUsed > 0) sawCompanionAntBall = true
    }

    assertTrue("Ant Ball Skill 1 should spawn Soldier Ants", sawSoldierAnts)
    assertTrue("Ant Ball passive should summon 100% HP complete Ant Ball clones", sawCompanionAntBall || engine.snapshot().side1Balls.size >= 2)
  }

  @Test
  fun antBallTrueMultiBallClonesCapAtThreeAndRequireAllKilledForKo() {
    val balance =
      OtaBalanceConfig()
        .withBallOverride(BallType.ANT, hp = 300, damageScale = 1.0f)
        .withBallOverride(BallType.WATER, hp = 350, damageScale = 0.25f)

    val engine =
      BattlePhysicsEngine(
        mode = GameMode.ONE_VS_ONE,
        p1BallType = BallType.ANT,
        p2BallType = BallType.WATER,
        aiDifficulty = AiDifficulty.NORMAL,
        speedMultiplier = 1.0f,
        hitStopEnabled = false,
        seed = 4242L,
        otaBalance = balance,
        onSound = {},
      )

    engine.setAimAngle(1, -1.5f)
    engine.confirmCurrentAim()
    engine.setAimAngle(2, 1.5f)
    engine.confirmCurrentAim()

    // Step ~33.6s (2100 frames * 0.016s) -> Ant passive triggers at 16s and 32s -> max 3 complete Ant Balls
    var maxAntBalls = 1
    var clone2FullHp = false
    var clone3FullHp = false
    repeat(2100) {
      engine.stepFrame(0.016f, 0xFF00E676) {}
      val snap = engine.snapshot()
      if (snap.side1Balls.size > maxAntBalls) {
        maxAntBalls = snap.side1Balls.size
      }
      if (snap.side1Balls.size >= 2 && snap.side1Balls[1].maxHp == 300f) clone2FullHp = true
      if (snap.side1Balls.size >= 3 && snap.side1Balls[2].maxHp == 300f) clone3FullHp = true
    }

    val snap = engine.snapshot()
    assertTrue("Ant passive must spawn up to 3 complete Ant Balls (saw $maxAntBalls)", maxAntBalls in 2..3)
    assertEquals("Ant passive must never exceed 3 total Ant Balls", 3, snap.side1AntTotalSpawned.coerceAtMost(3))
    assertTrue("Clone #2 must spawn with 100% original maxHp (300f)", clone2FullHp)
    if (maxAntBalls == 3) {
      assertTrue("Clone #3 must spawn with 100% original maxHp (300f)", clone3FullHp)
    }
    assertTrue("Soldier ants must retain crisp bigger radius >= 18.5f", snap.soldierAnts.all { it.baseRadius >= 18.5f })
  }

  @Test
  fun deterministicOnlineLaunchProducesIdenticalStateOnHostAndGuest() {
    val hostEngine =
      BattlePhysicsEngine(
        mode = GameMode.ONLINE_1VS1,
        p1BallType = BallType.FIRE,
        p2BallType = BallType.ANT,
        aiDifficulty = AiDifficulty.NORMAL,
        speedMultiplier = 1.0f,
        hitStopEnabled = true,
        seed = 987654321L,
        localPlayerSide = 1,
        onSound = {},
      )
    val guestEngine =
      BattlePhysicsEngine(
        mode = GameMode.ONLINE_1VS1,
        p1BallType = BallType.FIRE,
        p2BallType = BallType.ANT,
        aiDifficulty = AiDifficulty.NORMAL,
        speedMultiplier = 1.0f,
        hitStopEnabled = true,
        seed = 987654321L,
        localPlayerSide = 2,
        onSound = {},
      )

    hostEngine.launchOnlineBalls(p1AngleRad = -1.12f, p2AngleRad = 2.04f)
    guestEngine.launchOnlineBalls(p1AngleRad = -1.12f, p2AngleRad = 2.04f)

    repeat(300) {
      hostEngine.stepFrame(0.016f, 0xFFFF5722) {}
      guestEngine.stepFrame(0.016f, 0xFFFF5722) {}
    }

    val h = hostEngine.snapshot()
    val g = guestEngine.snapshot()
    assertEquals(h.p1.x, g.p1.x, 0.0001f)
    assertEquals(h.p1.y, g.p1.y, 0.0001f)
    assertEquals(h.p1.hp, g.p1.hp, 0.0001f)
    assertEquals(h.p2.x, g.p2.x, 0.0001f)
    assertEquals(h.p2.y, g.p2.y, 0.0001f)
    assertEquals(h.p2.hp, g.p2.hp, 0.0001f)
  }

  @Test
  fun customMinuteHourBallTrialProgressAndDirectApkUrlDetectionWork() {
    val now = 1_800_000_000_000L
    val progress =
      UserProgress(
        ballTrials = mapOf(BallType.ANT.id to (now + 45L * 60_000L)),
      )
    assertTrue(progress.isBallAvailable(BallType.ANT, now + 10_000L))
    assertFalse(progress.isBallPermanentlyOwned(BallType.ANT))
    assertEquals(45L * 60_000L - 10_000L, progress.ballTrialRemainingMillis(BallType.ANT, now + 10_000L))
    assertFalse(progress.isBallAvailable(BallType.ANT, now + 46L * 60_000L))

    assertTrue(OtaAppUpdateConfig.isDirectApkUrl("https://github.com/hct/bvb/releases/download/v1.0.2/app.apk"))
    assertFalse(OtaAppUpdateConfig.isDirectApkUrl("https://betadrop.app/i/VP5zbq"))
    assertEquals(
      "nicknew605/ball-vs-ball",
      com.example.util.AppUpdateManager.normalizeGithubRepoInput(
        "https://github.com/nicknew605/ball-vs-ball/blob/main/BallVsBall_v1.0.2-max.apk"
      ),
    )
    assertTrue(
      OtaAppUpdateConfig(
        latestVersionCode = 7,
        downloadUrl = "https://betadrop.app/i/VP5zbq",
      ).isUpdateAvailable(currentVersionCode = 6)
    )
  }

  @Test
  fun appUpdateConfigDetectsNewVersionsAndEnforcesHttpsOnly() {
    val safeUpdate =
      OtaAppUpdateConfig(
        latestVersionCode = 6,
        latestVersionName = "1.0.3",
        minSupportedVersionCode = 6,
        downloadUrl = "https://github.com/hct/ballvsball/releases/download/v1.0.3/app.apk",
        releaseNotesVi = "Them bong moi!",
      )
    assertTrue(safeUpdate.isUpdateAvailable(currentVersionCode = 5))
    assertTrue(safeUpdate.isMandatory(currentVersionCode = 5))
    assertFalse(safeUpdate.isUpdateAvailable(currentVersionCode = 6))

    val insecureUpdate = safeUpdate.copy(downloadUrl = "http://insecure.example.com/app.apk")
    assertFalse("Only https:// release links must be accepted", insecureUpdate.isUpdateAvailable(currentVersionCode = 5))
  }

  @Test
  fun iceKyBangHaFreezes10sDrainsRageApplies40PctSlowWhileIceStaysFree() {
    val defaultBalance = OtaBalanceConfig()
    assertEquals(6, defaultBalance.iceShardDamage)
    assertEquals(0.68f, defaultBalance.iceShardSpawnIntervalSec, 0.001f)
    assertEquals(10.0f, defaultBalance.iceFreezeDurationSec, 0.01f)
    assertEquals(0.70f, defaultBalance.iceFreezeRageDrainPct, 0.001f)
    assertEquals(0.40f, defaultBalance.icePostFreezeSlowPct, 0.001f)

    val testBalance =
      defaultBalance
        .withBallOverride(BallType.ICE, hp = 320, damageScale = 1.0f)
        .withBallOverride(BallType.FIRE, hp = 420, damageScale = 0.4f)

    val engine =
      BattlePhysicsEngine(
        mode = GameMode.ONE_VS_ONE,
        p1BallType = BallType.ICE,
        p2BallType = BallType.FIRE,
        aiDifficulty = AiDifficulty.NORMAL,
        speedMultiplier = 1.0f,
        hitStopEnabled = false,
        seed = 2027L,
        otaBalance = testBalance,
        onSound = {},
      )

    engine.setAimAngle(1, -1.1f)
    engine.confirmCurrentAim()
    engine.setAimAngle(2, 1.3f)
    engine.confirmCurrentAim()

    var sawArenaFreeze10s = false
    var iceMovedWhileEnemyFrozen = false
    var sawPostFreezeSlow = false
    var prevIceX = engine.snapshot().p1.x
    var prevIceY = engine.snapshot().p1.y

    // Step 42s (2625 * 0.016s) to allow Ice ult to trigger at >=20s and thaw after 10s
    repeat(2625) {
      engine.stepFrame(0.016f, 0xFF80D8FF) {}
      val snap = engine.snapshot()
      if (snap.arenaFreezeTimer >= 8.5f && snap.p2.frozenTimer >= 8.5f) {
        sawArenaFreeze10s = true
      }
      if (snap.p2.frozenTimer > 1.0f) {
        val movedDist = kotlin.math.hypot(snap.p1.x - prevIceX, snap.p1.y - prevIceY)
        if (movedDist > 1.0f) iceMovedWhileEnemyFrozen = true
      }
      if (snap.p2.postFreezeSlowTimer > 0.2f && snap.p2.effectiveSlowFactor() <= 0.61f) {
        sawPostFreezeSlow = true
      }
      prevIceX = snap.p1.x
      prevIceY = snap.p1.y
    }

    assertTrue("Ice Ky Bang Ha must freeze arena and enemy for 10s", sawArenaFreeze10s)
    assertTrue("Ice Ball must keep moving freely while enemy is frozen", iceMovedWhileEnemyFrozen)
    assertTrue("Enemy must suffer 40% post-freeze slow after thawing", sawPostFreezeSlow)
  }

  @Test
  fun sixBallParityAndGithubBlobToRawNormalizationWork() {
    val bal = OtaBalanceConfig()
    assertEquals(125f, bal.hpFor(BallType.FIRE), 0.01f)
    assertEquals(1.05f, bal.damageScaleFor(BallType.FIRE), 0.01f)
    assertEquals(130f, bal.hpFor(BallType.WATER), 0.01f)
    assertEquals(145f, bal.hpFor(BallType.GROUND), 0.01f)
    assertEquals(115f, bal.hpFor(BallType.THUNDER), 0.01f)
    assertEquals(1.05f, bal.damageScaleFor(BallType.THUNDER), 0.01f)
    assertEquals(120f, bal.hpFor(BallType.ICE), 0.01f)
    assertEquals(120f, bal.hpFor(BallType.ANT), 0.01f)

    val normalized =
      OtaAppUpdateConfig.normalizeDownloadUrl(
        "https://github.com/nicknew605-cpu/BallVsBallUDP/blob/main/BallVsBall_v1.0.2-max.apk"
      )
    assertEquals(
      "https://github.com/nicknew605-cpu/BallVsBallUDP/raw/main/BallVsBall_v1.0.2-max.apk",
      normalized,
    )
    assertTrue(OtaAppUpdateConfig.isDirectApkUrl(normalized))

    val defaultUpdate = OtaAppUpdateConfig()
    assertEquals(DEFAULT_V103_RAW_APK_URL, defaultUpdate.normalizedUrl())
    assertTrue(defaultUpdate.isDirectApkUrl())
    assertTrue(defaultUpdate.isUpdateAvailable(currentVersionCode = 6))
  }
}
