package com.example.util

import android.content.Context

class AdminLocalPrefs(context: Context) {
  private val prefs =
    context.applicationContext.getSharedPreferences("bvb_admin_local_prefs", Context.MODE_PRIVATE)

  fun loadGithubRepo(): String =
    prefs.getString(KEY_GITHUB_REPO, null)?.takeIf {
      it.isNotBlank() && !it.startsWith("blob/", ignoreCase = true) && !it.startsWith("raw/", ignoreCase = true)
    } ?: com.example.model.DEFAULT_GITHUB_REPO

  fun loadGithubToken(): String = prefs.getString(KEY_GITHUB_TOKEN, "").orEmpty()

  fun saveGithubCredentials(repo: String, token: String) {
    prefs.edit()
      .putString(KEY_GITHUB_REPO, repo.trim())
      .putString(KEY_GITHUB_TOKEN, token.trim())
      .apply()
  }

  private companion object {
    const val KEY_GITHUB_REPO = "gh_repo"
    const val KEY_GITHUB_TOKEN = "gh_pat"
  }
}
