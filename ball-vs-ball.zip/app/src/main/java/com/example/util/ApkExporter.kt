package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.BuildConfig
import java.io.File
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ApkInfo(
  val fileName: String,
  val sizeBytes: Long,
  val sourcePath: String,
) {
  val sizeMbFormatted: String
    get() = String.format(java.util.Locale.US, "%.2f MB", sizeBytes / (1024.0 * 1024.0))
}

object ApkExporter {
  private const val EXPORT_FILE_NAME = "BallVsBall_v${BuildConfig.VERSION_NAME}.apk"
  const val APK_MIME_TYPE = "application/vnd.android.package-archive"

  fun defaultFileName(): String = EXPORT_FILE_NAME

  fun inspectInstalledApk(context: Context): ApkInfo? {
    val sourcePath = context.applicationInfo?.sourceDir ?: return null
    val sourceFile = File(sourcePath)
    if (!sourceFile.exists() || !sourceFile.canRead()) return null
    return ApkInfo(
      fileName = EXPORT_FILE_NAME,
      sizeBytes = sourceFile.length(),
      sourcePath = sourcePath,
    )
  }

  suspend fun exportApkToUri(context: Context, destinationUri: Uri): Result<Long> =
    withContext(Dispatchers.IO) {
      runCatching {
        val sourcePath =
          context.applicationInfo?.sourceDir
            ?: throw IOException("Installed APK source path unavailable")
        val sourceFile = File(sourcePath)
        if (!sourceFile.exists() || !sourceFile.canRead()) {
          throw IOException("Cannot read installed APK package")
        }
        val out =
          context.contentResolver.openOutputStream(destinationUri)
            ?: throw IOException("Unable to open destination file stream")
        var copiedBytes = 0L
        out.use { output ->
          sourceFile.inputStream().use { input ->
            copiedBytes = input.copyTo(output, bufferSize = 64 * 1024)
            output.flush()
          }
        }
        copiedBytes
      }
    }

  suspend fun prepareShareIntent(context: Context, chooserTitle: String): Result<Intent> =
    withContext(Dispatchers.IO) {
      runCatching {
        val sourcePath =
          context.applicationInfo?.sourceDir
            ?: throw IOException("Installed APK source path unavailable")
        val sourceFile = File(sourcePath)
        if (!sourceFile.exists() || !sourceFile.canRead()) {
          throw IOException("Cannot read installed APK package")
        }

        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val stagedFile = File(exportDir, EXPORT_FILE_NAME)
        sourceFile.inputStream().use { input ->
          stagedFile.outputStream().use { output ->
            input.copyTo(output, bufferSize = 64 * 1024)
            output.flush()
          }
        }

        val contentUri =
          FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            stagedFile,
          )

        val shareIntent =
          Intent(Intent.ACTION_SEND).apply {
            type = APK_MIME_TYPE
            putExtra(Intent.EXTRA_STREAM, contentUri)
            putExtra(Intent.EXTRA_SUBJECT, EXPORT_FILE_NAME)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
          }
        Intent.createChooser(shareIntent, chooserTitle)
      }
    }
}
