package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.core.content.FileProvider
import com.example.model.ApkPackageInfo
import com.example.model.ApkUpdateState
import com.example.model.GitHubUploadState
import com.example.model.OtaAppUpdateConfig
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object AppUpdateManager {
  private const val APK_MIME = "application/vnd.android.package-archive"

  fun canInstallPackages(context: Context): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context.packageManager.canRequestPackageInstalls()

  fun openInstallPermissionSettings(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val intent =
        Intent(
          Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
          Uri.parse("package:${context.packageName}"),
        ).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(intent)
    }
  }

  fun launchApkInstaller(context: Context, apkPath: String): Boolean =
    runCatching {
      val file = File(apkPath)
      if (!file.exists() || file.length() <= 0L) return@runCatching false
      val contentUri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
      val intent =
        Intent(Intent.ACTION_VIEW).apply {
          setDataAndType(contentUri, APK_MIME)
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
      context.startActivity(intent)
      true
    }.getOrDefault(false)

  fun openWebDownloadUrl(context: Context, url: String): Boolean =
    runCatching {
      val intent =
        Intent(Intent.ACTION_VIEW, Uri.parse(url.trim())).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(intent)
      true
    }.getOrDefault(false)

  suspend fun inspectApkUri(context: Context, uri: Uri): Result<ApkPackageInfo> =
    withContext(Dispatchers.IO) {
      runCatching {
        val displayName = resolveDisplayName(context, uri) ?: "BallVsBall-update.apk"
        val stagingDir = File(context.cacheDir, "admin_upload").apply { mkdirs() }
        stagingDir.listFiles()?.forEach { old -> old.delete() }
        val safeName =
          displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").let {
            if (it.endsWith(".apk", ignoreCase = true)) it else "$it.apk"
          }
        val stagedFile = File(stagingDir, safeName)
        context.contentResolver.openInputStream(uri)?.use { input ->
          stagedFile.outputStream().use { out ->
            input.copyTo(out, bufferSize = 64 * 1024)
            out.flush()
          }
        } ?: throw IOException("Cannot read selected APK file")

        if (stagedFile.length() < 64_000L) {
          throw IOException("Selected file is not a valid APK package")
        }

        val pkgInfo =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.getPackageArchiveInfo(
              stagedFile.absolutePath,
              PackageManager.PackageInfoFlags.of(0L),
            )
          } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageArchiveInfo(stagedFile.absolutePath, 0)
          }

        val vCode =
          if (pkgInfo != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
              pkgInfo.longVersionCode.toInt()
            } else {
              @Suppress("DEPRECATION")
              pkgInfo.versionCode
            }
          } else {
            0
          }
        val vName = pkgInfo?.versionName?.takeIf { it.isNotBlank() } ?: ""
        val pkgName = pkgInfo?.packageName?.takeIf { it.isNotBlank() } ?: context.packageName

        ApkPackageInfo(
          fileName = safeName,
          packageName = pkgName,
          versionCode = vCode,
          versionName = vName,
          sizeBytes = stagedFile.length(),
          uriString = stagedFile.absolutePath,
        )
      }
    }

  suspend fun uploadApkToGitHubRelease(
    repoInput: String,
    tokenInput: String,
    apkInfo: ApkPackageInfo,
    versionCode: Int,
    versionName: String,
    releaseNotes: String,
    onProgress: (GitHubUploadState) -> Unit,
  ): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val (owner, repo) = parseGithubRepo(repoInput)
        val token = tokenInput.trim()
        require(token.isNotBlank()) { "GitHub Token is required" }

        val apkFile = File(apkInfo.uriString)
        if (!apkFile.exists() || apkFile.length() <= 0L) {
          throw IOException("Staged APK file not found — pick the APK again")
        }

        val cleanVer = versionName.trim().ifBlank { "v$versionCode" }.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val tagName = "v${cleanVer}-b${versionCode}"

        onProgress(GitHubUploadState.Uploading(8, "Creating GitHub Release $tagName..."))

        val releaseJson = createOrFetchRelease(owner, repo, token, tagName, versionName, releaseNotes)
        val rawUploadUrl = releaseJson.optString("upload_url").substringBefore("{")
        if (rawUploadUrl.isBlank()) {
          throw IOException("GitHub Release missing upload_url")
        }

        val assetName = URLEncoder.encode("BallVsBall_${cleanVer}_b${versionCode}.apk", "UTF-8")
        val uploadEndpoint = "$rawUploadUrl?name=$assetName"

        val existingAssets = releaseJson.optJSONArray("assets")
        if (existingAssets != null) {
          for (i in 0 until existingAssets.length()) {
            val asset = existingAssets.optJSONObject(i) ?: continue
            if (asset.optString("name") == "BallVsBall_${cleanVer}_b${versionCode}.apk") {
              val assetId = asset.optLong("id", -1L)
              if (assetId > 0L) {
                deleteReleaseAsset(owner, repo, token, assetId)
              }
            }
          }
        }

        onProgress(GitHubUploadState.Uploading(18, "Uploading APK (${String.format(java.util.Locale.US, "%.1f", apkInfo.sizeMb)} MB)..."))

        val conn = (URL(uploadEndpoint).openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          doOutput = true
          connectTimeout = 20_000
          readTimeout = 120_000
          setRequestProperty("Authorization", "Bearer $token")
          setRequestProperty("Accept", "application/vnd.github+json")
          setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
          setRequestProperty("Content-Type", APK_MIME)
          setFixedLengthStreamingMode(apkFile.length())
        }

        try {
          val total = apkFile.length().coerceAtLeast(1L)
          var sent = 0L
          var lastReportedPct = 18
          val buf = ByteArray(64 * 1024)
          conn.outputStream.use { out ->
            apkFile.inputStream().use { input ->
              while (true) {
                val read = input.read(buf)
                if (read <= 0) break
                out.write(buf, 0, read)
                sent += read
                val pct = (18 + ((sent * 78) / total).toInt()).coerceIn(18, 96)
                if (pct - lastReportedPct >= 3) {
                  lastReportedPct = pct
                  onProgress(GitHubUploadState.Uploading(pct, "Uploading APK... $pct%"))
                }
              }
              out.flush()
            }
          }

          val code = conn.responseCode
          val respText =
            (if (code in 200..299) conn.inputStream else conn.errorStream)
              ?.bufferedReader()
              ?.use { it.readText() }
              .orEmpty()
          if (code !in 200..299) {
            throw IOException("GitHub asset upload failed ($code): ${respText.take(220)}")
          }
          val respJson = JSONObject(respText)
          val downloadUrl = respJson.optString("browser_download_url")
          if (!OtaAppUpdateConfig.isSafeHttpsUrl(downloadUrl)) {
            throw IOException("GitHub response did not include a valid HTTPS download URL")
          }
          onProgress(GitHubUploadState.Success(downloadUrl = downloadUrl, tagName = tagName))
          downloadUrl
        } finally {
          conn.disconnect()
        }
      }
    }

  suspend fun downloadOrOpenUpdate(
    context: Context,
    rawUrl: String,
    versionCode: Int,
    onState: (ApkUpdateState) -> Unit,
  ) {
    val cleanUrl = OtaAppUpdateConfig.normalizeDownloadUrl(rawUrl)
    if (!OtaAppUpdateConfig.isSafeHttpsUrl(cleanUrl)) {
      onState(ApkUpdateState.Failed("Invalid HTTPS update link"))
      return
    }

    withContext(Dispatchers.IO) {
      try {
        onState(ApkUpdateState.Downloading(progressPct = 0, downloadedBytes = 0L, totalBytes = 0L))
        var targetUrl = cleanUrl
        var openedConn = openRedirectedConnection(targetUrl)

        // Support Betadrop or landing pages: inspect headers & extract embedded direct .apk href if HTML
        val contentType = openedConn.contentType?.lowercase().orEmpty()
        val finalUrlStr = openedConn.url.toString()
        val looksLikeBinaryApk =
          OtaAppUpdateConfig.isDirectApkUrl(finalUrlStr) ||
            contentType.contains("android.package-archive") ||
            (contentType.contains("octet-stream") && openedConn.contentLengthLong > 500_000L)

        if (!looksLikeBinaryApk && (contentType.contains("text/html") || !OtaAppUpdateConfig.isDirectApkUrl(targetUrl))) {
          val htmlPreview =
            runCatching {
              openedConn.inputStream.bufferedReader().use { reader ->
                val chars = CharArray(128 * 1024)
                val count = reader.read(chars)
                if (count > 0) String(chars, 0, count) else ""
              }
            }.getOrDefault("")
          openedConn.disconnect()

          val extractedApk = extractDirectApkUrlFromHtml(htmlPreview, openedConn.url)
          if (extractedApk != null) {
            targetUrl = extractedApk
            openedConn = openRedirectedConnection(targetUrl)
          } else {
            onState(ApkUpdateState.OpeningWeb(cleanUrl))
            withContext(Dispatchers.Main) {
              openWebDownloadUrl(context, cleanUrl)
            }
            return@withContext
          }
        }

        val updatesDir = File(context.cacheDir, "updates").apply { mkdirs() }
        updatesDir.listFiles()?.forEach { old -> if (old.name.endsWith(".apk")) old.delete() }
        val destFile = File(updatesDir, "BallVsBall_update_${versionCode}.apk")

        val totalBytes = openedConn.contentLengthLong.coerceAtLeast(0L)
        var downloaded = 0L
        var lastPct = -1
        val buf = ByteArray(64 * 1024)
        openedConn.inputStream.use { input ->
          destFile.outputStream().use { out ->
            while (true) {
              val read = input.read(buf)
              if (read <= 0) break
              out.write(buf, 0, read)
              downloaded += read
              val pct =
                if (totalBytes > 0L) ((downloaded * 100L) / totalBytes).toInt().coerceIn(0, 99)
                else 50
              if (pct != lastPct) {
                lastPct = pct
                onState(ApkUpdateState.Downloading(pct, downloaded, totalBytes))
              }
            }
            out.flush()
          }
        }
        openedConn.disconnect()

        if (destFile.length() < 100_000L) {
          destFile.delete()
          onState(ApkUpdateState.OpeningWeb(cleanUrl))
          withContext(Dispatchers.Main) {
            openWebDownloadUrl(context, cleanUrl)
          }
          return@withContext
        }

        if (!canInstallPackages(context)) {
          onState(ApkUpdateState.NeedsInstallPermission(destFile.absolutePath))
        } else {
          onState(ApkUpdateState.ReadyToInstall(destFile.absolutePath))
          withContext(Dispatchers.Main) {
            launchApkInstaller(context, destFile.absolutePath)
          }
        }
      } catch (e: Exception) {
        onState(ApkUpdateState.Failed(e.localizedMessage ?: "Download failed"))
      }
    }
  }

  fun normalizeGithubRepoInput(raw: String): String {
    val cleaned =
      raw.trim()
        .removePrefix("https://github.com/")
        .removePrefix("http://github.com/")
        .removePrefix("https://www.github.com/")
        .removePrefix("http://www.github.com/")
        .removePrefix("github.com/")
        .removePrefix("www.github.com/")
        .removeSuffix(".git")
        .trim('/')
    val parts = cleaned.split("/").filter { it.isNotBlank() }
    if (parts.isNotEmpty() && parts[0].lowercase() in setOf("blob", "raw", "tree", "releases")) {
      return com.example.model.DEFAULT_GITHUB_REPO
    }
    return if (parts.size >= 2) "${parts[0]}/${parts[1]}" else cleaned
  }

  private fun parseGithubRepo(raw: String): Pair<String, String> {
    val normalized = normalizeGithubRepoInput(raw)
    val parts = normalized.split("/").filter { it.isNotBlank() }
    require(parts.size >= 2) { "GitHub Repo must be in owner/repo format (vd: tenban/ball-vs-ball)" }
    return parts[0] to parts[1]
  }

  private fun createOrFetchRelease(
    owner: String,
    repo: String,
    token: String,
    tagName: String,
    versionName: String,
    notes: String,
  ): JSONObject {
    val endpoint = "https://api.github.com/repos/$owner/$repo/releases"
    val bodyJson =
      JSONObject()
        .put("tag_name", tagName)
        .put("name", "Ball vs Ball ${versionName.ifBlank { tagName }}")
        .put("body", notes.ifBlank { "Ball vs Ball OTA APK Release $tagName" })
        .put("draft", false)
        .put("prerelease", false)
        .toString()

    val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
      requestMethod = "POST"
      doOutput = true
      connectTimeout = 15_000
      readTimeout = 20_000
      setRequestProperty("Authorization", "Bearer $token")
      setRequestProperty("Accept", "application/vnd.github+json")
      setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
      setRequestProperty("Content-Type", "application/json; charset=utf-8")
    }
    return try {
      conn.outputStream.use { it.write(bodyJson.toByteArray(Charsets.UTF_8)) }
      val code = conn.responseCode
      val text =
        (if (code in 200..299) conn.inputStream else conn.errorStream)
          ?.bufferedReader()
          ?.use { it.readText() }
          .orEmpty()
      if (code in 200..299) {
        JSONObject(text)
      } else if (code == 422 && text.contains("already_exists", ignoreCase = true)) {
        fetchReleaseByTag(owner, repo, token, tagName)
      } else if (code == 401 || code == 403) {
        throw IOException("GitHub Token ($code): Thiếu quyền Contents/Releases write cho $owner/$repo")
      } else if (code == 404) {
        throw IOException("GitHub 404: Không tìm thấy repo $owner/$repo hoặc Token chưa có quyền truy cập repo này")
      } else {
        throw IOException("GitHub Release API ($code): ${text.take(220)}")
      }
    } finally {
      conn.disconnect()
    }
  }

  private fun fetchReleaseByTag(
    owner: String,
    repo: String,
    token: String,
    tagName: String,
  ): JSONObject {
    val conn =
      (URL("https://api.github.com/repos/$owner/$repo/releases/tags/$tagName").openConnection() as HttpURLConnection)
        .apply {
          requestMethod = "GET"
          connectTimeout = 15_000
          readTimeout = 15_000
          setRequestProperty("Authorization", "Bearer $token")
          setRequestProperty("Accept", "application/vnd.github+json")
          setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        }
    return try {
      val code = conn.responseCode
      val text =
        (if (code in 200..299) conn.inputStream else conn.errorStream)
          ?.bufferedReader()
          ?.use { it.readText() }
          .orEmpty()
      if (code !in 200..299) {
        throw IOException("GitHub Tag lookup ($code): ${text.take(200)}")
      }
      JSONObject(text)
    } finally {
      conn.disconnect()
    }
  }

  private fun deleteReleaseAsset(owner: String, repo: String, token: String, assetId: Long) {
    runCatching {
      val conn =
        (URL("https://api.github.com/repos/$owner/$repo/releases/assets/$assetId").openConnection() as HttpURLConnection)
          .apply {
            requestMethod = "DELETE"
            connectTimeout = 10_000
            readTimeout = 10_000
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/vnd.github+json")
          }
      conn.responseCode
      conn.disconnect()
    }
  }

  private fun openRedirectedConnection(startUrl: String): HttpURLConnection {
    var current = URL(startUrl)
    repeat(6) {
      val conn = (current.openConnection() as HttpURLConnection).apply {
        instanceFollowRedirects = false
        connectTimeout = 15_000
        readTimeout = 60_000
        setRequestProperty("User-Agent", "BallVsBall-Updater/1.0")
        setRequestProperty("Accept", "*/*")
      }
      val code = conn.responseCode
      if (code in 300..399) {
        val loc = conn.getHeaderField("Location").orEmpty()
        conn.disconnect()
        if (loc.isBlank()) throw IOException("Redirect without location")
        current = URL(current, loc)
      } else if (code in 200..299) {
        return conn
      } else {
        conn.disconnect()
        throw IOException("HTTP $code")
      }
    }
    throw IOException("Too many redirects")
  }

  private fun extractDirectApkUrlFromHtml(html: String, baseUrl: URL): String? {
    if (html.isBlank()) return null
    val absMatch = Regex("""["'](https://[^"'\s]+\.apk(?:\?[^"'\s]*)?)["']""", RegexOption.IGNORE_CASE).find(html)
    if (absMatch != null) return absMatch.groupValues[1]

    val relMatch = Regex("""href=["'](/[^"'\s]+\.apk(?:\?[^"'\s]*)?)["']""", RegexOption.IGNORE_CASE).find(html)
    if (relMatch != null) {
      return runCatching { URL(baseUrl, relMatch.groupValues[1]).toString() }.getOrNull()
    }
    return null
  }

  private fun resolveDisplayName(context: Context, uri: Uri): String? =
    runCatching {
      context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
          val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
          if (idx >= 0) cursor.getString(idx) else null
        } else null
      }
    }.getOrNull()
}
