package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tanh
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class SoundEffect {
  BALL_CLASH,
  WALL_BOUNCE,
  FIRE_CHIP,
  FIRE_LASER,
  FIRE_FURY,
  FIRE_REALM,
  WATER_ORB,
  WATER_TRAP,
  WATER_TSUNAMI,
  EXTINGUISH,
  GROUND_CHARGE,
  GROUND_QUAKE,
  GROUND_ARMOR,
  THUNDER_DASH,
  THUNDER_BOLT,
  ICE_SHARD,
  ICE_OVERDRIVE,
  ICE_FREEZE,
  ANT_SWARM,
  ANT_ROYAL,
  ANT_REGEN,
  GACHA_SPIN,
  GACHA_JACKPOT,
  KO_EXPLOSION,
  UI_TAP,
  CODE_UNLOCK,
  MAIL_NOTIFY,
  ROOM_READY,
  MATCH_FOUND,
  EMOTE_POP,
  DAILY_REWARD,
}

class ProceduralSoundEngine {
  private val sampleRate = 44100
  private val lock = Any()
  private val activeVoices = mutableListOf<Voice>()

  @Volatile private var sfxEnabled = true
  @Volatile private var musicEnabled = true
  @Volatile private var sfxVolume = 0.85f
  @Volatile private var musicVolume = 0.55f
  @Volatile private var combatIntensity = 0f
  @Volatile private var inBattle = false

  private var audioJob: Job? = null
  private var audioTrack: AudioTrack? = null
  private var bassPhase = 0.0
  private var arpPhase = 0.0
  private var padPhase = 0.0
  private var beatTimer = 0.0
  private var stepIndex = 0
  private var lastL = 0f
  private var lastR = 0f

  private data class Voice(
    val startFreq: Float,
    val endFreq: Float,
    val durationSec: Float,
    val gain: Float,
    val waveType: Int, // 0=sine, 1=triangle, 2=sub+noise punch, 3=FM metallic, 4=crystalline bell, 5=warm chord/horn
    val pan: Float = 0f, // -1 left .. +1 right
    val delaySec: Float = 0f,
    var elapsed: Float = 0f,
    var phase: Double = 0.0,
  )

  fun updateSettings(
    sfxOn: Boolean,
    musicOn: Boolean,
    sfxVol: Float,
    musicVol: Float,
  ) {
    sfxEnabled = sfxOn
    musicEnabled = musicOn
    sfxVolume = sfxVol.coerceIn(0f, 1f)
    musicVolume = musicVol.coerceIn(0f, 1f)
  }

  fun setBattleState(active: Boolean, intensity: Float) {
    inBattle = active
    combatIntensity = intensity.coerceIn(0f, 1f)
  }

  fun start(scope: CoroutineScope) {
    if (audioJob != null) return
    audioJob =
      scope.launch(Dispatchers.Default) {
        val minBuf =
          AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT,
          )
        if (minBuf <= 0) return@launch
        val bufferFrames = (minBuf / 4).coerceAtLeast(1024).coerceAtMost(3072)
        val track =
          try {
            AudioTrack.Builder()
              .setAudioAttributes(
                AudioAttributes.Builder()
                  .setUsage(AudioAttributes.USAGE_GAME)
                  .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                  .build()
              )
              .setAudioFormat(
                AudioFormat.Builder()
                  .setSampleRate(sampleRate)
                  .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                  .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                  .build()
              )
              .setBufferSizeInBytes(bufferFrames * 4)
              .setTransferMode(AudioTrack.MODE_STREAM)
              .build()
          } catch (_: Throwable) {
            null
          } ?: return@launch

        audioTrack = track
        try {
          track.play()
        } catch (_: Throwable) {
          releaseTrack()
          return@launch
        }

        val pcm = ShortArray(bufferFrames * 2)
        val dt = 1f / sampleRate
        var noiseSeed = 1337u

        // Prime stereo reverb delay lines (~36ms left, ~51ms right)
        val delayLenL = (sampleRate * 0.036f).toInt()
        val delayLenR = (sampleRate * 0.051f).toInt()
        val delayBufL = FloatArray(delayLenL)
        val delayBufR = FloatArray(delayLenR)
        var dIdxL = 0
        var dIdxR = 0

        // Crisp Esports D-minor pentatonic riff notes (Hz)
        val arpNotes = doubleArrayOf(293.66, 349.23, 440.00, 523.25, 587.33, 440.00, 392.00, 349.23)
        val bassRoots = doubleArrayOf(73.42, 73.42, 65.41, 58.27) // D2, D2, C2, Bb1

        while (isActive) {
          for (f in 0 until bufferFrames) {
            var mixL = 0f
            var mixR = 0f

            // 4-Layer Adaptive Stereo Esports BGM
            if (musicEnabled && musicVolume > 0.01f) {
              val tempoHz = if (inBattle) 2.60 + combatIntensity * 1.65 else 1.28
              beatTimer += dt
              val beatPeriod = 1.0 / tempoHz
              if (beatTimer >= beatPeriod) {
                beatTimer -= beatPeriod
                stepIndex = (stepIndex + 1) % 16
              }
              val beatPos = (beatTimer / beatPeriod).toFloat().coerceIn(0f, 1f)
              val punchEnv = (1f - beatPos) * (1f - beatPos)

              val barIdx = (stepIndex / 4) % bassRoots.size
              val bassHz = bassRoots[barIdx] * if (inBattle) 1.0 else 0.78
              bassPhase += 2.0 * PI * bassHz * dt
              if (bassPhase > 2.0 * PI) bassPhase -= 2.0 * PI

              val subKick = sin(bassPhase * (1.0 + (1f - beatPos) * 0.42)).toFloat() * punchEnv
              val sawHarmonic = (sin(bassPhase * 2.0) * 0.28 + sin(bassPhase * 3.0) * 0.14).toFloat() * punchEnv

              // Wide Stereo Pad
              val padHz = bassHz * 2.0
              padPhase += 2.0 * PI * padHz * dt
              if (padPhase > 2.0 * PI) padPhase -= 2.0 * PI
              val padL = sin(padPhase).toFloat() * 0.34f
              val padR = sin(padPhase * 1.004 + 0.4).toFloat() * 0.34f

              // Combat Arpeggio Pluck
              val arpHz = arpNotes[stepIndex % arpNotes.size] * if (combatIntensity > 0.65f) 1.5 else 1.0
              arpPhase += 2.0 * PI * arpHz * dt
              if (arpPhase > 2.0 * PI) arpPhase -= 2.0 * PI
              val arpEnv = ((1f - beatPos * 1.35f).coerceIn(0f, 1f)) * (if (inBattle) 0.25f + combatIntensity * 0.30f else 0.12f)
              val arpSample = (sin(arpPhase).toFloat() * 0.68f + sin(arpPhase * 2.0).toFloat() * 0.32f) * arpEnv
              val arpPan = if (stepIndex % 2 == 0) 0.26f else -0.26f

              // Crisp Battle Hi-Hat on intense beats
              var hatSample = 0f
              if (inBattle && beatPos < 0.12f) {
                noiseSeed = noiseSeed * 1664525u + 1013904223u
                val n = ((noiseSeed shr 16).toInt() and 0xFFFF) / 32768f - 1f
                hatSample = n * (1f - beatPos / 0.12f) * (0.04f + combatIntensity * 0.055f)
              }

              val bgGain = musicVolume * (if (inBattle) 0.15f else 0.10f)
              mixL += (subKick * 0.55f + sawHarmonic + padL + arpSample * (1f - arpPan * 0.4f) + hatSample) * bgGain
              mixR += (subKick * 0.55f + sawHarmonic + padR + arpSample * (1f + arpPan * 0.4f) - hatSample * 0.7f) * bgGain
            }

            synchronized(lock) {
              var idx = activeVoices.size - 1
              while (idx >= 0) {
                val v = activeVoices[idx]
                v.elapsed += dt
                if (v.elapsed < v.delaySec) {
                  idx--
                  continue
                }
                val activeTime = v.elapsed - v.delaySec
                if (activeTime >= v.durationSec) {
                  activeVoices.removeAt(idx)
                } else {
                  val t = (activeTime / v.durationSec).coerceIn(0f, 1f)
                  val freq = v.startFreq + (v.endFreq - v.startFreq) * t
                  v.phase += 2.0 * PI * freq * dt
                  if (v.phase > 2.0 * PI) v.phase -= 2.0 * PI

                  // Smooth 5ms half-cosine attack + clean quadratic-cubic decay eliminates clicks
                  val attackNorm = (activeTime / 0.005f).coerceIn(0f, 1f)
                  val attack = 0.5f * (1f - cos(PI.toFloat() * attackNorm))
                  val oneMinusT = 1f - t
                  val decay = oneMinusT * oneMinusT * (0.35f + 0.65f * oneMinusT)
                  val env = attack * decay

                  val raw =
                    when (v.waveType) {
                      0 -> sin(v.phase).toFloat()
                      1 -> {
                        val norm = (v.phase / (2.0 * PI)).toFloat()
                        if (norm < 0.5f) norm * 4f - 1f else 3f - norm * 4f
                      }
                      3 -> {
                        val mod = sin(v.phase * 2.5).toFloat() * 1.85f * (1f - t * 0.4f)
                        sin(v.phase + mod).toFloat()
                      }
                      4 -> {
                        (sin(v.phase).toFloat() * 0.58f +
                          sin(v.phase * 2.756).toFloat() * 0.28f +
                          sin(v.phase * 5.4).toFloat() * 0.14f)
                      }
                      5 -> {
                        (sin(v.phase).toFloat() * 0.48f +
                          sin(v.phase * 1.5).toFloat() * 0.30f +
                          sin(v.phase * 2.0).toFloat() * 0.22f)
                      }
                      else -> {
                        noiseSeed = noiseSeed * 1664525u + 1013904223u
                        val n = ((noiseSeed shr 16).toInt() and 0xFFFF) / 32768f - 1f
                        n * 0.50f + sin(v.phase).toFloat() * 0.50f
                      }
                    }
                  val amp = raw * env * v.gain * sfxVolume
                  val panClamped = v.pan.coerceIn(-0.85f, 0.85f)
                  val gainL = (1f - panClamped) * 0.72f
                  val gainR = (1f + panClamped) * 0.72f
                  mixL += amp * gainL
                  mixR += amp * gainR
                }
                idx--
              }
            }

            // Cross-stereo ambience + soft limiter + mild high-clarity smoothing
            val wetL = delayBufR[dIdxR] * 0.14f
            val wetR = delayBufL[dIdxL] * 0.14f
            delayBufL[dIdxL] = (mixL + wetL * 0.22f).coerceIn(-1.2f, 1.2f)
            delayBufR[dIdxR] = (mixR + wetR * 0.22f).coerceIn(-1.2f, 1.2f)
            dIdxL = (dIdxL + 1) % delayLenL
            dIdxR = (dIdxR + 1) % delayLenR

            val outL = tanh((mixL + wetL).toDouble()).toFloat()
            val outR = tanh((mixR + wetR).toDouble()).toFloat()
            val smoothL = lastL + (outL - lastL) * 0.86f
            val smoothR = lastR + (outR - lastR) * 0.86f
            lastL = smoothL
            lastR = smoothR

            val pIdx = f * 2
            pcm[pIdx] = (smoothL.coerceIn(-0.96f, 0.96f) * 32767f).toInt().toShort()
            pcm[pIdx + 1] = (smoothR.coerceIn(-0.96f, 0.96f) * 32767f).toInt().toShort()
          }

          try {
            val written = track.write(pcm, 0, pcm.size)
            if (written < 0) break
          } catch (_: Throwable) {
            break
          }
        }
        releaseTrack()
      }
  }

  fun play(effect: SoundEffect) = play(effect, pan = 0f)

  fun play(effect: SoundEffect, pan: Float) {
    if (!sfxEnabled || sfxVolume <= 0.01f) return
    val p = pan.coerceIn(-0.82f, 0.82f)
    val layers: List<Voice> =
      when (effect) {
        SoundEffect.BALL_CLASH ->
          listOf(
            Voice(230f, 54f, 0.15f, 0.54f, 2, pan = p),
            Voice(960f, 380f, 0.075f, 0.30f, 3, pan = (p + 0.18f).coerceIn(-0.82f, 0.82f)),
            Voice(1620f, 820f, 0.055f, 0.22f, 4, pan = (p - 0.18f).coerceIn(-0.82f, 0.82f)),
          )
        SoundEffect.WALL_BOUNCE ->
          listOf(
            Voice(450f, 195f, 0.065f, 0.26f, 0, pan = p),
            Voice(1180f, 620f, 0.048f, 0.15f, 4, pan = p),
          )
        SoundEffect.FIRE_CHIP ->
          listOf(
            Voice(780f, 1320f, 0.09f, 0.28f, 1, pan = p),
            Voice(1560f, 2140f, 0.07f, 0.16f, 3, pan = p),
          )
        SoundEffect.FIRE_LASER ->
          listOf(
            Voice(1560f, 410f, 0.24f, 0.36f, 3, pan = p),
            Voice(780f, 240f, 0.22f, 0.24f, 1, pan = -p * 0.4f),
            Voice(240f, 96f, 0.18f, 0.22f, 2, pan = 0f),
          )
        SoundEffect.FIRE_REALM ->
          listOf(
            Voice(140f, 58f, 0.58f, 0.48f, 2, pan = -0.3f),
            Voice(310f, 680f, 0.44f, 0.32f, 3, pan = 0.3f, delaySec = 0.03f),
            Voice(980f, 450f, 0.38f, 0.24f, 5, pan = 0f, delaySec = 0.06f),
          )
        SoundEffect.FIRE_FURY ->
          listOf(
            Voice(185f, 48f, 0.72f, 0.60f, 2, pan = p),
            Voice(490f, 130f, 0.56f, 0.38f, 3, pan = -0.38f, delaySec = 0.03f),
            Voice(980f, 320f, 0.42f, 0.26f, 5, pan = 0.38f, delaySec = 0.07f),
            Voice(1420f, 520f, 0.28f, 0.16f, 4, pan = 0f, delaySec = 0.11f),
          )
        SoundEffect.WATER_ORB ->
          listOf(
            Voice(600f, 1180f, 0.15f, 0.30f, 0, pan = p),
            Voice(920f, 1480f, 0.12f, 0.20f, 4, pan = -p * 0.5f, delaySec = 0.02f),
          )
        SoundEffect.WATER_TRAP ->
          listOf(
            Voice(380f, 820f, 0.24f, 0.32f, 0, pan = p),
            Voice(560f, 260f, 0.30f, 0.28f, 2, pan = -0.25f, delaySec = 0.04f),
          )
        SoundEffect.WATER_TSUNAMI ->
          listOf(
            Voice(250f, 70f, 0.62f, 0.56f, 2, pan = 0f),
            Voice(620f, 200f, 0.46f, 0.30f, 0, pan = -0.4f, delaySec = 0.05f),
            Voice(1240f, 400f, 0.36f, 0.20f, 4, pan = 0.4f, delaySec = 0.08f),
          )
        SoundEffect.EXTINGUISH ->
          listOf(Voice(1320f, 380f, 0.14f, 0.28f, 2, pan = p))
        SoundEffect.GROUND_CHARGE ->
          listOf(
            Voice(96f, 260f, 0.34f, 0.34f, 1, pan = p),
            Voice(210f, 390f, 0.28f, 0.22f, 5, pan = p, delaySec = 0.04f),
          )
        SoundEffect.GROUND_QUAKE ->
          listOf(
            Voice(88f, 28f, 0.52f, 0.66f, 2, pan = 0f),
            Voice(142f, 44f, 0.42f, 0.42f, 1, pan = -0.35f, delaySec = 0.02f),
            Voice(68f, 26f, 0.54f, 0.48f, 0, pan = 0.35f),
          )
        SoundEffect.GROUND_ARMOR ->
          listOf(
            Voice(240f, 380f, 0.20f, 0.34f, 5, pan = p),
            Voice(490f, 700f, 0.26f, 0.26f, 4, pan = p, delaySec = 0.04f),
          )
        SoundEffect.THUNDER_DASH ->
          listOf(
            Voice(1240f, 2700f, 0.14f, 0.34f, 3, pan = p),
            Voice(1960f, 720f, 0.13f, 0.24f, 2, pan = -p * 0.6f, delaySec = 0.015f),
          )
        SoundEffect.THUNDER_BOLT ->
          listOf(
            Voice(2680f, 320f, 0.18f, 0.48f, 3, pan = p),
            Voice(190f, 38f, 0.60f, 0.62f, 2, pan = 0f, delaySec = 0.02f),
            Voice(3500f, 1040f, 0.14f, 0.26f, 2, pan = -p * 0.5f),
          )
        SoundEffect.ICE_SHARD ->
          listOf(
            Voice(2040f, 3280f, 0.09f, 0.26f, 4, pan = p),
            Voice(2960f, 2240f, 0.11f, 0.22f, 3, pan = -p * 0.35f),
            Voice(4120f, 3100f, 0.06f, 0.12f, 4, pan = p * 0.5f, delaySec = 0.015f),
          )
        SoundEffect.ICE_OVERDRIVE ->
          listOf(
            Voice(1080f, 2340f, 0.22f, 0.30f, 4, pan = -0.3f),
            Voice(1580f, 2860f, 0.18f, 0.20f, 3, pan = 0.3f, delaySec = 0.04f),
          )
        SoundEffect.ICE_FREEZE ->
          listOf(
            Voice(2640f, 1180f, 0.46f, 0.38f, 4, pan = -0.45f),
            Voice(1760f, 3520f, 0.36f, 0.30f, 4, pan = 0.45f, delaySec = 0.04f),
            Voice(3280f, 4400f, 0.32f, 0.22f, 4, pan = 0f, delaySec = 0.09f),
            Voice(195f, 48f, 0.52f, 0.38f, 2, pan = 0f, delaySec = 0.03f),
          )
        SoundEffect.ANT_SWARM ->
          listOf(
            Voice(1080f, 1640f, 0.08f, 0.28f, 3, pan = -0.35f),
            Voice(1280f, 880f, 0.09f, 0.24f, 3, pan = 0.35f, delaySec = 0.04f),
            Voice(520f, 310f, 0.14f, 0.24f, 2, pan = p, delaySec = 0.02f),
          )
        SoundEffect.ANT_ROYAL ->
          listOf(
            Voice(247f, 370f, 0.34f, 0.42f, 5, pan = 0f),
            Voice(494f, 740f, 0.36f, 0.36f, 5, pan = -0.45f, delaySec = 0.06f),
            Voice(740f, 1109f, 0.44f, 0.38f, 4, pan = 0.45f, delaySec = 0.12f),
            Voice(140f, 68f, 0.48f, 0.34f, 2, pan = 0f),
          )
        SoundEffect.ANT_REGEN ->
          listOf(
            Voice(440f, 659f, 0.20f, 0.32f, 4, pan = -0.30f),
            Voice(659f, 988f, 0.28f, 0.32f, 5, pan = 0.30f, delaySec = 0.07f),
            Voice(988f, 1318f, 0.24f, 0.24f, 4, pan = 0f, delaySec = 0.14f),
          )
        SoundEffect.GACHA_SPIN ->
          listOf(
            Voice(440f, 660f, 0.09f, 0.26f, 4, pan = -0.4f),
            Voice(587f, 880f, 0.09f, 0.26f, 4, pan = 0f, delaySec = 0.09f),
            Voice(784f, 1174f, 0.12f, 0.30f, 4, pan = 0.4f, delaySec = 0.18f),
          )
        SoundEffect.GACHA_JACKPOT ->
          listOf(
            Voice(523f, 523f, 0.18f, 0.32f, 4, pan = -0.4f),
            Voice(659f, 659f, 0.20f, 0.32f, 4, pan = 0.4f, delaySec = 0.09f),
            Voice(784f, 784f, 0.22f, 0.34f, 5, pan = -0.2f, delaySec = 0.18f),
            Voice(1046f, 1046f, 0.44f, 0.38f, 4, pan = 0.2f, delaySec = 0.27f),
          )
        SoundEffect.KO_EXPLOSION ->
          listOf(
            Voice(155f, 32f, 0.78f, 0.68f, 2, pan = 0f),
            Voice(680f, 115f, 0.42f, 0.36f, 3, pan = -0.4f, delaySec = 0.02f),
            Voice(1080f, 300f, 0.30f, 0.26f, 4, pan = 0.4f, delaySec = 0.05f),
          )
        SoundEffect.UI_TAP ->
          listOf(Voice(780f, 1080f, 0.036f, 0.18f, 0, pan = p))
        SoundEffect.CODE_UNLOCK ->
          listOf(
            Voice(523f, 784f, 0.18f, 0.30f, 4, pan = -0.3f),
            Voice(784f, 1046f, 0.28f, 0.32f, 4, pan = 0.3f, delaySec = 0.10f),
          )
        SoundEffect.MAIL_NOTIFY ->
          listOf(
            Voice(880f, 880f, 0.12f, 0.26f, 4, pan = -0.2f),
            Voice(1174f, 1318f, 0.22f, 0.28f, 4, pan = 0.2f, delaySec = 0.09f),
          )
        SoundEffect.ROOM_READY ->
          listOf(
            Voice(659f, 988f, 0.14f, 0.28f, 4, pan = -0.25f),
            Voice(988f, 1318f, 0.22f, 0.32f, 5, pan = 0.25f, delaySec = 0.10f),
          )
        SoundEffect.MATCH_FOUND ->
          listOf(
            Voice(523.25f, 523.25f, 0.14f, 0.32f, 4, pan = -0.40f),
            Voice(659.25f, 659.25f, 0.14f, 0.32f, 4, pan = -0.15f, delaySec = 0.07f),
            Voice(783.99f, 783.99f, 0.16f, 0.34f, 5, pan = 0.15f, delaySec = 0.14f),
            Voice(1046.50f, 1046.50f, 0.38f, 0.40f, 4, pan = 0.35f, delaySec = 0.21f),
          )
        SoundEffect.EMOTE_POP ->
          listOf(
            Voice(640f, 1100f, 0.08f, 0.26f, 0, pan = p),
            Voice(1100f, 1380f, 0.09f, 0.20f, 4, pan = p, delaySec = 0.04f),
          )
        SoundEffect.DAILY_REWARD ->
          listOf(
            Voice(523f, 659f, 0.14f, 0.30f, 4, pan = -0.35f),
            Voice(659f, 784f, 0.14f, 0.30f, 4, pan = 0f, delaySec = 0.08f),
            Voice(784f, 1046f, 0.24f, 0.36f, 4, pan = 0.35f, delaySec = 0.16f),
            Voice(1046f, 1568f, 0.30f, 0.32f, 5, pan = 0f, delaySec = 0.24f),
          )
      }
    synchronized(lock) {
      for (v in layers) {
        if (activeVoices.size < 40) {
          activeVoices.add(v)
        }
      }
    }
  }

  fun stop() {
    audioJob?.cancel()
    audioJob = null
    releaseTrack()
  }

  private fun releaseTrack() {
    try {
      audioTrack?.stop()
      audioTrack?.release()
    } catch (_: Throwable) {}
    audioTrack = null
  }
}
