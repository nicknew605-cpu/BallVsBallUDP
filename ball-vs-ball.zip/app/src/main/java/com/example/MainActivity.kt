package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.localization.stringsFor
import com.example.model.AccountMode
import com.example.model.AppLanguage
import com.example.ui.components.AdmVipBadge
import com.example.ui.components.AppUpdatePromptDialog
import com.example.ui.screens.AdminOtaScreen
import com.example.ui.screens.ArenaScreen
import com.example.ui.screens.AuthGateScreen
import com.example.ui.screens.BallSelectScreen
import com.example.ui.screens.BallVaultScreen
import com.example.ui.screens.FriendsScreen
import com.example.ui.screens.LoadingOtaScreen
import com.example.ui.screens.MailboxScreen
import com.example.ui.screens.MenuScreen
import com.example.ui.screens.OnlineRoomScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ShopScreen
import com.example.ui.theme.BallVsBallTheme
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterPrimary
import com.example.util.AppUpdateManager
import com.example.viewmodel.GameViewModel
import com.example.viewmodel.StartupPhase
import kotlinx.coroutines.launch

private object Routes {
  const val MENU = "menu"
  const val BALL_SELECT = "ball_select"
  const val ARENA = "arena"
  const val SHOP = "shop"
  const val SETTINGS = "settings"
  const val VAULT = "vault"
  const val MAILBOX = "mailbox"
  const val FRIENDS = "friends"
  const val ONLINE_ROOM = "online_room"
  const val ADMIN_OTA = "admin_ota"
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      BallVsBallTheme {
        BallVsBallApp()
      }
    }
  }
}

@Composable
fun BallVsBallApp(gameViewModel: GameViewModel = viewModel()) {
  val context = LocalContext.current
  val progress by gameViewModel.userProgress.collectAsStateWithLifecycle()
  val settings by gameViewModel.gameSettings.collectAsStateWithLifecycle()
  val nowMillis by gameViewModel.nowMillis.collectAsStateWithLifecycle()
  val setup by gameViewModel.matchSetup.collectAsStateWithLifecycle()
  val startupPhase by gameViewModel.startupPhase.collectAsStateWithLifecycle()
  val accountMode by gameViewModel.accountMode.collectAsStateWithLifecycle()
  val loadingProgress by gameViewModel.loadingProgress.collectAsStateWithLifecycle()
  val loadingStatus by gameViewModel.loadingStatus.collectAsStateWithLifecycle()
  val currentUid by gameViewModel.currentUid.collectAsStateWithLifecycle()
  val authBusy by gameViewModel.authBusy.collectAsStateWithLifecycle()
  val authError by gameViewModel.authError.collectAsStateWithLifecycle()
  val otaConfig by gameViewModel.otaConfig.collectAsStateWithLifecycle()
  val appUpdateDismissed by gameViewModel.appUpdateDismissed.collectAsStateWithLifecycle()
  var manualUpdatePrompt by remember { mutableStateOf(false) }
  val isAdmin by gameViewModel.isAdmin.collectAsStateWithLifecycle()
  val mailbox by gameViewModel.mailbox.collectAsStateWithLifecycle()
  val activeRoom by gameViewModel.activeRoom.collectAsStateWithLifecycle()
  val roomChat by gameViewModel.roomChat.collectAsStateWithLifecycle()
  val roomPingMs by gameViewModel.roomPingMs.collectAsStateWithLifecycle()
  val roomBusy by gameViewModel.roomBusy.collectAsStateWithLifecycle()
  val matchmakingState by gameViewModel.matchmakingState.collectAsStateWithLifecycle()
  val friends by gameViewModel.friends.collectAsStateWithLifecycle()
  val incomingFriendRequests by gameViewModel.incomingFriendRequests.collectAsStateWithLifecycle()
  val incomingRoomInvites by gameViewModel.incomingRoomInvites.collectAsStateWithLifecycle()
  val apkUpdateState by gameViewModel.apkUpdateState.collectAsStateWithLifecycle()
  val githubUploadState by gameViewModel.githubUploadState.collectAsStateWithLifecycle()

  val strings = stringsFor(settings.language)
  val adminNotice = otaConfig.activeAdminNotice(settings.language, nowMillis)
  val adminNoticeRemainingMs =
    if (otaConfig.adminNoticeExpiresAtMillis > 0L && otaConfig.adminNoticeExpiresAtMillis > nowMillis) {
      otaConfig.adminNoticeExpiresAtMillis - nowMillis
    } else {
      0L
    }
  val unreadMailCount = mailbox.count { !it.claimed }
  val isGuestMode = accountMode == AccountMode.GUEST

  when {
    startupPhase == StartupPhase.LOADING -> {
      LoadingOtaScreen(
        strings = strings,
        progressFraction = loadingProgress,
        statusText = loadingStatus.ifBlank { strings.loadingOtaTitle },
      )
    }

    startupPhase == StartupPhase.AUTH_REQUIRED || currentUid == null -> {
      AuthGateScreen(
        strings = strings,
        isBusy = authBusy,
        errorMessage = authError,
        defaultNickname = progress.nickname,
        onGoogleSignIn = { nick -> gameViewModel.signInWithGoogle(context, nick) },
        onPlayAsGuest = { nick -> gameViewModel.continueAsGuest(nick) },
      )
    }

    else -> {
      key(currentUid) {
        val navController = rememberNavController()
        val overlayScope = rememberCoroutineScope()

        Box(modifier = Modifier.fillMaxSize()) {
          NavHost(
            navController = navController,
            startDestination = Routes.MENU,
          ) {
            composable(Routes.MENU) {
              MenuScreen(
                strings = strings,
                language = settings.language,
                progress = progress,
                nowMillis = nowMillis,
                unreadMailCount = unreadMailCount,
                otaCloudSynced = otaConfig.syncedFromCloud,
                isGuestMode = isGuestMode,
                isAdmin = isAdmin,
                adminNotice = adminNotice,
                adminNoticeRemainingMillis = adminNoticeRemainingMs,
                onStartClick = {
                  gameViewModel.playUiTap()
                  gameViewModel.syncEquippedBallToSetup()
                  navController.navigate(Routes.BALL_SELECT)
                },
                onOnline1v1Click = {
                  gameViewModel.playUiTap()
                  navController.navigate(Routes.ONLINE_ROOM)
                },
                onLinkGoogleClick = { navigateToOnline ->
                  gameViewModel.signInWithGoogle(context, progress.nickname) {
                    if (navigateToOnline) {
                      navController.navigate(Routes.ONLINE_ROOM)
                    }
                  }
                },
                onVaultClick = {
                  gameViewModel.playUiTap()
                  navController.navigate(Routes.VAULT)
                },
                onMailboxClick = {
                  gameViewModel.playUiTap()
                  navController.navigate(Routes.MAILBOX)
                },
                onShopClick = {
                  gameViewModel.playUiTap()
                  navController.navigate(Routes.SHOP)
                },
                onFriendsClick = {
                  gameViewModel.playUiTap()
                  navController.navigate(Routes.FRIENDS)
                },
                pendingFriendRequestsCount = incomingFriendRequests.size,
                onSettingsClick = {
                  gameViewModel.playUiTap()
                  navController.navigate(Routes.SETTINGS)
                },
                onAdminOtaClick = {
                  gameViewModel.playUiTap()
                  navController.navigate(Routes.ADMIN_OTA)
                },
                onClaimDailyReward = { gameViewModel.claimDailyLoginReward() },
                onRedeemCode = { code -> gameViewModel.redeemCode(code) },
              )
            }

            composable(Routes.FRIENDS) {
              FriendsScreen(
                strings = strings,
                progress = progress,
                isGuestMode = isGuestMode,
                isAdmin = isAdmin,
                friends = friends,
                incomingRequests = incomingFriendRequests,
                onLinkGoogle = { gameViewModel.signInWithGoogle(context, progress.nickname) },
                onSearchPlayers = { q -> gameViewModel.searchPlayers(q) },
                onSendFriendRequest = { target -> gameViewModel.sendFriendRequest(target) },
                onRespondFriendRequest = { req, accept -> gameViewModel.respondFriendRequest(req, accept) },
                onRemoveFriend = { uid -> gameViewModel.removeFriend(uid) },
                onInviteFriendBattle = { uid ->
                  val res = gameViewModel.inviteFriendToRoom(uid)
                  if (res.isSuccess) {
                    navController.navigate(Routes.ONLINE_ROOM)
                  }
                  res.map { Unit }
                },
                onBack = {
                  gameViewModel.playUiTap()
                  navController.popBackStack()
                },
              )
            }

            composable(Routes.ADMIN_OTA) {
              AdminOtaScreen(
                strings = strings,
                initialConfig = otaConfig,
                nowMillis = nowMillis,
                uploadState = githubUploadState,
                onPublishOtaConfig = { updated -> gameViewModel.publishAdminOtaConfig(updated) },
                onUploadAndPublishApk = { repo, token, apkInfo, cfg ->
                  gameViewModel.uploadApkAndPublishOta(repo, token, apkInfo, cfg)
                },
                onSearchPlayers = { q -> gameViewModel.searchPlayers(q) },
                onSendTargetedGift = { targetUid, coins, ball, trialMins, msg ->
                  gameViewModel.sendTargetedAdminGift(targetUid, coins, ball, trialMins, msg)
                },
                onBack = {
                  gameViewModel.playUiTap()
                  navController.popBackStack()
                },
              )
            }

          composable(Routes.VAULT) {
            BallVaultScreen(
              strings = strings,
              progress = progress,
              otaBalance = otaConfig.balance,
              nowMillis = nowMillis,
              onBuyOrEquipBall = { ball -> gameViewModel.buyOrEquipBall(ball) },
              onBack = {
                gameViewModel.playUiTap()
                navController.popBackStack()
              },
            )
          }

          composable(Routes.MAILBOX) {
            MailboxScreen(
              strings = strings,
              language = settings.language,
              letters = mailbox,
              onClaimLetter = { letter -> gameViewModel.claimMailboxLetter(letter) },
              onBack = {
                gameViewModel.playUiTap()
                navController.popBackStack()
              },
            )
          }

            composable(Routes.ONLINE_ROOM) {
              OnlineRoomScreen(
                strings = strings,
                currentUid = currentUid.orEmpty(),
                progress = progress,
                nowMillis = nowMillis,
                activeRoom = activeRoom,
                friends = friends,
                roomChat = roomChat,
                roomPingMs = roomPingMs,
                isRoomBusy = roomBusy,
                matchmakingState = matchmakingState,
                onStartQuickMatch = { gameViewModel.startQuickMatchmaking() },
                onCancelQuickMatch = { gameViewModel.cancelQuickMatchmaking() },
                onCreateRoom = { gameViewModel.createOnlineRoom() },
                onJoinRoom = { code -> gameViewModel.joinOnlineRoom(code) },
                onInviteFriend = { uid -> gameViewModel.inviteFriendToRoom(uid).map { Unit } },
                onToggleReady = { ready -> gameViewModel.toggleRoomReady(ready) },
                onSendChat = { text -> gameViewModel.sendRoomChat(text) },
                onSubmitPick3 = { code, picks -> gameViewModel.submitOnlinePick3(code, picks) },
                onSubmitBan1 = { code, ban -> gameViewModel.submitOnlineBan1(code, ban) },
                onSubmitFinalPick = { code, finalBall -> gameViewModel.submitOnlineFinalPick(code, finalBall) },
                onClaimDisconnectWin = { gameViewModel.claimOpponentDisconnectWin() },
                onLeaveRoom = { gameViewModel.leaveOnlineRoom() },
                onStartOnlineBattle = { room ->
                  if (navController.currentBackStackEntry?.destination?.route == Routes.ONLINE_ROOM) {
                    gameViewModel.prepareOnlineBattle(room)
                    navController.navigate(Routes.ARENA) { launchSingleTop = true }
                  }
                },
                onBack = {
                  gameViewModel.playUiTap()
                  navController.popBackStack()
                },
              )
            }

          composable(Routes.BALL_SELECT) {
            BallSelectScreen(
              strings = strings,
              progress = progress,
              otaBalance = otaConfig.balance,
              nowMillis = nowMillis,
              setup = setup,
              onSelectMode = { mode ->
                gameViewModel.playUiTap()
                gameViewModel.updateMatchSetup {
                  it.copy(
                    mode = mode,
                    p1DisplayName = progress.nickname.ifBlank { "P1" },
                    p2DisplayName = if (mode == com.example.model.GameMode.ONE_VS_AI) "AI" else "P2",
                  )
                }
              },
              onSelectP1Ball = { ball ->
                gameViewModel.playUiTap()
                gameViewModel.updateMatchSetup { it.copy(p1Ball = ball) }
              },
              onSelectP2Ball = { ball ->
                gameViewModel.playUiTap()
                gameViewModel.updateMatchSetup { it.copy(p2Ball = ball) }
              },
              onOpenShop = {
                gameViewModel.playUiTap()
                navController.navigate(Routes.SHOP)
              },
              onStartBattle = {
                gameViewModel.playUiTap()
                navController.navigate(Routes.ARENA)
              },
              onBack = {
                gameViewModel.playUiTap()
                navController.popBackStack()
              },
            )
          }

            composable(Routes.ARENA) {
              ArenaScreen(
                strings = strings,
                setup = setup,
                settings = settings,
                otaBalance = gameViewModel.effectiveArenaBalance(),
                otaVfx = otaConfig.vfx,
                progress = progress,
                activeRoom = activeRoom,
                currentUid = currentUid.orEmpty(),
                nowMillis = nowMillis,
                emoteEvents = gameViewModel.onlineEmoteEvents,
                soundEngine = gameViewModel.soundEngine,
                onSendEmote = { emote -> gameViewModel.sendBattleEmote(emote) },
                onSubmitOnlineAimAngle = { roomCode, expectedRound, angleRad ->
                  gameViewModel.submitOnlineAimAngle(roomCode, expectedRound, angleRad)
                },
                onForceDefaultMissingAim = { roomCode, expectedRound, targetIsHost ->
                  gameViewModel.forceDefaultMissingAim(roomCode, expectedRound, targetIsHost)
                },
                onRecordMatchOutcome = { mode, winnerId, durationSec ->
                  gameViewModel.recordMatchOutcome(mode, winnerId, durationSec)
                },
                onNextOnlineRound = {
                  gameViewModel.playUiTap()
                  navController.popBackStack()
                },
                onExitToMenu = {
                  gameViewModel.playUiTap()
                  gameViewModel.leaveOnlineRoom()
                  navController.popBackStack(Routes.MENU, inclusive = false)
                },
              )
            }

          composable(Routes.SHOP) {
            ShopScreen(
              strings = strings,
              progress = progress,
              otaBalance = otaConfig.balance,
              nowMillis = nowMillis,
              gachaSpinCost = otaConfig.gachaSpinCost,
              onBuyOrEquipBall = { ball -> gameViewModel.buyOrEquipBall(ball) },
              onBuyOrEquipEffect = { effect -> gameViewModel.buyOrEquipKillEffect(effect) },
              onSpinGacha = { gameViewModel.spinGacha() },
              onBack = {
                gameViewModel.playUiTap()
                navController.popBackStack()
              },
            )
          }

          composable(Routes.SETTINGS) {
            SettingsScreen(
              strings = strings,
              settings = settings,
              currentNickname = progress.nickname,
              isGuestMode = isGuestMode,
              currentVersionName = BuildConfig.VERSION_NAME,
              currentVersionCode = BuildConfig.VERSION_CODE,
              latestCloudVersionName = otaConfig.appUpdate.latestVersionName,
              latestCloudVersionCode = otaConfig.appUpdate.latestVersionCode,
              onCheckUpdates = {
                val refreshed = gameViewModel.refreshOtaConfig().getOrNull() ?: otaConfig
                val available = refreshed.appUpdate.isUpdateAvailable(BuildConfig.VERSION_CODE)
                if (available) {
                  manualUpdatePrompt = true
                }
                available
              },
              onSaveNickname = { name -> gameViewModel.saveNickname(name) },
              onLinkGoogle = { gameViewModel.signInWithGoogle(context, progress.nickname) },
              onSignOut = { gameViewModel.signOut(context) },
              onUpdateSettings = { transform -> gameViewModel.updateSettings(transform) },
              onResetProgress = {
                gameViewModel.playUiTap()
                gameViewModel.resetProgress()
              },
              onBack = {
                gameViewModel.playUiTap()
                navController.popBackStack()
              },
            )
          }
          }

          val topInvite = incomingRoomInvites.firstOrNull()
          if (topInvite != null && navController.currentBackStackEntry?.destination?.route != Routes.ARENA) {
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = ObsidianSurface,
              border = BorderStroke(1.5.dp, GoldAccent),
              shadowElevation = 10.dp,
              modifier =
                Modifier.align(Alignment.TopCenter)
                  .windowInsetsPadding(WindowInsets.safeDrawing)
                  .padding(horizontal = 14.dp, vertical = 8.dp)
                  .widthIn(max = 520.dp)
                  .fillMaxWidth()
                  .testTag("global_incoming_invite_banner"),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(Icons.Default.SportsEsports, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(22.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    if (topInvite.fromIsAdmin) AdmVipBadge(label = strings.admBadgeLabel)
                    Text(
                      text = topInvite.fromName.ifBlank { "Player" },
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                  Text(
                    text = "${strings.incomingInviteTitle} • ${topInvite.roomCode}",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaterPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
                TextButton(
                  onClick = { gameViewModel.dismissRoomInvite(topInvite.id) },
                  modifier = Modifier.height(48.dp).testTag("invite_banner_dismiss_button"),
                ) {
                  Text(strings.dismissInviteButton, color = TextSecondary)
                }
                Button(
                  onClick = {
                    overlayScope.launch {
                      gameViewModel.acceptRoomInvite(topInvite).onSuccess {
                        navController.navigate(Routes.ONLINE_ROOM) { launchSingleTop = true }
                      }
                    }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
                  modifier = Modifier.height(48.dp).testTag("invite_banner_accept_button"),
                ) {
                  Text(strings.acceptInviteButton, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }

        val appUpd = otaConfig.appUpdate
        val updateAvailable = appUpd.isUpdateAvailable(BuildConfig.VERSION_CODE)
        val mandatoryUpdate = appUpd.isMandatory(BuildConfig.VERSION_CODE)
        if (updateAvailable && (manualUpdatePrompt || !appUpdateDismissed || mandatoryUpdate)) {
          val notes =
            if (settings.language == AppLanguage.VI) appUpd.releaseNotesVi.ifBlank { appUpd.releaseNotesEn }
            else appUpd.releaseNotesEn.ifBlank { appUpd.releaseNotesVi }
          AppUpdatePromptDialog(
            strings = strings,
            currentVersionName = BuildConfig.VERSION_NAME,
            currentVersionCode = BuildConfig.VERSION_CODE,
            latestVersionName = appUpd.latestVersionName,
            latestVersionCode = appUpd.latestVersionCode,
            releaseNotes = notes,
            downloadUrl = appUpd.downloadUrl,
            isMandatory = mandatoryUpdate,
            updateState = apkUpdateState,
            onStartUpdate = { gameViewModel.startAppUpdateDownload(context) },
            onOpenInstallPermission = { AppUpdateManager.openInstallPermissionSettings(context) },
            onInstallReadyApk = { path -> gameViewModel.installReadyApkIfPermitted(context, path) },
            onDismiss = {
              manualUpdatePrompt = false
              gameViewModel.resetAppUpdateState()
              gameViewModel.dismissAppUpdatePrompt()
            },
          )
        }
      }
    }
  }
}
