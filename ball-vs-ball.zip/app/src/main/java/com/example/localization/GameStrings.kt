package com.example.localization

import androidx.compose.runtime.Immutable
import com.example.model.AiDifficulty
import com.example.model.AppLanguage
import com.example.model.BallRarity
import com.example.model.BallType
import com.example.model.GraphicsQuality
import com.example.model.KillEffectType

@Immutable
interface GameStrings {
  val appTitle: String
  val versionBadge: String
  val subtitle: String
  val coinsLabel: String
  val startButton: String
  val online1v1Button: String
  val vaultButton: String
  val mailboxButton: String
  val shopButton: String
  val friendsButton: String
  val settingsButton: String
  val codeButton: String
  val adminButton: String
  val dailyRewardButton: String
  val tanThuBannerPrefix: String
  val back: String
  val admBadgeLabel: String
  val playerIdLabel: String
  val copiedIdMsg: String
  val trialRemainingPrefix: String

  // Auth, Guest & Loading / OTA
  val loadingOtaTitle: String
  val loadingOtaCloudSynced: String
  val loadingOtaOffline: String
  val authTitle: String
  val authSubtitle: String
  val authGoogleSignInButton: String
  val authPlayGuestButton: String
  val authOrDivider: String
  val authNicknameLabel: String
  val authSaveNicknameButton: String
  val signOutButton: String
  val guestModeBadge: String
  val linkGoogleButton: String
  val onlineRequiresGoogleMsg: String

  // Daily Login Rewards
  val dailyRewardTitle: String
  val dailyRewardSubtitle: String
  val dailyRewardClaimButton: String
  val dailyRewardClaimedToday: String
  val dailyRewardDayPrefix: String
  val dailyRewardStreakLabel: String

  // Admin OTA Console
  val adminTitle: String
  val adminSubtitle: String
  val adminNoticeSection: String
  val adminNoticeViLabel: String
  val adminNoticeEnLabel: String
  val adminNoticeDurationLabel: String
  val adminNoticeExpiresPrefix: String
  val adminNotice1h: String
  val adminNotice6h: String
  val adminNotice24h: String
  val adminNotice3d: String
  val adminNotice7d: String
  val adminNoticePerm: String
  val adminNoticeClear: String
  val adminCodesSection: String
  val adminAddCodeTitle: String
  val adminCodeInputLabel: String
  val adminCoinsInputLabel: String
  val adminBallSelectLabel: String
  val adminExpiryLabel: String
  val adminExpiry24h: String
  val adminExpiry3d: String
  val adminExpiry7d: String
  val adminExpiryPerm: String
  val adminAddCodeButton: String
  val adminActiveLabel: String
  val adminExpiredLabel: String
  val adminDisabledLabel: String
  val adminVfxSection: String
  val adminBalanceSection: String
  val adminPerBallSection: String
  val adminPerBallHpLabel: String
  val adminPerBallDmgLabel: String
  val adminResetBallStatsButton: String
  val adminPublishButton: String
  val adminPublishSuccess: String
  val adminPublishError: String
  val adminGiftSection: String
  val adminGiftTargetHint: String
  val adminGiftMessageLabel: String
  val adminGiftSendButton: String
  val adminGiftSentSuccess: String
  val adminGiftSelectPlayerFirst: String
  val adminCodeTrialToggleLabel: String
  val adminTrialUnitMinutes: String
  val adminTrialUnitHours: String
  val adminTrialDurationLabel: String

  // Rarity & Vault
  val rarityCommon: String
  val rarityUncommon: String
  val rarityRare: String
  val vaultTitle: String
  val vaultSubtitle: String
  val statAttack: String
  val statDefense: String
  val statSpeed: String
  val statControl: String
  val ownedBadge: String
  val passiveLabel: String

  // Mailbox
  val mailboxTitle: String
  val mailboxEmpty: String
  val mailboxClaimButton: String
  val mailboxClaimedBadge: String
  val mailboxRewardPrefix: String

  // Online 1vs1 FT3
  val onlineTitle: String
  val onlineSubtitle: String
  val createRoomButton: String
  val joinRoomButton: String
  val roomCodePlaceholder: String
  val roomCodeLabel: String
  val waitingOpponentLabel: String
  val readyButton: String
  val unreadyButton: String
  val readyBadge: String
  val waitingReadyLabel: String
  val autoDraftHint: String
  val phasePick3Title: String
  val phaseBan1Title: String
  val phaseFinalPickTitle: String
  val lockSelectionButton: String
  val banBallButton: String
  val launchOnlineBattleButton: String
  val speedRewardNote: String
  val loserNoLossNote: String
  val leaveRoomButton: String
  val pingLabel: String
  val opponentOnlineLabel: String
  val opponentOfflineWarning: String
  val claimDisconnectWinButton: String
  val chatPlaceholder: String
  val sendChatButton: String
  val chatEmptyHint: String
  val roundSeriesLabel: String
  val roundResultNextLabel: String
  val nextRoundButton: String
  val matchFinishedTitle: String
  val emoteBarLabel: String
  val inviteFriendButton: String
  val inviteSentMsg: String
  val incomingInviteTitle: String
  val acceptInviteButton: String
  val dismissInviteButton: String
  val confirmAimButton: String
  val waitingOpponentAimLabel: String
  val enteringBattleLabel: String
  val ballTrialBadgePrefix: String
  val quickMatchButton: String
  val quickMatchDesc: String
  val quickMatchSearching: String
  val quickMatchCancel: String
  val quickMatchFound: String

  // Friends Hub
  val friendsTitle: String
  val friendsTabList: String
  val friendsTabRequests: String
  val friendsTabSearch: String
  val searchPlayerHint: String
  val searchButton: String
  val sendFriendRequestButton: String
  val friendRequestSentMsg: String
  val alreadyFriendsLabel: String
  val pendingLabel: String
  val acceptButton: String
  val declineButton: String
  val noFriendsHint: String
  val noRequestsHint: String
  val friendsNeedGoogleMsg: String

  // Ball Select
  val selectArenaTitle: String
  val modeLabel: String
  val mode1vAI: String
  val mode1v1: String
  val player1Label: String
  val player2Label: String
  val aiOpponentLabel: String
  val lockedLabel: String
  val unlockedTrialLabel: String
  val unlockInShopHint: String
  val fightButton: String
  val passiveRuleNote: String

  // Ball Details (All 6)
  val fireBallName: String
  val fireBallTagline: String
  val firePassiveDesc: String
  val fireNormalTitle: String
  val fireNormalDesc: String
  val fireUltTitle: String
  val fireUltDesc: String
  val waterBallName: String
  val waterBallTagline: String
  val waterPassiveDesc: String
  val waterNormalTitle: String
  val waterNormalDesc: String
  val waterUltTitle: String
  val waterUltDesc: String
  val groundBallName: String
  val groundBallTagline: String
  val groundPassiveDesc: String
  val groundNormalTitle: String
  val groundNormalDesc: String
  val groundUltTitle: String
  val groundUltDesc: String
  val thunderBallName: String
  val thunderBallTagline: String
  val thunderPassiveDesc: String
  val thunderNormalTitle: String
  val thunderNormalDesc: String
  val thunderUltTitle: String
  val thunderUltDesc: String
  val iceBallName: String
  val iceBallTagline: String
  val icePassiveDesc: String
  val iceNormalTitle: String
  val iceNormalDesc: String
  val iceUltTitle: String
  val iceUltDesc: String
  val antBallName: String
  val antBallTagline: String
  val antPassiveDesc: String
  val antNormalTitle: String
  val antNormalDesc: String
  val antUltTitle: String
  val antUltDesc: String
  val waterAdvantageBadge: String
  val statsSummary: String

  // Shop & Gacha
  val shopTitle: String
  val tabBalls: String
  val tabKillEffects: String
  val buyButton: String
  val equipButton: String
  val equippedLabel: String
  val freeTrialActiveLabel: String
  val notEnoughCoins: String
  val purchasedSuccess: String
  val gachaTitle: String
  val gachaSubtitle: String
  val gachaSpinButton: String
  val gachaPityLabel: String
  val gachaOddsLabel: String
  val gachaResultNew: String
  val gachaResultDup: String
  val gachaPityTriggered: String
  val effectDefaultName: String
  val effectDefaultDesc: String
  val effectShockwaveName: String
  val effectShockwaveDesc: String
  val effectNovaName: String
  val effectNovaDesc: String
  val effectDissolveName: String
  val effectDissolveDesc: String

  // Code Dialog
  val codeDialogTitle: String
  val codeDialogDesc: String
  val codePlaceholder: String
  val redeemButton: String
  val closeButton: String
  val codeSentToMailboxMsg: String
  val codeSuccessMsg: String
  val codeAlreadyRedeemedMsg: String
  val codeAlreadyActiveMsg: String
  val codeExpiredOrInvalidMsg: String
  val codeInvalidMsg: String

  // Settings & Graphics Tiers
  val settingsTitle: String
  val sectionAccount: String
  val sectionLanguage: String
  val languageVi: String
  val languageEn: String
  val sectionCombat: String
  val aiDifficultyLabel: String
  val diffEasy: String
  val diffNormal: String
  val diffHard: String
  val targetFpsLabel: String
  val gameSpeedLabel: String
  val sectionVisuals: String
  val graphicsQualityLabel: String
  val qualityLow: String
  val qualityMedium: String
  val qualityHigh: String
  val qualityUltra: String
  val autoReduceLagLabel: String
  val autoLagActiveTag: String
  val bloomShaderLabel: String
  val trailsLabel: String
  val shakeLabel: String
  val hitStopLabel: String
  val floatingDamageLabel: String
  val showFpsLabel: String
  val sectionAudio: String
  val sfxLabel: String
  val sfxVolumeLabel: String
  val musicLabel: String
  val musicVolumeLabel: String
  val resetProgressButton: String
  val resetConfirmTitle: String
  val resetConfirmDesc: String
  val confirmYes: String
  val cancel: String

  // Arena
  val aimP1Prompt: String
  val aimP2Prompt: String
  val aiAimingPrompt: String
  val launchButton: String
  val battleAutoTag: String
  val burnStatus: String
  val soakStatus: String
  val silenceStatus: String
  val armorStatus: String
  val frozenStatus: String
  val trappedStatus: String
  val venomStatus: String
  val exitMatch: String
  val pauseMatch: String
  val resumeMatch: String
  val koTitle: String
  val winnerP1: String
  val winnerP2: String
  val winnerAi: String
  val damageDealtLabel: String
  val skillsUsedLabel: String
  val matchTimeLabel: String
  val rewardCoinsLabel: String
  val rematchButton: String
  val mainMenuButton: String

  // Export APK
  val exportApkButton: String
  val exportApkDialogTitle: String
  val exportApkDialogDesc: String
  val exportApkSaveDevice: String
  val exportApkShare: String
  val exportApkWorking: String
  val exportApkSuccess: String
  val exportApkError: String

  // In-App Update & Admin Release Manager
  val updateDialogTitle: String
  val updateMandatoryBadge: String
  val updateOptionalBadge: String
  val updateNotesLabel: String
  val updatePermissionHint: String
  val updateNowButton: String
  val updateLaterButton: String
  val updateLinkError: String
  val sectionAppUpdate: String
  val currentVersionLabel: String
  val latestCloudVersionLabel: String
  val checkUpdateButton: String
  val upToDateMsg: String
  val adminReleaseSection: String
  val adminReleaseHint: String
  val adminVersionCodeLabel: String
  val adminMinVersionCodeLabel: String
  val adminVersionNameLabel: String
  val adminDownloadUrlLabel: String
  val adminReleaseNotesViLabel: String
  val adminReleaseNotesEnLabel: String
  val adminApkDropTitle: String
  val adminApkDropHint: String
  val adminPickApkButton: String
  val adminGithubRepoLabel: String
  val adminGithubTokenLabel: String
  val adminGithubTokenHint: String
  val adminUploadPublishButton: String
  val adminVersionWarningLow: String
  val adminFixVersionCodeButton: String
  val adminUploadMissingFields: String
  val updateDownloadingLabel: String
  val updateInstallPermissionNeeded: String
  val updateOpenSettingsButton: String
  val updateReadyInstallButton: String
  val updateOpeningBrowserMsg: String
  val updateRetryButton: String

  fun ballName(type: BallType): String =
    when (type) {
      BallType.FIRE -> fireBallName
      BallType.WATER -> waterBallName
      BallType.GROUND -> groundBallName
      BallType.THUNDER -> thunderBallName
      BallType.ICE -> iceBallName
      BallType.ANT -> antBallName
    }

  fun ballTagline(type: BallType): String =
    when (type) {
      BallType.FIRE -> fireBallTagline
      BallType.WATER -> waterBallTagline
      BallType.GROUND -> groundBallTagline
      BallType.THUNDER -> thunderBallTagline
      BallType.ICE -> iceBallTagline
      BallType.ANT -> antBallTagline
    }

  fun ballPassiveDesc(type: BallType): String =
    when (type) {
      BallType.FIRE -> firePassiveDesc
      BallType.WATER -> waterPassiveDesc
      BallType.GROUND -> groundPassiveDesc
      BallType.THUNDER -> thunderPassiveDesc
      BallType.ICE -> icePassiveDesc
      BallType.ANT -> antPassiveDesc
    }

  fun ballNormalTitle(type: BallType): String =
    when (type) {
      BallType.FIRE -> fireNormalTitle
      BallType.WATER -> waterNormalTitle
      BallType.GROUND -> groundNormalTitle
      BallType.THUNDER -> thunderNormalTitle
      BallType.ICE -> iceNormalTitle
      BallType.ANT -> antNormalTitle
    }

  fun ballNormalDesc(type: BallType): String =
    when (type) {
      BallType.FIRE -> fireNormalDesc
      BallType.WATER -> waterNormalDesc
      BallType.GROUND -> groundNormalDesc
      BallType.THUNDER -> thunderNormalDesc
      BallType.ICE -> iceNormalDesc
      BallType.ANT -> antNormalDesc
    }

  fun ballUltTitle(type: BallType): String =
    when (type) {
      BallType.FIRE -> fireUltTitle
      BallType.WATER -> waterUltTitle
      BallType.GROUND -> groundUltTitle
      BallType.THUNDER -> thunderUltTitle
      BallType.ICE -> iceUltTitle
      BallType.ANT -> antUltTitle
    }

  fun ballUltDesc(type: BallType): String =
    when (type) {
      BallType.FIRE -> fireUltDesc
      BallType.WATER -> waterUltDesc
      BallType.GROUND -> groundUltDesc
      BallType.THUNDER -> thunderUltDesc
      BallType.ICE -> iceUltDesc
      BallType.ANT -> antUltDesc
    }

  fun rarityName(rarity: BallRarity): String =
    when (rarity) {
      BallRarity.COMMON -> rarityCommon
      BallRarity.UNCOMMON -> rarityUncommon
      BallRarity.RARE -> rarityRare
    }

  fun killEffectName(type: KillEffectType): String =
    when (type) {
      KillEffectType.DEFAULT_BURST -> effectDefaultName
      KillEffectType.SHOCKWAVE -> effectShockwaveName
      KillEffectType.PARTICLE_NOVA -> effectNovaName
      KillEffectType.DISSOLVE -> effectDissolveName
    }

  fun killEffectDesc(type: KillEffectType): String =
    when (type) {
      KillEffectType.DEFAULT_BURST -> effectDefaultDesc
      KillEffectType.SHOCKWAVE -> effectShockwaveDesc
      KillEffectType.PARTICLE_NOVA -> effectNovaDesc
      KillEffectType.DISSOLVE -> effectDissolveDesc
    }

  fun difficultyName(difficulty: AiDifficulty): String =
    when (difficulty) {
      AiDifficulty.EASY -> diffEasy
      AiDifficulty.NORMAL -> diffNormal
      AiDifficulty.HARD -> diffHard
    }

  fun qualityName(quality: GraphicsQuality): String =
    when (quality) {
      GraphicsQuality.LOW -> qualityLow
      GraphicsQuality.MEDIUM -> qualityMedium
      GraphicsQuality.HIGH -> qualityHigh
      GraphicsQuality.ULTRA -> qualityUltra
    }
}

private object ViGameStrings : GameStrings {
  override val appTitle = "BALL VS BALL"
  override val versionBadge = "v1.0.3 Beta • HCT"
  override val subtitle = "Đấu Trường Vật Lý 120Hz"
  override val coinsLabel = "Xu"
  override val startButton = "ĐẤU OFFLINE"
  override val online1v1Button = "1VS1 ONLINE"
  override val vaultButton = "KHO BÓNG"
  override val mailboxButton = "HÒM THƯ"
  override val shopButton = "SHOP GACHA"
  override val friendsButton = "BẠN BÈ"
  override val settingsButton = "CÀI ĐẶT"
  override val codeButton = "GIFTCODE"
  override val adminButton = "ADMIN OTA"
  override val dailyRewardButton = "ĐIỂM DANH"
  override val tanThuBannerPrefix = "Code TanThu • Còn"
  override val back = "Quay lại"
  override val admBadgeLabel = "ADM"
  override val playerIdLabel = "ID"
  override val copiedIdMsg = "Đã sao chép ID người chơi!"
  override val trialRemainingPrefix = "Thử còn"
  override val loadingOtaTitle = "Đang đồng bộ dữ liệu..."
  override val loadingOtaCloudSynced = "OTA Online"
  override val loadingOtaOffline = "Chơi Offline"
  override val authTitle = "CHỌN CHẾ ĐỘ VÀO GAME"
  override val authSubtitle = "Đăng nhập Google để lưu Cloud & đấu 1vs1 Online, hoặc chơi Khách Offline ngay lập tức."
  override val authGoogleSignInButton = "ĐĂNG NHẬP GOOGLE"
  override val authPlayGuestButton = "CHƠI KHÁCH (OFFLINE)"
  override val authOrDivider = "HOẶC"
  override val authNicknameLabel = "Tên hiển thị"
  override val authSaveNicknameButton = "Lưu"
  override val signOutButton = "Đăng xuất"
  override val guestModeBadge = "Khách Offline"
  override val linkGoogleButton = "Liên kết Google"
  override val onlineRequiresGoogleMsg = "Cần đăng nhập Google để vào phòng 1vs1 Online."
  override val dailyRewardTitle = "ĐIỂM DANH 7 NGÀY"
  override val dailyRewardSubtitle = "Đăng nhập mỗi ngày nhận Xu miễn phí, ngày 7 nhận mốc VIP 1.500 Xu."
  override val dailyRewardClaimButton = "NHẬN QUÀ HÔM NAY"
  override val dailyRewardClaimedToday = "Đã điểm danh hôm nay"
  override val dailyRewardDayPrefix = "Ngày"
  override val dailyRewardStreakLabel = "Chuỗi hiện tại"
  override val adminTitle = "ADMIN OTA CONSOLE"
  override val adminSubtitle = "Quản trị viên • Điều chỉnh thông báo hẹn giờ, HP/Sát thương bóng & APK từ xa."
  override val adminNoticeSection = "Thông Báo Toàn Server (Có Hẹn Giờ)"
  override val adminNoticeViLabel = "Nội dung VI"
  override val adminNoticeEnLabel = "Nội dung EN"
  override val adminNoticeDurationLabel = "Thời hạn hiển thị"
  override val adminNoticeExpiresPrefix = "Tự ẩn sau"
  override val adminNotice1h = "1 giờ"
  override val adminNotice6h = "6 giờ"
  override val adminNotice24h = "24 giờ"
  override val adminNotice3d = "3 ngày"
  override val adminNotice7d = "7 ngày"
  override val adminNoticePerm = "Không giới hạn"
  override val adminNoticeClear = "Tắt thông báo"
  override val adminCodesSection = "Quản Lý Giftcode OTA"
  override val adminAddCodeTitle = "Thêm Giftcode Mới"
  override val adminCodeInputLabel = "Mã (VD: Tet2026)"
  override val adminCoinsInputLabel = "Xu thưởng"
  override val adminBallSelectLabel = "Bóng tặng kèm"
  override val adminExpiryLabel = "Thời hạn code"
  override val adminExpiry24h = "24 giờ"
  override val adminExpiry3d = "3 ngày"
  override val adminExpiry7d = "7 ngày"
  override val adminExpiryPerm = "Vĩnh viễn"
  override val adminAddCodeButton = "THÊM GIFTCODE"
  override val adminActiveLabel = "Đang bật"
  override val adminExpiredLabel = "Hết hạn"
  override val adminDisabledLabel = "Đã tắt"
  override val adminVfxSection = "Hiệu Ứng Hình Ảnh (OTA)"
  override val adminBalanceSection = "Thông Số Kỹ Năng Chung (OTA)"
  override val adminPerBallSection = "Tùy Chỉnh Máu & Sát Thương Từng Bóng (Offline + Online)"
  override val adminPerBallHpLabel = "Máu (HP)"
  override val adminPerBallDmgLabel = "Hệ số Sát Thương"
  override val adminResetBallStatsButton = "Khôi phục gốc"
  override val adminPublishButton = "XUẤT BẢN OTA NGAY"
  override val adminPublishSuccess = "Đã cập nhật OTA lên toàn bộ máy!"
  override val adminPublishError = "Không thể xuất bản OTA."
  override val adminGiftSection = "Tặng Quà Riêng Theo ID / Tên"
  override val adminGiftTargetHint = "Tìm BVB-XXXXXX hoặc Tên"
  override val adminGiftMessageLabel = "Lời nhắn hòm thư"
  override val adminGiftSendButton = "GỬI QUÀ NGAY"
  override val adminGiftSentSuccess = "Đã gửi quà vào Hòm Thư người chơi!"
  override val adminGiftSelectPlayerFirst = "Hãy tìm và chọn 1 người chơi nhận quà."
  override val adminCodeTrialToggleLabel = "Dạng dùng thử Bóng theo thời gian"
  override val adminTrialUnitMinutes = "Phút"
  override val adminTrialUnitHours = "Giờ"
  override val adminTrialDurationLabel = "Thời lượng"
  override val rarityCommon = "COMMON"
  override val rarityUncommon = "UNCOMMON"
  override val rarityRare = "RARE"
  override val vaultTitle = "KHO BÓNG"
  override val vaultSubtitle = "Xem nội tại, kỹ năng, chỉ số HP/Sát thương hiện tại và mở khóa bóng."
  override val statAttack = "Sát thương"
  override val statDefense = "Phòng thủ"
  override val statSpeed = "Tốc độ"
  override val statControl = "Khống chế"
  override val ownedBadge = "Đã sở hữu"
  override val passiveLabel = "Nội tại"
  override val mailboxTitle = "HÒM THƯ"
  override val mailboxEmpty = "Hòm thư trống. Nhập TriAn (+5.000 Xu) hoặc TaiDz-111!"
  override val mailboxClaimButton = "NHẬN"
  override val mailboxClaimedBadge = "Đã nhận"
  override val mailboxRewardPrefix = "Quà:"
  override val onlineTitle = "PHÒNG 1VS1 FT3"
  override val onlineSubtitle = "Chạm 3 điểm thắng! Sẵn sàng để hệ thống tự bốc 3 bóng sở hữu • Cấm 1 • Chọn 1."
  override val createRoomButton = "TẠO PHÒNG MỚI"
  override val joinRoomButton = "VÀO PHÒNG"
  override val roomCodePlaceholder = "Nhập mã phòng (VD: HCT992)"
  override val roomCodeLabel = "Phòng:"
  override val waitingOpponentLabel = "Đang chờ đối thủ..."
  override val readyButton = "SẴN SÀNG"
  override val unreadyButton = "HỦY SẴN SÀNG"
  override val readyBadge = "Đã sẵn sàng"
  override val waitingReadyLabel = "Chờ đối thủ bấm Sẵn Sàng"
  override val autoDraftHint = "Hệ thống vừa bốc ngẫu nhiên 3 bóng bạn đang sở hữu cho hiệp này!"
  override val phasePick3Title = "ĐANG CHIA BÀI 3 BÓNG..."
  override val phaseBan1Title = "BƯỚC 1/2: CẤM 1 BÓNG CỦA ĐỐI THỦ"
  override val phaseFinalPickTitle = "BƯỚC 2/2: CHỌN BÓNG THI ĐẤU HIỆP NÀY"
  override val lockSelectionButton = "XÁC NHẬN"
  override val banBallButton = "CẤM BÓNG NÀY"
  override val launchOnlineBattleButton = "VÀO TRẬN NGAY"
  override val speedRewardNote = "Thắng chung cuộc FT3 thưởng nhanh: <=15s +240 Xu • <=25s +190 Xu"
  override val loserNoLossNote = "Thua không bị trừ Xu!"
  override val leaveRoomButton = "Rời phòng"
  override val pingLabel = "Ping"
  override val opponentOnlineLabel = "Kết nối ổn định"
  override val opponentOfflineWarning = "Đối thủ mất kết nối khỏi phòng!"
  override val claimDisconnectWinButton = "XỬ THẮNG VĂNG PHÒNG"
  override val chatPlaceholder = "Nhắn tin với đối thủ..."
  override val sendChatButton = "Gửi"
  override val chatEmptyHint = "Chưa có tin nhắn. Chào đối thủ một câu!"
  override val roundSeriesLabel = "Hiệp"
  override val roundResultNextLabel = "Hiệp kết thúc! Quay lại phòng bốc 3 bóng ngẫu nhiên mới."
  override val nextRoundButton = "HIỆP TIẾP THEO"
  override val matchFinishedTitle = "CHUNG CUỘC FT3"
  override val emoteBarLabel = "Biểu cảm"
  override val inviteFriendButton = "MỜI BẠN"
  override val inviteSentMsg = "Đã gửi lời mời vào phòng!"
  override val incomingInviteTitle = "LỜI MỜI 1VS1"
  override val acceptInviteButton = "VÀO NGAY"
  override val dismissInviteButton = "Đóng"
  override val confirmAimButton = "CHỐT HƯỚNG"
  override val waitingOpponentAimLabel = "Đợi đối thủ ngắm bắn..."
  override val enteringBattleLabel = "Đang vào đấu trường..."
  override val ballTrialBadgePrefix = "Thử:"
  override val quickMatchButton = "GHÉP NGẪU NHIÊN"
  override val quickMatchDesc = "Gặp ngay người chơi đang online để vào thẳng Cấm/Chọn FT3."
  override val quickMatchSearching = "Đang tìm đối thủ online..."
  override val quickMatchCancel = "HỦY TÌM TRẬN"
  override val quickMatchFound = "Đã tìm thấy đối thủ! Đang vào Cấm/Chọn FT3..."
  override val friendsTitle = "BẠN BÈ & ID"
  override val friendsTabList = "Bạn bè"
  override val friendsTabRequests = "Lời mời"
  override val friendsTabSearch = "Tìm kiếm"
  override val searchPlayerHint = "Nhập ID (BVB-...) hoặc Tên"
  override val searchButton = "Tìm"
  override val sendFriendRequestButton = "Kết bạn"
  override val friendRequestSentMsg = "Đã gửi lời mời kết bạn!"
  override val alreadyFriendsLabel = "Đã kết bạn"
  override val pendingLabel = "Đang chờ"
  override val acceptButton = "Chấp nhận"
  override val declineButton = "Từ chối"
  override val noFriendsHint = "Chưa có bạn bè. Chia sẻ ID BVB hoặc tìm kiếm để kết bạn!"
  override val noRequestsHint = "Chưa có lời mời kết bạn nào."
  override val friendsNeedGoogleMsg = "Đăng nhập Google để dùng Danh sách Bạn bè & Mời phòng."
  override val selectArenaTitle = "CHỌN ĐẤU OFFLINE"
  override val modeLabel = "Chế độ"
  override val mode1vAI = "1 vs AI"
  override val mode1v1 = "1 vs 1"
  override val player1Label = "Người chơi 1"
  override val player2Label = "Người chơi 2"
  override val aiOpponentLabel = "Máy (AI)"
  override val lockedLabel = "Đang khóa"
  override val unlockedTrialLabel = "Thử 24h"
  override val unlockInShopHint = "Điểm danh ngày, nhập TriAn (+5.000 Xu) hoặc quay Gacha để mở Ant Ball!"
  override val fightButton = "VÀO ĐẤU TRƯỜNG"
  override val passiveRuleNote = "Ngắm góc ban đầu, bóng tự động chiến đấu & kích hoạt nội tại theo vật lý."
  override val fireBallName = "Fire Ball"
  override val fireBallTagline = "Hỏa Cầu • Vùng Lửa Thiêu Đốt"
  override val firePassiveDesc = "Nội tại Realm of Fire: 5s đầu thiêu đốt 4 tường liên tục 15s. Địch chạm tường cháy 2% máu/giây trong 3s và chậm 40% (2s)."
  override val fireNormalTitle = "Skill 1: Mạng Lưới Laser Lửa"
  override val fireNormalDesc = "Gắn chip lửa lên tường khi nảy, nối tia laser đốt 2 sát thương mỗi 0.25s khi cắt ngang đối thủ."
  override val fireUltTitle = "Nộ 100%: Fire Fury"
  override val fireUltDesc = "Bão lửa thiêu đốt toàn sàn đấu trong 5s gây 6% máu/giây kèm sóng nổ rực cháy."
  override val waterBallName = "Water Ball"
  override val waterBallTagline = "Thủy Cầu • Xoáy Nước Tốc Biến"
  override val waterPassiveDesc = "Nội tại Tidal Surge: Nảy tường tăng +8% tốc độ (tối đa 3 tầng) và đẩy nhanh nhịp bắn cầu nước."
  override val waterNormalTitle = "Skill 1: Hố Xoáy & Aqua Orb"
  override val waterNormalDesc = "70% đặt bẫy xoáy giữ địch tại chỗ gây 20 sát thương, kèm cầu nước đuổi theo dập chip lửa."
  override val waterUltTitle = "Nộ 100%: Tsunami"
  override val waterUltDesc = "Sóng thần quét ngang đấu trường (khắc chế Fire Ball), đẩy lùi mạnh và rửa sạch bẫy lửa."
  override val groundBallName = "Ground Ball"
  override val groundBallTagline = "Địa Cầu • Thiết Giáp Đá Cứng"
  override val groundPassiveDesc = "Nội tại Bastion: Va chạm làm choáng nhẹ đối thủ (-15% tốc độ) và tăng lực hất văng."
  override val groundNormalTitle = "Skill 1 (5s CD): Địa Chấn Tụ Nộ"
  override val groundNormalDesc = "Khi gồng giảm 10% ST nhận; giáng 3 đợt nứt đất (12 ST + chậm 60%) và nghiền nát kiến lính xung quanh."
  override val groundUltTitle = "Nộ / 18s: Giáp Đất (5s)"
  override val groundUltDesc = "Bát giác giáp đá miễn nhiễm 100% khống chế (kể cả Kỷ Băng Hà) và giảm 30% ST nhận vào trong 5s."
  override val thunderBallName = "Thunder Ball"
  override val thunderBallTagline = "Lôi Cầu • Ảo Ảnh Tốc Độ"
  override val thunderPassiveDesc = "Nội tại Tụ Điện: Di chuyển tích tụ điểm tĩnh điện, va chạm cộng dồn sát thương sốc điện và +5 Nộ."
  override val thunderNormalTitle = "Skill 1 (5s CD): Tốc Biến Ảo Ảnh"
  override val thunderNormalDesc = "Rải 80-100 ảo ảnh khắp sàn đấu trong 3.5s; mỗi ảo ảnh bị chạm giúp hồi +1% Nộ."
  override val thunderUltTitle = "Nộ 100%: Sét Tử Vong"
  override val thunderUltDesc = "Giáng tia sét gây 32% máu hiện tại (+2% mỗi lần tung) và khóa kỹ năng địch 2s."
  override val iceBallName = "Ice Ball"
  override val iceBallTagline = "Băng Cầu • Kỷ Băng Hà"
  override val icePassiveDesc = "Nội tại Hàn Khí: Tỏa sương lạnh làm chậm kẻ địch gần 200px và tăng tốc tích mảnh băng (0.68s/mảnh)."
  override val iceNormalTitle = "Skill 1 (10s CD): Mưa Mảnh Băng"
  override val iceNormalDesc = "Tích đủ 5 mảnh bắn loạt băng nhọn (6 ST + chậm 70%); kích hoạt giúp tăng +70% tốc độ ra mảnh."
  override val iceUltTitle = "Nộ / 20s: Kỷ Băng Hà (10s)"
  override val iceUltDesc = "Đóng băng toàn đấu trường & kẻ địch 10s, giảm 70% Nộ địch ngay lập tức; Ice vẫn tự do tấn công. Hết đóng băng làm chậm địch 40%."
  override val antBallName = "Ant Ball"
  override val antBallTagline = "Kiến Chúa • Bầy Đàn & Độc Tố"
  override val antPassiveDesc = "Nội tại Tái Sinh Tế Bào: Mỗi 16s đẻ thêm 1 Ant Ball (100% HP, tối đa 3 bóng/trận). Diệt sạch mọi Ant Ball mới thắng!"
  override val antNormalTitle = "Skill 1 (8s CD): Thả Bầy Kiến Lính"
  override val antNormalDesc = "Thả 1/3/5/7/10 kiến lính bám đuổi địch với tốc độ cao; chưa chạm địch sẽ tồn tại VĨNH VIỄN (5 ST + chậm 0.5s)."
  override val antUltTitle = "Nộ 100%: Kiến Hậu (90%) • Kiến Vua (8%) • Song Hoàng (1%)"
  override val antUltDesc = "Hậu buff kiến to +15%, 7 ST, độc tê 1%/s. Vua tăng +10% tốc, độc 3%/s, hồi 20 máu/16s. Có cả 2 nhân đôi toàn bộ buff!"
  override val waterAdvantageBadge = "Khắc Fire"
  override val statsSummary = "Cân bằng 6 Bóng • Vật lý 120Hz"
  override val shopTitle = "SHOP & GACHA"
  override val tabBalls = "Kho Bóng"
  override val tabKillEffects = "Hiệu Ứng KO"
  override val buyButton = "Mua"
  override val equipButton = "Trang bị"
  override val equippedLabel = "Đang dùng"
  override val freeTrialActiveLabel = "Dùng thử 24h"
  override val notEnoughCoins = "Chưa đủ Xu!"
  override val purchasedSuccess = "Đã mở khóa & trang bị!"
  override val gachaTitle = "QUAY GACHA"
  override val gachaSubtitle = "Săn bóng Uncommon & Rare Ant Ball! Bảo hiểm Pity ở lượt thứ 10."
  override val gachaSpinButton = "QUAY • 120 Xu"
  override val gachaPityLabel = "Thanh Pity"
  override val gachaOddsLabel = "Common 70% • Uncommon 22% • Rare 8%"
  override val gachaResultNew = "MỞ KHÓA BÓNG MỚI!"
  override val gachaResultDup = "Trùng bóng! Hoàn"
  override val gachaPityTriggered = "NỔ BẢO HIỂM PITY!"
  override val effectDefaultName = "Vụ Nổ Nguyên Bản"
  override val effectDefaultDesc = "Nổ hạt năng lượng theo màu nguyên tố khi KO."
  override val effectShockwaveName = "Sóng Xung Kích"
  override val effectShockwaveDesc = "Ba vòng xung kích neon lan tỏa khắp hộp đấu."
  override val effectNovaName = "Siêu Tân Tinh"
  override val effectNovaDesc = "90 tia sáng trọng lực bùng nổ rực rỡ."
  override val effectDissolveName = "Tan Rã Nguyên Tố"
  override val effectDissolveDesc = "Phân rã bóng đối thủ thành tro năng lượng bay lên."
  override val codeDialogTitle = "NHẬP GIFTCODE"
  override val codeDialogDesc = "Thử mã TriAn (+5.000 Xu trong 7 ngày), TaiDz-111 (Thunder Ball) hoặc TanThu (thử all bóng 24h)."
  override val codePlaceholder = "Nhập mã code..."
  override val redeemButton = "NHẬN QUÀ"
  override val closeButton = "Đóng"
  override val codeSentToMailboxMsg = "Đã gửi quà vào Hòm Thư!"
  override val codeSuccessMsg = "Đã mở khóa dùng thử tất cả bóng trong 24h!"
  override val codeAlreadyRedeemedMsg = "Bạn đã nhập mã này trước đó rồi."
  override val codeAlreadyActiveMsg = "Gói dùng thử TanThu 24h vẫn đang hoạt động!"
  override val codeExpiredOrInvalidMsg = "Mã không hợp lệ hoặc đã hết hạn."
  override val codeInvalidMsg = "Mã không hợp lệ hoặc đã hết hạn."
  override val settingsTitle = "CÀI ĐẶT"
  override val sectionAccount = "Tài Khoản"
  override val sectionLanguage = "Ngôn ngữ / Language"
  override val languageVi = "Tiếng Việt"
  override val languageEn = "English"
  override val sectionCombat = "Chiến Đấu & AI"
  override val aiDifficultyLabel = "Độ khó AI"
  override val diffEasy = "Dễ"
  override val diffNormal = "Chuẩn"
  override val diffHard = "Cao thủ"
  override val targetFpsLabel = "Khung hình (FPS)"
  override val gameSpeedLabel = "Tốc độ trận"
  override val sectionVisuals = "Đồ Họa & Hiệu Ứng"
  override val graphicsQualityLabel = "Chất lượng VFX"
  override val qualityLow = "Thấp"
  override val qualityMedium = "Vừa"
  override val qualityHigh = "Cao"
  override val qualityUltra = "Siêu nét"
  override val autoReduceLagLabel = "Tự hạ chi tiết khi tụt FPS"
  override val autoLagActiveTag = "Giảm lag"
  override val bloomShaderLabel = "Ánh sáng & Bloom"
  override val trailsLabel = "Vệt đuôi chuyển động"
  override val shakeLabel = "Rung chấn va chạm"
  override val hitStopLabel = "Khựng nhịp đòn nặng"
  override val floatingDamageLabel = "Hiện số sát thương"
  override val showFpsLabel = "Hiện bộ đếm FPS"
  override val sectionAudio = "Âm Thanh Stereo 44.1kHz"
  override val sfxLabel = "Hiệu ứng âm thanh (SFX)"
  override val sfxVolumeLabel = "Âm lượng SFX"
  override val musicLabel = "Nhạc nền đấu trường"
  override val musicVolumeLabel = "Âm lượng nhạc"
  override val resetProgressButton = "Đặt lại dữ liệu"
  override val resetConfirmTitle = "Xóa dữ liệu hiện tại?"
  override val resetConfirmDesc = "Xu, bóng đã mua, chuỗi điểm danh và Pity sẽ về mặc định."
  override val confirmYes = "Đồng ý"
  override val cancel = "Hủy"
  override val aimP1Prompt = "Kéo để chọn góc bắn"
  override val aimP2Prompt = "Người 2: Kéo chọn góc bắn"
  override val aiAimingPrompt = "Đối thủ đang ngắm hướng..."
  override val launchButton = "PHÓNG"
  override val battleAutoTag = "ĐẤU VẬT LÝ TỰ ĐỘNG"
  override val burnStatus = "THIÊU ĐỐT"
  override val soakStatus = "LÀM CHẬM"
  override val silenceStatus = "TÊ TÁI"
  override val armorStatus = "GIÁP ĐẤT"
  override val frozenStatus = "ĐÓNG BĂNG"
  override val trappedStatus = "BỊ GIAM"
  override val venomStatus = "ĐỘC KIẾN"
  override val exitMatch = "Thoát"
  override val pauseMatch = "Tạm dừng"
  override val resumeMatch = "Tiếp tục"
  override val koTitle = "HẠ GỤC!"
  override val winnerP1 = "CHIẾN THẮNG!"
  override val winnerP2 = "ĐỐI THỦ THẮNG!"
  override val winnerAi = "AI THẮNG!"
  override val damageDealtLabel = "Sát thương"
  override val skillsUsedLabel = "Kỹ năng"
  override val matchTimeLabel = "Thời gian"
  override val rewardCoinsLabel = "Thưởng Xu"
  override val rematchButton = "ĐẤU LẠI"
  override val mainMenuButton = "TRANG CHỦ"
  override val exportApkButton = "XUẤT APK"
  override val exportApkDialogTitle = "XUẤT FILE APK"
  override val exportApkDialogDesc = "Đóng gói file cài đặt APK hiện tại của Ball vs Ball để lưu về máy hoặc chia sẻ."
  override val exportApkSaveDevice = "Lưu APK về máy"
  override val exportApkShare = "Chia sẻ file APK"
  override val exportApkWorking = "Đang đóng gói APK..."
  override val exportApkSuccess = "Xuất file APK thành công!"
  override val exportApkError = "Không thể xuất APK trên thiết bị này."
  override val updateDialogTitle = "BẢN CẬP NHẬT MỚI"
  override val updateMandatoryBadge = "Bắt buộc"
  override val updateOptionalBadge = "Khuyên dùng"
  override val updateNotesLabel = "Thay đổi mới:"
  override val updatePermissionHint = "Hệ thống mở liên kết tải APK đã ký và hỏi xác nhận cài đè trực tiếp ngay trong Android."
  override val updateNowButton = "CẬP NHẬT NGAY"
  override val updateLaterButton = "Để sau"
  override val updateLinkError = "Link tải không hợp lệ hoặc cần bắt đầu bằng https://"
  override val sectionAppUpdate = "Phiên Bản & Cập Nhật"
  override val currentVersionLabel = "Phiên bản máy"
  override val latestCloudVersionLabel = "Bản mới nhất Cloud"
  override val checkUpdateButton = "Kiểm tra cập nhật"
  override val upToDateMsg = "Bạn đang ở phiên bản 1.0.3 Beta mới nhất!"
  override val adminReleaseSection = "Phát Hành APK Mới (Auto Update)"
  override val adminReleaseHint = "Kéo thả / chọn file APK để tự up GitHub Releases lấy link cài 1 chạm, hoặc dán link web Betadrop."
  override val adminVersionCodeLabel = "Version Code mới"
  override val adminMinVersionCodeLabel = "Code tối thiểu"
  override val adminVersionNameLabel = "Tên phiên bản (VD: 1.0.3 Beta)"
  override val adminDownloadUrlLabel = "Link tải APK / Web (https://...)"
  override val adminReleaseNotesViLabel = "Ghi chú VI"
  override val adminReleaseNotesEnLabel = "Ghi chú EN"
  override val adminApkDropTitle = "Kéo thả file .APK vào đây"
  override val adminApkDropHint = "Tự động đọc Version Code, Version Name & dung lượng file APK."
  override val adminPickApkButton = "CHỌN FILE APK"
  override val adminGithubRepoLabel = "GitHub Repo (vd: user/ball-vs-ball)"
  override val adminGithubTokenLabel = "GitHub Personal Token (chỉ lưu trên máy)"
  override val adminGithubTokenHint = "Token GitHub lưu cục bộ trên thiết bị Admin, không bao giờ gửi lên Firestore."
  override val adminUploadPublishButton = "UP GITHUB & PHÁT HÀNH NGAY"
  override val adminVersionWarningLow = "Cảnh báo: Version Code của APK phải lớn hơn bản đang chạy để người chơi nhận update!"
  override val adminFixVersionCodeButton = "Nâng +1 Code"
  override val adminUploadMissingFields = "Vui lòng chọn file APK, nhập Repo (owner/repo) và GitHub Token."
  override val updateDownloadingLabel = "Đang tải bản cập nhật APK..."
  override val updateInstallPermissionNeeded = "Cần bật quyền 'Cài đặt ứng dụng không xác định' cho Ball vs Ball để cài 1 chạm."
  override val updateOpenSettingsButton = "MỞ CÀI ĐẶT QUYỀN"
  override val updateReadyInstallButton = "CÀI ĐẶT APK NGAY"
  override val updateOpeningBrowserMsg = "Đang mở trang tải phiên bản mới..."
  override val updateRetryButton = "Thử lại"
}

private object EnGameStrings : GameStrings {
  override val appTitle = "BALL VS BALL"
  override val versionBadge = "v1.0.3 Beta • HCT"
  override val subtitle = "120Hz Physics & PvP Arena"
  override val coinsLabel = "Coins"
  override val startButton = "PLAY OFFLINE"
  override val online1v1Button = "1VS1 ONLINE"
  override val vaultButton = "BALL VAULT"
  override val mailboxButton = "MAILBOX"
  override val shopButton = "SHOP GACHA"
  override val friendsButton = "FRIENDS"
  override val settingsButton = "SETTINGS"
  override val codeButton = "GIFTCODE"
  override val adminButton = "ADMIN OTA"
  override val dailyRewardButton = "DAILY LOGIN"
  override val tanThuBannerPrefix = "TanThu • Left"
  override val back = "Back"
  override val admBadgeLabel = "ADM"
  override val playerIdLabel = "ID"
  override val copiedIdMsg = "Player ID copied!"
  override val trialRemainingPrefix = "Trial left"
  override val loadingOtaTitle = "Syncing live config..."
  override val loadingOtaCloudSynced = "OTA Live"
  override val loadingOtaOffline = "Offline"
  override val authTitle = "CHOOSE ACCESS MODE"
  override val authSubtitle = "Sign in with Google for Cloud sync & 1vs1 Online, or play Offline instantly as Guest."
  override val authGoogleSignInButton = "SIGN IN WITH GOOGLE"
  override val authPlayGuestButton = "PLAY AS GUEST (OFFLINE)"
  override val authOrDivider = "OR"
  override val authNicknameLabel = "Player Name"
  override val authSaveNicknameButton = "Save"
  override val signOutButton = "Sign Out"
  override val guestModeBadge = "Guest Offline"
  override val linkGoogleButton = "Link Google"
  override val onlineRequiresGoogleMsg = "Google Sign-In is required to join 1vs1 Online rooms."
  override val dailyRewardTitle = "7-DAY LOGIN REWARDS"
  override val dailyRewardSubtitle = "Check in daily for free Coins — Day 7 grants a 1,500 Coin VIP bonus!"
  override val dailyRewardClaimButton = "CLAIM TODAY'S REWARD"
  override val dailyRewardClaimedToday = "Claimed for today"
  override val dailyRewardDayPrefix = "Day"
  override val dailyRewardStreakLabel = "Current Streak"
  override val adminTitle = "ADMIN OTA CONSOLE"
  override val adminSubtitle = "Admin • Timed bulletins, per-ball HP/Dmg balance (Offline+Online) & APK updates."
  override val adminNoticeSection = "Timed Global Notice"
  override val adminNoticeViLabel = "Notice VI"
  override val adminNoticeEnLabel = "Notice EN"
  override val adminNoticeDurationLabel = "Notice Duration"
  override val adminNoticeExpiresPrefix = "Ends in"
  override val adminNotice1h = "1 Hour"
  override val adminNotice6h = "6 Hours"
  override val adminNotice24h = "24 Hours"
  override val adminNotice3d = "3 Days"
  override val adminNotice7d = "7 Days"
  override val adminNoticePerm = "No Expiry"
  override val adminNoticeClear = "Clear Notice"
  override val adminCodesSection = "OTA Giftcode Manager"
  override val adminAddCodeTitle = "Create Giftcode"
  override val adminCodeInputLabel = "Code (e.g. Tet2026)"
  override val adminCoinsInputLabel = "Coins"
  override val adminBallSelectLabel = "Bonus Ball"
  override val adminExpiryLabel = "Code Duration"
  override val adminExpiry24h = "24h"
  override val adminExpiry3d = "3 Days"
  override val adminExpiry7d = "7 Days"
  override val adminExpiryPerm = "Permanent"
  override val adminAddCodeButton = "ADD GIFTCODE"
  override val adminActiveLabel = "Active"
  override val adminExpiredLabel = "Expired"
  override val adminDisabledLabel = "Disabled"
  override val adminVfxSection = "Visual Effects Tuning (OTA)"
  override val adminBalanceSection = "Global Skill Parameters (OTA)"
  override val adminPerBallSection = "Per-Ball HP & Damage Tuning (Offline + Online)"
  override val adminPerBallHpLabel = "Max HP"
  override val adminPerBallDmgLabel = "Damage Scale"
  override val adminResetBallStatsButton = "Reset Defaults"
  override val adminPublishButton = "PUBLISH OTA LIVE"
  override val adminPublishSuccess = "Published live OTA config to all players!"
  override val adminPublishError = "Failed to publish OTA config."
  override val adminGiftSection = "Send Targeted Player Gift"
  override val adminGiftTargetHint = "Search BVB-XXXXXX or Name"
  override val adminGiftMessageLabel = "Mailbox message"
  override val adminGiftSendButton = "SEND GIFT"
  override val adminGiftSentSuccess = "Gift delivered to player's Mailbox!"
  override val adminGiftSelectPlayerFirst = "Search and select a target player first."
  override val adminCodeTrialToggleLabel = "Timed Ball Trial Mode"
  override val adminTrialUnitMinutes = "Minutes"
  override val adminTrialUnitHours = "Hours"
  override val adminTrialDurationLabel = "Duration"
  override val rarityCommon = "COMMON"
  override val rarityUncommon = "UNCOMMON"
  override val rarityRare = "RARE"
  override val vaultTitle = "BALL VAULT"
  override val vaultSubtitle = "Inspect passives, skills, live HP/Damage stats & unlock fighters."
  override val statAttack = "Attack"
  override val statDefense = "Defense"
  override val statSpeed = "Speed"
  override val statControl = "Control"
  override val ownedBadge = "Owned"
  override val passiveLabel = "Passive"
  override val mailboxTitle = "MAILBOX"
  override val mailboxEmpty = "No mail yet. Redeem TriAn (+5,000 Coins) or TaiDz-111!"
  override val mailboxClaimButton = "CLAIM"
  override val mailboxClaimedBadge = "Claimed"
  override val mailboxRewardPrefix = "Reward:"
  override val onlineTitle = "1VS1 ONLINE FT3"
  override val onlineSubtitle = "First to 3 wins! Both press Ready -> Auto-deal 3 owned balls -> Ban 1 -> Pick 1."
  override val createRoomButton = "CREATE ROOM"
  override val joinRoomButton = "JOIN ROOM"
  override val roomCodePlaceholder = "Room Code (e.g. HCT992)"
  override val roomCodeLabel = "Room:"
  override val waitingOpponentLabel = "Waiting for opponent..."
  override val readyButton = "READY"
  override val unreadyButton = "CANCEL READY"
  override val readyBadge = "Ready"
  override val waitingReadyLabel = "Waiting for both players to Ready"
  override val autoDraftHint = "System auto-dealt 3 random balls from your owned roster for this round!"
  override val phasePick3Title = "DEALING 3 OWNED BALLS..."
  override val phaseBan1Title = "STEP 1/2: BAN 1 OPPONENT BALL"
  override val phaseFinalPickTitle = "STEP 2/2: PICK YOUR FIGHTER"
  override val lockSelectionButton = "CONFIRM"
  override val banBallButton = "BAN BALL"
  override val launchOnlineBattleButton = "ENTER BATTLE"
  override val speedRewardNote = "FT3 Match Win Bonus: <=15s +240 Coins • <=25s +190 Coins"
  override val loserNoLossNote = "Loser loses 0 Coins!"
  override val leaveRoomButton = "Leave"
  override val pingLabel = "Ping"
  override val opponentOnlineLabel = "Connected"
  override val opponentOfflineWarning = "Opponent disconnected from room!"
  override val claimDisconnectWinButton = "CLAIM FORFEIT WIN"
  override val chatPlaceholder = "Chat with opponent..."
  override val sendChatButton = "Send"
  override val chatEmptyHint = "No messages yet. Say hello!"
  override val roundSeriesLabel = "Round"
  override val roundResultNextLabel = "Round finished! Returning to room to deal 3 fresh random balls."
  override val nextRoundButton = "NEXT ROUND"
  override val matchFinishedTitle = "FT3 SERIES RESULT"
  override val emoteBarLabel = "Emotes"
  override val inviteFriendButton = "INVITE FRIEND"
  override val inviteSentMsg = "Room invite sent!"
  override val incomingInviteTitle = "1VS1 INVITE"
  override val acceptInviteButton = "JOIN NOW"
  override val dismissInviteButton = "Dismiss"
  override val confirmAimButton = "LOCK AIM"
  override val waitingOpponentAimLabel = "Waiting for opponent's aim..."
  override val enteringBattleLabel = "Entering battle..."
  override val ballTrialBadgePrefix = "Trial:"
  override val quickMatchButton = "QUICK RANDOM MATCH"
  override val quickMatchDesc = "Instantly pairs with any live player searching and jumps straight into FT3 Pick/Ban."
  override val quickMatchSearching = "Searching for an online opponent..."
  override val quickMatchCancel = "CANCEL SEARCH"
  override val quickMatchFound = "Opponent found! Entering FT3 Pick/Ban..."
  override val friendsTitle = "FRIENDS & ID"
  override val friendsTabList = "Friends"
  override val friendsTabRequests = "Requests"
  override val friendsTabSearch = "Find"
  override val searchPlayerHint = "Enter BVB-... ID or Nickname"
  override val searchButton = "Find"
  override val sendFriendRequestButton = "Add Friend"
  override val friendRequestSentMsg = "Friend request sent!"
  override val alreadyFriendsLabel = "Friends"
  override val pendingLabel = "Pending"
  override val acceptButton = "Accept"
  override val declineButton = "Decline"
  override val noFriendsHint = "No friends yet. Share your BVB ID or search to connect!"
  override val noRequestsHint = "No pending friend requests."
  override val friendsNeedGoogleMsg = "Sign in with Google to use Friends & Room Invites."
  override val selectArenaTitle = "OFFLINE ARENA"
  override val modeLabel = "Mode"
  override val mode1vAI = "1 vs AI"
  override val mode1v1 = "1 vs 1"
  override val player1Label = "Player 1"
  override val player2Label = "Player 2"
  override val aiOpponentLabel = "AI Bot"
  override val lockedLabel = "Locked"
  override val unlockedTrialLabel = "24h Trial"
  override val unlockInShopHint = "Claim daily login, redeem TriAn (+5,000 Coins) or spin Gacha for Rare Ant Ball!"
  override val fightButton = "START MATCH"
  override val passiveRuleNote = "Aim once to launch — balls fight autonomously via physics & passives."
  override val fireBallName = "Fire Ball"
  override val fireBallTagline = "Flame Core • Realm of Fire"
  override val firePassiveDesc = "Passive — Realm of Fire: Within 5s, ignites all 4 walls for 15s. Wall hits burn 2% max HP/sec (no delay, 3s) & slow 40% (2s)."
  override val fireNormalTitle = "Skill 1: Plasma Laser Web"
  override val fireNormalDesc = "Plants Fire Chips on walls and links laser beams burning 2 dmg/0.25s across enemy paths."
  override val fireUltTitle = "Rage 100%: Fire Fury"
  override val fireUltDesc = "Blazes across the whole arena for 5s, dealing 6% max HP/sec + meteor burst."
  override val waterBallName = "Water Ball"
  override val waterBallTagline = "Hydro Core • Tidal Surge"
  override val waterPassiveDesc = "Passive — Tidal Surge: Wall hits grant +8% speed (up to 3 stacks) and hasten Aqua Orbs."
  override val waterNormalTitle = "Skill 1: Vortex Trap & Aqua Orb"
  override val waterNormalDesc = "70% chance to drop a spinning whirlpool trap (20 dmg) plus homing Aqua Orbs."
  override val waterUltTitle = "Rage 100%: Tsunami"
  override val waterUltDesc = "Sweeps the arena with a tidal wave (bonus vs Fire), pushing back & clearing traps."
  override val groundBallName = "Ground Ball"
  override val groundBallTagline = "Terra Core • Heavy Bastion"
  override val groundPassiveDesc = "Passive — Bastion Resonance: Clashes briefly stagger foes (-15% speed) with heavy knockback."
  override val groundNormalTitle = "Skill 1 (5s CD): Seismic Charge"
  override val groundNormalDesc = "Reduces incoming dmg 10% while charging, then unleashes 3 Quake waves (12 dmg + 60% slow) clearing nearby Soldier Ants."
  override val groundUltTitle = "Rage / 18s: Earth Aegis (5s)"
  override val groundUltDesc = "Stone armor grants 100% CC immunity (blocks Absolute Zero freeze) and 30% damage reduction for 5s."
  override val thunderBallName = "Thunder Ball"
  override val thunderBallTagline = "Volt Core • Static Afterimages"
  override val thunderPassiveDesc = "Passive — Static Capacitor: Builds charge while moving, adding shock dmg & +5 Rage on clash."
  override val thunderNormalTitle = "Skill 1 (5s CD): Supersonic Scatter"
  override val thunderNormalDesc = "Scatters 80-100 afterimages across the arena for 3.5s (+1% Rage when touched)."
  override val thunderUltTitle = "Rage 100%: Deathbolt"
  override val thunderUltDesc = "Calls down sky lightning dealing 32% current HP (+2% stack) & 2s Skill Silence."
  override val iceBallName = "Ice Ball"
  override val iceBallTagline = "Cryo Core • Absolute Zero"
  override val icePassiveDesc = "Passive — Permafrost Aura: Chills enemies within 200px & builds Ice Shards faster (0.68s)."
  override val iceNormalTitle = "Skill 1 (10s CD): Crystal Volley"
  override val iceNormalDesc = "Builds 5 shards to fire 5 spears (6 dmg + 70% slow); active boosts shard speed +70%."
  override val iceUltTitle = "Rage / 20s: Absolute Zero (10s)"
  override val iceUltDesc = "Freezes the arena & enemies for 10s, draining 70% enemy Rage immediately while Ice attacks freely; applies 40% slow after thaw."
  override val antBallName = "Ant Ball"
  override val antBallTagline = "Swarm Core • Royal Colony"
  override val antPassiveDesc = "Passive — Ant Cell Regeneration: Spawns a full 100% HP Ant Ball every 16s (max 3 total). Opponents must defeat ALL Ant Balls!"
  override val antNormalTitle = "Skill 1 (8s CD): Swarm Release"
  override val antNormalDesc = "Spawns 1/3/5/7/10 fast Soldier Ants: persist FOREVER until hitting an enemy (5 dmg + 0.5s slow)."
  override val antUltTitle = "Rage 100%: Queen (90%) • King (8%) • Both (1%)"
  override val antUltDesc = "Queen buffs ants +15% size, 7 dmg, 1%/s stun venom. King adds +10% speed, 3%/s venom & heals 20 HP/16s. Both = 2x all buffs!"
  override val waterAdvantageBadge = "Counters Fire"
  override val statsSummary = "Balanced 6-Ball Roster • 120Hz Physics"
  override val shopTitle = "SHOP & GACHA"
  override val tabBalls = "Balls"
  override val tabKillEffects = "KO Effects"
  override val buyButton = "Buy"
  override val equipButton = "Equip"
  override val equippedLabel = "Equipped"
  override val freeTrialActiveLabel = "24h Trial"
  override val notEnoughCoins = "Not enough Coins!"
  override val purchasedSuccess = "Unlocked & equipped!"
  override val gachaTitle = "LUCKY GACHA"
  override val gachaSubtitle = "Spin for Uncommon & Rare Ant Ball! Pity guaranteed on spin #10."
  override val gachaSpinButton = "SPIN • 120 Coins"
  override val gachaPityLabel = "Pity Counter"
  override val gachaOddsLabel = "Common 70% • Uncommon 22% • Rare 8%"
  override val gachaResultNew = "NEW BALL UNLOCKED!"
  override val gachaResultDup = "Duplicate! Refund"
  override val gachaPityTriggered = "PITY TRIGGERED!"
  override val effectDefaultName = "Core Burst"
  override val effectDefaultDesc = "Classic elemental particle burst upon knockout."
  override val effectShockwaveName = "Shockwave Rings"
  override val effectShockwaveDesc = "Triple expanding neon shockwave rings across the arena."
  override val effectNovaName = "Particle Nova"
  override val effectNovaDesc = "90-particle luminous supernova with gravity sparks."
  override val effectDissolveName = "Elemental Dissolve"
  override val effectDissolveDesc = "Disintegrates the defeated fighter into rising embers."
  override val codeDialogTitle = "REDEEM GIFTCODE"
  override val codeDialogDesc = "Try TriAn (+5,000 Coins, 7-day limit), TaiDz-111 (free Thunder Ball) or TanThu (24h all balls)."
  override val codePlaceholder = "Enter code..."
  override val redeemButton = "REDEEM"
  override val closeButton = "Close"
  override val codeSentToMailboxMsg = "Success! Reward delivered to your Mailbox."
  override val codeSuccessMsg = "TanThu activated! All balls unlocked for 24h."
  override val codeAlreadyRedeemedMsg = "Code already redeemed!"
  override val codeAlreadyActiveMsg = "TanThu 24h trial is already active!"
  override val codeExpiredOrInvalidMsg = "Invalid or expired code."
  override val codeInvalidMsg = "Invalid or expired code."
  override val settingsTitle = "SETTINGS"
  override val sectionAccount = "Account"
  override val sectionLanguage = "Language / Ngôn ngữ"
  override val languageVi = "Tiếng Việt"
  override val languageEn = "English"
  override val sectionCombat = "Combat & AI"
  override val aiDifficultyLabel = "AI Difficulty"
  override val diffEasy = "Easy"
  override val diffNormal = "Normal"
  override val diffHard = "Hard"
  override val targetFpsLabel = "Frame Rate"
  override val gameSpeedLabel = "Match Speed"
  override val sectionVisuals = "Graphics & VFX"
  override val graphicsQualityLabel = "VFX Detail Preset"
  override val qualityLow = "Low"
  override val qualityMedium = "Medium"
  override val qualityHigh = "High"
  override val qualityUltra = "Ultra"
  override val autoReduceLagLabel = "Auto Lag-Guard (FPS)"
  override val autoLagActiveTag = "Auto-Scaled"
  override val bloomShaderLabel = "Bloom Glow & Shaders"
  override val trailsLabel = "Motion Trails"
  override val shakeLabel = "Screen Shake"
  override val hitStopLabel = "Impact Hit-Stop"
  override val floatingDamageLabel = "Floating Damage"
  override val showFpsLabel = "Show FPS"
  override val sectionAudio = "44.1kHz Stereo Audio"
  override val sfxLabel = "Sound Effects (SFX)"
  override val sfxVolumeLabel = "SFX Volume"
  override val musicLabel = "Arena Music"
  override val musicVolumeLabel = "Music Volume"
  override val resetProgressButton = "Reset Progress"
  override val resetConfirmTitle = "Reset all data?"
  override val resetConfirmDesc = "Coins, unlocked balls, streak & Gacha Pity will reset."
  override val confirmYes = "Confirm"
  override val cancel = "Cancel"
  override val aimP1Prompt = "Drag to aim your launch"
  override val aimP2Prompt = "Player 2: Drag to aim"
  override val aiAimingPrompt = "Opponent calculating angle..."
  override val launchButton = "LAUNCH"
  override val battleAutoTag = "AUTO PHYSICS BATTLE"
  override val burnStatus = "BURNING"
  override val soakStatus = "SLOWED"
  override val silenceStatus = "SILENCED"
  override val armorStatus = "ARMORED"
  override val frozenStatus = "FROZEN"
  override val trappedStatus = "TRAPPED"
  override val venomStatus = "VENOM"
  override val exitMatch = "Exit"
  override val pauseMatch = "Pause"
  override val resumeMatch = "Resume"
  override val koTitle = "KNOCKOUT!"
  override val winnerP1 = "VICTORY!"
  override val winnerP2 = "OPPONENT WINS!"
  override val winnerAi = "AI WINS!"
  override val damageDealtLabel = "Damage"
  override val skillsUsedLabel = "Skills"
  override val matchTimeLabel = "Duration"
  override val rewardCoinsLabel = "Coins Earned"
  override val rematchButton = "REMATCH"
  override val mainMenuButton = "MENU"
  override val exportApkButton = "EXPORT APK"
  override val exportApkDialogTitle = "EXPORT APK"
  override val exportApkDialogDesc = "Package and export Ball vs Ball's installable APK to storage or share."
  override val exportApkSaveDevice = "Save APK to Device"
  override val exportApkShare = "Share APK File"
  override val exportApkWorking = "Packaging APK..."
  override val exportApkSuccess = "APK exported successfully!"
  override val exportApkError = "Unable to export APK on this device."
  override val updateDialogTitle = "NEW UPDATE AVAILABLE!"
  override val updateMandatoryBadge = "Required"
  override val updateOptionalBadge = "Recommended"
  override val updateNotesLabel = "What's New:"
  override val updatePermissionHint = "Opens the signed APK download link so Android can prompt direct update installation."
  override val updateNowButton = "UPDATE NOW"
  override val updateLaterButton = "Later"
  override val updateLinkError = "Download URL must start with https://"
  override val sectionAppUpdate = "Version & Updates"
  override val currentVersionLabel = "Installed"
  override val latestCloudVersionLabel = "Latest Cloud"
  override val checkUpdateButton = "Check for Updates"
  override val upToDateMsg = "You are on the latest v1.0.3 Beta!"
  override val adminReleaseSection = "App APK Release Manager"
  override val adminReleaseHint = "Drag & drop or pick an APK to upload directly to GitHub Releases for 1-tap auto-update, or paste a Betadrop web link."
  override val adminVersionCodeLabel = "Latest Version Code"
  override val adminMinVersionCodeLabel = "Min Supported Code"
  override val adminVersionNameLabel = "Version Name (e.g. 1.0.3 Beta)"
  override val adminDownloadUrlLabel = "APK / Web Download URL (https://...)"
  override val adminReleaseNotesViLabel = "Release Notes VI"
  override val adminReleaseNotesEnLabel = "Release Notes EN"
  override val adminApkDropTitle = "Drop .APK file here"
  override val adminApkDropHint = "Auto-reads Version Code, Version Name & APK size."
  override val adminPickApkButton = "SELECT APK FILE"
  override val adminGithubRepoLabel = "GitHub Repo (e.g. owner/repo)"
  override val adminGithubTokenLabel = "GitHub Token (stored locally only)"
  override val adminGithubTokenHint = "Stored strictly in local Admin preferences and never uploaded to Firestore."
  override val adminUploadPublishButton = "UPLOAD & PUBLISH NOW"
  override val adminVersionWarningLow = "Warning: APK Version Code must be higher than current version for players to receive updates!"
  override val adminFixVersionCodeButton = "Bump +1 Code"
  override val adminUploadMissingFields = "Please select an APK file and provide GitHub owner/repo + Token."
  override val updateDownloadingLabel = "Downloading APK update..."
  override val updateInstallPermissionNeeded = "Allow 'Install unknown apps' for Ball vs Ball for 1-tap update."
  override val updateOpenSettingsButton = "ALLOW INSTALLS"
  override val updateReadyInstallButton = "INSTALL APK NOW"
  override val updateOpeningBrowserMsg = "Opening update download page..."
  override val updateRetryButton = "Retry"
}

fun stringsFor(language: AppLanguage): GameStrings =
  when (language) {
    AppLanguage.VI -> ViGameStrings
    AppLanguage.EN -> EnGameStrings
  }
