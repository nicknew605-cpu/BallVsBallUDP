package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.audio.ProceduralSoundEngine
import com.example.audio.SoundEffect
import com.example.auth.GoogleAuthHelper
import com.example.data.GamePreferencesRepository
import com.example.data.cloud.CloudGameRepository
import com.example.data.cloud.OnlineRoomRepository
import com.example.model.AccountMode
import com.example.model.ApkPackageInfo
import com.example.model.ApkUpdateState
import com.example.model.BallType
import com.example.model.CodeRedeemResult
import com.example.model.DailyRewardTier
import com.example.model.FriendEntry
import com.example.model.FriendRequestEntry
import com.example.model.GachaSpinResult
import com.example.model.GameMode
import com.example.model.GameSettings
import com.example.model.GitHubUploadState
import com.example.model.KillEffectType
import com.example.model.MailboxLetter
import com.example.model.MatchmakingUiState
import com.example.model.OnlineEmote
import com.example.model.OnlineRoomPhase
import com.example.model.OnlineRoomState
import com.example.model.OtaBalanceConfig
import com.example.model.OtaLiveConfig
import com.example.model.PlayerDirectoryEntry
import com.example.model.RoomChatMessage
import com.example.model.RoomInviteEntry
import com.example.model.ShopPurchaseResult
import com.example.model.UserProgress
import com.example.util.AppUpdateManager
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class StartupPhase {
  LOADING,
  AUTH_REQUIRED,
  READY,
}

data class MatchSetup(
  val mode: GameMode = GameMode.ONE_VS_AI,
  val p1Ball: BallType = BallType.FIRE,
  val p2Ball: BallType = BallType.WATER,
  val seed: Long = System.nanoTime(),
  val onlineRoomCode: String? = null,
  val p1DisplayName: String = "P1",
  val p2DisplayName: String = "AI",
  val localPlayerSide: Int = 1,
)

data class OnlineEmoteEvent(
  val playerId: Int,
  val emote: OnlineEmote,
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
  private val appContext = application.applicationContext
  private val repository = GamePreferencesRepository(appContext)
  private val cloudRepo by lazy { CloudGameRepository(appContext) }
  private val roomRepo by lazy { OnlineRoomRepository(appContext) }
  val soundEngine = ProceduralSoundEngine()

  val userProgress: StateFlow<UserProgress> =
    repository.userProgressFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.Eagerly,
      initialValue = UserProgress(),
    )

  val gameSettings: StateFlow<GameSettings> =
    repository.gameSettingsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.Eagerly,
      initialValue = GameSettings(),
    )

  private val _nowMillis = MutableStateFlow(System.currentTimeMillis())
  val nowMillis: StateFlow<Long> = _nowMillis.asStateFlow()

  private val _matchSetup = MutableStateFlow(MatchSetup())
  val matchSetup: StateFlow<MatchSetup> = _matchSetup.asStateFlow()

  private val _startupPhase = MutableStateFlow(StartupPhase.LOADING)
  val startupPhase: StateFlow<StartupPhase> = _startupPhase.asStateFlow()

  private val _accountMode = MutableStateFlow(AccountMode.GUEST)
  val accountMode: StateFlow<AccountMode> = _accountMode.asStateFlow()

  private val _loadingProgress = MutableStateFlow(0.2f)
  val loadingProgress: StateFlow<Float> = _loadingProgress.asStateFlow()

  private val _loadingStatus = MutableStateFlow("")
  val loadingStatus: StateFlow<String> = _loadingStatus.asStateFlow()

  private val _currentUid = MutableStateFlow<String?>(null)
  val currentUid: StateFlow<String?> = _currentUid.asStateFlow()

  private val _authBusy = MutableStateFlow(false)
  val authBusy: StateFlow<Boolean> = _authBusy.asStateFlow()

  private val _authError = MutableStateFlow<String?>(null)
  val authError: StateFlow<String?> = _authError.asStateFlow()

  private val _otaConfig = MutableStateFlow(OtaLiveConfig())
  val otaConfig: StateFlow<OtaLiveConfig> = _otaConfig.asStateFlow()

  private val _appUpdateDismissed = MutableStateFlow(false)
  val appUpdateDismissed: StateFlow<Boolean> = _appUpdateDismissed.asStateFlow()

  private val _apkUpdateState = MutableStateFlow<ApkUpdateState>(ApkUpdateState.Idle)
  val apkUpdateState: StateFlow<ApkUpdateState> = _apkUpdateState.asStateFlow()

  private val _githubUploadState = MutableStateFlow<GitHubUploadState>(GitHubUploadState.Idle)
  val githubUploadState: StateFlow<GitHubUploadState> = _githubUploadState.asStateFlow()

  private val _isAdmin = MutableStateFlow(false)
  val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

  private val _mailbox = MutableStateFlow<List<MailboxLetter>>(emptyList())
  val mailbox: StateFlow<List<MailboxLetter>> = _mailbox.asStateFlow()

  private val _friends = MutableStateFlow<List<FriendEntry>>(emptyList())
  val friends: StateFlow<List<FriendEntry>> = _friends.asStateFlow()

  private val _incomingFriendRequests = MutableStateFlow<List<FriendRequestEntry>>(emptyList())
  val incomingFriendRequests: StateFlow<List<FriendRequestEntry>> = _incomingFriendRequests.asStateFlow()

  private val _incomingRoomInvites = MutableStateFlow<List<RoomInviteEntry>>(emptyList())
  val incomingRoomInvites: StateFlow<List<RoomInviteEntry>> = _incomingRoomInvites.asStateFlow()

  private val _activeRoom = MutableStateFlow<OnlineRoomState?>(null)
  val activeRoom: StateFlow<OnlineRoomState?> = _activeRoom.asStateFlow()

  private val _roomChat = MutableStateFlow<List<RoomChatMessage>>(emptyList())
  val roomChat: StateFlow<List<RoomChatMessage>> = _roomChat.asStateFlow()

  private val _roomPingMs = MutableStateFlow(0L)
  val roomPingMs: StateFlow<Long> = _roomPingMs.asStateFlow()

  private val _roomBusy = MutableStateFlow(false)
  val roomBusy: StateFlow<Boolean> = _roomBusy.asStateFlow()

  private val _onlineEmoteEvents = MutableSharedFlow<OnlineEmoteEvent>(extraBufferCapacity = 16)
  val onlineEmoteEvents: SharedFlow<OnlineEmoteEvent> = _onlineEmoteEvents.asSharedFlow()

  private val _matchmakingState = MutableStateFlow<MatchmakingUiState>(MatchmakingUiState.Idle)
  val matchmakingState: StateFlow<MatchmakingUiState> = _matchmakingState.asStateFlow()

  private var cloudObserversJob: Job? = null
  private var roomObserverJob: Job? = null
  private var roomSyncJob: Job? = null
  private var roomChatJob: Job? = null
  private var roomHeartbeatJob: Job? = null
  private var matchmakingJob: Job? = null
  private var lastSyncedPhaseKey: String? = null
  private var lastHostEmoteAtSeen = 0L
  private var lastGuestEmoteAtSeen = 0L
  private var recordedSeriesRewardKey: String? = null

  init {
    soundEngine.start(viewModelScope)

    viewModelScope.launch {
      repository.ensureVaultInitialized()
      repository.ensurePlayerCode()
      repository.checkAndReconcileTanThuExpiration()
      bootstrapStartupSession()
    }

    viewModelScope.launch {
      gameSettings.collectLatest { settings ->
        soundEngine.updateSettings(
          sfxOn = settings.sfxEnabled,
          musicOn = settings.musicEnabled,
          sfxVol = settings.sfxVolume,
          musicVol = settings.musicVolume,
        )
      }
    }

    viewModelScope.launch {
      while (isActive) {
        val now = System.currentTimeMillis()
        _nowMillis.value = now
        val progress = userProgress.value
        val hasExpiredTanThu = progress.tanThuActivatedAtMillis > 0L && !progress.isTanThuActive(now)
        val hasExpiredTrial = progress.ballTrials.any { it.value <= now }
        if (hasExpiredTanThu || hasExpiredTrial) {
          repository.checkAndReconcileTanThuExpiration(now)
        }
        delay(1000L)
      }
    }
  }

  private suspend fun bootstrapStartupSession() {
    _startupPhase.value = StartupPhase.LOADING
    _loadingProgress.value = 0.25f
    val existingUser = GoogleAuthHelper.attemptAutoSignIn(appContext)
    if (existingUser != null) {
      _accountMode.value = AccountMode.GOOGLE
      repository.setGuestSession(active = false)
      _currentUid.value = existingUser.uid
      syncCloudAndEnterMenu(mergeGuestProgress = false)
    } else if (repository.isGuestSessionFlow.first()) {
      _accountMode.value = AccountMode.GUEST
      _currentUid.value = GUEST_UID
      _isAdmin.value = false
      _otaConfig.value = OtaLiveConfig(syncedFromCloud = false)
      _loadingProgress.value = 1.0f
      delay(160L)
      _startupPhase.value = StartupPhase.READY
    } else {
      _currentUid.value = null
      _startupPhase.value = StartupPhase.AUTH_REQUIRED
    }
  }

  fun continueAsGuest(nicknameInput: String) {
    if (_authBusy.value) return
    viewModelScope.launch {
      _authBusy.value = true
      _authError.value = null
      val cleanNick = nicknameInput.trim().take(24).ifBlank { "Guest" }
      repository.setGuestSession(active = true, nickname = cleanNick)
      repository.ensurePlayerCode()
      _accountMode.value = AccountMode.GUEST
      _currentUid.value = GUEST_UID
      _isAdmin.value = false
      _mailbox.value = emptyList()
      _friends.value = emptyList()
      _incomingFriendRequests.value = emptyList()
      _incomingRoomInvites.value = emptyList()
      _otaConfig.value = OtaLiveConfig(syncedFromCloud = false)
      _loadingProgress.value = 1.0f
      _startupPhase.value = StartupPhase.READY
      _authBusy.value = false
      soundEngine.play(SoundEffect.ROOM_READY)
    }
  }

  fun signInWithGoogle(activityContext: Context, nicknameInput: String = "", onSuccessCallback: (() -> Unit)? = null) {
    if (_authBusy.value) return
    viewModelScope.launch {
      _authBusy.value = true
      _authError.value = null
      val wasGuest = _accountMode.value == AccountMode.GUEST || repository.isGuestSessionFlow.first()
      val res = GoogleAuthHelper.signInWithGoogle(activityContext)
      res.onSuccess { user ->
        val cleanNick = nicknameInput.trim().take(24)
        if (cleanNick.isNotEmpty()) {
          repository.setNickname(cleanNick)
        }
        repository.setGuestSession(active = false)
        _accountMode.value = AccountMode.GOOGLE
        _currentUid.value = user.uid
        _startupPhase.value = StartupPhase.LOADING
        syncCloudAndEnterMenu(mergeGuestProgress = wasGuest)
        onSuccessCallback?.invoke()
      }.onFailure { err ->
        _authError.value = err.localizedMessage ?: "Google Sign-In failed"
      }
      _authBusy.value = false
    }
  }

  fun signOut(activityContext: Context) {
    viewModelScope.launch {
      cloudObserversJob?.cancel()
      leaveOnlineRoom()
      _mailbox.value = emptyList()
      _friends.value = emptyList()
      _incomingFriendRequests.value = emptyList()
      _incomingRoomInvites.value = emptyList()
      _isAdmin.value = false
      repository.setGuestSession(active = false)
      if (Firebase.auth.currentUser != null) {
        GoogleAuthHelper.signOut(activityContext)
      }
      _accountMode.value = AccountMode.GUEST
      _currentUid.value = null
      _startupPhase.value = StartupPhase.AUTH_REQUIRED
    }
  }

  private suspend fun syncCloudAndEnterMenu(mergeGuestProgress: Boolean) {
    _loadingProgress.value = 0.55f
    _isAdmin.value = cloudRepo.isAdminAccount()
    runCatching {
      val liveOta = cloudRepo.fetchOtaLiveConfig()
      _otaConfig.value = liveOta
    }
    _loadingProgress.value = 0.80f
    runCatching {
      val localFallback = userProgress.value
      val synced = cloudRepo.ensureOrLoadUserProfile(localFallback, mergeFromGuest = mergeGuestProgress)
      repository.applySyncedProgress(synced)
    }
    startCloudListeners()
    _loadingProgress.value = 1.0f
    delay(200L)
    _startupPhase.value = StartupPhase.READY
  }

  private fun startCloudListeners() {
    cloudObserversJob?.cancel()
    if (Firebase.auth.currentUser == null) return
    cloudObserversJob = viewModelScope.launch {
      launch {
        cloudRepo.observeUserProfile()
          .catch { /* keep local vault */ }
          .collectLatest { cloudProg ->
            repository.applySyncedProgress(cloudProg)
          }
      }
      launch {
        cloudRepo.observeMailbox()
          .catch { /* ignore transient offline */ }
          .collectLatest { letters ->
            _mailbox.value = letters
          }
      }
      launch {
        cloudRepo.observeOtaLiveConfig()
          .catch { /* ignore transient offline */ }
          .collectLatest { liveOta ->
            val prevVersion = _otaConfig.value.appUpdate.latestVersionCode
            _otaConfig.value = liveOta
            if (liveOta.appUpdate.latestVersionCode > prevVersion &&
              liveOta.appUpdate.isUpdateAvailable(BuildConfig.VERSION_CODE)
            ) {
              _appUpdateDismissed.value = false
              _apkUpdateState.value = ApkUpdateState.Idle
            }
          }
      }
      launch {
        cloudRepo.observeFriends()
          .catch { }
          .collectLatest { list -> _friends.value = list }
      }
      launch {
        cloudRepo.observeIncomingFriendRequests()
          .catch { }
          .collectLatest { list -> _incomingFriendRequests.value = list }
      }
      launch {
        cloudRepo.observeIncomingRoomInvites()
          .catch { }
          .collectLatest { list -> _incomingRoomInvites.value = list }
      }
    }
  }

  private suspend fun pushLocalProgressToCloud(updated: UserProgress) {
    if (Firebase.auth.currentUser != null) {
      runCatching { cloudRepo.saveUserProgress(updated) }
    }
  }

  suspend fun claimDailyLoginReward(): DailyRewardTier? {
    val claimed = repository.claimDailyLoginReward(System.currentTimeMillis()) ?: return null
    pushLocalProgressToCloud(userProgress.value)
    soundEngine.play(SoundEffect.DAILY_REWARD)
    return claimed
  }

  fun saveNickname(rawName: String) {
    viewModelScope.launch {
      val updated = repository.setNickname(rawName)
      pushLocalProgressToCloud(updated)
      soundEngine.play(SoundEffect.CODE_UNLOCK)
    }
  }

  fun updateMatchSetup(transform: (MatchSetup) -> MatchSetup) {
    _matchSetup.value = transform(_matchSetup.value)
  }

  fun syncEquippedBallToSetup() {
    val progress = userProgress.value
    val now = _nowMillis.value
    val p1 =
      if (progress.isBallAvailable(progress.equippedBall, now)) progress.equippedBall
      else BallType.FIRE
    val defaultP2 =
      if (_matchSetup.value.p2Ball != p1) _matchSetup.value.p2Ball
      else if (p1 == BallType.FIRE) BallType.WATER else BallType.FIRE
    _matchSetup.value =
      _matchSetup.value.copy(
        p1Ball = p1,
        p2Ball = defaultP2,
        seed = System.nanoTime(),
        onlineRoomCode = null,
        p1DisplayName = progress.nickname.ifBlank { "P1" },
        p2DisplayName = if (_matchSetup.value.mode == GameMode.ONE_VS_AI) "AI" else "P2",
        localPlayerSide = 1,
      )
  }

  fun effectiveArenaBalance(): OtaBalanceConfig =
    if (_matchSetup.value.mode == GameMode.ONLINE_1VS1) {
      _activeRoom.value?.balanceSnapshot ?: _otaConfig.value.balance
    } else {
      _otaConfig.value.balance
    }

  fun playUiTap() {
    soundEngine.play(SoundEffect.UI_TAP)
  }

  fun dismissAppUpdatePrompt() {
    _appUpdateDismissed.value = true
  }

  fun startAppUpdateDownload(context: Context) {
    val appUpdate = _otaConfig.value.appUpdate
    if (!appUpdate.isUpdateAvailable(BuildConfig.VERSION_CODE)) return
    viewModelScope.launch {
      AppUpdateManager.downloadOrOpenUpdate(
        context = context,
        rawUrl = appUpdate.downloadUrl,
        versionCode = appUpdate.latestVersionCode,
        onState = { st -> _apkUpdateState.value = st },
      )
    }
  }

  fun resetAppUpdateState() {
    _apkUpdateState.value = ApkUpdateState.Idle
  }

  fun installReadyApkIfPermitted(context: Context, apkPath: String) {
    if (!AppUpdateManager.canInstallPackages(context)) {
      _apkUpdateState.value = ApkUpdateState.NeedsInstallPermission(apkPath)
      AppUpdateManager.openInstallPermissionSettings(context)
    } else {
      _apkUpdateState.value = ApkUpdateState.ReadyToInstall(apkPath)
      AppUpdateManager.launchApkInstaller(context, apkPath)
    }
  }

  suspend fun refreshOtaConfig(): Result<OtaLiveConfig> =
    runCatching {
      val liveOta = cloudRepo.fetchOtaLiveConfig()
      _otaConfig.value = liveOta
      if (liveOta.appUpdate.isUpdateAvailable(BuildConfig.VERSION_CODE)) {
        _appUpdateDismissed.value = false
      }
      liveOta
    }

  suspend fun publishAdminOtaConfig(updated: OtaLiveConfig): Result<OtaLiveConfig> {
    if (!cloudRepo.isAdminAccount()) {
      return Result.failure(IllegalStateException("Unauthorized"))
    }
    return runCatching {
      val saved = cloudRepo.saveOtaLiveConfig(updated)
      _otaConfig.value = saved
      soundEngine.play(SoundEffect.CODE_UNLOCK)
      saved
    }
  }

  suspend fun uploadApkAndPublishOta(
    repo: String,
    token: String,
    apkInfo: ApkPackageInfo,
    updatedDraft: OtaLiveConfig,
  ): Result<OtaLiveConfig> {
    if (!cloudRepo.isAdminAccount()) {
      return Result.failure(IllegalStateException("Unauthorized"))
    }
    val notes = updatedDraft.appUpdate.releaseNotesVi.ifBlank { updatedDraft.appUpdate.releaseNotesEn }
    val uploadRes =
      AppUpdateManager.uploadApkToGitHubRelease(
        repoInput = repo,
        tokenInput = token,
        apkInfo = apkInfo,
        versionCode = updatedDraft.appUpdate.latestVersionCode,
        versionName = updatedDraft.appUpdate.latestVersionName,
        releaseNotes = notes,
        onProgress = { st -> _githubUploadState.value = st },
      )
    return uploadRes.fold(
      onSuccess = { url ->
        val toPublish =
          updatedDraft.copy(
            appUpdate = updatedDraft.appUpdate.copy(downloadUrl = url)
          )
        publishAdminOtaConfig(toPublish)
      },
      onFailure = { err ->
        _githubUploadState.value = GitHubUploadState.Failed(err.localizedMessage ?: "Upload failed")
        Result.failure(err)
      },
    )
  }

  suspend fun searchPlayers(query: String): List<PlayerDirectoryEntry> {
    if (Firebase.auth.currentUser == null) return emptyList()
    return cloudRepo.searchPlayers(query)
  }

  suspend fun sendFriendRequest(target: PlayerDirectoryEntry): Result<Unit> =
    runCatching {
      cloudRepo.sendFriendRequest(userProgress.value, target)
      soundEngine.play(SoundEffect.CODE_UNLOCK)
    }

  suspend fun respondFriendRequest(request: FriendRequestEntry, accept: Boolean): Result<Unit> =
    runCatching {
      cloudRepo.respondFriendRequest(request, accept, userProgress.value)
      soundEngine.play(SoundEffect.ROOM_READY)
    }

  suspend fun removeFriend(friendUid: String) {
    runCatching { cloudRepo.removeFriend(friendUid) }
  }

  suspend fun inviteFriendToRoom(friendUid: String): Result<OnlineRoomState> {
    if (Firebase.auth.currentUser == null) {
      return Result.failure(IllegalStateException("Google Sign-In required"))
    }
    return runCatching {
      val room =
        _activeRoom.value ?: run {
          val created = roomRepo.createRoom(userProgress.value.nickname, balanceSnapshot = _otaConfig.value.balance)
          observeRoom(created.roomCode)
          created
        }
      cloudRepo.sendRoomInvite(room.roomCode, userProgress.value.nickname, friendUid)
      soundEngine.play(SoundEffect.MAIL_NOTIFY)
      room
    }
  }

  suspend fun acceptRoomInvite(invite: RoomInviteEntry): Result<OnlineRoomState> {
    runCatching { cloudRepo.respondRoomInvite(invite.id, accept = true) }
    return joinOnlineRoom(invite.roomCode)
  }

  fun dismissRoomInvite(inviteId: String) {
    viewModelScope.launch {
      runCatching { cloudRepo.respondRoomInvite(inviteId, accept = false) }
    }
  }

  suspend fun sendTargetedAdminGift(
    targetUid: String,
    coins: Int,
    ball: BallType?,
    trialMinutes: Int,
    message: String,
  ): Result<Unit> =
    runCatching {
      cloudRepo.sendTargetedGiftToPlayer(
        targetUid = targetUid,
        rewardCoins = coins,
        rewardBall = ball,
        trialMinutes = trialMinutes,
        customMessageVi = message,
        customMessageEn = message,
      )
      soundEngine.play(SoundEffect.MAIL_NOTIFY)
    }

  suspend fun redeemCode(code: String): CodeRedeemResult {
    val outcome = repository.processGiftCode(code, _otaConfig.value, System.currentTimeMillis())
    if (outcome.letterToSend != null) {
      val l = outcome.letterToSend
      if (Firebase.auth.currentUser != null) {
        runCatching {
          cloudRepo.sendMailboxReward(
            mailId = l.id,
            sender = l.sender,
            titleVi = l.titleVi,
            titleEn = l.titleEn,
            bodyVi = l.bodyVi,
            bodyEn = l.bodyEn,
            rewardCoins = l.rewardCoins,
            rewardBall = l.rewardBall,
            sourceCode = l.sourceCode,
          )
        }
        pushLocalProgressToCloud(userProgress.value)
      } else {
        val updated = repository.claimMailboxReward(l)
        _mailbox.value = _mailbox.value + l.copy(claimed = true)
        pushLocalProgressToCloud(updated)
      }
      soundEngine.play(SoundEffect.MAIL_NOTIFY)
    } else if (outcome.status == CodeRedeemResult.SUCCESS_TRIAL_ACTIVATED) {
      pushLocalProgressToCloud(userProgress.value)
      soundEngine.play(SoundEffect.CODE_UNLOCK)
    }
    return outcome.status
  }

  suspend fun claimMailboxLetter(letter: MailboxLetter) {
    if (letter.claimed) return
    val updated = repository.claimMailboxReward(letter)
    if (Firebase.auth.currentUser != null) {
      runCatching {
        cloudRepo.markMailClaimed(letter.id)
        cloudRepo.saveUserProgress(updated)
      }
    }
    soundEngine.play(SoundEffect.GACHA_JACKPOT)
  }

  suspend fun buyOrEquipBall(ball: BallType): ShopPurchaseResult {
    val result = repository.buyOrEquipBall(ball)
    if (result == ShopPurchaseResult.SUCCESS || result == ShopPurchaseResult.ALREADY_OWNED) {
      pushLocalProgressToCloud(userProgress.value)
      soundEngine.play(SoundEffect.CODE_UNLOCK)
    }
    return result
  }

  suspend fun buyOrEquipKillEffect(effect: KillEffectType): ShopPurchaseResult {
    val result = repository.buyOrEquipKillEffect(effect)
    if (result == ShopPurchaseResult.SUCCESS || result == ShopPurchaseResult.ALREADY_OWNED) {
      pushLocalProgressToCloud(userProgress.value)
      soundEngine.play(SoundEffect.CODE_UNLOCK)
    }
    return result
  }

  suspend fun spinGacha(): GachaSpinResult {
    soundEngine.play(SoundEffect.GACHA_SPIN)
    val cost = _otaConfig.value.gachaSpinCost
    val result = repository.spinGacha(cost)
    if (result is GachaSpinResult.Success) {
      pushLocalProgressToCloud(userProgress.value)
      if (result.isNewUnlock || result.triggeredPity) {
        soundEngine.play(SoundEffect.GACHA_JACKPOT)
      } else {
        soundEngine.play(SoundEffect.CODE_UNLOCK)
      }
    }
    return result
  }

  fun updateSettings(transform: (GameSettings) -> GameSettings) {
    viewModelScope.launch { repository.updateSettings(transform) }
  }

  fun resetProgress() {
    viewModelScope.launch {
      val updated = repository.resetProgress()
      pushLocalProgressToCloud(updated)
      _matchSetup.value = MatchSetup()
    }
  }

  // Online 1vs1 FT3 Room Actions (Requires Google Auth)
  suspend fun createOnlineRoom(): Result<OnlineRoomState> {
    if (Firebase.auth.currentUser == null) {
      return Result.failure(IllegalStateException("Google Sign-In required for 1vs1 Online"))
    }
    cancelQuickMatchmaking()
    _roomBusy.value = true
    return try {
      val created =
        roomRepo.createRoom(
          hostNickname = userProgress.value.nickname,
          balanceSnapshot = _otaConfig.value.balance,
        )
      recordedSeriesRewardKey = null
      observeRoom(created.roomCode)
      soundEngine.play(SoundEffect.ROOM_READY)
      Result.success(created)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Result.failure(e)
    } finally {
      _roomBusy.value = false
    }
  }

  suspend fun joinOnlineRoom(roomCode: String): Result<OnlineRoomState> {
    if (Firebase.auth.currentUser == null) {
      return Result.failure(IllegalStateException("Google Sign-In required for 1vs1 Online"))
    }
    cancelQuickMatchmaking()
    _roomBusy.value = true
    return try {
      val joined = roomRepo.joinRoom(roomCode, userProgress.value.nickname)
      recordedSeriesRewardKey = null
      observeRoom(joined.roomCode)
      soundEngine.play(SoundEffect.ROOM_READY)
      Result.success(joined)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Result.failure(e)
    } finally {
      _roomBusy.value = false
    }
  }

  fun startQuickMatchmaking() {
    if (Firebase.auth.currentUser == null) {
      _matchmakingState.value = MatchmakingUiState.Failed("Google Sign-In required for 1vs1 Online")
      return
    }
    if (_roomBusy.value || matchmakingJob?.isActive == true) return
    matchmakingJob?.cancel()
    _matchmakingState.value = MatchmakingUiState.Searching(elapsedSec = 0)
    val nickname = userProgress.value.nickname

    matchmakingJob = viewModelScope.launch {
      try {
        val instantRoom =
          roomRepo.findAndClaimWaitingOpponent(
            myNickname = nickname,
            balanceSnapshot = _otaConfig.value.balance,
            respectTieBreaker = false,
          )
        if (instantRoom != null) {
          recordedSeriesRewardKey = null
          _matchmakingState.value = MatchmakingUiState.Matched(instantRoom.roomCode, instantRoom.guestName)
          soundEngine.play(SoundEffect.MATCH_FOUND)
          observeRoom(instantRoom.roomCode)
          return@launch
        }

        roomRepo.enqueueWaitingTicket(nickname)
        val ticketObserver = launch {
          roomRepo.observeMyMatchmakingTicket()
            .catch { /* rely on retry tick */ }
            .collect { ticket ->
              if (ticket != null && ticket.status == "matched" && ticket.roomCode.isNotBlank()) {
                val joined = runCatching {
                  roomRepo.joinRoom(ticket.roomCode, nickname, autoReady = true)
                }.getOrNull()
                roomRepo.cancelMatchmakingTicket()
                if (joined != null) {
                  recordedSeriesRewardKey = null
                  _matchmakingState.value = MatchmakingUiState.Matched(joined.roomCode, joined.hostName)
                  soundEngine.play(SoundEffect.MATCH_FOUND)
                  observeRoom(joined.roomCode)
                  matchmakingJob?.cancel()
                }
              }
            }
        }

        var elapsed = 0
        while (isActive) {
          delay(1000L)
          elapsed++
          _matchmakingState.value = MatchmakingUiState.Searching(elapsedSec = elapsed)
          if (elapsed % 3 == 0) {
            roomRepo.refreshWaitingTicketHeartbeat(nickname)
            val found =
              roomRepo.findAndClaimWaitingOpponent(
                myNickname = nickname,
                balanceSnapshot = _otaConfig.value.balance,
                respectTieBreaker = true,
              )
            if (found != null) {
              ticketObserver.cancel()
              recordedSeriesRewardKey = null
              _matchmakingState.value = MatchmakingUiState.Matched(found.roomCode, found.guestName)
              soundEngine.play(SoundEffect.MATCH_FOUND)
              observeRoom(found.roomCode)
              break
            }
          }
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        roomRepo.cancelMatchmakingTicket()
        _matchmakingState.value = MatchmakingUiState.Failed(e.localizedMessage ?: "Matchmaking failed")
      }
    }
  }

  fun cancelQuickMatchmaking() {
    matchmakingJob?.cancel()
    matchmakingJob = null
    if (_matchmakingState.value !is MatchmakingUiState.Matched) {
      _matchmakingState.value = MatchmakingUiState.Idle
    }
    viewModelScope.launch { roomRepo.cancelMatchmakingTicket() }
  }

  private fun observeRoom(roomCode: String) {
    roomObserverJob?.cancel()
    roomSyncJob?.cancel()
    roomChatJob?.cancel()
    roomHeartbeatJob?.cancel()
    lastSyncedPhaseKey = null
    lastHostEmoteAtSeen = 0L
    lastGuestEmoteAtSeen = 0L

    roomObserverJob = viewModelScope.launch {
      roomRepo.observeRoom(roomCode)
        .catch { _activeRoom.value = null }
        .collect { room ->
          _activeRoom.value = room
          if (room != null) {
            if (_matchmakingState.value !is MatchmakingUiState.Idle) {
              _matchmakingState.value = MatchmakingUiState.Idle
            }
            val uid = _currentUid.value.orEmpty()
            val amHost = room.isHost(uid)

            val myPicks = if (amHost) room.hostPicks else room.guestPicks
            val needsDeal = room.phase == OnlineRoomPhase.PICK_3 && room.guestUid.isNotBlank() && myPicks.isEmpty()
            val needsReconcile =
              when (room.phase) {
                OnlineRoomPhase.WAITING -> room.bothReady()
                OnlineRoomPhase.PICK_3 -> room.hostPicks.size == 3 && room.guestPicks.size == 3
                OnlineRoomPhase.BAN_1 -> room.hostBannedBall != null && room.guestBannedBall != null
                OnlineRoomPhase.FINAL_PICK -> room.hostFinalBall != null && room.guestFinalBall != null
                else -> false
              }
            if (needsDeal || needsReconcile) {
              val syncKey =
                "${room.roomCode}:${room.currentRound}:${room.phase.wireValue}:" +
                  "${room.hostPicks.size}:${room.guestPicks.size}:" +
                  "${room.hostBannedBall != null}:${room.guestBannedBall != null}:" +
                  "${room.hostFinalBall != null}:${room.guestFinalBall != null}:${room.bothReady()}"
              if (syncKey != lastSyncedPhaseKey && roomSyncJob?.isActive != true) {
                lastSyncedPhaseKey = syncKey
                roomSyncJob = viewModelScope.launch {
                  if (needsDeal) {
                    val now = System.currentTimeMillis()
                    val availableOwned =
                      BallType.entries.filter { userProgress.value.isBallAvailable(it, now) }.toSet()
                    val dealt = roomRepo.dealRandom3Balls(availableOwned)
                    runCatching { roomRepo.submitPick3(room, dealt) }
                  }
                  runCatching { roomRepo.reconcileRoomPhase(room.roomCode) }
                }
              }
            }

            // Dispatch remote/local emotes cleanly into live match canvas (Host = id 1, Guest = id 2)
            if (room.hostEmoteAtMs > lastHostEmoteAtSeen && room.hostEmote != null) {
              lastHostEmoteAtSeen = room.hostEmoteAtMs
              _onlineEmoteEvents.tryEmit(OnlineEmoteEvent(1, room.hostEmote))
            }
            if (room.guestEmoteAtMs > lastGuestEmoteAtSeen && room.guestEmote != null) {
              lastGuestEmoteAtSeen = room.guestEmoteAtMs
              _onlineEmoteEvents.tryEmit(OnlineEmoteEvent(2, room.guestEmote))
            }
          }
        }
    }

    roomChatJob = viewModelScope.launch {
      roomRepo.observeRoomChat(roomCode)
        .catch { /* keep existing chat */ }
        .collectLatest { msgs ->
          _roomChat.value = msgs
        }
    }

    roomHeartbeatJob = viewModelScope.launch {
      while (isActive) {
        val current = _activeRoom.value
        if (current != null && current.phase != OnlineRoomPhase.FINISHED) {
          val rtt = roomRepo.pingHeartbeat(current)
          if (rtt > 0L) _roomPingMs.value = rtt
          val stuckNeedsReconcile =
            when (current.phase) {
              OnlineRoomPhase.WAITING -> current.bothReady()
              OnlineRoomPhase.PICK_3 -> current.hostPicks.size == 3 && current.guestPicks.size == 3
              OnlineRoomPhase.BAN_1 -> current.hostBannedBall != null && current.guestBannedBall != null
              OnlineRoomPhase.FINAL_PICK -> current.hostFinalBall != null && current.guestFinalBall != null
              else -> false
            }
          if (stuckNeedsReconcile && roomSyncJob?.isActive != true) {
            runCatching { roomRepo.reconcileRoomPhase(current.roomCode) }
          }
        }
        delay(3000L)
      }
    }
  }

  suspend fun toggleRoomReady(ready: Boolean): Result<Unit> {
    val room = _activeRoom.value ?: return Result.failure(IllegalStateException("Room unavailable"))
    val now = System.currentTimeMillis()
    val ownedAvailable = BallType.entries.filter { userProgress.value.isBallAvailable(it, now) }.toSet()
    return runCatching {
      _roomBusy.value = true
      roomRepo.setReady(
        room = room,
        ready = ready,
        myOwnedBalls = ownedAvailable,
        activeBalance = _otaConfig.value.balance,
      )
      soundEngine.play(SoundEffect.ROOM_READY)
    }.also { _roomBusy.value = false }
  }

  suspend fun sendRoomChat(text: String) {
    val room = _activeRoom.value ?: return
    runCatching {
      roomRepo.sendChatMessage(room.roomCode, userProgress.value.nickname, text)
    }
  }

  fun sendBattleEmote(emote: OnlineEmote) {
    val room = _activeRoom.value
    if (room != null && Firebase.auth.currentUser != null) {
      viewModelScope.launch { roomRepo.sendEmote(room, emote) }
    } else {
      _onlineEmoteEvents.tryEmit(OnlineEmoteEvent(playerId = 1, emote = emote))
    }
    soundEngine.play(SoundEffect.EMOTE_POP)
  }

  suspend fun submitOnlinePick3(roomCode: String, picks: List<BallType>): Result<Unit> {
    val room = _activeRoom.value ?: return Result.failure(IllegalStateException("Room unavailable"))
    if (room.roomCode != roomCode) return Result.failure(IllegalStateException("Room mismatch"))
    return runCatching {
      _roomBusy.value = true
      roomRepo.submitPick3(room, picks)
      roomRepo.reconcileRoomPhase(roomCode)
    }.also { _roomBusy.value = false }
  }

  suspend fun submitOnlineBan1(roomCode: String, banned: BallType): Result<Unit> {
    val room = _activeRoom.value ?: return Result.failure(IllegalStateException("Room unavailable"))
    if (room.roomCode != roomCode) return Result.failure(IllegalStateException("Room mismatch"))
    return runCatching {
      _roomBusy.value = true
      roomRepo.submitBan1(room, banned)
      roomRepo.reconcileRoomPhase(roomCode)
    }.also { _roomBusy.value = false }
  }

  suspend fun submitOnlineFinalPick(roomCode: String, finalBall: BallType): Result<Unit> {
    val room = _activeRoom.value ?: return Result.failure(IllegalStateException("Room unavailable"))
    if (room.roomCode != roomCode) return Result.failure(IllegalStateException("Room mismatch"))
    return runCatching {
      _roomBusy.value = true
      roomRepo.submitFinalBall(room, finalBall)
      roomRepo.reconcileRoomPhase(roomCode)
    }.also { _roomBusy.value = false }
  }

  fun submitOnlineAimAngle(roomCode: String, expectedRound: Int, angleRad: Double) {
    viewModelScope.launch {
      roomRepo.submitAimAngle(roomCode, expectedRound, angleRad)
    }
  }

  fun forceDefaultMissingAim(roomCode: String, expectedRound: Int, targetIsHost: Boolean) {
    viewModelScope.launch {
      val fallback = if (targetIsHost) -1.1 else -2.04
      roomRepo.forceDefaultMissingAim(roomCode, expectedRound, targetIsHost, fallback)
    }
  }

  suspend fun claimOpponentDisconnectWin(): Result<Int> {
    val room = _activeRoom.value ?: return Result.failure(IllegalStateException("No active room"))
    val uid = _currentUid.value.orEmpty()
    if (!room.isOpponentDisconnected(uid)) {
      return Result.failure(IllegalStateException("Opponent still connected"))
    }
    return runCatching {
      val coins = room.computeSpeedRewardCoins(15f)
      roomRepo.reportMatchFinished(room.roomCode, uid, 15f, coins)
      val updated = repository.recordMatchResult(coinsEarned = coins, playerWon = true)
      pushLocalProgressToCloud(updated)
      soundEngine.play(SoundEffect.KO_EXPLOSION)
      coins
    }
  }

  /**
   * Canonical Online battle configuration: Host is ALWAYS side 1 (P1), Guest is ALWAYS side 2 (P2)
   * on BOTH devices so seeded deterministic physics simulate identically across both phones.
   */
  fun prepareOnlineBattle(room: OnlineRoomState) {
    val uid = _currentUid.value.orEmpty()
    val amHost = room.isHost(uid)
    val hostBall = room.hostFinalBall ?: BallType.FIRE
    val guestBall = room.guestFinalBall ?: BallType.WATER
    _matchSetup.value =
      MatchSetup(
        mode = GameMode.ONLINE_1VS1,
        p1Ball = hostBall,
        p2Ball = guestBall,
        seed = room.seed + (room.currentRound.toLong() * 7919L),
        onlineRoomCode = room.roomCode,
        p1DisplayName = room.hostName.ifBlank { "Host" },
        p2DisplayName = room.guestName.ifBlank { "Guest" },
        localPlayerSide = if (amHost) 1 else 2,
      )
  }

  fun leaveOnlineRoom() {
    matchmakingJob?.cancel()
    matchmakingJob = null
    _matchmakingState.value = MatchmakingUiState.Idle
    roomObserverJob?.cancel()
    roomSyncJob?.cancel()
    roomChatJob?.cancel()
    roomHeartbeatJob?.cancel()
    lastSyncedPhaseKey = null
    _activeRoom.value = null
    _roomChat.value = emptyList()
    _roomPingMs.value = 0L
    recordedSeriesRewardKey = null
    viewModelScope.launch { roomRepo.cancelMatchmakingTicket() }
  }

  suspend fun recordMatchOutcome(mode: GameMode, winnerId: Int, durationSec: Float): Int {
    val room = _activeRoom.value
    if (mode == GameMode.ONLINE_1VS1 && room != null && Firebase.auth.currentUser != null) {
      val uid = _currentUid.value.orEmpty()
      val winnerUid = if (winnerId == 1) room.hostUid else room.guestUid
      val seriesCoins = room.computeSpeedRewardCoins(durationSec)
      val updatedRoom =
        runCatching {
          roomRepo.reportRoundFinished(
            roomCode = room.roomCode,
            roundWinnerUid = winnerUid,
            roundDurationSec = durationSec,
            rewardCoinsIfSeriesEnds = seriesCoins,
            expectedRound = room.currentRound,
          )
        }.getOrNull() ?: _activeRoom.value

      val finalPhase = updatedRoom?.phase ?: room.phase
      return if (finalPhase == OnlineRoomPhase.FINISHED) {
        val seriesKey = "series_${room.roomCode}"
        val wonSeries = (updatedRoom?.winnerUid ?: winnerUid) == uid
        val earned = if (wonSeries) (updatedRoom?.rewardCoins ?: seriesCoins) else 0
        if (recordedSeriesRewardKey != seriesKey) {
          recordedSeriesRewardKey = seriesKey
          val updated = repository.recordMatchResult(coinsEarned = earned, playerWon = wonSeries)
          pushLocalProgressToCloud(updated)
        }
        earned
      } else {
        0
      }
    }

    val playerWon = winnerId == 1
    val coinsEarned =
      when (mode) {
        GameMode.ONE_VS_AI -> if (playerWon) 65 else 25
        GameMode.ONE_VS_ONE -> 40
        GameMode.ONLINE_1VS1 -> if (playerWon) 150 else 0
      }

    val updated = repository.recordMatchResult(coinsEarned = coinsEarned, playerWon = playerWon)
    pushLocalProgressToCloud(updated)
    return coinsEarned
  }

  override fun onCleared() {
    super.onCleared()
    soundEngine.stop()
  }

  companion object {
    private const val GUEST_UID = "guest_local"
  }
}
