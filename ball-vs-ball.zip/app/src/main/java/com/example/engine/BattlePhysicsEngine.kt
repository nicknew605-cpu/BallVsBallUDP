package com.example.engine

import com.example.audio.SoundEffect
import com.example.model.AiDifficulty
import com.example.model.BallType
import com.example.model.GameMode
import com.example.model.OtaBalanceConfig
import com.example.model.OtaVfxConfig
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

const val ARENA_WIDTH = 1000f
const val ARENA_HEIGHT = 1340f
const val BALL_RADIUS = 46f
const val BALL_MAX_HP = 120f
const val BASE_COLLISION_DAMAGE = 5f
const val FIXED_PHYSICS_DT = 1f / 120f

enum class ArenaPhase {
  AIMING_P1,
  AIMING_P2,
  AI_AIMING,
  BATTLING,
  KO_SLOWMO,
  FINISHED,
}

data class TrailPoint(val x: Float, val y: Float, val alpha: Float)

data class BallEntity(
  val id: Int,
  val cloneIndex: Int = 1,
  val type: BallType,
  var x: Float,
  var y: Float,
  var prevX: Float,
  var prevY: Float,
  var vx: Float,
  var vy: Float,
  var hp: Float = BALL_MAX_HP,
  val maxHp: Float = BALL_MAX_HP,
  var rage: Float = 0f,
  var aimAngleRad: Float = -1.1f,
  var hitCooldown: Float = 0f,
  var lastWallId: Int = -1,
  // Fire (Passive: Realm of Fire + Fury)
  var burnTimer: Float = 0f,
  var burnDamagePerTick: Float = 0f,
  var burnTickAccumulator: Float = 0f,
  var laserBurnCooldown: Float = 0f,
  var fireRealmActivated: Boolean = false,
  var soulBurnTimer: Float = 0f,
  var soulBurnPopupAccum: Float = 0f,
  var soulBurnDmgAccum: Float = 0f,
  // Water (Passive: Tidal Surge + Trap + Orb)
  var aquaOrbTimer: Float = 3.0f,
  var trapPlaceCooldown: Float = 0f,
  var trappedTimer: Float = 0f,
  var trappedCenterX: Float = 0f,
  var trappedCenterY: Float = 0f,
  var trapTickAccumulator: Float = 0f,
  var trapDamagePerTick: Float = 5f,
  var trapImmunityTimer: Float = 0f,
  var tidalSurgeTimer: Float = 0f,
  var tidalStacks: Int = 0,
  // Shared Slow / CC / Power
  var soakTimer: Float = 0f,
  var slowFactor: Float = 1.0f,
  var silenceTimer: Float = 0f,
  var frozenTimer: Float = 0f,
  var postFreezeSlowTimer: Float = 0f,
  var postFreezeSlowFactor: Float = 0.60f,
  var powerReductionTimer: Float = 0f,
  // Ground (Skill 1 & Armor + Passive: Bastion Resonance)
  var seismicCooldownTimer: Float = 2.5f,
  var seismicChargingTimer: Float = 0f,
  var pendingQuakes: Int = 0,
  var quakeStaggerTimer: Float = 0f,
  var earthArmorCooldownTimer: Float = 9.0f,
  var earthArmorTimer: Float = 0f,
  // Thunder (Passive: Static Capacitor + Dash + Deathbolt)
  var sonicDashCooldownTimer: Float = 2.6f,
  var sonicDashActiveTimer: Float = 0f,
  var afterimageSpawnTimer: Float = 0f,
  var targetAfterimagesToSpawn: Int = 0,
  var spawnedAfterimagesInDash: Int = 0,
  var dashRageGained: Int = 0,
  var deathboltStacks: Int = 0,
  var staticDistanceAccum: Float = 0f,
  var staticChargeStacks: Int = 0,
  // Ice (Passive: Permafrost Aura + Shards + Overdrive + Absolute Zero)
  var iceShardAccumTimer: Float = 0f,
  var orbitingShards: Int = 0,
  var cryoOverdriveCooldownTimer: Float = 4.0f,
  var cryoOverdriveActiveTimer: Float = 0f,
  var absoluteZeroCooldownTimer: Float = 20.0f,
  // Ant Ball (Rare: Passive Ant Cell Regeneration + Swarm Skill 1 + Royal Queen/King Ult)
  var antRegenTimer: Float = 0f,
  var antRegensUsed: Int = 0,
  var antSwarmCooldownTimer: Float = 2.8f,
  var antQueenTimer: Float = 0f,
  var antKingTimer: Float = 0f,
  var antKingHealTimer: Float = 0f,
  val antSlowStacks: MutableList<Float> = mutableListOf(),
  var venomTimer: Float = 0f,
  var venomPctPerSec: Float = 0f,
  var venomJoltAccum: Float = 0f,
  var venomPopupAccum: Float = 0f,
  var venomDmgAccum: Float = 0f,
  // Combat Stats & Visuals
  var totalDamageDealt: Float = 0f,
  var skillsTriggered: Int = 0,
  var flashTimer: Float = 0f,
  var rotationDeg: Float = 0f,
  val trail: ArrayDeque<TrailPoint> = ArrayDeque(16),
) {
  val isCcImmune: Boolean
    get() = earthArmorTimer > 0f

  val outgoingPowerMultiplier: Float
    get() = if (powerReductionTimer > 0f) 0.60f else 1.0f

  fun effectiveSlowFactor(): Float {
    if (isCcImmune) return 1.0f
    val soakScale = if (soakTimer > 0f) slowFactor else 1.0f
    val postFreezeScale = if (postFreezeSlowTimer > 0f) postFreezeSlowFactor else 1.0f
    val antStackCount = antSlowStacks.size
    val antScale = if (antStackCount > 0) 0.85f.pow(antStackCount).coerceAtLeast(0.15f) else 1.0f
    return minOf(soakScale, postFreezeScale, antScale).coerceIn(0.15f, 1.0f)
  }

  fun allDamageReduction(balance: OtaBalanceConfig = OtaBalanceConfig()): Float =
    when {
      earthArmorTimer > 0f -> balance.groundArmorAllReduction
      seismicChargingTimer > 0f -> balance.groundChargeReduction
      else -> 0f
    }
}

data class FireChip(
  val id: Long,
  val ownerId: Int,
  val x: Float,
  val y: Float,
  val wallId: Int,
  var remainingLife: Float = 20f,
)

data class LaserBeam(
  val ownerId: Int,
  val x1: Float,
  val y1: Float,
  val x2: Float,
  val y2: Float,
  var remainingLife: Float = 2f,
)

data class AquaOrb(
  val id: Long,
  val ownerId: Int,
  var x: Float,
  var y: Float,
  var vx: Float,
  var vy: Float,
  var remainingLife: Float = 7.5f,
  val radius: Float = 20f,
)

data class HydroTrap(
  val id: Long,
  val ownerId: Int,
  val x: Float,
  val y: Float,
  val radius: Float = 66f,
  var remainingLife: Float = 8.0f,
  var angleDeg: Float = 0f,
)

data class TsunamiWave(
  val ownerId: Int,
  var y: Float,
  val vy: Float,
  var remainingLife: Float = 1.45f,
  var hasHitEnemy: Boolean = false,
)

data class ThunderAfterimage(
  val id: Long,
  val ownerId: Int,
  val x: Float,
  val y: Float,
  var remainingLife: Float = 3.5f,
  val maxLife: Float = 3.5f,
)

data class LightningBolt(
  val targetX: Float,
  val targetY: Float,
  val jaggedOffsets: List<Float>,
  var remainingLife: Float = 0.50f,
)

data class IceShard(
  val id: Long,
  val ownerId: Int,
  var x: Float,
  var y: Float,
  var vx: Float,
  var vy: Float,
  var remainingLife: Float = 4.0f,
  val radius: Float = 15f,
)

/**
 * Soldier Ant summoned by Ant Ball Skill 1.
 * Bigger crisp model (baseRadius = 18.5f), faster normal speed, infinite lifetime & infinite stacking until hitting an enemy.
 */
data class SoldierAnt(
  val id: Long,
  val ownerId: Int,
  var x: Float,
  var y: Float,
  var angleRad: Float,
  var ageSec: Float = 0f,
  val baseRadius: Float = 18.5f,
)

data class CompanionAntBall(
  val id: Long,
  val ownerId: Int,
  var x: Float,
  var y: Float,
  var vx: Float,
  var vy: Float,
  var hp: Float = 38f,
  val maxHp: Float = 38f,
  var hitCooldown: Float = 0f,
  var remainingLife: Float = 16.0f,
  val radius: Float = 27f,
)

data class RoyalAntUnit(
  val ownerId: Int,
  val isQueen: Boolean,
  var x: Float,
  var y: Float,
  var remainingLife: Float,
  val maxLife: Float,
)

data class BattleEmoteBubble(
  val id: Long,
  val playerId: Int,
  val text: String,
  val colorArgb: Long,
  var remainingLife: Float = 2.6f,
)

data class Particle(
  var x: Float,
  var y: Float,
  var vx: Float,
  var vy: Float,
  var size: Float,
  var life: Float,
  val maxLife: Float,
  val colorArgb: Long,
  val gravity: Float = 0f,
)

data class ShockwaveRing(
  val x: Float,
  val y: Float,
  var radius: Float,
  val maxRadius: Float,
  var life: Float,
  val maxLife: Float,
  val colorArgb: Long,
)

data class FloatingDamage(
  val id: Long,
  var x: Float,
  var y: Float,
  val text: String,
  val colorArgb: Long,
  var life: Float = 0.85f,
  val maxLife: Float = 0.85f,
  val isCrit: Boolean = false,
)

data class ArenaSnapshot(
  val phase: ArenaPhase,
  val mode: GameMode,
  val p1: BallEntity,
  val p2: BallEntity,
  val side1Balls: List<BallEntity> = listOf(p1),
  val side2Balls: List<BallEntity> = listOf(p2),
  val side1AntTotalSpawned: Int = if (p1.type == BallType.ANT) 1 else 0,
  val side2AntTotalSpawned: Int = if (p2.type == BallType.ANT) 1 else 0,
  val side1AntNextSpawnRemSec: Float = 0f,
  val side2AntNextSpawnRemSec: Float = 0f,
  val side1TotalDamageDealt: Float = p1.totalDamageDealt,
  val side2TotalDamageDealt: Float = p2.totalDamageDealt,
  val side1SkillsTriggered: Int = p1.skillsTriggered,
  val side2SkillsTriggered: Int = p2.skillsTriggered,
  val chips: List<FireChip>,
  val lasers: List<LaserBeam>,
  val aquaOrbs: List<AquaOrb>,
  val hydroTraps: List<HydroTrap>,
  val tsunamis: List<TsunamiWave>,
  val afterimages: List<ThunderAfterimage>,
  val lightningBolts: List<LightningBolt>,
  val iceShards: List<IceShard>,
  val soldierAnts: List<SoldierAnt> = emptyList(),
  val companionAnts: List<CompanionAntBall> = emptyList(),
  val royalAnts: List<RoyalAntUnit> = emptyList(),
  val emoteBubbles: List<BattleEmoteBubble> = emptyList(),
  val particles: List<Particle>,
  val shockwaves: List<ShockwaveRing>,
  val floatingDamages: List<FloatingDamage>,
  val matchElapsedSec: Float,
  val shakeIntensity: Float,
  val heatDistortionTimer: Float,
  val fireRealmTimer: Float = 0f,
  val fireRealmOwnerId: Int = 0,
  val waterRippleTimer: Float,
  val arenaFreezeTimer: Float,
  val quakeFissureTimer: Float = 0f,
  val quakeOriginX: Float = ARENA_WIDTH * 0.5f,
  val quakeOriginY: Float = ARENA_HEIGHT * 0.5f,
  val winnerId: Int,
  val interpolationAlpha: Float,
)

class BattlePhysicsEngine(
  private val mode: GameMode,
  private val p1BallType: BallType,
  private val p2BallType: BallType,
  private val aiDifficulty: AiDifficulty,
  private val speedMultiplier: Float,
  private val hitStopEnabled: Boolean,
  private val seed: Long = System.nanoTime(),
  private val otaBalance: OtaBalanceConfig = OtaBalanceConfig(),
  private val otaVfx: OtaVfxConfig = OtaVfxConfig(),
  private val localPlayerSide: Int = 1,
  private val onSound: (SoundEffect) -> Unit = {},
  private val onSoundPan: ((SoundEffect, Float) -> Unit)? = null,
) {
  private val rng = Random(seed)

  private val p1MaxHp = otaBalance.hpFor(p1BallType)
  private val p2MaxHp = otaBalance.hpFor(p2BallType)

  private val side1Balls =
    mutableListOf(
      BallEntity(
        id = 1,
        cloneIndex = 1,
        type = p1BallType,
        x = ARENA_WIDTH * 0.5f,
        y = ARENA_HEIGHT * 0.78f,
        prevX = ARENA_WIDTH * 0.5f,
        prevY = ARENA_HEIGHT * 0.78f,
        vx = 0f,
        vy = 0f,
        hp = p1MaxHp,
        maxHp = p1MaxHp,
        aimAngleRad = -1.18f,
      )
    )

  private val side2Balls =
    mutableListOf(
      BallEntity(
        id = 2,
        cloneIndex = 1,
        type = p2BallType,
        x = ARENA_WIDTH * 0.5f,
        y = ARENA_HEIGHT * 0.22f,
        prevX = ARENA_WIDTH * 0.5f,
        prevY = ARENA_HEIGHT * 0.22f,
        vx = 0f,
        vy = 0f,
        hp = p2MaxHp,
        maxHp = p2MaxHp,
        aimAngleRad = 1.96f,
      )
    )

  private var side1AntSpawnCount = if (p1BallType == BallType.ANT) 1 else 0
  private var side2AntSpawnCount = if (p2BallType == BallType.ANT) 1 else 0
  private var side1AntRegenTimer = 0f
  private var side2AntRegenTimer = 0f

  private var phase: ArenaPhase =
    if (mode == GameMode.ONLINE_1VS1 && localPlayerSide == 2) ArenaPhase.AIMING_P2
    else ArenaPhase.AIMING_P1

  private var nextEntityId = 1L
  private var accumulator = 0f
  private var matchElapsedSec = 0f
  private var aiAimTimer = 0f
  private var koSlowMoTimer = 0f
  private var hitStopTimer = 0f
  private var shakeIntensity = 0f
  private var heatDistortionTimer = 0f
  private var fireRealmTimer = 0f
  private var fireRealmOwnerId = 0
  private var waterRippleTimer = 0f
  private var arenaFreezeTimer = 0f
  private var quakeFissureTimer = 0f
  private var quakeOriginX = ARENA_WIDTH * 0.5f
  private var quakeOriginY = ARENA_HEIGHT * 0.5f
  private var winnerId = 0
  private var trailSampleTimer = 0f

  private val chips = mutableListOf<FireChip>()
  private val lasers = mutableListOf<LaserBeam>()
  private val aquaOrbs = mutableListOf<AquaOrb>()
  private val hydroTraps = mutableListOf<HydroTrap>()
  private val tsunamis = mutableListOf<TsunamiWave>()
  private val afterimages = mutableListOf<ThunderAfterimage>()
  private val lightningBolts = mutableListOf<LightningBolt>()
  private val iceShards = mutableListOf<IceShard>()
  private val soldierAnts = mutableListOf<SoldierAnt>()
  private val companionAnts = mutableListOf<CompanionAntBall>()
  private val royalAnts = mutableListOf<RoyalAntUnit>()
  private val emoteBubbles = mutableListOf<BattleEmoteBubble>()
  private val particles = mutableListOf<Particle>()
  private val shockwaves = mutableListOf<ShockwaveRing>()
  private val floatingDamages = mutableListOf<FloatingDamage>()

  private val baseSpeed = 670f * speedMultiplier.coerceIn(0.75f, 1.35f)

  private fun emitSound(effect: SoundEffect, worldX: Float = ARENA_WIDTH * 0.5f) {
    val pan = ((worldX / ARENA_WIDTH) * 2f - 1f).coerceIn(-0.85f, 0.85f)
    onSoundPan?.invoke(effect, pan) ?: onSound(effect)
  }

  private fun leadBall(sideId: Int): BallEntity {
    val list = if (sideId == 1) side1Balls else side2Balls
    return list.firstOrNull { it.hp > 0f } ?: list.lastOrNull() ?: list.first()
  }

  private fun ballsOf(sideId: Int): MutableList<BallEntity> =
    if (sideId == 1) side1Balls else side2Balls

  private fun enemyBallsOf(sideId: Int): MutableList<BallEntity> =
    if (sideId == 1) side2Balls else side1Balls

  private fun nearestLivingEnemy(fromX: Float, fromY: Float, attackerSideId: Int): BallEntity? {
    var best: BallEntity? = null
    var bestDist = Float.MAX_VALUE
    val enemies = enemyBallsOf(attackerSideId)
    for (i in enemies.indices) {
      val e = enemies[i]
      if (e.hp <= 0f) continue
      val d = (e.x - fromX) * (e.x - fromX) + (e.y - fromY) * (e.y - fromY)
      if (d < bestDist) {
        bestDist = d
        best = e
      }
    }
    return best
  }

  private fun hasRoyalQueen(sideId: Int): Boolean =
    ballsOf(sideId).any { it.hp > 0f && it.antQueenTimer > 0f }

  private fun hasRoyalKing(sideId: Int): Boolean =
    ballsOf(sideId).any { it.hp > 0f && it.antKingTimer > 0f }

  fun setAimAngle(playerId: Int, angleRad: Float) {
    val p1Lead = side1Balls.first()
    val p2Lead = side2Balls.first()
    when {
      playerId == 1 && phase == ArenaPhase.AIMING_P1 -> p1Lead.aimAngleRad = angleRad
      playerId == 2 && phase == ArenaPhase.AIMING_P2 -> p2Lead.aimAngleRad = angleRad
    }
  }

  fun currentLocalAimAngle(): Float =
    if (localPlayerSide == 2) side2Balls.first().aimAngleRad else side1Balls.first().aimAngleRad

  fun launchOnlineBalls(p1AngleRad: Float, p2AngleRad: Float) {
    if (phase == ArenaPhase.BATTLING || phase == ArenaPhase.KO_SLOWMO || phase == ArenaPhase.FINISHED) {
      return
    }
    side1Balls.first().aimAngleRad = p1AngleRad
    side2Balls.first().aimAngleRad = p2AngleRad
    launchBothBalls()
  }

  fun triggerEmote(playerId: Int, badgeText: String, colorArgb: Long) {
    emoteBubbles.removeAll { it.playerId == playerId }
    emoteBubbles.add(
      BattleEmoteBubble(
        id = nextEntityId++,
        playerId = playerId,
        text = badgeText.take(8),
        colorArgb = colorArgb,
      )
    )
    emitSound(SoundEffect.EMOTE_POP)
  }

  fun confirmCurrentAim() {
    val p1Lead = side1Balls.first()
    val p2Lead = side2Balls.first()
    when (phase) {
      ArenaPhase.AIMING_P1 -> {
        emitSound(SoundEffect.UI_TAP, p1Lead.x)
        when (mode) {
          GameMode.ONE_VS_ONE -> phase = ArenaPhase.AIMING_P2
          GameMode.ONLINE_1VS1 -> Unit // Handled atomically via Firestore OnlineRoomRepository + launchOnlineBalls()
          GameMode.ONE_VS_AI -> {
            p2Lead.aimAngleRad = chooseAiAngle()
            aiAimTimer = 0.50f
            phase = ArenaPhase.AI_AIMING
          }
        }
      }
      ArenaPhase.AIMING_P2 -> {
        if (mode == GameMode.ONE_VS_ONE) {
          emitSound(SoundEffect.UI_TAP, p2Lead.x)
          launchBothBalls()
        }
      }
      else -> Unit
    }
  }

  private fun chooseAiAngle(): Float {
    val p1Lead = side1Balls.first()
    val p2Lead = side2Balls.first()
    val dx = p1Lead.x - p2Lead.x
    val dy = p1Lead.y - p2Lead.y
    val directAngle = atan2(dy, dx)
    return when (aiDifficulty) {
      AiDifficulty.EASY -> rng.nextFloat() * (2f * PI.toFloat()) - PI.toFloat()
      AiDifficulty.NORMAL -> directAngle + if (rng.nextBoolean()) 0.42f else -0.42f
      AiDifficulty.HARD -> {
        val side = if (cos(p1Lead.aimAngleRad) >= 0f) 0.24f else -0.24f
        directAngle + side
      }
    }
  }

  private fun launchBothBalls() {
    val p1Lead = side1Balls.first()
    val p2Lead = side2Balls.first()
    p1Lead.vx = cos(p1Lead.aimAngleRad) * baseSpeed
    p1Lead.vy = sin(p1Lead.aimAngleRad) * baseSpeed
    p2Lead.vx = cos(p2Lead.aimAngleRad) * baseSpeed
    p2Lead.vy = sin(p2Lead.aimAngleRad) * baseSpeed
    phase = ArenaPhase.BATTLING
    emitSound(SoundEffect.BALL_CLASH)
  }

  fun stepFrame(rawDeltaSec: Float, killEffectArgb: Long, onKoTriggered: (Int) -> Unit) {
    val frameDt = rawDeltaSec.coerceIn(0f, 0.05f)

    if (phase == ArenaPhase.AI_AIMING) {
      aiAimTimer -= frameDt
      if (aiAimTimer <= 0f) launchBothBalls()
      return
    }

    if (phase == ArenaPhase.KO_SLOWMO) {
      koSlowMoTimer -= frameDt
      updateVisualEffectsOnly(frameDt * 0.25f)
      if (koSlowMoTimer <= 0f) phase = ArenaPhase.FINISHED
      return
    }

    if (phase != ArenaPhase.BATTLING) {
      updateVisualEffectsOnly(frameDt)
      return
    }

    if (hitStopTimer > 0f) {
      hitStopTimer -= frameDt
      shakeIntensity = max(0f, shakeIntensity - frameDt * 38f)
      return
    }

    accumulator += frameDt
    var steps = 0
    while (accumulator >= FIXED_PHYSICS_DT && steps < 8) {
      stepFixedPhysics(FIXED_PHYSICS_DT, killEffectArgb, onKoTriggered)
      accumulator -= FIXED_PHYSICS_DT
      steps++
      if (phase != ArenaPhase.BATTLING) break
    }
  }

  private fun stepFixedPhysics(
    dt: Float,
    killEffectArgb: Long,
    onKoTriggered: (Int) -> Unit,
  ) {
    matchElapsedSec += dt
    shakeIntensity = max(0f, shakeIntensity - dt * 36f)
    heatDistortionTimer = max(0f, heatDistortionTimer - dt)
    fireRealmTimer = max(0f, fireRealmTimer - dt)
    if (fireRealmTimer <= 0f) fireRealmOwnerId = 0
    waterRippleTimer = max(0f, waterRippleTimer - dt)
    arenaFreezeTimer = max(0f, arenaFreezeTimer - dt)
    quakeFissureTimer = max(0f, quakeFissureTimer - dt)

    if (heatDistortionTimer > 0f && rng.nextFloat() < 0.35f) {
      spawnEmberParticles(rng.nextFloat() * ARENA_WIDTH, rng.nextFloat() * ARENA_HEIGHT * 0.5f, 2, 0xFFFF6D00)
    }
    if (fireRealmTimer > 0f && rng.nextFloat() < 0.55f) {
      when (rng.nextInt(4)) {
        0 -> spawnEmberParticles(10f, rng.nextFloat() * ARENA_HEIGHT, 2, 0xFFFF3D00)
        1 -> spawnEmberParticles(ARENA_WIDTH - 10f, rng.nextFloat() * ARENA_HEIGHT, 2, 0xFFFF3D00)
        2 -> spawnEmberParticles(rng.nextFloat() * ARENA_WIDTH, 10f, 2, 0xFFFFB300)
        else -> spawnEmberParticles(rng.nextFloat() * ARENA_WIDTH, ARENA_HEIGHT - 10f, 2, 0xFFFFB300)
      }
    }
    if (arenaFreezeTimer > 0f && rng.nextFloat() < 0.42f) {
      spawnEmberParticles(rng.nextFloat() * ARENA_WIDTH, rng.nextFloat() * ARENA_HEIGHT, 2, 0xFFE1F5FE)
    }

    // Track living status before step so individual clone deaths trigger crisp pop VFX
    for (i in side1Balls.indices) {
      val b = side1Balls[i]
      if (b.hp <= 0f) continue
      b.prevX = b.x
      b.prevY = b.y
      val enemy = nearestLivingEnemy(b.x, b.y, b.id) ?: leadBall(2)
      updateBallStatusAndTimers(b, enemy, dt)
      moveBallAndHandleWalls(b, enemy, dt)
    }
    for (i in side2Balls.indices) {
      val b = side2Balls[i]
      if (b.hp <= 0f) continue
      b.prevX = b.x
      b.prevY = b.y
      val enemy = nearestLivingEnemy(b.x, b.y, b.id) ?: leadBall(1)
      updateBallStatusAndTimers(b, enemy, dt)
      moveBallAndHandleWalls(b, enemy, dt)
    }

    // Ant Cell Regeneration Passive: every 15s while ANY Ant Ball on that side is alive,
    // spawn 1 complete 100% HP Ant Ball up to max 3 complete Ant Balls on the arena!
    tickSideAntCellRegen(sideId = 1, dt = dt)
    tickSideAntCellRegen(sideId = 2, dt = dt)

    resolveAllBallCollisions()

    updateChipsAndLasers(dt)
    updateHydroTraps(dt)
    updateAquaOrbs(dt)
    updateTsunamiWaves(dt)
    updateAfterimages(dt)
    updateIceShards(dt)
    updateSoldierAnts(dt)
    updateRoyalAnts(dt)
    updateVisualEffectsOnly(dt)

    trailSampleTimer += dt
    if (trailSampleTimer >= 0.016f) {
      trailSampleTimer = 0f
      for (b in side1Balls) if (b.hp > 0f) pushTrail(b)
      for (b in side2Balls) if (b.hp > 0f) pushTrail(b)
    }

    // Check Ultimates for every living ball
    for (b in side1Balls) {
      if (b.hp > 0f && b.rage >= 100f && b.silenceTimer <= 0f) {
        val enemy = nearestLivingEnemy(b.x, b.y, b.id)
        if (enemy != null) triggerUltimate(b, enemy)
      }
    }
    for (b in side2Balls) {
      if (b.hp > 0f && b.rage >= 100f && b.silenceTimer <= 0f) {
        val enemy = nearestLivingEnemy(b.x, b.y, b.id)
        if (enemy != null) triggerUltimate(b, enemy)
      }
    }

    // Clamp zero HP and check full side elimination (round ends ONLY when ALL balls on a side are dead!)
    var side1Alive = false
    for (b in side1Balls) {
      if (b.hp <= 0f) b.hp = 0f else side1Alive = true
    }
    var side2Alive = false
    for (b in side2Balls) {
      if (b.hp <= 0f) b.hp = 0f else side2Alive = true
    }

    if (!side1Alive || !side2Alive) {
      winnerId = if (!side1Alive && !side2Alive) 2 else if (!side2Alive) 1 else 2
      val loser = if (winnerId == 1) side2Balls.last() else side1Balls.last()
      phase = ArenaPhase.KO_SLOWMO
      koSlowMoTimer = 1.35f
      shakeIntensity = 26f
      spawnShockwave(loser.x, loser.y, 460f, 0.7f, killEffectArgb)
      emitSound(SoundEffect.KO_EXPLOSION, loser.x)
      onKoTriggered(winnerId)
    }
  }

  private fun tickSideAntCellRegen(sideId: Int, dt: Float) {
    val ballType = if (sideId == 1) p1BallType else p2BallType
    if (ballType != BallType.ANT) return

    val list = ballsOf(sideId)
    val anchor = list.firstOrNull { it.hp > 0f } ?: return
    val currentSpawned = if (sideId == 1) side1AntSpawnCount else side2AntSpawnCount
    val maxTotalAntBalls = otaBalance.antMaxRegens.coerceIn(1, 5)
    if (currentSpawned >= maxTotalAntBalls) return

    val updatedTimer = (if (sideId == 1) side1AntRegenTimer else side2AntRegenTimer) + dt
    if (sideId == 1) side1AntRegenTimer = updatedTimer else side2AntRegenTimer = updatedTimer
    anchor.antRegenTimer = updatedTimer

    if (updatedTimer >= otaBalance.antRegenIntervalSec) {
      if (sideId == 1) {
        side1AntRegenTimer = 0f
        side1AntSpawnCount++
      } else {
        side2AntRegenTimer = 0f
        side2AntSpawnCount++
      }
      val newIdx = if (sideId == 1) side1AntSpawnCount else side2AntSpawnCount
      val fullHp = if (sideId == 1) p1MaxHp else p2MaxHp
      val spawnAngle = rng.nextFloat() * (2f * PI.toFloat())
      val spawnX = (anchor.x + cos(spawnAngle) * (BALL_RADIUS * 2.1f)).coerceIn(BALL_RADIUS + 8f, ARENA_WIDTH - BALL_RADIUS - 8f)
      val spawnY = (anchor.y + sin(spawnAngle) * (BALL_RADIUS * 2.1f)).coerceIn(BALL_RADIUS + 8f, ARENA_HEIGHT - BALL_RADIUS - 8f)
      val clone =
        BallEntity(
          id = sideId,
          cloneIndex = newIdx,
          type = BallType.ANT,
          x = spawnX,
          y = spawnY,
          prevX = spawnX,
          prevY = spawnY,
          vx = cos(spawnAngle) * baseSpeed,
          vy = sin(spawnAngle) * baseSpeed,
          hp = fullHp,
          maxHp = fullHp,
          antQueenTimer = anchor.antQueenTimer,
          antKingTimer = anchor.antKingTimer,
          antSwarmCooldownTimer = 1.4f,
        )
      list.add(clone)
      for (b in list) {
        b.antRegensUsed = newIdx - 1
      }
      anchor.skillsTriggered++
      spawnShockwave(clone.x, clone.y, 240f, 0.50f, 0xFF00E676)
      spawnEmberParticles(clone.x, clone.y, 24, 0xFFB9FF66)
      addFloatingPopup(
        FloatingDamage(
          id = nextEntityId++,
          x = clone.x,
          y = clone.y - BALL_RADIUS - 16f,
          text = "ANT #$newIdx!",
          colorArgb = 0xFF00E676,
          isCrit = true,
        )
      )
      emitSound(SoundEffect.ANT_REGEN, clone.x)
    }
  }

  private fun pushTrail(ball: BallEntity) {
    if (ball.trail.size >= 14) ball.trail.removeAt(0)
    ball.trail.addLast(TrailPoint(ball.x, ball.y, 1f))
  }

  private fun updateBallStatusAndTimers(ball: BallEntity, enemy: BallEntity, dt: Float) {
    ball.hitCooldown = max(0f, ball.hitCooldown - dt)
    ball.laserBurnCooldown = max(0f, ball.laserBurnCooldown - dt)
    ball.flashTimer = max(0f, ball.flashTimer - dt)
    ball.trapPlaceCooldown = max(0f, ball.trapPlaceCooldown - dt)
    ball.trapImmunityTimer = max(0f, ball.trapImmunityTimer - dt)
    ball.powerReductionTimer = max(0f, ball.powerReductionTimer - dt)
    ball.earthArmorTimer = max(0f, ball.earthArmorTimer - dt)
    ball.cryoOverdriveActiveTimer = max(0f, ball.cryoOverdriveActiveTimer - dt)
    ball.tidalSurgeTimer = max(0f, ball.tidalSurgeTimer - dt)
    if (ball.tidalSurgeTimer <= 0f) ball.tidalStacks = 0
    ball.antQueenTimer = max(0f, ball.antQueenTimer - dt)
    ball.antKingTimer = max(0f, ball.antKingTimer - dt)

    val slowIter = ball.antSlowStacks.listIterator()
    while (slowIter.hasNext()) {
      val rem = slowIter.next() - dt
      if (rem <= 0f) slowIter.remove() else slowIter.set(rem)
    }

    if (ball.isCcImmune) {
      ball.soakTimer = 0f
      ball.slowFactor = 1.0f
      ball.silenceTimer = 0f
      ball.frozenTimer = 0f
      ball.postFreezeSlowTimer = 0f
      ball.trappedTimer = 0f
      ball.antSlowStacks.clear()
    } else {
      ball.soakTimer = max(0f, ball.soakTimer - dt)
      if (ball.soakTimer <= 0f) ball.slowFactor = 1.0f
      ball.silenceTimer = max(0f, ball.silenceTimer - dt)
      val wasFrozen = ball.frozenTimer > 0f
      ball.frozenTimer = max(0f, ball.frozenTimer - dt)
      if (wasFrozen && ball.frozenTimer <= 0f) {
        ball.postFreezeSlowTimer = 4.0f
        ball.postFreezeSlowFactor = (1f - otaBalance.icePostFreezeSlowPct).coerceIn(0.25f, 1.0f)
        spawnEmberParticles(ball.x, ball.y, 10, 0xFF80D8FF)
      } else {
        ball.postFreezeSlowTimer = max(0f, ball.postFreezeSlowTimer - dt)
      }
    }

    if (ball.frozenTimer <= 0f) {
      ball.rotationDeg =
        (ball.rotationDeg + dt * (if (ball.type == BallType.FIRE || ball.type == BallType.THUNDER) 220f else -190f)) %
          360f
    }

    // 1. Fire Realm of Fire Soul Burn: Continuous NO-DELAY 2% HP/sec for 3s
    if (ball.soulBurnTimer > 0f) {
      ball.soulBurnTimer = max(0f, ball.soulBurnTimer - dt)
      val scale = otaBalance.damageScaleFor(enemy.type)
      val elementalFactor = if (ball.type == BallType.WATER) 0.90f else 1.0f
      val rawDmg = ball.maxHp * 0.02f * dt * scale * enemy.outgoingPowerMultiplier * (1f - ball.allDamageReduction(otaBalance)) * elementalFactor
      if (rawDmg > 0f) {
        ball.hp -= rawDmg
        enemy.totalDamageDealt += rawDmg
        ball.soulBurnDmgAccum += rawDmg
      }
      ball.soulBurnPopupAccum += dt
      if (ball.soulBurnPopupAccum >= 0.35f) {
        ball.soulBurnPopupAccum = 0f
        if (ball.soulBurnDmgAccum >= 0.4f) {
          spawnEmberParticles(ball.x, ball.y, 4, 0xFFFF3D00)
          addFloatingPopup(
            FloatingDamage(
              id = nextEntityId++,
              x = ball.x + (rng.nextFloat() - 0.5f) * 28f,
              y = ball.y - BALL_RADIUS * 0.7f,
              text = "-${max(1, ball.soulBurnDmgAccum.roundToInt())}",
              colorArgb = 0xFFFF5722,
            )
          )
          ball.soulBurnDmgAccum = 0f
        }
      }
    }

    // 2. Fire Fury 5s map-wide burn (6% max HP/sec)
    if (ball.burnTimer > 0f) {
      ball.burnTimer = max(0f, ball.burnTimer - dt)
      ball.burnTickAccumulator += dt
      if (ball.burnTickAccumulator >= 0.5f) {
        ball.burnTickAccumulator -= 0.5f
        val rawTickDmg = ball.burnDamagePerTick
        val elementalFactor = if (ball.type == BallType.WATER) 0.90f else 1.0f
        applyDamage(
          attacker = enemy,
          victim = ball,
          amount = rawTickDmg * elementalFactor,
          colorArgb = 0xFFFF7043,
        )
        spawnEmberParticles(ball.x, ball.y, 7, 0xFFFF6D00)
      }
    }

    // 3. Ant Royal Colony Venom DoT
    if (ball.venomTimer > 0f) {
      ball.venomTimer = max(0f, ball.venomTimer - dt)
      val scale = otaBalance.damageScaleFor(enemy.type)
      val rawVenom = ball.maxHp * ball.venomPctPerSec * dt * scale * enemy.outgoingPowerMultiplier * (1f - ball.allDamageReduction(otaBalance))
      if (rawVenom > 0f) {
        ball.hp -= rawVenom
        enemy.totalDamageDealt += rawVenom
        ball.venomDmgAccum += rawVenom
      }
      ball.venomJoltAccum += dt
      if (ball.venomJoltAccum >= 1.15f) {
        ball.venomJoltAccum = 0f
        if (!ball.isCcImmune) {
          ball.silenceTimer = max(ball.silenceTimer, 0.25f)
        }
        spawnEmberParticles(ball.x, ball.y, 5, 0xFF00E676)
      }
      ball.venomPopupAccum += dt
      if (ball.venomPopupAccum >= 0.45f) {
        ball.venomPopupAccum = 0f
        if (ball.venomDmgAccum >= 0.4f) {
          addFloatingPopup(
            FloatingDamage(
              id = nextEntityId++,
              x = ball.x + (rng.nextFloat() - 0.5f) * 28f,
              y = ball.y - BALL_RADIUS * 0.7f,
              text = "-${max(1, ball.venomDmgAccum.roundToInt())}",
              colorArgb = 0xFFB9FF66,
            )
          )
          ball.venomDmgAccum = 0f
        }
      }
    }

    // 4. Water Hydro Vortex trap pinning
    if (ball.trappedTimer > 0f) {
      ball.trappedTimer = max(0f, ball.trappedTimer - dt)
      ball.trapTickAccumulator += dt
      if (ball.trapTickAccumulator >= 0.34f) {
        ball.trapTickAccumulator -= 0.34f
        applyDamage(
          attacker = enemy,
          victim = ball,
          amount = ball.trapDamagePerTick,
          colorArgb = 0xFF00E5FF,
        )
        spawnEmberParticles(ball.x, ball.y, 8, 0xFF18FFFF)
      }
      if (ball.trappedTimer <= 0f) {
        ball.trapImmunityTimer = 2.8f
      }
    }

    val canAct = ball.silenceTimer <= 0f && ball.frozenTimer <= 0f && ball.hp > 0f

    when (ball.type) {
      BallType.FIRE -> {
        if (canAct && !ball.fireRealmActivated && matchElapsedSec in 0.8f..5.0f) {
          ball.fireRealmActivated = true
          fireRealmTimer = 15.0f
          fireRealmOwnerId = ball.id
          ball.skillsTriggered++
          spawnShockwave(ARENA_WIDTH * 0.5f, ARENA_HEIGHT * 0.5f, 680f, 0.65f, 0xFFFF3D00)
          emitSound(SoundEffect.FIRE_REALM, ball.x)
        }
      }
      BallType.WATER -> {
        if (canAct) {
          val flowSpeedScale = if (ball.tidalSurgeTimer > 0f) 1.25f else 1.0f
          ball.aquaOrbTimer -= dt * flowSpeedScale
          if (ball.aquaOrbTimer <= 0f) {
            ball.aquaOrbTimer = 4.2f
            spawnAquaOrb(ball, enemy)
          }
        }
      }
      BallType.GROUND -> {
        if (canAct && ball.seismicChargingTimer <= 0f && ball.pendingQuakes == 0) {
          ball.seismicCooldownTimer -= dt
          if (ball.seismicCooldownTimer <= 0f) {
            ball.seismicCooldownTimer = otaBalance.groundSkill1CooldownSec
            ball.seismicChargingTimer = 1.6f
            emitSound(SoundEffect.GROUND_CHARGE, ball.x)
          }
        }
        if (ball.seismicChargingTimer > 0f) {
          ball.seismicChargingTimer = max(0f, ball.seismicChargingTimer - dt)
          if (ball.seismicChargingTimer <= 0f) {
            ball.pendingQuakes = 3
            ball.quakeStaggerTimer = 0f
            ball.skillsTriggered++
          }
        }
        if (ball.pendingQuakes > 0) {
          ball.quakeStaggerTimer -= dt
          if (ball.quakeStaggerTimer <= 0f) {
            ball.pendingQuakes--
            ball.quakeStaggerTimer = 0.55f
            triggerGroundQuakeWave(ball)
          }
        }
        if (canAct && ball.earthArmorTimer <= 0f) {
          ball.earthArmorCooldownTimer -= dt
          if (ball.earthArmorCooldownTimer <= 0f) {
            activateGroundArmor(ball)
          }
        }
      }
      BallType.THUNDER -> {
        if (canAct) {
          ball.sonicDashCooldownTimer -= dt
          if (ball.sonicDashCooldownTimer <= 0f) {
            ball.sonicDashCooldownTimer = 5.0f
            ball.sonicDashActiveTimer = 0.40f
            ball.targetAfterimagesToSpawn = listOf(80, 85, 95, 100).random(rng)
            ball.spawnedAfterimagesInDash = 0
            ball.dashRageGained = 0
            ball.afterimageSpawnTimer = 0f
            ball.skillsTriggered++
            emitSound(SoundEffect.THUNDER_DASH, ball.x)
          }
        }
        if (ball.sonicDashActiveTimer > 0f) {
          ball.sonicDashActiveTimer = max(0f, ball.sonicDashActiveTimer - dt)
          val remainingClones = ball.targetAfterimagesToSpawn - ball.spawnedAfterimagesInDash
          if (remainingClones > 0) {
            val batch = if (ball.sonicDashActiveTimer <= dt * 2f) remainingClones else 4
            val duration = otaBalance.thunderAfterimageDurationSec
            repeat(batch) {
              if (afterimages.size >= 115) afterimages.removeAt(0)
              val randomX = BALL_RADIUS + rng.nextFloat() * (ARENA_WIDTH - BALL_RADIUS * 2f)
              val randomY = BALL_RADIUS + rng.nextFloat() * (ARENA_HEIGHT - BALL_RADIUS * 2f)
              afterimages.add(
                ThunderAfterimage(
                  id = nextEntityId++,
                  ownerId = ball.id,
                  x = randomX,
                  y = randomY,
                  remainingLife = duration,
                  maxLife = duration,
                )
              )
              ball.spawnedAfterimagesInDash++
            }
          }
        }
      }
      BallType.ICE -> {
        if (canAct) {
          for (targetEnemy in enemyBallsOf(ball.id)) {
            if (targetEnemy.hp <= 0f) continue
            val dist = hypot(targetEnemy.x - ball.x, targetEnemy.y - ball.y)
            if (dist <= 200f && !targetEnemy.isCcImmune) {
              targetEnemy.soakTimer = max(targetEnemy.soakTimer, 0.35f)
              targetEnemy.slowFactor = min(targetEnemy.slowFactor, 0.80f)
            }
          }
          ball.cryoOverdriveCooldownTimer -= dt
          if (ball.cryoOverdriveCooldownTimer <= 0f) {
            ball.cryoOverdriveCooldownTimer = 10.0f
            ball.cryoOverdriveActiveTimer = 5.0f
            ball.skillsTriggered++
            emitSound(SoundEffect.ICE_OVERDRIVE, ball.x)
          }
          val baseInterval = otaBalance.iceShardSpawnIntervalSec
          val interval = if (ball.cryoOverdriveActiveTimer > 0f) baseInterval / 1.7f else baseInterval
          ball.iceShardAccumTimer += dt
          if (ball.iceShardAccumTimer >= interval) {
            ball.iceShardAccumTimer -= interval
            ball.orbitingShards++
            if (ball.orbitingShards >= 5) {
              ball.orbitingShards = 0
              fireIceShardVolley(ball, enemy)
            }
          }
          ball.absoluteZeroCooldownTimer -= dt
          if (ball.absoluteZeroCooldownTimer <= 0f) {
            ball.absoluteZeroCooldownTimer = 20.0f
            if (ball.rage >= 45f) {
              triggerUltimate(ball, enemy)
            } else {
              addRage(ball, 35f)
            }
          }
        }
      }
      BallType.ANT -> {
        // Every active Ant Ball independently casts Skill 1 (Swarm Release every 8s)
        if (canAct) {
          ball.antSwarmCooldownTimer -= dt
          if (ball.antSwarmCooldownTimer <= 0f) {
            ball.antSwarmCooldownTimer = otaBalance.antSkill1CooldownSec
            triggerAntSwarmSkill(ball, enemy)
          }
        }
        // King Ant heal pulse every 15s (doubled when BOTH Queen & King are active!)
        if (ball.antKingTimer > 0f) {
          ball.antKingHealTimer += dt
          if (ball.antKingHealTimer >= 15.0f) {
            ball.antKingHealTimer = 0f
            val bothActive = ball.antQueenTimer > 0f
            val burnHealMult = if (ball.burnTimer > 0f || ball.soulBurnTimer > 0f) 0.65f else 1.0f
            val healAmount = (if (bothActive) 40f else 20f) * burnHealMult
            ball.hp = min(ball.maxHp, ball.hp + healAmount)
            spawnEmberParticles(ball.x, ball.y, 16, 0xFF00E676)
            addFloatingPopup(
              FloatingDamage(
                id = nextEntityId++,
                x = ball.x,
                y = ball.y - BALL_RADIUS - 12f,
                text = "+${healAmount.roundToInt()}",
                colorArgb = 0xFF00E676,
                isCrit = true,
              )
            )
            emitSound(SoundEffect.ANT_REGEN, ball.x)
          }
        } else {
          ball.antKingHealTimer = 0f
        }
      }
    }
  }

  private fun moveBallAndHandleWalls(ball: BallEntity, @Suppress("UNUSED_PARAMETER") enemy: BallEntity, dt: Float) {
    if (ball.frozenTimer > 0f || ball.seismicChargingTimer > 0f) return

    if (ball.trappedTimer > 0f) {
      val orbitAngle = matchElapsedSec * 14f
      ball.x = (ball.trappedCenterX + cos(orbitAngle) * 18f).coerceIn(BALL_RADIUS, ARENA_WIDTH - BALL_RADIUS)
      ball.y = (ball.trappedCenterY + sin(orbitAngle) * 18f).coerceIn(BALL_RADIUS, ARENA_HEIGHT - BALL_RADIUS)
      return
    }

    val dashBoost = if (ball.sonicDashActiveTimer > 0f) 2.55f else 1.0f
    val tidalBoost = if (ball.type == BallType.WATER && ball.tidalSurgeTimer > 0f) 1f + ball.tidalStacks * 0.08f else 1.0f
    val slowScale = ball.effectiveSlowFactor()

    val currentSpeed = hypot(ball.vx, ball.vy).coerceAtLeast(1f)
    val targetMin = baseSpeed * 0.88f * slowScale * dashBoost * tidalBoost
    val targetMax = baseSpeed * 1.28f * slowScale * dashBoost * tidalBoost
    val clampedSpeed = currentSpeed.coerceIn(targetMin, targetMax)
    if (abs(currentSpeed - clampedSpeed) > 1f) {
      val factor = clampedSpeed / currentSpeed
      ball.vx *= factor
      ball.vy *= factor
    }

    val prevX = ball.x
    val prevY = ball.y
    ball.x += ball.vx * dt
    ball.y += ball.vy * dt

    if (ball.type == BallType.THUNDER) {
      ball.staticDistanceAccum += hypot(ball.x - prevX, ball.y - prevY)
      if (ball.staticDistanceAccum >= 620f) {
        ball.staticDistanceAccum = 0f
        ball.staticChargeStacks = (ball.staticChargeStacks + 1).coerceAtMost(3)
      }
    }

    var hitWallId = -1
    if (ball.x - BALL_RADIUS < 0f) {
      ball.x = BALL_RADIUS
      ball.vx = abs(ball.vx)
      hitWallId = 0
    } else if (ball.x + BALL_RADIUS > ARENA_WIDTH) {
      ball.x = ARENA_WIDTH - BALL_RADIUS
      ball.vx = -abs(ball.vx)
      hitWallId = 1
    }

    if (ball.y - BALL_RADIUS < 0f) {
      ball.y = BALL_RADIUS
      ball.vy = abs(ball.vy)
      hitWallId = 2
    } else if (ball.y + BALL_RADIUS > ARENA_HEIGHT) {
      ball.y = ARENA_HEIGHT - BALL_RADIUS
      ball.vy = -abs(ball.vy)
      hitWallId = 3
    }

    val touchingFireRealmWall =
      fireRealmTimer > 0f &&
        fireRealmOwnerId != ball.id &&
        (hitWallId >= 0 ||
          ball.x - BALL_RADIUS <= 8f ||
          ball.x + BALL_RADIUS >= ARENA_WIDTH - 8f ||
          ball.y - BALL_RADIUS <= 8f ||
          ball.y + BALL_RADIUS >= ARENA_HEIGHT - 8f)

    if (touchingFireRealmWall) {
      ball.soulBurnTimer = 3.0f
      if (!ball.isCcImmune) {
        ball.soakTimer = max(ball.soakTimer, 2.0f)
        ball.slowFactor = min(ball.slowFactor, 0.60f)
      }
      if (hitWallId >= 0) {
        spawnEmberParticles(ball.x, ball.y, 8, 0xFFFF3D00)
      }
    }

    if (hitWallId >= 0) {
      if (abs(ball.vx) < 150f) ball.vx += if (ball.vx >= 0f) 110f else -110f
      if (abs(ball.vy) < 150f) ball.vy += if (ball.vy >= 0f) 110f else -110f
      addRage(ball, if (ball.type == BallType.WATER) 6f else 5f)
      emitSound(SoundEffect.WALL_BOUNCE, ball.x)
      spawnEmberParticles(ball.x, ball.y, 4, colorForBall(ball.type))

      if (ball.type == BallType.FIRE && ball.silenceTimer <= 0f) {
        handleFireWallBounce(ball, hitWallId)
      } else if (ball.type == BallType.WATER && ball.silenceTimer <= 0f) {
        ball.tidalSurgeTimer = 3.5f
        ball.tidalStacks = (ball.tidalStacks + 1).coerceAtMost(3)
        if (ball.trapPlaceCooldown <= 0f && rng.nextFloat() < 0.70f) {
          deployHydroTrap(ball)
        }
      }
      ball.lastWallId = hitWallId
    }
  }

  private fun resolveAllBallCollisions() {
    val minDist = BALL_RADIUS * 2f
    val all = ArrayList<BallEntity>(side1Balls.size + side2Balls.size)
    for (b in side1Balls) if (b.hp > 0f) all.add(b)
    for (b in side2Balls) if (b.hp > 0f) all.add(b)

    for (i in 0 until all.size) {
      val a = all[i]
      for (j in i + 1 until all.size) {
        val b = all[j]
        val dx = b.x - a.x
        val dy = b.y - a.y
        val dist = hypot(dx, dy)
        if (dist <= 0.001f || dist >= minDist) continue

        val nx = dx / dist
        val ny = dy / dist
        val overlap = minDist - dist

        if (a.frozenTimer <= 0f && a.trappedTimer <= 0f && a.seismicChargingTimer <= 0f) {
          a.x -= nx * (overlap * 0.5f + 0.5f)
          a.y -= ny * (overlap * 0.5f + 0.5f)
        }
        if (b.frozenTimer <= 0f && b.trappedTimer <= 0f && b.seismicChargingTimer <= 0f) {
          b.x += nx * (overlap * 0.5f + 0.5f)
          b.y += ny * (overlap * 0.5f + 0.5f)
        }

        val rvx = b.vx - a.vx
        val rvy = b.vy - a.vy
        val velAlongNormal = rvx * nx + rvy * ny
        if (velAlongNormal < 0f) {
          val restitution = 1.03f
          val impulse = -(1f + restitution) * velAlongNormal * 0.5f
          if (a.frozenTimer <= 0f && a.seismicChargingTimer <= 0f) {
            a.vx -= impulse * nx
            a.vy -= impulse * ny
          }
          if (b.frozenTimer <= 0f && b.seismicChargingTimer <= 0f) {
            b.vx += impulse * nx
            b.vy += impulse * ny
          }
        }

        // Only opposing-side collisions deal damage & trigger combat effects
        if (a.id != b.id && a.hitCooldown <= 0f && b.hitCooldown <= 0f) {
          a.hitCooldown = 0.14f
          b.hitCooldown = 0.14f
          a.flashTimer = 0.12f
          b.flashTimer = 0.12f

          val aExtra = if (a.type == BallType.THUNDER && a.staticChargeStacks > 0) a.staticChargeStacks * 1.5f else 0f
          val bExtra = if (b.type == BallType.THUNDER && b.staticChargeStacks > 0) b.staticChargeStacks * 1.5f else 0f
          if (aExtra > 0f) { a.staticChargeStacks = 0; addRage(a, 5f) }
          if (bExtra > 0f) { b.staticChargeStacks = 0; addRage(b, 5f) }

          applyDamage(attacker = a, victim = b, amount = BASE_COLLISION_DAMAGE + aExtra, colorArgb = 0xFFFFFFFF)
          applyDamage(attacker = b, victim = a, amount = BASE_COLLISION_DAMAGE + bExtra, colorArgb = 0xFFFFFFFF)

          if (a.type == BallType.GROUND && !b.isCcImmune) {
            b.soakTimer = max(b.soakTimer, 0.9f)
            b.slowFactor = min(b.slowFactor, 0.85f)
          }
          if (b.type == BallType.GROUND && !a.isCcImmune) {
            a.soakTimer = max(a.soakTimer, 0.9f)
            a.slowFactor = min(a.slowFactor, 0.85f)
          }

          if (a.type == BallType.ICE) a.iceShardAccumTimer += 0.25f
          if (b.type == BallType.ICE) b.iceShardAccumTimer += 0.25f

          addRage(a, if (a.type == BallType.WATER) 16f else 14f)
          addRage(b, if (b.type == BallType.WATER) 16f else 14f)

          val cx = (a.x + b.x) * 0.5f
          val cy = (a.y + b.y) * 0.5f
          spawnEmberParticles(cx, cy, 16, 0xFFFFD54F)
          spawnShockwave(cx, cy, 130f, 0.25f, 0xFFFFFFFF)

          if (hitStopEnabled) hitStopTimer = 0.022f
          shakeIntensity = max(shakeIntensity, 10f)
          emitSound(SoundEffect.BALL_CLASH, cx)
        }
      }
    }
  }

  private fun deployHydroTrap(waterBall: BallEntity) {
    waterBall.trapPlaceCooldown = 0.85f
    val ownerTraps = hydroTraps.filter { it.ownerId == waterBall.id }
    if (ownerTraps.size >= 2) {
      hydroTraps.remove(ownerTraps.first())
    }
    hydroTraps.add(
      HydroTrap(
        id = nextEntityId++,
        ownerId = waterBall.id,
        x = waterBall.x.coerceIn(72f, ARENA_WIDTH - 72f),
        y = waterBall.y.coerceIn(72f, ARENA_HEIGHT - 72f),
      )
    )
    waterBall.skillsTriggered++
    emitSound(SoundEffect.WATER_TRAP, waterBall.x)
  }

  private fun handleFireWallBounce(fireBall: BallEntity, wallId: Int) {
    val ownerChips = chips.filter { it.ownerId == fireBall.id }
    if (ownerChips.size >= 7) chips.remove(ownerChips.first())

    val chipX =
      when (wallId) {
        0 -> 14f
        1 -> ARENA_WIDTH - 14f
        else -> fireBall.x
      }
    val chipY =
      when (wallId) {
        2 -> 14f
        3 -> ARENA_HEIGHT - 14f
        else -> fireBall.y
      }

    chips.add(FireChip(id = nextEntityId++, ownerId = fireBall.id, x = chipX, y = chipY, wallId = wallId))
    emitSound(SoundEffect.FIRE_CHIP, chipX)

    val updatedOwnerChips = chips.filter { it.ownerId == fireBall.id }
    if (updatedOwnerChips.size >= 2 && fireBall.lastWallId != -1 && fireBall.lastWallId != wallId) {
      lasers.removeAll { it.ownerId == fireBall.id }
      for (i in updatedOwnerChips.indices) {
        for (j in i + 1 until updatedOwnerChips.size) {
          val a = updatedOwnerChips[i]
          val b = updatedOwnerChips[j]
          lasers.add(LaserBeam(ownerId = fireBall.id, x1 = a.x, y1 = a.y, x2 = b.x, y2 = b.y))
        }
      }
      fireBall.skillsTriggered++
      emitSound(SoundEffect.FIRE_LASER, fireBall.x)
    }
  }

  private fun triggerGroundQuakeWave(groundBall: BallEntity) {
    quakeFissureTimer = 0.90f
    quakeOriginX = groundBall.x
    quakeOriginY = groundBall.y
    spawnShockwave(groundBall.x, groundBall.y, 820f, 0.55f, 0xFFD48C3B)
    spawnShockwave(groundBall.x, groundBall.y, 520f, 0.38f, 0xFFFFCA62)
    spawnEmberParticles(groundBall.x, groundBall.y, 16, 0xFFD48C3B)
    shakeIntensity = max(shakeIntensity, 18f)
    emitSound(SoundEffect.GROUND_QUAKE, groundBall.x)
    for (enemy in enemyBallsOf(groundBall.id)) {
      if (enemy.hp <= 0f) continue
      applyDamage(
        attacker = groundBall,
        victim = enemy,
        amount = otaBalance.groundSkill1Damage,
        colorArgb = 0xFFFFCA62,
      )
      if (!enemy.isCcImmune) {
        enemy.soakTimer = 1.5f
        enemy.slowFactor = 0.40f
      }
      spawnEmberParticles(enemy.x, enemy.y, 16, 0xFFFFB74D)
    }
    val antIter = soldierAnts.iterator()
    while (antIter.hasNext()) {
      val ant = antIter.next()
      if (ant.ownerId != groundBall.id && hypot(ant.x - groundBall.x, ant.y - groundBall.y) <= 290f) {
        spawnEmberParticles(ant.x, ant.y, 4, 0xFFFFCA62)
        antIter.remove()
      }
    }
  }

  private fun activateGroundArmor(groundBall: BallEntity) {
    groundBall.earthArmorCooldownTimer = otaBalance.groundArmorCooldownSec
    groundBall.earthArmorTimer = otaBalance.groundArmorDurationSec
    groundBall.rage = 0f
    groundBall.skillsTriggered++
    spawnShockwave(groundBall.x, groundBall.y, 210f, 0.42f, 0xFFFFCA62)
    emitSound(SoundEffect.GROUND_ARMOR, groundBall.x)
  }

  private fun fireIceShardVolley(iceBall: BallEntity, enemy: BallEntity) {
    val baseAngle = atan2(enemy.y - iceBall.y, enemy.x - iceBall.x)
    val speed = 770f * speedMultiplier
    for (i in -2..2) {
      val angle = baseAngle + i * 0.14f
      iceShards.add(
        IceShard(
          id = nextEntityId++,
          ownerId = iceBall.id,
          x = iceBall.x + cos(angle) * (BALL_RADIUS + 14f),
          y = iceBall.y + sin(angle) * (BALL_RADIUS + 14f),
          vx = cos(angle) * speed,
          vy = sin(angle) * speed,
        )
      )
    }
    iceBall.skillsTriggered++
    emitSound(SoundEffect.ICE_SHARD, iceBall.x)
  }

  private fun triggerAntSwarmSkill(antBall: BallEntity, enemy: BallEntity) {
    // Weighted random: 1 (40%), 3 (28%), 5 (18%), 7 (9%), 10 (5%)
    val r = rng.nextFloat()
    val count =
      when {
        r < 0.40f -> 1
        r < 0.68f -> 3
        r < 0.86f -> 5
        r < 0.95f -> 7
        else -> 10
      }
    spawnSoldierAnts(antBall, enemy, count)
    antBall.skillsTriggered++
    addFloatingPopup(
      FloatingDamage(
        id = nextEntityId++,
        x = antBall.x,
        y = antBall.y - BALL_RADIUS - 16f,
        text = "x$count ANTS",
        colorArgb = 0xFFB9FF66,
        isCrit = count >= 7,
      )
    )
    emitSound(SoundEffect.ANT_SWARM, antBall.x)
  }

  private fun spawnSoldierAnts(antBall: BallEntity, enemy: BallEntity, count: Int) {
    val baseAngle = atan2(enemy.y - antBall.y, enemy.x - antBall.x)
    repeat(count) { idx ->
      val spread = (idx - (count - 1) * 0.5f) * 0.34f + (rng.nextFloat() - 0.5f) * 0.25f
      val a = baseAngle + spread
      soldierAnts.add(
        SoldierAnt(
          id = nextEntityId++,
          ownerId = antBall.id,
          x = (antBall.x + cos(a) * (BALL_RADIUS + 20f)).coerceIn(24f, ARENA_WIDTH - 24f),
          y = (antBall.y + sin(a) * (BALL_RADIUS + 20f)).coerceIn(24f, ARENA_HEIGHT - 24f),
          angleRad = a,
        )
      )
    }
  }

  private fun spawnAquaOrb(owner: BallEntity, enemy: BallEntity) {
    val activeForOwner = aquaOrbs.count { it.ownerId == owner.id }
    if (activeForOwner >= 3) {
      aquaOrbs.firstOrNull { it.ownerId == owner.id }?.let { aquaOrbs.remove(it) }
    }
    val angle = atan2(enemy.y - owner.y, enemy.x - owner.x) + (rng.nextFloat() - 0.5f) * 0.35f
    val speed = 470f * speedMultiplier
    aquaOrbs.add(
      AquaOrb(
        id = nextEntityId++,
        ownerId = owner.id,
        x = owner.x + cos(angle) * (BALL_RADIUS + 18f),
        y = owner.y + sin(angle) * (BALL_RADIUS + 18f),
        vx = cos(angle) * speed,
        vy = sin(angle) * speed,
      )
    )
    owner.skillsTriggered++
    emitSound(SoundEffect.WATER_ORB, owner.x)
  }

  private fun triggerUltimate(attacker: BallEntity, victim: BallEntity) {
    attacker.rage = 0f
    attacker.skillsTriggered++
    if (hitStopEnabled) hitStopTimer = 0.036f
    shakeIntensity = max(shakeIntensity, 18f)

    when (attacker.type) {
      BallType.FIRE -> {
        for (e in enemyBallsOf(attacker.id)) {
          if (e.hp <= 0f) continue
          e.burnTimer = 5.0f
          e.burnTickAccumulator = 0.45f
          e.burnDamagePerTick = (e.maxHp * 0.06f) * 0.5f
          spawnEmberParticles(e.x, e.y, 26, 0xFFFF3D00)
        }
        heatDistortionTimer = 5.0f
        spawnShockwave(attacker.x, attacker.y, 460f, 0.52f, 0xFFFF5722)
        emitSound(SoundEffect.FIRE_FURY, attacker.x)
      }
      BallType.WATER -> {
        attacker.burnTimer = 0f
        attacker.soulBurnTimer = 0f
        attacker.venomTimer = 0f
        val startY = attacker.y
        val vy = if (victim.y > attacker.y) 940f else -940f
        tsunamis.add(TsunamiWave(ownerId = attacker.id, y = startY, vy = vy))
        waterRippleTimer = 1.6f
        spawnShockwave(attacker.x, attacker.y, 400f, 0.5f, 0xFF00E5FF)
        emitSound(SoundEffect.WATER_TSUNAMI, attacker.x)
      }
      BallType.GROUND -> {
        activateGroundArmor(attacker)
      }
      BallType.THUNDER -> {
        val pct = otaBalance.thunderDeathboltPct + attacker.deathboltStacks * 0.02f
        val dmg = max(8f, victim.hp * pct)
        attacker.deathboltStacks++
        applyDamage(
          attacker = attacker,
          victim = victim,
          amount = dmg,
          colorArgb = 0xFFFFEA00,
          labelSuffix = "*",
        )
        if (!victim.isCcImmune) {
          victim.silenceTimer = 2.0f
        }
        attacker.sonicDashCooldownTimer = 0f
        val offsets = List(7) { (rng.nextFloat() - 0.5f) * 52f }
        if (lightningBolts.size >= 4) lightningBolts.removeAt(0)
        lightningBolts.add(LightningBolt(victim.x, victim.y, jaggedOffsets = offsets))
        spawnShockwave(victim.x, victim.y, 310f, 0.45f, 0xFFFFEA00)
        spawnEmberParticles(victim.x, victim.y, 32, 0xFF7C4DFF)
        emitSound(SoundEffect.THUNDER_BOLT, victim.x)
      }
      BallType.ICE -> {
        attacker.absoluteZeroCooldownTimer = 20.0f
        val freezeDur = otaBalance.iceFreezeDurationSec.coerceIn(2.0f, 15.0f)
        arenaFreezeTimer = freezeDur
        val drainMult = (1f - otaBalance.iceFreezeRageDrainPct).coerceIn(0f, 1f)
        for (e in enemyBallsOf(attacker.id)) {
          if (e.hp <= 0f) continue
          val prevRage = e.rage
          e.rage = (prevRage * drainMult).coerceAtLeast(0f)
          val drainedPct = (prevRage - e.rage).roundToInt()
          if (!e.isCcImmune) {
            e.frozenTimer = max(e.frozenTimer, freezeDur)
            e.powerReductionTimer = max(e.powerReductionTimer, freezeDur * 0.4f)
          }
          addFloatingPopup(
            FloatingDamage(
              id = nextEntityId++,
              x = e.x,
              y = e.y - BALL_RADIUS - 20f,
              text = if (e.isCcImmune) "IMMUNE!" else "KY BANG HA!",
              colorArgb = if (e.isCcImmune) 0xFFFFCA62 else 0xFF80D8FF,
              isCrit = true,
            )
          )
          if (drainedPct >= 5) {
            addFloatingPopup(
              FloatingDamage(
                id = nextEntityId++,
                x = e.x,
                y = e.y - BALL_RADIUS + 4f,
                text = "-$drainedPct% NO",
                colorArgb = 0xFF40C4FF,
              )
            )
          }
          spawnEmberParticles(e.x, e.y, 18, 0xFF80D8FF)
        }
        spawnShockwave(attacker.x, attacker.y, 760f, 0.7f, 0xFF80D8FF)
        spawnShockwave(attacker.x, attacker.y, 460f, 0.45f, 0xFFFFFFFF)
        spawnEmberParticles(attacker.x, attacker.y, 36, 0xFFE1F5FE)
        emitSound(SoundEffect.ICE_FREEZE, attacker.x)
      }
      BallType.ANT -> {
        // 90% Queen Ant, 8% King Ant, 1% Both Queen + King, 1% Queen + Royal Frenzy
        val roll = rng.nextFloat()
        val royalDuration = 10.0f
        val summonQueen = roll < 0.90f || roll >= 0.98f
        val summonKing = roll in 0.90f..0.99f

        royalAnts.removeAll { it.ownerId == attacker.id }
        val allyList = ballsOf(attacker.id)
        if (summonQueen) {
          for (ally in allyList) ally.antQueenTimer = royalDuration
          royalAnts.add(
            RoyalAntUnit(
              ownerId = attacker.id,
              isQueen = true,
              x = if (attacker.id == 1) 140f else ARENA_WIDTH - 140f,
              y = if (attacker.id == 1) ARENA_HEIGHT - 160f else 160f,
              remainingLife = royalDuration,
              maxLife = royalDuration,
            )
          )
        }
        if (summonKing) {
          for (ally in allyList) {
            ally.antKingTimer = royalDuration
            ally.antKingHealTimer = 14.5f
          }
          royalAnts.add(
            RoyalAntUnit(
              ownerId = attacker.id,
              isQueen = false,
              x = if (attacker.id == 1) ARENA_WIDTH - 140f else 140f,
              y = if (attacker.id == 1) ARENA_HEIGHT - 160f else 160f,
              remainingLife = royalDuration,
              maxLife = royalDuration,
            )
          )
        }
        if (roll >= 0.99f) {
          spawnSoldierAnts(attacker, victim, 3)
        }
        val banner =
          when {
            summonQueen && summonKing -> "QUEEN+KING!"
            summonKing -> "KING ANT!"
            else -> "QUEEN ANT!"
          }
        addFloatingPopup(
          FloatingDamage(
            id = nextEntityId++,
            x = attacker.x,
            y = attacker.y - BALL_RADIUS - 22f,
            text = banner,
            colorArgb = if (summonKing && summonQueen) 0xFFFFD54F else 0xFFFF2E63,
            isCrit = true,
          )
        )
        spawnShockwave(attacker.x, attacker.y, 480f, 0.6f, 0xFF00E676)
        spawnEmberParticles(attacker.x, attacker.y, 26, 0xFFFF2E63)
        emitSound(SoundEffect.ANT_ROYAL, attacker.x)
      }
    }
  }

  private fun updateChipsAndLasers(dt: Float) {
    val chipIter = chips.iterator()
    while (chipIter.hasNext()) {
      val chip = chipIter.next()
      chip.remainingLife -= dt
      if (chip.remainingLife <= 0f) chipIter.remove()
    }

    val laserIter = lasers.iterator()
    while (laserIter.hasNext()) {
      val laser = laserIter.next()
      laser.remainingLife -= dt
      if (laser.remainingLife <= 0f) {
        laserIter.remove()
        continue
      }
      val attacker = leadBall(laser.ownerId)
      for (victim in enemyBallsOf(laser.ownerId)) {
        if (victim.hp <= 0f) continue
        if (victim.laserBurnCooldown <= 0f &&
          pointToSegmentDistance(victim.x, victim.y, laser.x1, laser.y1, laser.x2, laser.y2) <=
            BALL_RADIUS + 8f
        ) {
          victim.laserBurnCooldown = 0.25f
          applyDamage(
            attacker = attacker,
            victim = victim,
            amount = 2f,
            colorArgb = 0xFFFF9100,
          )
          spawnEmberParticles(victim.x, victim.y, 5, 0xFFFFAB00)
        }
      }
    }
  }

  private fun updateHydroTraps(dt: Float) {
    val iter = hydroTraps.iterator()
    while (iter.hasNext()) {
      val trap = iter.next()
      trap.remainingLife -= dt
      trap.angleDeg = (trap.angleDeg + dt * 340f) % 360f
      if (trap.remainingLife <= 0f) {
        iter.remove()
        continue
      }
      val owner = leadBall(trap.ownerId)
      var sprung = false
      for (victim in enemyBallsOf(trap.ownerId)) {
        if (victim.hp <= 0f) continue
        if (victim.trappedTimer <= 0f &&
          victim.trapImmunityTimer <= 0f &&
          hypot(victim.x - trap.x, victim.y - trap.y) <= trap.radius + BALL_RADIUS * 0.45f
        ) {
          if (!victim.isCcImmune) {
            victim.trappedTimer = 1.4f
            victim.trappedCenterX = trap.x
            victim.trappedCenterY = trap.y
            victim.trapTickAccumulator = 0.30f
            victim.trapDamagePerTick = 5f
          } else {
            applyDamage(owner, victim, 10f, colorArgb = 0xFF00E5FF)
          }
          spawnShockwave(trap.x, trap.y, 130f, 0.3f, 0xFF00E5FF)
          emitSound(SoundEffect.WATER_TRAP, trap.x)
          sprung = true
          break
        }
      }
      if (sprung) iter.remove()
    }
  }

  private fun updateAquaOrbs(dt: Float) {
    val iter = aquaOrbs.iterator()
    while (iter.hasNext()) {
      val orb = iter.next()
      orb.remainingLife -= dt
      if (orb.remainingLife <= 0f) {
        iter.remove()
        continue
      }
      val owner = leadBall(orb.ownerId)
      val enemy = nearestLivingEnemy(orb.x, orb.y, orb.ownerId) ?: leadBall(if (orb.ownerId == 1) 2 else 1)

      val targetAngle = atan2(enemy.y - orb.y, enemy.x - orb.x)
      val currentAngle = atan2(orb.vy, orb.vx)
      var diff = targetAngle - currentAngle
      while (diff > PI) diff -= (2f * PI.toFloat())
      while (diff < -PI) diff += (2f * PI.toFloat())
      val steer = diff.coerceIn(-1.45f * dt, 1.45f * dt)
      val speed = hypot(orb.vx, orb.vy)
      val nextAngle = currentAngle + steer
      orb.vx = cos(nextAngle) * speed
      orb.vy = sin(nextAngle) * speed

      orb.x += orb.vx * dt
      orb.y += orb.vy * dt

      if (orb.x < orb.radius) {
        orb.x = orb.radius
        orb.vx = abs(orb.vx)
      } else if (orb.x > ARENA_WIDTH - orb.radius) {
        orb.x = ARENA_WIDTH - orb.radius
        orb.vx = -abs(orb.vx)
      }
      if (orb.y < orb.radius) {
        orb.y = orb.radius
        orb.vy = abs(orb.vy)
      } else if (orb.y > ARENA_HEIGHT - orb.radius) {
        orb.y = ARENA_HEIGHT - orb.radius
        orb.vy = -abs(orb.vy)
      }

      val extinguished =
        chips.firstOrNull {
          it.ownerId == enemy.id && hypot(it.x - orb.x, it.y - orb.y) <= orb.radius + 26f
        }
      if (extinguished != null) {
        chips.remove(extinguished)
        spawnEmberParticles(extinguished.x, extinguished.y, 12, 0xFFB2EBF2)
        emitSound(SoundEffect.EXTINGUISH, extinguished.x)
      }

      if (enemy.hp > 0f && hypot(enemy.x - orb.x, enemy.y - orb.y) <= BALL_RADIUS + orb.radius) {
        val elementalBonus = if (enemy.type == BallType.FIRE) 1f else 0f
        applyDamage(owner, enemy, 7f + elementalBonus, colorArgb = 0xFF00E5FF)
        if (!enemy.isCcImmune) {
          enemy.soakTimer = 2.0f
          enemy.slowFactor = 0.86f
        }
        enemy.flashTimer = 0.14f
        addRage(owner, 7f)
        spawnEmberParticles(orb.x, orb.y, 16, 0xFF00E5FF)
        spawnShockwave(orb.x, orb.y, 95f, 0.25f, 0xFF00E5FF)
        shakeIntensity = max(shakeIntensity, 7f)
        emitSound(SoundEffect.WATER_ORB, orb.x)
        iter.remove()
      }
    }
  }

  private fun updateTsunamiWaves(dt: Float) {
    val iter = tsunamis.iterator()
    while (iter.hasNext()) {
      val wave = iter.next()
      wave.remainingLife -= dt
      if (wave.remainingLife <= 0f) {
        iter.remove()
        continue
      }
      wave.y += wave.vy * dt
      if (wave.y < 0f) wave.y = ARENA_HEIGHT
      if (wave.y > ARENA_HEIGHT) wave.y = 0f

      val owner = leadBall(wave.ownerId)
      val enemySide = if (wave.ownerId == 1) 2 else 1

      if (rng.nextFloat() < 0.7f) {
        spawnEmberParticles(rng.nextFloat() * ARENA_WIDTH, wave.y, 2, 0xFF80DEEA)
      }

      val washed = chips.filter { it.ownerId == enemySide && abs(it.y - wave.y) <= 65f }
      if (washed.isNotEmpty()) {
        washed.forEach { spawnEmberParticles(it.x, it.y, 8, 0xFFE0F7FA) }
        chips.removeAll(washed)
        emitSound(SoundEffect.EXTINGUISH)
      }

      if (!wave.hasHitEnemy) {
        for (enemy in enemyBallsOf(wave.ownerId)) {
          if (enemy.hp <= 0f) continue
          if (abs(enemy.y - wave.y) <= BALL_RADIUS + 42f) {
            wave.hasHitEnemy = true
            val dmg = if (enemy.type == BallType.FIRE) 25f else 22f
            applyDamage(owner, enemy, dmg, colorArgb = 0xFF18FFFF, labelSuffix = "!")
            if (!enemy.isCcImmune) {
              enemy.soakTimer = 2.5f
              enemy.slowFactor = 0.84f
              enemy.vy += if (wave.vy > 0f) 260f else -260f
            }
            enemy.flashTimer = 0.22f
            spawnEmberParticles(enemy.x, enemy.y, 24, 0xFF00E5FF)
            spawnShockwave(enemy.x, enemy.y, 220f, 0.35f, 0xFF18FFFF)
            shakeIntensity = max(shakeIntensity, 16f)
          }
        }
      }
    }
  }

  private fun updateAfterimages(dt: Float) {
    val iter = afterimages.iterator()
    while (iter.hasNext()) {
      val clone = iter.next()
      clone.remainingLife -= dt
      if (clone.remainingLife <= 0f) {
        iter.remove()
        continue
      }
      val owner = leadBall(clone.ownerId)
      for (enemy in enemyBallsOf(clone.ownerId)) {
        if (enemy.hp <= 0f) continue
        if (hypot(enemy.x - clone.x, enemy.y - clone.y) <= BALL_RADIUS + 18f) {
          if (owner.dashRageGained < 45) {
            addRage(owner, 1f)
            owner.dashRageGained++
          }
          spawnEmberParticles(clone.x, clone.y, 3, 0xFFFFEA00)
          iter.remove()
          break
        }
      }
    }
  }

  private fun updateIceShards(dt: Float) {
    val iter = iceShards.iterator()
    while (iter.hasNext()) {
      val shard = iter.next()
      shard.remainingLife -= dt
      if (shard.remainingLife <= 0f) {
        iter.remove()
        continue
      }
      shard.x += shard.vx * dt
      shard.y += shard.vy * dt
      if (shard.x < 0f || shard.x > ARENA_WIDTH || shard.y < 0f || shard.y > ARENA_HEIGHT) {
        iter.remove()
        continue
      }
      val owner = leadBall(shard.ownerId)
      for (enemy in enemyBallsOf(shard.ownerId)) {
        if (enemy.hp <= 0f) continue
        if (hypot(enemy.x - shard.x, enemy.y - shard.y) <= BALL_RADIUS + shard.radius) {
          applyDamage(owner, enemy, otaBalance.iceShardDamage.toFloat(), colorArgb = 0xFF80D8FF)
          if (!enemy.isCcImmune) {
            enemy.soakTimer = 1.2f
            enemy.slowFactor = 0.30f
          }
          enemy.flashTimer = 0.1f
          addRage(owner, 4f)
          spawnEmberParticles(shard.x, shard.y, 10, 0xFFE1F5FE)
          spawnShockwave(shard.x, shard.y, 72f, 0.20f, 0xFF80D8FF)
          iter.remove()
          break
        }
      }
    }
  }

  private fun updateSoldierAnts(dt: Float) {
    // Soldier Ants have NO lifetime limit and CANNOT be destroyed until biting an enemy ball!
    val iter = soldierAnts.iterator()
    while (iter.hasNext()) {
      val ant = iter.next()
      ant.ageSec += dt
      val owner = leadBall(ant.ownerId)
      val enemy = nearestLivingEnemy(ant.x, ant.y, ant.ownerId) ?: continue

      val hasQueen = hasRoyalQueen(ant.ownerId)
      val hasKing = hasRoyalKing(ant.ownerId)
      val bothActive = hasQueen && hasKing

      val sizeScale =
        when {
          bothActive -> 1.32f
          hasQueen -> 1.18f
          else -> 1.0f
        }
      val speedMult =
        when {
          bothActive -> 1.28f
          hasKing -> 1.16f
          else -> 1.0f
        }
      val moveSpeed = 265f * speedMultiplier * speedMult
      val targetAngle = atan2(enemy.y - ant.y, enemy.x - ant.x)
      ant.angleRad = targetAngle
      ant.x = (ant.x + cos(targetAngle) * moveSpeed * dt).coerceIn(14f, ARENA_WIDTH - 14f)
      ant.y = (ant.y + sin(targetAngle) * moveSpeed * dt).coerceIn(14f, ARENA_HEIGHT - 14f)

      val antRadius = ant.baseRadius * sizeScale
      if (hypot(enemy.x - ant.x, enemy.y - ant.y) <= BALL_RADIUS + antRadius) {
        val biteDamage =
          when {
            bothActive -> 9f
            hasQueen -> 7f
            else -> 5f
          }
        applyDamage(owner, enemy, biteDamage, colorArgb = 0xFFFF2E63)
        if (!enemy.isCcImmune) {
          enemy.antSlowStacks.add(0.5f)
        }
        if (hasQueen || hasKing) {
          val venomPct =
            when {
              bothActive -> 0.08f
              hasKing -> 0.03f
              else -> 0.01f
            }
          enemy.venomTimer = 5.0f
          enemy.venomPctPerSec = max(enemy.venomPctPerSec, venomPct)
        }
        addRage(owner, 4f)
        spawnEmberParticles(ant.x, ant.y, 7, 0xFF00E676)
        iter.remove()
      }
    }
  }

  private fun updateRoyalAnts(dt: Float) {
    val iter = royalAnts.iterator()
    while (iter.hasNext()) {
      val unit = iter.next()
      unit.remainingLife -= dt
      if (unit.remainingLife <= 0f) {
        iter.remove()
      }
    }
  }

  private fun updateVisualEffectsOnly(dt: Float) {
    val eIter = emoteBubbles.iterator()
    while (eIter.hasNext()) {
      val e = eIter.next()
      e.remainingLife -= dt
      if (e.remainingLife <= 0f) eIter.remove()
    }

    val bIter = lightningBolts.iterator()
    while (bIter.hasNext()) {
      val b = bIter.next()
      b.remainingLife -= dt
      if (b.remainingLife <= 0f) bIter.remove()
    }

    val pIter = particles.iterator()
    while (pIter.hasNext()) {
      val p = pIter.next()
      p.life -= dt
      if (p.life <= 0f) pIter.remove()
      else {
        p.vy += p.gravity * dt
        p.x += p.vx * dt
        p.y += p.vy * dt
      }
    }

    val sIter = shockwaves.iterator()
    while (sIter.hasNext()) {
      val s = sIter.next()
      s.life -= dt
      if (s.life <= 0f) sIter.remove()
      else s.radius = s.maxRadius * (1f - s.life / s.maxLife)
    }

    val dIter = floatingDamages.iterator()
    while (dIter.hasNext()) {
      val d = dIter.next()
      d.life -= dt
      if (d.life <= 0f) dIter.remove()
      else d.y -= 58f * dt
    }
  }

  fun triggerKoExplosionParticles(winnerId: Int, effectTypeId: String) {
    val loser = if (winnerId == 1) side2Balls.last() else side1Balls.last()
    val primaryColor = colorForBall(loser.type)
    val secondaryColor = if (winnerId == 1) 0xFFFFD54F else 0xFF18FFFF

    when (effectTypeId) {
      "shockwave" -> {
        spawnShockwave(loser.x, loser.y, 520f, 0.85f, primaryColor)
        spawnShockwave(loser.x, loser.y, 380f, 0.65f, 0xFFFFFFFF)
        spawnShockwave(loser.x, loser.y, 240f, 0.45f, secondaryColor)
        spawnEmberParticles(loser.x, loser.y, 45, primaryColor)
      }
      "particle_nova" -> {
        repeat(80) {
          if (particles.size >= 280) particles.removeAt(0)
          val angle = rng.nextFloat() * 2f * PI.toFloat()
          val speed = 140f + rng.nextFloat() * 640f
          val color = if (it % 3 == 0) 0xFFFFFFFF else if (it % 2 == 0) primaryColor else secondaryColor
          particles.add(
            Particle(
              x = loser.x,
              y = loser.y,
              vx = cos(angle) * speed,
              vy = sin(angle) * speed,
              size = 5f + rng.nextFloat() * 9f,
              life = 0.9f + rng.nextFloat() * 0.5f,
              maxLife = 1.4f,
              colorArgb = color,
              gravity = 240f,
            )
          )
        }
      }
      "dissolve" -> {
        repeat(65) {
          if (particles.size >= 280) particles.removeAt(0)
          val offsetX = (rng.nextFloat() - 0.5f) * BALL_RADIUS * 2f
          val offsetY = (rng.nextFloat() - 0.5f) * BALL_RADIUS * 2f
          particles.add(
            Particle(
              x = loser.x + offsetX,
              y = loser.y + offsetY,
              vx = offsetX * 1.8f + (rng.nextFloat() - 0.5f) * 80f,
              vy = -120f - rng.nextFloat() * 280f,
              size = 6f + rng.nextFloat() * 8f,
              life = 1.1f + rng.nextFloat() * 0.5f,
              maxLife = 1.6f,
              colorArgb = if (it % 2 == 0) primaryColor else 0xFFFFD54F,
              gravity = -120f,
            )
          )
        }
      }
      else -> {
        spawnShockwave(loser.x, loser.y, 340f, 0.5f, primaryColor)
        spawnEmberParticles(loser.x, loser.y, 32, primaryColor)
      }
    }
  }

  private fun applyDamage(
    attacker: BallEntity,
    victim: BallEntity,
    amount: Float,
    colorArgb: Long,
    labelSuffix: String = "",
  ) {
    val otaScale = otaBalance.damageScaleFor(attacker.type)
    val scaled = amount * otaScale * attacker.outgoingPowerMultiplier
    val reduced = scaled * (1f - victim.allDamageReduction(otaBalance))
    if (reduced <= 0.1f) return
    val prevHp = victim.hp
    victim.hp -= reduced
    attacker.totalDamageDealt += reduced
    if (prevHp > 0f && victim.hp <= 0f && ballsOf(victim.id).any { it !== victim && it.hp > 0f }) {
      // Clone or individual Ant Ball burst VFX when teammate remains alive!
      spawnShockwave(victim.x, victim.y, 200f, 0.42f, colorForBall(victim.type))
      spawnEmberParticles(victim.x, victim.y, 20, 0xFFFF2E63)
      emitSound(SoundEffect.BALL_CLASH, victim.x)
    }
    val shown = max(1, reduced.roundToInt())
    addFloatingPopup(
      FloatingDamage(
        id = nextEntityId++,
        x = victim.x + (rng.nextFloat() - 0.5f) * 34f,
        y = victim.y - BALL_RADIUS * 0.8f,
        text = "-$shown$labelSuffix",
        colorArgb = colorArgb,
        isCrit = shown >= 15 || labelSuffix.isNotEmpty(),
      )
    )
  }

  private fun addFloatingPopup(popup: FloatingDamage) {
    if (floatingDamages.size >= 28) floatingDamages.removeAt(0)
    floatingDamages.add(popup)
  }

  private fun addRage(ball: BallEntity, delta: Float) {
    if (ball.earthArmorTimer > 0f) return
    ball.rage = min(100f, ball.rage + delta)
  }

  private fun spawnEmberParticles(x: Float, y: Float, count: Int, colorArgb: Long) {
    val scaledCount = (count * otaVfx.particleMultiplier).roundToInt().coerceIn(1, 54)
    val scaleFactor = otaVfx.effectScale.coerceIn(0.75f, 1.5f)
    repeat(scaledCount) {
      if (particles.size >= 280) particles.removeAt(0)
      val angle = rng.nextFloat() * 2f * PI.toFloat()
      val speed = 60f + rng.nextFloat() * 290f
      particles.add(
        Particle(
          x = x,
          y = y,
          vx = cos(angle) * speed,
          vy = sin(angle) * speed,
          size = (3.5f + rng.nextFloat() * 5.2f) * scaleFactor,
          life = 0.35f + rng.nextFloat() * 0.45f,
          maxLife = 0.8f,
          colorArgb = colorArgb,
        )
      )
    }
  }

  private fun spawnShockwave(
    x: Float,
    y: Float,
    maxRadius: Float,
    duration: Float,
    colorArgb: Long,
  ) {
    if (shockwaves.size >= 18) shockwaves.removeAt(0)
    shockwaves.add(
      ShockwaveRing(
        x = x,
        y = y,
        radius = 12f,
        maxRadius = maxRadius * otaVfx.effectScale.coerceIn(0.8f, 1.45f),
        life = duration,
        maxLife = duration,
        colorArgb = colorArgb,
      )
    )
  }

  private fun pointToSegmentDistance(
    px: Float,
    py: Float,
    x1: Float,
    y1: Float,
    x2: Float,
    y2: Float,
  ): Float {
    val dx = x2 - x1
    val dy = y2 - y1
    val lenSq = dx * dx + dy * dy
    if (lenSq <= 0.0001f) return hypot(px - x1, py - y1)
    val t = (((px - x1) * dx + (py - y1) * dy) / lenSq).coerceIn(0f, 1f)
    val projX = x1 + t * dx
    val projY = y1 + t * dy
    return hypot(px - projX, py - projY)
  }

  private fun colorForBall(type: BallType): Long =
    when (type) {
      BallType.FIRE -> 0xFFFF5722
      BallType.WATER -> 0xFF00E5FF
      BallType.GROUND -> 0xFFD48C3B
      BallType.THUNDER -> 0xFFFFEA00
      BallType.ICE -> 0xFF80D8FF
      BallType.ANT -> 0xFFFF2E63
    }

  private fun cloneBall(b: BallEntity): BallEntity =
    b.copy(
      trail = ArrayDeque(b.trail),
      antSlowStacks = b.antSlowStacks.toMutableList(),
    )

  fun snapshot(): ArenaSnapshot {
    val s1 = side1Balls.map(::cloneBall)
    val s2 = side2Balls.map(::cloneBall)
    val lead1 = s1.firstOrNull { it.hp > 0f } ?: s1.last()
    val lead2 = s2.firstOrNull { it.hp > 0f } ?: s2.last()
    val s1Rem =
      if (p1BallType == BallType.ANT && s1.any { it.hp > 0f } && side1AntSpawnCount < otaBalance.antMaxRegens) {
        (otaBalance.antRegenIntervalSec - side1AntRegenTimer).coerceAtLeast(0f)
      } else 0f
    val s2Rem =
      if (p2BallType == BallType.ANT && s2.any { it.hp > 0f } && side2AntSpawnCount < otaBalance.antMaxRegens) {
        (otaBalance.antRegenIntervalSec - side2AntRegenTimer).coerceAtLeast(0f)
      } else 0f
    return ArenaSnapshot(
      phase = phase,
      mode = mode,
      p1 = lead1,
      p2 = lead2,
      side1Balls = s1,
      side2Balls = s2,
      side1AntTotalSpawned = side1AntSpawnCount,
      side2AntTotalSpawned = side2AntSpawnCount,
      side1AntNextSpawnRemSec = s1Rem,
      side2AntNextSpawnRemSec = s2Rem,
      side1TotalDamageDealt = s1.sumOf { it.totalDamageDealt.toDouble() }.toFloat(),
      side2TotalDamageDealt = s2.sumOf { it.totalDamageDealt.toDouble() }.toFloat(),
      side1SkillsTriggered = s1.sumOf { it.skillsTriggered },
      side2SkillsTriggered = s2.sumOf { it.skillsTriggered },
      chips = chips.map { it.copy() },
      lasers = lasers.map { it.copy() },
      aquaOrbs = aquaOrbs.map { it.copy() },
      hydroTraps = hydroTraps.map { it.copy() },
      tsunamis = tsunamis.map { it.copy() },
      afterimages = afterimages.map { it.copy() },
      lightningBolts = lightningBolts.map { it.copy() },
      iceShards = iceShards.map { it.copy() },
      soldierAnts = soldierAnts.map { it.copy() },
      companionAnts = emptyList(),
      royalAnts = royalAnts.map { it.copy() },
      emoteBubbles = emoteBubbles.map { it.copy() },
      particles = particles.map { it.copy() },
      shockwaves = shockwaves.map { it.copy() },
      floatingDamages = floatingDamages.map { it.copy() },
      matchElapsedSec = matchElapsedSec,
      shakeIntensity = shakeIntensity,
      heatDistortionTimer = heatDistortionTimer,
      fireRealmTimer = fireRealmTimer,
      fireRealmOwnerId = fireRealmOwnerId,
      waterRippleTimer = waterRippleTimer,
      arenaFreezeTimer = arenaFreezeTimer,
      quakeFissureTimer = quakeFissureTimer,
      quakeOriginX = quakeOriginX,
      quakeOriginY = quakeOriginY,
      winnerId = winnerId,
      interpolationAlpha = (accumulator / FIXED_PHYSICS_DT).coerceIn(0f, 1f),
    )
  }
}
