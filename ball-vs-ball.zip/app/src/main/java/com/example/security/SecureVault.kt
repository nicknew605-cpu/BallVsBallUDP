package com.example.security

import android.content.Context
import android.util.Base64
import com.example.model.BallType
import com.example.model.KillEffectType
import com.example.model.UserProgress
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object SecureVault {
  // Obfuscated key material combined with package identity to deter static inspection & tampering
  private val kA = byteArrayOf(0x4B, 0x19, 0x72, 0x6A, 0x3C, 0x55, 0x2F, 0x71)
  private val kB = byteArrayOf(0x21, 0x6E, 0x14, 0x58, 0x4D, 0x07, 0x63, 0x39)
  private val kMask = byteArrayOf(0x3A, 0x51, 0x22, 0x1F, 0x44, 0x69, 0x0E, 0x7C)
  private const val SALT_TAG = "bvb_hct_vault_v1"
  private const val GCM_TAG_BITS = 128
  private const val IV_SIZE = 12
  private const val HMAC_SIZE = 32

  private val random = SecureRandom()

  private fun deriveKeys(context: Context): Pair<SecretKeySpec, SecretKeySpec> {
    val pkg = context.packageName
    val rawSecret = ByteArray(16)
    for (i in 0 until 8) {
      rawSecret[i] = (kA[i].toInt() xor kMask[i].toInt()).toByte()
      rawSecret[i + 8] = (kB[i].toInt() xor kMask[7 - i].toInt()).toByte()
    }
    val digest = MessageDigest.getInstance("SHA-256")
    digest.update(rawSecret)
    digest.update(pkg.toByteArray(Charsets.UTF_8))
    digest.update(SALT_TAG.toByteArray(Charsets.UTF_8))
    val master = digest.digest()

    val aesKey = SecretKeySpec(master.copyOfRange(0, 16), "AES")
    val hmacDigest = MessageDigest.getInstance("SHA-256").digest(master + byteArrayOf(0x5A, 0x3C))
    val hmacKey = SecretKeySpec(hmacDigest, "HmacSHA256")
    return aesKey to hmacKey
  }

  fun seal(context: Context, progress: UserProgress): String {
    val payload = serialize(progress).toByteArray(Charsets.UTF_8)
    val (aesKey, hmacKey) = deriveKeys(context)

    val iv = ByteArray(IV_SIZE).also { random.nextBytes(it) }
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, aesKey, GCMParameterSpec(GCM_TAG_BITS, iv))
    val cipherText = cipher.doFinal(payload)

    val mac = Mac.getInstance("HmacSHA256")
    mac.init(hmacKey)
    mac.update(iv)
    mac.update(cipherText)
    val tag = mac.doFinal()

    val combined = ByteArray(iv.size + cipherText.size + tag.size)
    System.arraycopy(iv, 0, combined, 0, iv.size)
    System.arraycopy(cipherText, 0, combined, iv.size, cipherText.size)
    System.arraycopy(tag, 0, combined, iv.size + cipherText.size, tag.size)
    return Base64.encodeToString(combined, Base64.NO_WRAP)
  }

  fun unseal(context: Context, encoded: String?): UserProgress? {
    if (encoded.isNullOrBlank()) return null
    return try {
      val combined = Base64.decode(encoded, Base64.NO_WRAP)
      if (combined.size <= IV_SIZE + HMAC_SIZE) return null

      val iv = combined.copyOfRange(0, IV_SIZE)
      val cipherLen = combined.size - IV_SIZE - HMAC_SIZE
      val cipherText = combined.copyOfRange(IV_SIZE, IV_SIZE + cipherLen)
      val storedTag = combined.copyOfRange(IV_SIZE + cipherLen, combined.size)

      val (aesKey, hmacKey) = deriveKeys(context)
      val mac = Mac.getInstance("HmacSHA256")
      mac.init(hmacKey)
      mac.update(iv)
      mac.update(cipherText)
      val expectedTag = mac.doFinal()
      if (!MessageDigest.isEqual(storedTag, expectedTag)) return null

      val cipher = Cipher.getInstance("AES/GCM/NoPadding")
      cipher.init(Cipher.DECRYPT_MODE, aesKey, GCMParameterSpec(GCM_TAG_BITS, iv))
      val plain = String(cipher.doFinal(cipherText), Charsets.UTF_8)
      deserialize(plain)
    } catch (_: Throwable) {
      null
    }
  }

  private fun serialize(p: UserProgress): String {
    val balls = p.purchasedBalls.joinToString(",") { it.id }
    val effects = p.purchasedKillEffects.joinToString(",") { it.id }
    val safeNick = Base64.encodeToString(p.nickname.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    val codes = p.redeemedCodes.joinToString(",") { it.trim() }
    val safeCode = Base64.encodeToString(p.playerCode.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    val trials =
      p.ballTrials.entries.joinToString(";") { (id, exp) -> "${id.trim()}:$exp" }
    return listOf(
      p.coins.toString(),
      balls,
      effects,
      p.equippedBall.id,
      p.equippedKillEffect.id,
      p.tanThuActivatedAtMillis.toString(),
      p.totalWins.toString(),
      p.totalMatches.toString(),
      p.gachaPityCount.toString(),
      p.totalSpins.toString(),
      safeNick,
      codes,
      p.dailyStreak.toString(),
      p.lastDailyClaimEpochDay.toString(),
      safeCode,
      trials,
    ).joinToString("|")
  }

  private fun deserialize(raw: String): UserProgress? {
    val parts = raw.split("|")
    if (parts.size < 10) return null
    val coins = parts[0].toIntOrNull()?.coerceAtLeast(0) ?: return null
    val balls =
      parts[1]
        .split(",")
        .filter { it.isNotBlank() }
        .map { BallType.fromId(it) }
        .toSet() + BallType.FIRE
    val effects =
      parts[2]
        .split(",")
        .filter { it.isNotBlank() }
        .map { KillEffectType.fromId(it) }
        .toSet() + KillEffectType.DEFAULT_BURST
    val equippedBall = BallType.fromId(parts[3])
    val equippedEffect = KillEffectType.fromId(parts[4])
    val tanThuAt = parts[5].toLongOrNull() ?: 0L
    val wins = parts[6].toIntOrNull()?.coerceAtLeast(0) ?: 0
    val matches = parts[7].toIntOrNull()?.coerceAtLeast(0) ?: 0
    val pity = parts[8].toIntOrNull()?.coerceIn(0, 9) ?: 0
    val spins = parts[9].toIntOrNull()?.coerceAtLeast(0) ?: 0
    val nickname =
      if (parts.size > 10 && parts[10].isNotBlank()) {
        runCatching { String(Base64.decode(parts[10], Base64.NO_WRAP), Charsets.UTF_8) }
          .getOrNull()
          ?.takeIf { it.isNotBlank() } ?: "Challenger"
      } else {
        "Challenger"
      }
    val redeemedCodes =
      if (parts.size > 11 && parts[11].isNotBlank()) {
        parts[11].split(",").filter { it.isNotBlank() }.toSet()
      } else {
        emptySet()
      }
    val dailyStreak =
      if (parts.size > 12) parts[12].toIntOrNull()?.coerceAtLeast(0) ?: 0 else 0
    val lastDailyEpochDay =
      if (parts.size > 13) parts[13].toLongOrNull()?.coerceAtLeast(0L) ?: 0L else 0L
    val playerCode =
      if (parts.size > 14 && parts[14].isNotBlank()) {
        runCatching { String(Base64.decode(parts[14], Base64.NO_WRAP), Charsets.UTF_8) }
          .getOrNull()
          .orEmpty()
      } else {
        ""
      }
    val ballTrials =
      if (parts.size > 15 && parts[15].isNotBlank()) {
        parts[15]
          .split(";")
          .mapNotNull { entry ->
            val segs = entry.split(":")
            if (segs.size == 2) {
              val exp = segs[1].toLongOrNull() ?: 0L
              if (segs[0].isNotBlank() && exp > 0L) segs[0].trim() to exp else null
            } else {
              null
            }
          }
          .toMap()
      } else {
        emptyMap()
      }

    return UserProgress(
      nickname = nickname,
      coins = coins,
      purchasedBalls = balls,
      purchasedKillEffects = effects,
      equippedBall = equippedBall,
      equippedKillEffect = equippedEffect,
      tanThuActivatedAtMillis = tanThuAt,
      totalWins = wins,
      totalMatches = matches,
      gachaPityCount = pity,
      totalSpins = spins,
      redeemedCodes = redeemedCodes,
      dailyStreak = dailyStreak,
      lastDailyClaimEpochDay = lastDailyEpochDay,
      playerCode = playerCode,
      ballTrials = ballTrials,
    )
  }
}
