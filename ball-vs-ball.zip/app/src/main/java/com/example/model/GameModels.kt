package com.example.model

const val APP_DISPLAY_VERSION = "1.0.3 Beta"
const val APP_VERSION_CODE = 7
const val DEFAULT_GITHUB_REPO = "nicknew605-cpu/BallVsBallUDP"
const val DEFAULT_V103_RAW_APK_URL =
  "https://github.com/nicknew605-cpu/BallVsBallUDP/raw/main/BallVsBall_v1.0.3-beta.apk"
const val TAN_THU_CODE = "TanThu"
const val TAIDZ_CODE = "TaiDz-111"
const val TRIAN_CODE = "TriAn"
const val TRIAN_CREATED_AT_MILLIS = 1794641400000L
const val TRIAN_EXPIRES_AT_MILLIS = 1795246200000L
const val ADMIN_OWNER_EMAIL = "nicknew605@gmail.com"
const val TAN_THU_DURATION_MILLIS = 24L * 60L * 60L * 1000L
const val GACHA_SPIN_COST = 120
const val GACHA_PITY_THRESHOLD = 10
const val ONLINE_FT3_TARGET_SCORE = 3

enum class AppLanguage(val code: String) {
  VI("vi"),
  EN("en");

  companion object {
    fun fromCode(code: String?): AppLanguage =
      entries.firstOrNull { it.code == code } ?: VI
  }
}

enum class AccountMode {
  GUEST,
  GOOGLE,
}

enum class GraphicsQuality(val id: String, val tierRank: Int) {
  LOW("low", 0),
  MEDIUM("medium", 1),
  HIGH("high", 2),
  ULTRA("ultra", 3);

  companion object {
    fun fromId(id: String?): GraphicsQuality =
      entries.firstOrNull { it.id == id } ?: HIGH
  }
}

enum class BallRarity(val id: String) {
  COMMON("common"),
  UNCOMMON("uncommon"),
  RARE("rare");

  companion object {
    fun fromId(id: String?): BallRarity =
      when (id?.lowercase()) {
        "common", "popular" -> COMMON
        "uncommon" -> UNCOMMON
        "rare" -> RARE
        else -> COMMON
      }
  }
}

enum class BallType(
  val id: String,
  val price: Int,
  val rarity: BallRarity,
  val baseHp: Int,
  val attackRating: Int,
  val defenseRating: Int,
  val speedRating: Int,
  val controlRating: Int,
) {
  FIRE("fire", 0, BallRarity.COMMON, 125, 86, 62, 82, 74),
  WATER("water", 1200, BallRarity.COMMON, 130, 80, 74, 82, 88),
  GROUND("ground", 2200, BallRarity.COMMON, 145, 78, 94, 62, 86),
  THUNDER("thunder", 4200, BallRarity.UNCOMMON, 115, 90, 56, 98, 80),
  ICE("ice", 4500, BallRarity.UNCOMMON, 120, 82, 74, 68, 99),
  ANT("ant", 5200, BallRarity.RARE, 120, 84, 74, 74, 94);

  companion object {
    fun fromId(id: String?): BallType = entries.firstOrNull { it.id == id } ?: FIRE
  }
}

enum class KillEffectType(val id: String, val price: Int) {
  DEFAULT_BURST("default_burst", 0),
  SHOCKWAVE("shockwave", 250),
  PARTICLE_NOVA("particle_nova", 480),
  DISSOLVE("dissolve", 750);

  companion object {
    fun fromId(id: String?): KillEffectType =
      entries.firstOrNull { it.id == id } ?: DEFAULT_BURST
  }
}

enum class GameMode(val id: String) {
  ONE_VS_AI("1vsAI"),
  ONE_VS_ONE("1vs1"),
  ONLINE_1VS1("online_1vs1");

  companion object {
    fun fromId(id: String?): GameMode = entries.firstOrNull { it.id == id } ?: ONE_VS_AI
  }
}

enum class AiDifficulty(val id: String) {
  EASY("easy"),
  NORMAL("normal"),
  HARD("hard");

  companion object {
    fun fromId(id: String?): AiDifficulty = entries.firstOrNull { it.id == id } ?: NORMAL
  }
}

data class DailyRewardTier(
  val day: Int,
  val coins: Int,
  val labelVi: String,
  val labelEn: String,
) {
  companion object {
    val weekSchedule: List<DailyRewardTier> = listOf(
      DailyRewardTier(1, 120, "Ngay 1", "Day 1"),
      DailyRewardTier(2, 220, "Ngay 2", "Day 2"),
      DailyRewardTier(3, 350, "Ngay 3", "Day 3"),
      DailyRewardTier(4, 500, "Ngay 4", "Day 4"),
      DailyRewardTier(5, 750, "Ngay 5", "Day 5"),
      DailyRewardTier(6, 1000, "Ngay 6", "Day 6"),
      DailyRewardTier(7, 1500, "Ngay 7 VIP", "Day 7 VIP"),
    )

    fun tierForNextClaim(currentStreak: Int): DailyRewardTier {
      val idx = (currentStreak % 7).coerceIn(0, 6)
      return weekSchedule[idx]
    }
  }
}

data class GameSettings(
  val language: AppLanguage = AppLanguage.VI,
  val targetFps: Int = 120,
  val aiDifficulty: AiDifficulty = AiDifficulty.NORMAL,
  val sfxEnabled: Boolean = true,
  val musicEnabled: Boolean = true,
  val sfxVolume: Float = 0.85f,
  val musicVolume: Float = 0.55f,
  val bloomAndShadersEnabled: Boolean = true,
  val trailsEnabled: Boolean = true,
  val screenShakeEnabled: Boolean = true,
  val hitStopEnabled: Boolean = true,
  val floatingDamageEnabled: Boolean = true,
  val speedMultiplier: Float = 1.0f,
  val showFpsCounter: Boolean = false,
  val graphicsQuality: GraphicsQuality = GraphicsQuality.HIGH,
  val autoReduceLag: Boolean = true,
)

data class UserProgress(
  val nickname: String = "Challenger",
  val coins: Int = 160,
  val purchasedBalls: Set<BallType> = setOf(BallType.FIRE),
  val purchasedKillEffects: Set<KillEffectType> = setOf(KillEffectType.DEFAULT_BURST),
  val equippedBall: BallType = BallType.FIRE,
  val equippedKillEffect: KillEffectType = KillEffectType.DEFAULT_BURST,
  val tanThuActivatedAtMillis: Long = 0L,
  val totalWins: Int = 0,
  val totalMatches: Int = 0,
  val gachaPityCount: Int = 0,
  val totalSpins: Int = 0,
  val redeemedCodes: Set<String> = emptySet(),
  val dailyStreak: Int = 0,
  val lastDailyClaimEpochDay: Long = 0L,
  val playerCode: String = "",
  val ballTrials: Map<String, Long> = emptyMap(),
) {
  fun tanThuRemainingMillis(nowMillis: Long = System.currentTimeMillis()): Long {
    if (tanThuActivatedAtMillis <= 0L) return 0L
    val elapsed = nowMillis - tanThuActivatedAtMillis
    return if (elapsed in 0L until TAN_THU_DURATION_MILLIS) {
      TAN_THU_DURATION_MILLIS - elapsed
    } else {
      0L
    }
  }

  fun isTanThuActive(nowMillis: Long = System.currentTimeMillis()): Boolean =
    tanThuRemainingMillis(nowMillis) > 0L

  fun ballTrialRemainingMillis(
    ball: BallType,
    nowMillis: Long = System.currentTimeMillis(),
  ): Long {
    val expiresAt = ballTrials[ball.id] ?: 0L
    return (expiresAt - nowMillis).coerceAtLeast(0L)
  }

  fun activeTrialBalls(nowMillis: Long = System.currentTimeMillis()): Map<BallType, Long> =
    ballTrials.mapNotNull { (id, expiresAt) ->
      val rem = expiresAt - nowMillis
      if (rem > 0L) BallType.fromId(id) to rem else null
    }.toMap()

  fun isBallPermanentlyOwned(ball: BallType): Boolean = ball in purchasedBalls

  fun isBallAvailable(ball: BallType, nowMillis: Long = System.currentTimeMillis()): Boolean =
    ball in purchasedBalls || isTanThuActive(nowMillis) || ballTrialRemainingMillis(ball, nowMillis) > 0L

  fun isKillEffectAvailable(
    effect: KillEffectType,
    nowMillis: Long = System.currentTimeMillis(),
  ): Boolean = effect in purchasedKillEffects || isTanThuActive(nowMillis)

  fun isDailyClaimable(nowMillis: Long = System.currentTimeMillis()): Boolean {
    val todayEpochDay = currentEpochDay(nowMillis)
    return lastDailyClaimEpochDay < todayEpochDay
  }

  fun nextDailyRewardTier(): DailyRewardTier = DailyRewardTier.tierForNextClaim(dailyStreak)

  companion object {
    fun currentEpochDay(nowMillis: Long = System.currentTimeMillis()): Long =
      (nowMillis / 86_400_000L).coerceAtLeast(1L)
  }
}

enum class CodeRedeemResult {
  SUCCESS_SENT_TO_MAILBOX,
  SUCCESS_TRIAL_ACTIVATED,
  ALREADY_REDEEMED,
  ALREADY_ACTIVE,
  EXPIRED_OR_INVALID,
  INVALID,
}

enum class ShopPurchaseResult {
  SUCCESS,
  INSUFFICIENT_COINS,
  ALREADY_OWNED,
}

sealed interface GachaSpinResult {
  data object InsufficientCoins : GachaSpinResult

  data class Success(
    val pulledBall: BallType,
    val isNewUnlock: Boolean,
    val duplicateRefundCoins: Int,
    val triggeredPity: Boolean,
    val newPityCount: Int,
  ) : GachaSpinResult
}

data class MailboxLetter(
  val id: String,
  val sender: String,
  val titleVi: String,
  val titleEn: String,
  val bodyVi: String,
  val bodyEn: String,
  val rewardCoins: Int,
  val rewardBall: BallType?,
  val sourceCode: String,
  val claimed: Boolean,
  val createdAtMillis: Long,
  val trialMinutes: Int = 0,
)

data class OtaGiftCodeEntry(
  val code: String,
  val rewardCoins: Int = 0,
  val rewardBallId: String = "",
  val titleVi: String = "",
  val titleEn: String = "",
  val bodyVi: String = "",
  val bodyEn: String = "",
  val isTrial24h: Boolean = false,
  val trialBallId: String = "",
  val trialDurationMinutes: Int = 0,
  val createdAtMillis: Long = 0L,
  val expiresAtMillis: Long = 0L,
) {
  fun isExpired(nowMillis: Long = System.currentTimeMillis()): Boolean =
    expiresAtMillis > 0L && nowMillis > expiresAtMillis

  fun isBallTrialCode(): Boolean = trialBallId.isNotBlank() && trialDurationMinutes > 0
}

data class BallBalanceOverride(
  val hp: Int = 120,
  val damageScale: Float = 1.0f,
)

data class OtaBalanceConfig(
  val thunderDeathboltPct: Float = 0.32f,
  val thunderAfterimageDurationSec: Float = 3.5f,
  val iceShardSpawnIntervalSec: Float = 0.68f,
  val iceShardDamage: Int = 6,
  val iceFreezeDurationSec: Float = 10.0f,
  val iceFreezeRageDrainPct: Float = 0.70f,
  val icePostFreezeSlowPct: Float = 0.40f,
  val groundSkill1CooldownSec: Float = 5.0f,
  val groundSkill1Damage: Float = 12f,
  val groundChargeReduction: Float = 0.10f,
  val groundArmorAllReduction: Float = 0.30f,
  val groundArmorDurationSec: Float = 5.0f,
  val groundArmorCooldownSec: Float = 18.0f,
  val antRegenIntervalSec: Float = 16.0f,
  val antMaxRegens: Int = 3,
  val antSkill1CooldownSec: Float = 8.0f,
  val ballOverrides: Map<String, BallBalanceOverride> = defaultBallOverrides(),
) {
  fun overrideFor(type: BallType): BallBalanceOverride =
    ballOverrides[type.id] ?: BallBalanceOverride(hp = type.baseHp, damageScale = 1.0f)

  fun hpFor(type: BallType): Float = overrideFor(type).hp.coerceIn(60, 400).toFloat()

  fun damageScaleFor(type: BallType): Float = overrideFor(type).damageScale.coerceIn(0.4f, 2.5f)

  fun withBallOverride(type: BallType, hp: Int, damageScale: Float): OtaBalanceConfig {
    val updated = ballOverrides.toMutableMap()
    updated[type.id] = BallBalanceOverride(
      hp = hp.coerceIn(60, 400),
      damageScale = damageScale.coerceIn(0.4f, 2.5f),
    )
    return copy(ballOverrides = updated)
  }

  companion object {
    fun defaultBallOverrides(): Map<String, BallBalanceOverride> =
      BallType.entries.associate { ball ->
        val defaultDamageScale = when (ball) {
          BallType.FIRE -> 1.05f
          BallType.THUNDER -> 1.05f
          else -> 1.0f
        }
        ball.id to BallBalanceOverride(hp = ball.baseHp, damageScale = defaultDamageScale)
      }
  }
}

data class OtaVfxConfig(
  val particleMultiplier: Float = 1.28f,
  val glowIntensity: Float = 1.30f,
  val effectScale: Float = 1.10f,
  val vibrancyBoost: Float = 1.15f,
)

data class OtaAppUpdateConfig(
  val latestVersionCode: Int = APP_VERSION_CODE,
  val latestVersionName: String = APP_DISPLAY_VERSION,
  val minSupportedVersionCode: Int = APP_VERSION_CODE,
  val downloadUrl: String = DEFAULT_V103_RAW_APK_URL,
  val releaseNotesVi: String = "",
  val releaseNotesEn: String = "",
) {
  fun normalizedUrl(): String = normalizeDownloadUrl(downloadUrl)

  fun isUpdateAvailable(currentVersionCode: Int): Boolean =
    latestVersionCode > currentVersionCode && isSafeHttpsUrl(normalizedUrl())

  fun isMandatory(currentVersionCode: Int): Boolean =
    isUpdateAvailable(currentVersionCode) && currentVersionCode < minSupportedVersionCode

  fun isDirectApkUrl(): Boolean = isDirectApkUrl(normalizedUrl())

  companion object {
    private val APK_URL_PATTERN = Regex("\\.apk([?#].*)?$", RegexOption.IGNORE_CASE)
    private val GITHUB_BLOB_PATTERN =
      Regex("^https://github\\.com/([^/]+/[^/]+)/blob/(.+)$", RegexOption.IGNORE_CASE)

    fun normalizeDownloadUrl(url: String): String {
      val trimmed = url.trim()
      val blobMatch = GITHUB_BLOB_PATTERN.matchEntire(trimmed)
      return if (blobMatch != null) {
        "https://github.com/${blobMatch.groupValues[1]}/raw/${blobMatch.groupValues[2]}"
      } else {
        trimmed
      }
    }

    fun isSafeHttpsUrl(url: String): Boolean {
      val trimmed = normalizeDownloadUrl(url)
      return trimmed.startsWith("https://", ignoreCase = true) && trimmed.length > 10
    }

    fun isDirectApkUrl(url: String): Boolean {
      val trimmed = normalizeDownloadUrl(url)
      if (!isSafeHttpsUrl(trimmed)) return false
      return APK_URL_PATTERN.containsMatchIn(trimmed) ||
        (trimmed.contains("/releases/download/", ignoreCase = true) &&
          trimmed.contains(".apk", ignoreCase = true))
    }
  }
}

data class ApkPackageInfo(
  val fileName: String,
  val packageName: String,
  val versionCode: Int,
  val versionName: String,
  val sizeBytes: Long,
  val uriString: String,
) {
  val sizeMb: Float get() = sizeBytes / (1024f * 1024f)
}

sealed interface ApkUpdateState {
  data object Idle : ApkUpdateState

  data class Downloading(
    val progressPct: Int,
    val downloadedBytes: Long,
    val totalBytes: Long,
  ) : ApkUpdateState

  data class OpeningWeb(val url: String) : ApkUpdateState

  data class NeedsInstallPermission(val apkPath: String) : ApkUpdateState

  data class ReadyToInstall(val apkPath: String) : ApkUpdateState

  data class Failed(val message: String) : ApkUpdateState
}

sealed interface GitHubUploadState {
  data object Idle : GitHubUploadState

  data class Uploading(
    val progressPct: Int,
    val statusText: String,
  ) : GitHubUploadState

  data class Success(
    val downloadUrl: String,
    val tagName: String,
  ) : GitHubUploadState

  data class Failed(val message: String) : GitHubUploadState
}

data class PlayerDirectoryEntry(
  val uid: String,
  val playerCode: String,
  val nickname: String,
  val totalWins: Int = 0,
  val totalMatches: Int = 0,
  val isAdmin: Boolean = false,
  val updatedAtMillis: Long = 0L,
)

data class FriendRequestEntry(
  val id: String,
  val fromUid: String,
  val fromCode: String,
  val fromName: String,
  val fromIsAdmin: Boolean = false,
  val toUid: String,
  val toCode: String,
  val toName: String,
  val status: String = "pending",
  val createdAtMillis: Long = 0L,
)

data class FriendEntry(
  val uid: String,
  val playerCode: String,
  val nickname: String,
  val isAdmin: Boolean = false,
  val addedAtMillis: Long = 0L,
)

data class RoomInviteEntry(
  val id: String,
  val roomCode: String,
  val fromUid: String,
  val fromName: String,
  val fromIsAdmin: Boolean = false,
  val toUid: String,
  val status: String = "pending",
  val createdAtMillis: Long = 0L,
  val expiresAtMillis: Long = 0L,
) {
  fun isValid(nowMillis: Long = System.currentTimeMillis()): Boolean =
    status == "pending" && (expiresAtMillis <= 0L || nowMillis <= expiresAtMillis)
}

data class OtaLiveConfig(
  val configVersion: Int = 104,
  val gachaSpinCost: Int = GACHA_SPIN_COST,
  val activeCodes: List<OtaGiftCodeEntry> = defaultCodes(),
  val disabledCodes: List<String> = emptyList(),
  val balance: OtaBalanceConfig = OtaBalanceConfig(),
  val vfx: OtaVfxConfig = OtaVfxConfig(),
  val appUpdate: OtaAppUpdateConfig = OtaAppUpdateConfig(),
  val adminNoticeVi: String = "",
  val adminNoticeEn: String = "",
  val adminNoticeExpiresAtMillis: Long = 0L,
  val syncedFromCloud: Boolean = false,
) {
  fun isAdminNoticeExpired(nowMillis: Long = System.currentTimeMillis()): Boolean =
    adminNoticeExpiresAtMillis > 0L && nowMillis > adminNoticeExpiresAtMillis

  fun activeAdminNotice(language: AppLanguage, nowMillis: Long = System.currentTimeMillis()): String {
    if (isAdminNoticeExpired(nowMillis)) return ""
    val raw = if (language == AppLanguage.VI) adminNoticeVi else adminNoticeEn
    return raw.ifBlank { if (language == AppLanguage.VI) adminNoticeEn else adminNoticeVi }.trim()
  }

  companion object {
    fun defaultCodes(): List<OtaGiftCodeEntry> = listOf(
      OtaGiftCodeEntry(
        code = TRIAN_CODE,
        rewardCoins = 5000,
        rewardBallId = "",
        titleVi = "Qua Tri An 1.0.2 Release - 5.000 Xu",
        titleEn = "v1.0.2 Release Appreciation - 5,000 Coins",
        bodyVi = "Cam on ban da dong hanh cung Ball vs Ball 1.0.2 Release! Nhan ngay 5.000 Xu khoi dau (hieu luc 7 ngay).",
        bodyEn = "Thank you for playing Ball vs Ball 1.0.2 Release! Claim 5,000 starter Coins (valid 7 days).",
        createdAtMillis = TRIAN_CREATED_AT_MILLIS,
        expiresAtMillis = TRIAN_EXPIRES_AT_MILLIS,
      ),
      OtaGiftCodeEntry(
        code = TAIDZ_CODE,
        rewardCoins = 0,
        rewardBallId = BallType.THUNDER.id,
        titleVi = "Qua Tan Thu Thunder Ball - TaiDz-111",
        titleEn = "Free Thunder Ball - TaiDz-111",
        bodyVi = "Nhan ngay Thunder Ball vinh vien mien phi qua thu he thong!",
        bodyEn = "Claim your free permanent Thunder Ball via system mail!",
      ),
      OtaGiftCodeEntry(
        code = TAN_THU_CODE,
        rewardCoins = 0,
        rewardBallId = "",
        titleVi = "Qua Tan Thu 24h",
        titleEn = "24h Rookie Trial Pass",
        bodyVi = "Mo khoa dung thu toan bo Bong (gom ca Ant Ball) trong 24 gio.",
        bodyEn = "Unlocks all Balls (including Rare Ant Ball) for 24 hours.",
        isTrial24h = true,
      ),
    )
  }
}

enum class OnlineEmote(val id: String, val badgeText: String, val labelVi: String, val labelEn: String) {
  GG("gg", "GG!", "Hay qua!", "Well played!"),
  HAHA("haha", "HAHA", "Haha!", "Haha!"),
  ANGRY("angry", "GRRR!", "Cay qua!", "So close!"),
  CRY("cry", "T_T", "Khoc rong!", "No way!"),
  RUSH("rush", "RUSH", "Len luon!", "Let's go!"),
  SHIELD("shield", "SAFE", "Do ne!", "Blocked!");

  companion object {
    fun fromId(id: String?): OnlineEmote? =
      entries.firstOrNull { it.id == id?.lowercase() }
  }
}

data class RoomChatMessage(
  val id: String,
  val senderUid: String,
  val senderName: String,
  val text: String,
  val sentAtMillis: Long,
)

enum class OnlineRoomPhase(val wireValue: String) {
  WAITING("waiting"),
  PICK_3("pick_3"),
  BAN_1("ban_1"),
  FINAL_PICK("final_pick"),
  PLAYING("playing"),
  FINISHED("finished");

  companion object {
    fun fromWire(value: String?): OnlineRoomPhase =
      entries.firstOrNull { it.wireValue == value } ?: WAITING
  }
}

data class OnlineRoomState(
  val roomCode: String,
  val hostUid: String,
  val hostName: String,
  val guestUid: String,
  val guestName: String,
  val phase: OnlineRoomPhase,
  val hostPicks: List<BallType>,
  val guestPicks: List<BallType>,
  val hostBannedBall: BallType?,
  val guestBannedBall: BallType?,
  val hostFinalBall: BallType?,
  val guestFinalBall: BallType?,
  val seed: Long,
  val winnerUid: String,
  val matchDurationSec: Float,
  val rewardCoins: Int,
  val hostReady: Boolean = false,
  val guestReady: Boolean = false,
  val hostScore: Int = 0,
  val guestScore: Int = 0,
  val currentRound: Int = 1,
  val hostLastHeartbeatMs: Long = 0L,
  val guestLastHeartbeatMs: Long = 0L,
  val hostEmote: OnlineEmote? = null,
  val guestEmote: OnlineEmote? = null,
  val hostEmoteAtMs: Long = 0L,
  val guestEmoteAtMs: Long = 0L,
  val hostIsAdmin: Boolean = false,
  val guestIsAdmin: Boolean = false,
  val hostAimRad: Double = -99.0,
  val guestAimRad: Double = -99.0,
  val balanceSnapshot: OtaBalanceConfig? = null,
) {
  fun isHost(uid: String): Boolean = hostUid == uid

  fun bothReady(): Boolean = guestUid.isNotBlank() && hostReady && guestReady

  fun hasHostAim(): Boolean = hostAimRad > -10.0 && hostAimRad < 10.0

  fun hasGuestAim(): Boolean = guestAimRad > -10.0 && guestAimRad < 10.0

  fun hasBothAims(): Boolean = hasHostAim() && hasGuestAim()

  fun isOpponentDisconnected(myUid: String, nowMillis: Long = System.currentTimeMillis()): Boolean {
    if (guestUid.isBlank()) return false
    val opponentHb = if (isHost(myUid)) guestLastHeartbeatMs else hostLastHeartbeatMs
    if (opponentHb <= 0L) return false
    return (nowMillis - opponentHb) > 12_000L
  }

  fun computeSpeedRewardCoins(durationSec: Float): Int =
    when {
      durationSec <= 15f -> 240
      durationSec <= 25f -> 190
      durationSec <= 40f -> 150
      else -> 120
    }
}

data class MatchmakingTicketEntry(
  val uid: String,
  val nickname: String,
  val isAdmin: Boolean = false,
  val status: String = "waiting",
  val roomCode: String = "",
  val matchedWithUid: String = "",
  val heartbeatMs: Long = 0L,
)

sealed interface MatchmakingUiState {
  data object Idle : MatchmakingUiState
  data class Searching(val elapsedSec: Int) : MatchmakingUiState
  data class Matched(val roomCode: String, val opponentName: String) : MatchmakingUiState
  data class Failed(val message: String) : MatchmakingUiState
}

