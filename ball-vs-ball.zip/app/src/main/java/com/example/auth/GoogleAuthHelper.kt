package com.example.auth

import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.tasks.await

object GoogleAuthHelper {
  private const val TAG = "GoogleAuthHelper"

  suspend fun attemptAutoSignIn(context: Context): FirebaseUser? {
    Firebase.auth.currentUser?.let { return it }
    return try {
      val webClientId = context.getString(R.string.default_web_client_id)
      val option =
        GetGoogleIdOption.Builder()
          .setFilterByAuthorizedAccounts(true)
          .setServerClientId(webClientId)
          .setAutoSelectEnabled(true)
          .build()
      val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
      val result = CredentialManager.create(context).getCredential(context, request)
      val credential = result.credential
      if (credential is CustomCredential &&
        credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
      ) {
        val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
        val firebaseCred = GoogleAuthProvider.getCredential(googleCred.idToken, null)
        Firebase.auth.signInWithCredential(firebaseCred).await().user
      } else {
        null
      }
    } catch (e: GetCredentialCancellationException) {
      Log.w(TAG, "Silent auto sign-in cancelled", e)
      null
    } catch (e: Exception) {
      Log.i(TAG, "Silent auto sign-in unavailable: ${e.message}")
      null
    }
  }

  suspend fun signInWithGoogle(context: Context): Result<FirebaseUser> {
    return try {
      val webClientId = context.getString(R.string.default_web_client_id)
      val option = GetSignInWithGoogleOption.Builder(webClientId).build()
      val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
      val result = CredentialManager.create(context).getCredential(context, request)
      val credential = result.credential
      if (credential is CustomCredential &&
        credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
      ) {
        val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
        val firebaseCred = GoogleAuthProvider.getCredential(googleCred.idToken, null)
        val user =
          Firebase.auth.signInWithCredential(firebaseCred).await().user
            ?: return Result.failure(IllegalStateException("Google Sign-In returned empty FirebaseUser"))
        Result.success(user)
      } else {
        Result.failure(IllegalStateException("Unexpected credential type returned"))
      }
    } catch (e: GetCredentialCancellationException) {
      Log.w(TAG, "Google sign-in cancelled by user", e)
      Result.failure(e)
    } catch (e: Exception) {
      Log.e(TAG, "Google sign-in failed", e)
      Result.failure(e)
    }
  }

  suspend fun signOut(context: Context) {
    runCatching {
      CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
    }
    Firebase.auth.signOut()
  }
}
