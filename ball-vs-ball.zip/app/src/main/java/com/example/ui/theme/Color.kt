package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF060911)
val ObsidianSurface = Color(0xFF0E1524)
val ObsidianSurfaceElevated = Color(0xFF162036)
val ObsidianGlass = Color(0xCC11192B)
val ObsidianBorder = Color(0xFF283755)
val NeonCyanBorder = Color(0xFF00D4FF)

val FirePrimary = Color(0xFFFF5722)
val FireCore = Color(0xFFFFB300)
val FireGlow = Color(0xFFFF3D00)

val WaterPrimary = Color(0xFF00E5FF)
val WaterCore = Color(0xFF2979FF)
val WaterGlow = Color(0xFF18FFFF)

val GroundPrimary = Color(0xFFD48C3B)
val GroundCore = Color(0xFF8D5524)
val GroundGlow = Color(0xFFFFCA62)

val ThunderPrimary = Color(0xFFFFEA00)
val ThunderCore = Color(0xFF7C4DFF)
val ThunderGlow = Color(0xFFFFFF72)

val IcePrimary = Color(0xFF80D8FF)
val IceCore = Color(0xFF40C4FF)
val IceGlow = Color(0xFFE1F5FE)

val AntPrimary = Color(0xFFFF2E63)
val AntCore = Color(0xFF00E676)
val AntGlow = Color(0xFFB9FF66)

val RarityCommonColor = Color(0xFF38BDF8)
val RarityPopularColor = RarityCommonColor
val RarityUncommonColor = Color(0xFFC084FC)
val RarityRareColor = Color(0xFFFF4D6D)

val GoldAccent = Color(0xFFFFD54F)
val EmeraldSuccess = Color(0xFF00E676)
val CrimsonDanger = Color(0xFFFF2E55)
val TextPrimary = Color(0xFFF3F7FF)
val TextSecondary = Color(0xFF93A4C4)
