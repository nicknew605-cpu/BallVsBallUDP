package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.BallType
import com.example.model.GACHA_PITY_THRESHOLD
import com.example.model.GACHA_SPIN_COST
import com.example.model.GachaSpinResult
import com.example.model.KillEffectType
import com.example.model.OtaBalanceConfig
import com.example.model.ShopPurchaseResult
import com.example.model.UserProgress
import com.example.ui.components.AnimatedElementBallBadge
import com.example.ui.components.CoinPill
import com.example.ui.components.ElementSkillIconBadge
import com.example.ui.components.GachaRevealDialog
import com.example.ui.components.GlassArenaCard
import com.example.ui.components.NeonPillBadge
import com.example.ui.components.RarityBadge
import com.example.ui.components.TanThuCountdownBanner
import com.example.ui.components.ballAccentColor
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.RarityRareColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterPrimary
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

@Composable
fun ShopScreen(
  strings: GameStrings,
  progress: UserProgress,
  otaBalance: OtaBalanceConfig = OtaBalanceConfig(),
  nowMillis: Long,
  gachaSpinCost: Int = GACHA_SPIN_COST,
  onBuyOrEquipBall: suspend (BallType) -> ShopPurchaseResult,
  onBuyOrEquipEffect: suspend (KillEffectType) -> ShopPurchaseResult,
  onSpinGacha: suspend () -> GachaSpinResult,
  onBack: () -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var gachaOutcome by remember { mutableStateOf<GachaSpinResult.Success?>(null) }
  var isSpinning by remember { mutableStateOf(false) }
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val tanThuActive = progress.isTanThuActive(nowMillis)

  Scaffold(
    containerColor = ObsidianBg,
    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    contentWindowInsets = WindowInsets.safeDrawing,
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(Brush.verticalGradient(listOf(Color(0xFF0A101E), ObsidianBg)))
          .padding(innerPadding)
    ) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .widthIn(max = 640.dp)
            .align(Alignment.Center)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            IconButton(
              onClick = onBack,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("shop_back_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = strings.back,
                tint = TextPrimary,
              )
            }
            Text(
              text = strings.shopTitle,
              style = MaterialTheme.typography.titleLarge,
              color = TextPrimary,
              maxLines = 1,
              softWrap = false,
              overflow = TextOverflow.Ellipsis,
            )
          }
          CoinPill(coins = progress.coins, label = strings.coinsLabel)
        }

        if (tanThuActive) {
          TanThuCountdownBanner(
            remainingMillis = progress.tanThuRemainingMillis(nowMillis),
            prefix = strings.tanThuBannerPrefix,
          )
        }

        TabRow(
          selectedTabIndex = selectedTab,
          containerColor = ObsidianSurface,
          contentColor = WaterPrimary,
        ) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = { Text(strings.tabBalls, style = MaterialTheme.typography.labelLarge, maxLines = 1, softWrap = false) },
            modifier = Modifier.testTag("shop_tab_balls"),
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = { Text(strings.tabKillEffects, style = MaterialTheme.typography.labelLarge, maxLines = 1, softWrap = false) },
            modifier = Modifier.testTag("shop_tab_effects"),
          )
        }

        if (selectedTab == 0) {
          // Lucky Gacha Machine Card
          GlassArenaCard(borderColor = RarityRareColor.copy(alpha = 0.7f)) {
            Column(
              modifier =
                Modifier.fillMaxWidth()
                  .background(
                    Brush.linearGradient(
                      listOf(RarityRareColor.copy(alpha = 0.16f), ObsidianSurface)
                    )
                  )
                  .padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Icon(Icons.Default.Casino, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(28.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = strings.gachaTitle, style = MaterialTheme.typography.titleLarge, color = GoldAccent)
                  Text(text = strings.gachaOddsLabel, style = MaterialTheme.typography.labelSmall, color = WaterPrimary)
                }
              }
              Text(text = strings.gachaSubtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text(text = strings.gachaPityLabel, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                  Text(
                    text = "${progress.gachaPityCount} / $GACHA_PITY_THRESHOLD",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = RarityRareColor,
                  )
                }
                LinearProgressIndicator(
                  progress = { (progress.gachaPityCount.toFloat() / GACHA_PITY_THRESHOLD).coerceIn(0f, 1f) },
                  modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(999.dp)),
                  color = RarityRareColor,
                  trackColor = ObsidianSurfaceElevated,
                )
              }

              Button(
                onClick = {
                  if (!isSpinning) {
                    isSpinning = true
                    scope.launch {
                      when (val res = onSpinGacha()) {
                        is GachaSpinResult.InsufficientCoins -> {
                          snackbarHostState.showSnackbar("${strings.notEnoughCoins} ($gachaSpinCost)")
                        }
                        is GachaSpinResult.Success -> {
                          gachaOutcome = res
                        }
                      }
                      isSpinning = false
                    }
                  }
                },
                enabled = !isSpinning,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black),
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("gacha_spin_button"),
              ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("${strings.gachaTitle} • $gachaSpinCost ${strings.coinsLabel}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
              }
            }
          }

          // All 6 Elemental Balls
          BallType.entries.forEach { ball ->
            val available = progress.isBallAvailable(ball, nowMillis)
            val isPurchased = ball in progress.purchasedBalls
            val isEquipped = progress.equippedBall == ball
            val accent = ballAccentColor(ball)
            val liveStat = otaBalance.overrideFor(ball)

            GlassArenaCard(borderColor = if (isEquipped) accent else ObsidianBorder) {
              Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  AnimatedElementBallBadge(type = ball, size = 54.dp)
                  ElementSkillIconBadge(type = ball, size = 46.dp)
                  Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      Text(
                        text = strings.ballName(ball),
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                      )
                      RarityBadge(rarity = ball.rarity, strings = strings)
                    }
                    Text(text = strings.ballTagline(ball), style = MaterialTheme.typography.bodyMedium, color = accent)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                      NeonPillBadge(text = "${liveStat.hp} HP", color = EmeraldSuccess)
                      NeonPillBadge(text = "DMG ${(liveStat.damageScale * 100).roundToInt()}%", color = GoldAccent)
                    }
                  }
                }

                Text(text = strings.ballPassiveDesc(ball), style = MaterialTheme.typography.bodyMedium, color = WaterPrimary)
                Text(text = strings.ballNormalDesc(ball), style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Text(text = strings.ballUltDesc(ball), style = MaterialTheme.typography.bodyMedium, color = GoldAccent.copy(alpha = 0.9f))

                ShopItemActionRow(
                  price = ball.price,
                  available = available,
                  isPurchased = isPurchased,
                  isEquipped = isEquipped,
                  accent = accent,
                  strings = strings,
                  testTag = "shop_ball_${ball.id}_btn",
                  onClick = {
                    scope.launch {
                      val res = onBuyOrEquipBall(ball)
                      if (res == ShopPurchaseResult.INSUFFICIENT_COINS) {
                        snackbarHostState.showSnackbar(strings.notEnoughCoins)
                      } else if (res == ShopPurchaseResult.SUCCESS) {
                        snackbarHostState.showSnackbar(strings.purchasedSuccess)
                      }
                    }
                  },
                )
              }
            }
          }
        } else {
          KillEffectType.entries.forEach { effect ->
            val available = progress.isKillEffectAvailable(effect, nowMillis)
            val isPurchased = effect in progress.purchasedKillEffects
            val isEquipped = progress.equippedKillEffect == effect
            val accent =
              when (effect) {
                KillEffectType.DEFAULT_BURST -> FirePrimary
                KillEffectType.SHOCKWAVE -> WaterPrimary
                KillEffectType.PARTICLE_NOVA -> GoldAccent
                KillEffectType.DISSOLVE -> EmeraldSuccess
              }
            val icon =
              when (effect) {
                KillEffectType.DEFAULT_BURST -> Icons.Default.FlashOn
                KillEffectType.SHOCKWAVE -> Icons.Default.Radar
                KillEffectType.PARTICLE_NOVA -> Icons.Default.AutoAwesome
                KillEffectType.DISSOLVE -> Icons.Default.BlurOn
              }

            GlassArenaCard(borderColor = if (isEquipped) accent else ObsidianBorder) {
              Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = accent.copy(alpha = 0.16f),
                    modifier = Modifier.size(52.dp),
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(28.dp))
                    }
                  }
                  Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(text = strings.killEffectName(effect), style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                    Text(text = strings.killEffectDesc(effect), style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                  }
                }

                ShopItemActionRow(
                  price = effect.price,
                  available = available,
                  isPurchased = isPurchased,
                  isEquipped = isEquipped,
                  accent = accent,
                  strings = strings,
                  testTag = "shop_effect_${effect.id}_btn",
                  onClick = {
                    scope.launch {
                      val res = onBuyOrEquipEffect(effect)
                      if (res == ShopPurchaseResult.INSUFFICIENT_COINS) {
                        snackbarHostState.showSnackbar(strings.notEnoughCoins)
                      } else if (res == ShopPurchaseResult.SUCCESS) {
                        snackbarHostState.showSnackbar(strings.purchasedSuccess)
                      }
                    }
                  },
                )
              }
            }
          }
        }
      }
    }
  }

  gachaOutcome?.let { outcome ->
    GachaRevealDialog(
      result = outcome,
      strings = strings,
      onDismiss = { gachaOutcome = null },
    )
  }
}

@Composable
private fun ShopItemActionRow(
  price: Int,
  available: Boolean,
  isPurchased: Boolean,
  isEquipped: Boolean,
  accent: Color,
  strings: GameStrings,
  testTag: String,
  onClick: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    if (!isPurchased && available) {
      Text(text = strings.freeTrialActiveLabel, style = MaterialTheme.typography.labelLarge, color = EmeraldSuccess)
    } else if (!isPurchased) {
      Text(
        text = "$price ${strings.coinsLabel}",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = GoldAccent,
      )
    } else {
      Spacer(modifier = Modifier.width(1.dp))
    }

    Button(
      onClick = onClick,
      enabled = !isEquipped,
      shape = RoundedCornerShape(12.dp),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = if (available) accent else GoldAccent,
          contentColor = Color.Black,
          disabledContainerColor = ObsidianSurface,
          disabledContentColor = EmeraldSuccess,
        ),
      border = if (isEquipped) BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.6f)) else null,
      modifier = Modifier.height(48.dp).testTag(testTag),
    ) {
      if (isEquipped) {
        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(strings.equippedLabel, style = MaterialTheme.typography.labelLarge)
      } else if (available) {
        Text(strings.equipButton, style = MaterialTheme.typography.labelLarge)
      } else {
        Text("${strings.buyButton} ($price)", style = MaterialTheme.typography.labelLarge)
      }
    }
  }
}
