package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.ui.components.GameLogoCutoutBadge
import com.example.ui.components.GlassArenaCard
import com.example.ui.components.NeonPillBadge
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.RarityUncommonColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThunderPrimary
import com.example.ui.theme.WaterPrimary

@Composable
fun LoadingOtaScreen(
  strings: GameStrings,
  progressFraction: Float,
  statusText: String,
) {
  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Color(0xFF0A101D), ObsidianBg, Color(0xFF05070B))))
        .windowInsetsPadding(WindowInsets.safeDrawing)
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    GlassArenaCard(
      modifier = Modifier.fillMaxWidth().widthIn(max = 460.dp),
      borderColor = WaterPrimary.copy(alpha = 0.48f),
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        GameLogoCutoutBadge(size = 112.dp)
        Text(
          text = strings.appTitle,
          style = MaterialTheme.typography.headlineLarge,
          color = TextPrimary,
          maxLines = 1,
          softWrap = false,
          overflow = TextOverflow.Ellipsis,
        )
        NeonPillBadge(text = strings.versionBadge, color = RarityUncommonColor)
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Icon(Icons.Default.CloudDone, contentDescription = null, tint = WaterPrimary, modifier = Modifier.size(18.dp))
          Text(
            text = statusText.ifBlank { strings.loadingOtaTitle },
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
        LinearProgressIndicator(
          progress = { progressFraction.coerceIn(0f, 1f) },
          modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(999.dp)).testTag("ota_loading_progress"),
          color = WaterPrimary,
          trackColor = ObsidianSurfaceElevated,
        )
      }
    }
  }
}

@Composable
fun AuthGateScreen(
  strings: GameStrings,
  isBusy: Boolean,
  errorMessage: String?,
  defaultNickname: String,
  onGoogleSignIn: (nicknameInput: String) -> Unit,
  onPlayAsGuest: (nicknameInput: String) -> Unit,
) {
  var nicknameInput by remember(defaultNickname) { mutableStateOf(defaultNickname) }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Color(0xFF0A101D), ObsidianBg, Color(0xFF05070B))))
        .windowInsetsPadding(WindowInsets.safeDrawing)
        .padding(22.dp),
    contentAlignment = Alignment.Center,
  ) {
    GlassArenaCard(
      modifier = Modifier.fillMaxWidth().widthIn(max = 460.dp),
      borderColor = ThunderPrimary.copy(alpha = 0.5f),
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(22.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        GameLogoCutoutBadge(size = 98.dp)
        NeonPillBadge(text = strings.versionBadge, color = RarityUncommonColor)

        Text(
          text = strings.authTitle,
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
          color = GoldAccent,
          textAlign = TextAlign.Center,
          maxLines = 1,
          softWrap = false,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = strings.authSubtitle,
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
          textAlign = TextAlign.Center,
        )

        OutlinedTextField(
          value = nicknameInput,
          onValueChange = { if (it.length <= 24) nicknameInput = it },
          singleLine = true,
          label = { Text(strings.authNicknameLabel) },
          leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = WaterPrimary) },
          modifier = Modifier.fillMaxWidth().testTag("auth_nickname_input"),
        )

        errorMessage?.let { err ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = err,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.error,
              modifier = Modifier.padding(10.dp),
            )
          }
        }

        Button(
          onClick = { onGoogleSignIn(nicknameInput.trim()) },
          enabled = !isBusy,
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = FirePrimary, contentColor = Color.White),
          modifier = Modifier.fillMaxWidth().height(54.dp).testTag("google_sign_in_button"),
        ) {
          if (isBusy) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
          } else {
            Icon(Icons.Default.Login, contentDescription = null)
          }
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = strings.authGoogleSignInButton,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          HorizontalDivider(modifier = Modifier.weight(1f), color = ObsidianBorder)
          Text(strings.authOrDivider, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
          HorizontalDivider(modifier = Modifier.weight(1f), color = ObsidianBorder)
        }

        OutlinedButton(
          onClick = { onPlayAsGuest(nicknameInput.trim()) },
          enabled = !isBusy,
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.2.dp, WaterPrimary.copy(alpha = 0.72f)),
          modifier = Modifier.fillMaxWidth().height(52.dp).testTag("guest_sign_in_button"),
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, tint = WaterPrimary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = strings.authPlayGuestButton,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = WaterPrimary,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
          )
        }

        Surface(
          shape = RoundedCornerShape(10.dp),
          color = ObsidianSurfaceElevated,
          border = BorderStroke(1.dp, ObsidianBorder),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = "TriAn -> +5.000 Xu • TaiDz-111 -> Thunder",
            style = MaterialTheme.typography.labelSmall,
            color = EmeraldSuccess,
            textAlign = TextAlign.Center,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp),
          )
        }
      }
    }
  }
}
