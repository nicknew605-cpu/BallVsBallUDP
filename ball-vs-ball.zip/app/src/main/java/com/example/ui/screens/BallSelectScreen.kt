package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.BallType
import com.example.model.GameMode
import com.example.model.OtaBalanceConfig
import com.example.model.UserProgress
import com.example.ui.components.AnimatedElementBallBadge
import com.example.ui.components.CoinPill
import com.example.ui.components.ElementSkillIconBadge
import com.example.ui.components.GlassArenaCard
import com.example.ui.components.RarityBadge
import com.example.ui.components.ballAccentColor
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterPrimary
import com.example.viewmodel.MatchSetup

@Composable
fun BallSelectScreen(
  strings: GameStrings,
  progress: UserProgress,
  otaBalance: OtaBalanceConfig = OtaBalanceConfig(),
  nowMillis: Long,
  setup: MatchSetup,
  onSelectMode: (GameMode) -> Unit,
  onSelectP1Ball: (BallType) -> Unit,
  onSelectP2Ball: (BallType) -> Unit,
  onOpenShop: () -> Unit,
  onStartBattle: () -> Unit,
  onBack: () -> Unit,
) {
  val tanThuActive = progress.isTanThuActive(nowMillis)

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Color(0xFF0A101E), ObsidianBg)))
  ) {
    Column(
      modifier =
        Modifier.fillMaxSize()
          .windowInsetsPadding(WindowInsets.safeDrawing)
          .padding(horizontal = 16.dp, vertical = 12.dp)
          .widthIn(max = 640.dp)
          .align(Alignment.Center)
          .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          IconButton(
            onClick = onBack,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("select_back_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = strings.back,
              tint = TextPrimary,
            )
          }
          Text(
            text = strings.selectArenaTitle,
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
          )
        }
        CoinPill(coins = progress.coins, label = strings.coinsLabel)
      }

      Text(text = strings.modeLabel, style = MaterialTheme.typography.labelLarge, color = TextSecondary)
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ModeChipButton(
          label = strings.mode1vAI,
          selected = setup.mode == GameMode.ONE_VS_AI,
          testTag = "mode_1vai_button",
          modifier = Modifier.weight(1f),
          onClick = { onSelectMode(GameMode.ONE_VS_AI) },
        )
        ModeChipButton(
          label = strings.mode1v1,
          selected = setup.mode == GameMode.ONE_VS_ONE,
          testTag = "mode_1v1_button",
          modifier = Modifier.weight(1f),
          onClick = { onSelectMode(GameMode.ONE_VS_ONE) },
        )
      }

      Text(text = strings.player1Label, style = MaterialTheme.typography.labelLarge, color = TextSecondary)
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(horizontal = 2.dp),
      ) {
        items(BallType.entries) { ball ->
          val unlocked = progress.isBallAvailable(ball, nowMillis)
          val trialRemMs = progress.ballTrialRemainingMillis(ball, nowMillis)
          val isTrial = unlocked && ball !in progress.purchasedBalls && (tanThuActive || trialRemMs > 0L)
          val trialLabel =
            if (trialRemMs > 0L) "${strings.ballTrialBadgePrefix} ${formatSelectTrialDuration(trialRemMs)}"
            else strings.unlockedTrialLabel
          CompactBallPickerCard(
            ball = ball,
            name = strings.ballName(ball),
            hp = otaBalance.overrideFor(ball).hp,
            selected = setup.p1Ball == ball,
            unlocked = unlocked,
            isTrial = isTrial,
            trialText = trialLabel,
            strings = strings,
            testTag = "p1_ball_${ball.id}",
            onClick = { if (unlocked) onSelectP1Ball(ball) else onOpenShop() },
          )
        }
      }

      Text(
        text = if (setup.mode == GameMode.ONE_VS_AI) strings.aiOpponentLabel else strings.player2Label,
        style = MaterialTheme.typography.labelLarge,
        color = TextSecondary,
      )
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(horizontal = 2.dp),
      ) {
        items(BallType.entries) { ball ->
          val unlockedForSlot =
            setup.mode == GameMode.ONE_VS_AI || progress.isBallAvailable(ball, nowMillis)
          CompactBallPickerCard(
            ball = ball,
            name = strings.ballName(ball),
            hp = otaBalance.overrideFor(ball).hp,
            selected = setup.p2Ball == ball,
            unlocked = unlockedForSlot,
            isTrial = false,
            strings = strings,
            testTag = "p2_ball_${ball.id}",
            onClick = { if (unlockedForSlot) onSelectP2Ball(ball) else onOpenShop() },
          )
        }
      }

      if (BallType.entries.any { !progress.isBallAvailable(it, nowMillis) }) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = ObsidianSurfaceElevated,
          border = BorderStroke(1.dp, WaterPrimary.copy(alpha = 0.35f)),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = strings.unlockInShopHint,
              style = MaterialTheme.typography.bodyMedium,
              color = TextSecondary,
              modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onOpenShop, modifier = Modifier.testTag("select_open_shop_button")) {
              Icon(Icons.Default.Casino, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Gacha", color = GoldAccent)
            }
          }
        }
      }

      BallSkillDetailCard(ball = setup.p1Ball, strings = strings)

      Text(text = strings.passiveRuleNote, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

      Button(
        onClick = onStartBattle,
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = ballAccentColor(setup.p1Ball), contentColor = Color.Black),
        modifier = Modifier.fillMaxWidth().height(56.dp).testTag("enter_arena_button"),
      ) {
        Icon(Icons.Default.PlayArrow, contentDescription = strings.fightButton)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = strings.fightButton, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
private fun ModeChipButton(
  label: String,
  selected: Boolean,
  testTag: String,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    modifier = modifier.height(48.dp).testTag(testTag),
    shape = RoundedCornerShape(14.dp),
    color = if (selected) WaterPrimary.copy(alpha = 0.18f) else ObsidianSurface,
    border = BorderStroke(1.5.dp, if (selected) WaterPrimary else ObsidianBorder),
  ) {
    Box(contentAlignment = Alignment.Center) {
      Text(
        text = label,
        style = MaterialTheme.typography.titleLarge,
        color = if (selected) WaterPrimary else TextSecondary,
      )
    }
  }
}

@Composable
private fun CompactBallPickerCard(
  ball: BallType,
  name: String,
  hp: Int,
  selected: Boolean,
  unlocked: Boolean,
  isTrial: Boolean,
  trialText: String = "",
  strings: GameStrings,
  testTag: String,
  onClick: () -> Unit,
) {
  val accent = ballAccentColor(ball)
  Surface(
    onClick = onClick,
    modifier = Modifier.width(136.dp).testTag(testTag),
    shape = RoundedCornerShape(16.dp),
    color = if (selected) accent.copy(alpha = 0.16f) else ObsidianSurface,
    border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) accent else ObsidianBorder),
  ) {
    Column(
      modifier = Modifier.padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
      RarityBadge(rarity = ball.rarity, strings = strings)
      AnimatedElementBallBadge(type = ball, size = 50.dp)
      Text(
        text = name,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = TextPrimary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
      if (!unlocked) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          Icon(Icons.Default.Lock, contentDescription = strings.lockedLabel, tint = GoldAccent, modifier = Modifier.size(13.dp))
          Text(strings.lockedLabel, style = MaterialTheme.typography.labelSmall, color = GoldAccent)
        }
      } else if (isTrial) {
        Text(
          text = trialText.ifBlank { strings.unlockedTrialLabel },
          style = MaterialTheme.typography.labelSmall,
          color = EmeraldSuccess,
          maxLines = 1,
          softWrap = false,
        )
      } else {
        Text("$hp HP", style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 1)
      }
    }
  }
}

private fun formatSelectTrialDuration(remMillis: Long): String {
  val totalMins = ((remMillis + 59_999L) / 60_000L).coerceAtLeast(1L)
  val hrs = totalMins / 60L
  val mins = totalMins % 60L
  return if (hrs > 0L) "${hrs}h${mins}m" else "${totalMins}m"
}

@Composable
private fun BallSkillDetailCard(ball: BallType, strings: GameStrings) {
  val accent = ballAccentColor(ball)
  GlassArenaCard(borderColor = accent.copy(alpha = 0.45f)) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(7.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        ElementSkillIconBadge(type = ball, size = 44.dp)
        Text(text = strings.ballTagline(ball), style = MaterialTheme.typography.titleMedium, color = accent, modifier = Modifier.weight(1f))
        RarityBadge(rarity = ball.rarity, strings = strings)
      }
      Text(text = strings.ballPassiveDesc(ball), style = MaterialTheme.typography.bodyMedium, color = WaterPrimary)
      Text(text = strings.ballNormalTitle(ball), style = MaterialTheme.typography.labelLarge, color = TextPrimary)
      Text(text = strings.ballNormalDesc(ball), style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
      Text(text = strings.ballUltTitle(ball), style = MaterialTheme.typography.labelLarge, color = GoldAccent)
      Text(text = strings.ballUltDesc(ball), style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
    }
  }
}
