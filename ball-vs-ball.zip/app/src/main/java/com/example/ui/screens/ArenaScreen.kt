package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.audio.ProceduralSoundEngine
import com.example.audio.SoundEffect
import com.example.engine.ArenaPhase
import com.example.engine.BallEntity
import com.example.engine.BattlePhysicsEngine
import com.example.localization.GameStrings
import com.example.model.BallType
import com.example.model.GameMode
import com.example.model.GameSettings
import com.example.model.GraphicsQuality
import com.example.model.ONLINE_FT3_TARGET_SCORE
import com.example.model.OnlineEmote
import com.example.model.OnlineRoomPhase
import com.example.model.OnlineRoomState
import com.example.model.OtaBalanceConfig
import com.example.model.OtaVfxConfig
import com.example.model.UserProgress
import com.example.ui.arena.ArenaCanvas
import com.example.ui.components.AdmVipBadge
import com.example.ui.components.ElementSkillIconBadge
import com.example.ui.components.GlassArenaCard
import com.example.ui.components.ballAccentColor
import com.example.ui.components.ballCoreColor
import com.example.ui.theme.AntGlow
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.FireCore
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GroundGlow
import com.example.ui.theme.IceGlow
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThunderPrimary
import com.example.ui.theme.WaterCore
import com.example.ui.theme.WaterPrimary
import com.example.viewmodel.MatchSetup
import com.example.viewmodel.OnlineEmoteEvent
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharedFlow

@Composable
fun ArenaScreen(
  strings: GameStrings,
  setup: MatchSetup,
  settings: GameSettings,
  otaBalance: OtaBalanceConfig,
  otaVfx: OtaVfxConfig = OtaVfxConfig(),
  progress: UserProgress,
  activeRoom: OnlineRoomState? = null,
  currentUid: String = "",
  nowMillis: Long = System.currentTimeMillis(),
  emoteEvents: SharedFlow<OnlineEmoteEvent>? = null,
  soundEngine: ProceduralSoundEngine,
  onSendEmote: (OnlineEmote) -> Unit = {},
  onSubmitOnlineAimAngle: (roomCode: String, expectedRound: Int, angleRad: Double) -> Unit = { _, _, _ -> },
  onForceDefaultMissingAim: (roomCode: String, expectedRound: Int, targetIsHost: Boolean) -> Unit = { _, _, _ -> },
  onRecordMatchOutcome: suspend (GameMode, Int, Float) -> Int,
  onNextOnlineRound: () -> Unit = {},
  onExitToMenu: () -> Unit,
) {
  var matchGeneration by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var earnedCoins by remember(matchGeneration) { mutableStateOf<Int?>(null) }
  var fpsDisplay by remember { mutableIntStateOf(settings.targetFps) }
  var effectiveQuality by remember(settings.graphicsQuality) { mutableStateOf(settings.graphicsQuality) }

  val localSide = if (setup.mode == GameMode.ONLINE_1VS1) setup.localPlayerSide else 1
  val roundSeed =
    if (setup.mode == GameMode.ONLINE_1VS1 && activeRoom != null) {
      activeRoom.seed + (activeRoom.currentRound.toLong() * 7919L)
    } else {
      setup.seed
    }

  val battleRound =
    remember(matchGeneration, setup.onlineRoomCode, roundSeed) {
      activeRoom?.currentRound ?: 1
    }

  var localAimSubmittedRound by remember(matchGeneration, setup.onlineRoomCode, battleRound) {
    mutableIntStateOf(-1)
  }
  var onlineBallsLaunchedRound by remember(matchGeneration, setup.onlineRoomCode, battleRound) {
    mutableIntStateOf(-1)
  }
  var autoReturnedRound by remember(matchGeneration, setup.onlineRoomCode, battleRound) {
    mutableIntStateOf(-1)
  }

  val engine =
    remember(matchGeneration, setup, settings.aiDifficulty, settings.speedMultiplier, settings.hitStopEnabled, otaBalance, otaVfx) {
      BattlePhysicsEngine(
        mode = setup.mode,
        p1BallType = setup.p1Ball,
        p2BallType = setup.p2Ball,
        aiDifficulty = settings.aiDifficulty,
        speedMultiplier = settings.speedMultiplier,
        hitStopEnabled = settings.hitStopEnabled,
        seed = roundSeed,
        otaBalance = otaBalance,
        otaVfx = otaVfx,
        localPlayerSide = localSide,
        onSound = { soundEngine.play(it) },
        onSoundPan = { effect, pan -> soundEngine.play(effect, pan) },
      )
    }

  var snapshot by remember(engine) { mutableStateOf(engine.snapshot()) }

  // Launch both balls deterministically once Host and Guest aim angles arrive from Firestore
  LaunchedEffect(
    engine,
    activeRoom?.roomCode,
    activeRoom?.currentRound,
    activeRoom?.phase,
    activeRoom?.hostAimRad,
    activeRoom?.guestAimRad,
  ) {
    val room = activeRoom ?: return@LaunchedEffect
    if (setup.mode == GameMode.ONLINE_1VS1 &&
      room.phase == OnlineRoomPhase.PLAYING &&
      room.hasBothAims() &&
      onlineBallsLaunchedRound != room.currentRound
    ) {
      onlineBallsLaunchedRound = room.currentRound
      engine.launchOnlineBalls(room.hostAimRad.toFloat(), room.guestAimRad.toFloat())
      snapshot = engine.snapshot()
    }
  }

  // Timeout safety so an idle/lagging opponent doesn't freeze the aiming phase indefinitely
  LaunchedEffect(localAimSubmittedRound, activeRoom?.currentRound, activeRoom?.phase) {
    val room = activeRoom ?: return@LaunchedEffect
    if (setup.mode == GameMode.ONLINE_1VS1 &&
      room.phase == OnlineRoomPhase.PLAYING &&
      localAimSubmittedRound == room.currentRound &&
      !room.hasBothAims()
    ) {
      delay(12_000L)
      val latest = activeRoom
      if (latest != null && !latest.hasBothAims()) {
        onForceDefaultMissingAim(latest.roomCode, latest.currentRound, !latest.hasHostAim())
      }
    }
  }

  // Relay incoming Emote events straight into physics engine comic bubbles
  LaunchedEffect(engine, emoteEvents) {
    emoteEvents?.collect { evt ->
      val color = if (evt.playerId == 1) 0xFF00E5FF else 0xFFFFD54F
      engine.triggerEmote(evt.playerId, evt.emote.badgeText, color)
    }
  }

  BackHandler {
    if (snapshot.phase == ArenaPhase.FINISHED) {
      onExitToMenu()
    } else {
      isPaused = !isPaused
    }
  }

  DisposableEffect(Unit) {
    onDispose { soundEngine.setBattleState(active = false, intensity = 0f) }
  }

  // 60Hz / 120Hz VSync simulation loop with Auto Lag-Guard frame-time monitoring
  LaunchedEffect(engine, isPaused, settings.targetFps, settings.autoReduceLag) {
    var lastNanos = 0L
    var fpsAccumSec = 0f
    var fpsFrames = 0
    var slowFrameStreak = 0
    val minFrameGapSec = if (settings.targetFps <= 60) 0.0155f else 0f
    var renderGapAccum = 0f

    while (true) {
      withFrameNanos { frameNanos ->
        if (lastNanos == 0L) {
          lastNanos = frameNanos
          return@withFrameNanos
        }
        val rawDt = ((frameNanos - lastNanos) / 1_000_000_000.0).toFloat().coerceIn(0f, 0.05f)
        lastNanos = frameNanos

        if (!isPaused) {
          if (settings.autoReduceLag && effectiveQuality != GraphicsQuality.LOW) {
            if (rawDt > 0.028f) {
              slowFrameStreak++
              if (slowFrameStreak >= 6) {
                slowFrameStreak = 0
                effectiveQuality =
                  when (effectiveQuality) {
                    GraphicsQuality.ULTRA -> GraphicsQuality.HIGH
                    GraphicsQuality.HIGH -> GraphicsQuality.MEDIUM
                    GraphicsQuality.MEDIUM -> GraphicsQuality.LOW
                    GraphicsQuality.LOW -> GraphicsQuality.LOW
                  }
              }
            } else {
              slowFrameStreak = 0
            }
          }

          val koColorArgb =
            when (progress.equippedBall) {
              BallType.FIRE -> 0xFFFF5722
              BallType.WATER -> 0xFF00E5FF
              BallType.GROUND -> 0xFFD48C3B
              BallType.THUNDER -> 0xFFFFEA00
              BallType.ICE -> 0xFF80D8FF
              BallType.ANT -> 0xFFFF2E63
            }
          engine.stepFrame(rawDt, koColorArgb) { winnerId ->
            engine.triggerKoExplosionParticles(winnerId, progress.equippedKillEffect.id)
          }

          renderGapAccum += rawDt
          if (renderGapAccum >= minFrameGapSec) {
            renderGapAccum = 0f
            val nextSnap = engine.snapshot()
            snapshot = nextSnap
            val intensity = max(nextSnap.p1.rage, nextSnap.p2.rage) / 100f
            soundEngine.setBattleState(
              active = nextSnap.phase == ArenaPhase.BATTLING,
              intensity = intensity,
            )
            fpsFrames++
          }

          fpsAccumSec += rawDt
          if (fpsAccumSec >= 0.5f) {
            fpsDisplay = (fpsFrames / fpsAccumSec).roundToInt()
            fpsAccumSec = 0f
            fpsFrames = 0
          }
        }
      }
    }
  }

  // Record coin / FT3 round result once KO completes
  LaunchedEffect(snapshot.phase, matchGeneration) {
    if (snapshot.phase == ArenaPhase.FINISHED && earnedCoins == null) {
      earnedCoins = onRecordMatchOutcome(setup.mode, snapshot.winnerId, snapshot.matchElapsedSec)
    }
  }

  // Synchronously return to room for Round N+1 once Firestore advances currentRound > battleRound.
  // Intentionally NOT keyed on activeRoom?.phase so PICK_3 -> BAN_1 auto-deal does not cancel delay().
  LaunchedEffect(snapshot.phase, battleRound, activeRoom?.currentRound) {
    val room = activeRoom ?: return@LaunchedEffect
    if (setup.mode == GameMode.ONLINE_1VS1 &&
      snapshot.phase == ArenaPhase.FINISHED &&
      room.phase != OnlineRoomPhase.FINISHED &&
      room.currentRound > battleRound &&
      autoReturnedRound != battleRound
    ) {
      delay(1400L)
      autoReturnedRound = battleRound
      onNextOnlineRound()
    }
  }

  val oppDisconnected =
    setup.mode == GameMode.ONLINE_1VS1 &&
      activeRoom != null &&
      activeRoom.isOpponentDisconnected(currentUid, nowMillis)

  val waitingOpponentAim =
    setup.mode == GameMode.ONLINE_1VS1 &&
      activeRoom != null &&
      localAimSubmittedRound == activeRoom.currentRound &&
      !activeRoom.hasBothAims()

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(ObsidianBg)
        .windowInsetsPadding(WindowInsets.safeDrawing)
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      ArenaTopHud(
        strings = strings,
        setup = setup,
        activeRoom = activeRoom,
        p1 = snapshot.p1,
        p2 = snapshot.p2,
        side1Balls = snapshot.side1Balls,
        side2Balls = snapshot.side2Balls,
        elapsedSec = snapshot.matchElapsedSec,
        fps = if (settings.showFpsCounter) fpsDisplay else null,
        qualityBadge = strings.qualityName(effectiveQuality),
        autoScaled = settings.autoReduceLag && effectiveQuality != settings.graphicsQuality,
        oppDisconnected = oppDisconnected,
        onPauseClick = {
          soundEngine.play(SoundEffect.UI_TAP)
          isPaused = true
        },
        onExitClick = onExitToMenu,
      )

      Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
        ArenaCanvas(
          snapshot = snapshot,
          settings = settings,
          effectiveQuality = effectiveQuality,
          otaVfx = otaVfx,
          interactivePlayerId = if (setup.mode == GameMode.ONLINE_1VS1) localSide else null,
          onAimAngleChanged = { playerId, angle ->
            if (setup.mode == GameMode.ONLINE_1VS1) {
              if (localAimSubmittedRound != (activeRoom?.currentRound ?: 1)) {
                engine.setAimAngle(localSide, angle)
                snapshot = engine.snapshot()
              }
            } else {
              engine.setAimAngle(playerId, angle)
              snapshot = engine.snapshot()
            }
          },
          modifier = Modifier.fillMaxSize().testTag("arena_canvas"),
        )
      }

      ArenaBottomBar(
        strings = strings,
        phase = snapshot.phase,
        isOnline = setup.mode == GameMode.ONLINE_1VS1,
        waitingOpponentAim = waitingOpponentAim,
        p1Name = setup.p1DisplayName,
        p2Name = setup.p2DisplayName,
        localName = if (localSide == 2) setup.p2DisplayName else setup.p1DisplayName,
        onConfirmAim = {
          if (setup.mode == GameMode.ONLINE_1VS1) {
            val room = activeRoom
            if (room != null && localAimSubmittedRound != room.currentRound) {
              localAimSubmittedRound = room.currentRound
              onSubmitOnlineAimAngle(room.roomCode, room.currentRound, engine.currentLocalAimAngle().toDouble())
            }
          } else {
            engine.confirmCurrentAim()
            snapshot = engine.snapshot()
          }
        },
        onSendEmote = { emote ->
          onSendEmote(emote)
          if (setup.mode != GameMode.ONLINE_1VS1) {
            engine.triggerEmote(1, emote.badgeText, 0xFF00E5FF)
          }
        },
      )
    }

    if (isPaused && snapshot.phase != ArenaPhase.FINISHED) {
      Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.72f)),
        contentAlignment = Alignment.Center,
      ) {
        GlassArenaCard(
          modifier = Modifier.fillMaxWidth(0.84f),
          borderColor = ObsidianBorder,
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            Text(
              text = strings.pauseMatch,
              style = MaterialTheme.typography.headlineMedium,
              color = TextPrimary,
            )
            Button(
              onClick = { isPaused = false },
              modifier = Modifier.fillMaxWidth().height(50.dp).testTag("resume_match_button"),
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text(strings.resumeMatch, style = MaterialTheme.typography.labelLarge)
            }
            OutlinedButton(
              onClick = onExitToMenu,
              modifier = Modifier.fillMaxWidth().height(50.dp).testTag("pause_exit_button"),
            ) {
              Text(strings.exitMatch, color = TextPrimary)
            }
          }
        }
      }
    }

    if (snapshot.phase == ArenaPhase.FINISHED) {
      val localWon =
        if (setup.mode == GameMode.ONLINE_1VS1) snapshot.winnerId == localSide
        else snapshot.winnerId == 1
      val winnerText =
        when {
          setup.mode == GameMode.ONLINE_1VS1 ->
            if (localWon) "${if (localSide == 1) setup.p1DisplayName else setup.p2DisplayName} • ${strings.winnerP1}"
            else "${if (snapshot.winnerId == 1) setup.p1DisplayName else setup.p2DisplayName} • ${strings.winnerP2}"
          snapshot.winnerId == 1 -> "${setup.p1DisplayName} • ${strings.winnerP1}"
          setup.mode == GameMode.ONE_VS_ONE -> "${setup.p2DisplayName} • ${strings.winnerP2}"
          else -> strings.winnerAi
        }
      val winnerBall = if (snapshot.winnerId == 1) snapshot.p1 else snapshot.p2
      val accent = ballAccentColor(winnerBall.type)
      val isOnlineMidRound =
        setup.mode == GameMode.ONLINE_1VS1 &&
          activeRoom != null &&
          activeRoom.phase != OnlineRoomPhase.FINISHED

      Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.76f)),
        contentAlignment = Alignment.Center,
      ) {
        GlassArenaCard(
          modifier = Modifier.fillMaxWidth(0.9f),
          borderColor = accent.copy(alpha = 0.7f),
        ) {
          Column(
            modifier = Modifier.padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Text(
              text = strings.koTitle,
              style = MaterialTheme.typography.labelLarge,
              color = GoldAccent,
            )
            Text(
              text = winnerText,
              style = MaterialTheme.typography.headlineMedium,
              color = accent,
              textAlign = TextAlign.Center,
            )
            if (isOnlineMidRound && activeRoom != null) {
              Text(
                text = strings.roundResultNextLabel,
                style = MaterialTheme.typography.bodySmall,
                color = WaterPrimary,
                textAlign = TextAlign.Center,
              )
              Text(
                text = "${activeRoom.hostName} ${activeRoom.hostScore} : ${activeRoom.guestScore} ${activeRoom.guestName} (FT$ONLINE_FT3_TARGET_SCORE)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = GoldAccent,
              )
            }

            Surface(
              shape = RoundedCornerShape(14.dp),
              color = ObsidianSurfaceElevated,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                StatRow(
                  label = "${strings.damageDealtLabel} (${setup.p1DisplayName} / ${setup.p2DisplayName})",
                  value = "${snapshot.side1TotalDamageDealt.roundToInt()} / ${snapshot.side2TotalDamageDealt.roundToInt()}",
                )
                StatRow(
                  label = "${strings.skillsUsedLabel} (${setup.p1DisplayName} / ${setup.p2DisplayName})",
                  value = "${snapshot.side1SkillsTriggered} / ${snapshot.side2SkillsTriggered}",
                )
                StatRow(
                  label = strings.matchTimeLabel,
                  value = String.format(Locale.US, "%.1fs", snapshot.matchElapsedSec),
                )
                if (!isOnlineMidRound) {
                  StatRow(
                    label = strings.rewardCoinsLabel,
                    value = "+${earnedCoins ?: 0} ${strings.coinsLabel}",
                    valueColor = GoldAccent,
                  )
                }
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              OutlinedButton(
                onClick = onExitToMenu,
                modifier = Modifier.weight(1f).height(50.dp).testTag("arena_menu_button"),
              ) {
                Text(strings.mainMenuButton, color = TextPrimary, maxLines = 1, softWrap = false)
              }
              if (setup.mode != GameMode.ONLINE_1VS1) {
                Button(
                  onClick = {
                    soundEngine.play(SoundEffect.UI_TAP)
                    isPaused = false
                    matchGeneration++
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
                  modifier = Modifier.weight(1f).height(50.dp).testTag("rematch_button"),
                ) {
                  Icon(Icons.Default.Refresh, contentDescription = null)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(strings.rematchButton, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
              } else if (isOnlineMidRound) {
                Button(
                  onClick = {
                    autoReturnedRound = activeRoom?.currentRound ?: -1
                    onNextOnlineRound()
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = WaterPrimary, contentColor = Color.Black),
                  modifier = Modifier.weight(1f).height(50.dp).testTag("online_next_round_button"),
                ) {
                  Icon(Icons.Default.PlayArrow, contentDescription = null)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(strings.nextRoundButton, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ArenaTopHud(
  strings: GameStrings,
  setup: MatchSetup,
  activeRoom: OnlineRoomState?,
  p1: BallEntity,
  p2: BallEntity,
  side1Balls: List<BallEntity>,
  side2Balls: List<BallEntity>,
  elapsedSec: Float,
  fps: Int?,
  qualityBadge: String,
  autoScaled: Boolean,
  oppDisconnected: Boolean,
  onPauseClick: () -> Unit,
  onExitClick: () -> Unit,
) {
  Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      IconButton(
        onClick = onExitClick,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("arena_exit_button"),
      ) {
        Icon(Icons.Default.Close, contentDescription = strings.exitMatch, tint = TextSecondary)
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text =
            if (setup.mode == GameMode.ONLINE_1VS1 && activeRoom != null) {
              "${activeRoom.hostScore} : ${activeRoom.guestScore}  •  " +
                String.format(Locale.US, "%02d:%02d", (elapsedSec / 60).toInt(), (elapsedSec % 60).toInt())
            } else {
              String.format(Locale.US, "%02d:%02d", (elapsedSec / 60).toInt(), (elapsedSec % 60).toInt())
            },
          style = MaterialTheme.typography.titleLarge,
          color = TextPrimary,
        )
        Text(
          text =
            if (oppDisconnected) strings.opponentOfflineWarning
            else buildString {
              if (fps != null) append("$fps FPS • ")
              append(qualityBadge)
              if (autoScaled) append(" (${strings.autoLagActiveTag})")
            },
          style = MaterialTheme.typography.labelSmall,
          color = if (oppDisconnected) CrimsonDanger else if (autoScaled) GoldAccent else EmeraldSuccess,
        )
      }

      IconButton(
        onClick = onPauseClick,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("arena_pause_button"),
      ) {
        Icon(Icons.Default.Pause, contentDescription = strings.pauseMatch, tint = TextPrimary)
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      BallHudCard(
        label =
          if (setup.mode == GameMode.ONE_VS_AI) "P1 • ${strings.ballName(p1.type)}"
          else "${setup.p1DisplayName} • ${strings.ballName(p1.type)}",
        isAdminSide = setup.mode == GameMode.ONLINE_1VS1 && activeRoom?.hostIsAdmin == true,
        admBadgeLabel = strings.admBadgeLabel,
        ball = p1,
        sideBalls = side1Balls,
        strings = strings,
        modifier = Modifier.weight(1f),
      )
      BallHudCard(
        label =
          if (setup.mode == GameMode.ONE_VS_AI) "AI • ${strings.ballName(p2.type)}"
          else "${setup.p2DisplayName} • ${strings.ballName(p2.type)}",
        isAdminSide = setup.mode == GameMode.ONLINE_1VS1 && activeRoom?.guestIsAdmin == true,
        admBadgeLabel = strings.admBadgeLabel,
        ball = p2,
        sideBalls = side2Balls,
        strings = strings,
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun BallHudCard(
  label: String,
  isAdminSide: Boolean,
  admBadgeLabel: String,
  ball: BallEntity,
  sideBalls: List<BallEntity>,
  strings: GameStrings,
  modifier: Modifier = Modifier,
) {
  val accent = ballAccentColor(ball.type)
  val core = ballCoreColor(ball.type)
  val aliveBalls = sideBalls.filter { it.hp > 0f }
  val totalHp = aliveBalls.sumOf { it.hp.toDouble() }.toFloat().coerceAtLeast(0f)
  val totalMaxHp = (sideBalls.sumOf { it.maxHp.toDouble() }.toFloat()).coerceAtLeast(ball.maxHp)
  val hpRatio = (totalHp / totalMaxHp).coerceIn(0f, 1f)
  val maxRage = (aliveBalls.maxOfOrNull { it.rage } ?: ball.rage).coerceIn(0f, 100f)
  val rageRatio = (maxRage / 100f).coerceIn(0f, 1f)

  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(14.dp),
    color = ObsidianSurface,
    border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
          modifier = Modifier.weight(1f),
        ) {
          ElementSkillIconBadge(type = ball.type, size = 22.dp)
          if (isAdminSide) {
            AdmVipBadge(label = admBadgeLabel)
          }
          Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
          )
        }
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          if (sideBalls.size > 1) {
            Text(
              text = "x${aliveBalls.size}/${sideBalls.size}",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = GoldAccent,
            )
          }
          Text(
            text = "${totalHp.roundToInt()}/${totalMaxHp.roundToInt()}",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (hpRatio < 0.3f) CrimsonDanger else TextPrimary,
            maxLines = 1,
            softWrap = false,
          )
        }
      }

      LinearProgressIndicator(
        progress = { hpRatio },
        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(999.dp)),
        color = if (hpRatio < 0.3f) CrimsonDanger else accent,
        trackColor = ObsidianSurfaceElevated,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        LinearProgressIndicator(
          progress = { rageRatio },
          modifier = Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(999.dp)),
          color = if (rageRatio >= 0.9f) GoldAccent else core,
          trackColor = ObsidianSurfaceElevated,
        )
        Text(
          text = "${maxRage.roundToInt()}%",
          style = MaterialTheme.typography.labelSmall,
          color = GoldAccent,
        )
      }

      if (ball.burnTimer > 0f || ball.soakTimer > 0f || ball.postFreezeSlowTimer > 0f || ball.silenceTimer > 0f || ball.earthArmorTimer > 0f || ball.frozenTimer > 0f || ball.trappedTimer > 0f || ball.venomTimer > 0f) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          if (ball.burnTimer > 0f) Text(strings.burnStatus, style = MaterialTheme.typography.labelSmall, color = FireCore)
          if (ball.soakTimer > 0f || (ball.postFreezeSlowTimer > 0f && ball.frozenTimer <= 0f)) {
            Text(
              strings.soakStatus,
              style = MaterialTheme.typography.labelSmall,
              color = if (ball.postFreezeSlowTimer > 0f) IceGlow else WaterPrimary,
            )
          }
          if (ball.silenceTimer > 0f) Text(strings.silenceStatus, style = MaterialTheme.typography.labelSmall, color = ThunderPrimary)
          if (ball.earthArmorTimer > 0f) Text(strings.armorStatus, style = MaterialTheme.typography.labelSmall, color = GroundGlow)
          if (ball.frozenTimer > 0f) Text(strings.frozenStatus, style = MaterialTheme.typography.labelSmall, color = IceGlow)
          if (ball.trappedTimer > 0f) Text(strings.trappedStatus, style = MaterialTheme.typography.labelSmall, color = WaterCore)
          if (ball.venomTimer > 0f) Text(strings.venomStatus, style = MaterialTheme.typography.labelSmall, color = AntGlow)
        }
      }
    }
  }
}

@Composable
private fun ArenaBottomBar(
  strings: GameStrings,
  phase: ArenaPhase,
  isOnline: Boolean,
  waitingOpponentAim: Boolean,
  p1Name: String,
  p2Name: String,
  localName: String,
  onConfirmAim: () -> Unit,
  onSendEmote: (OnlineEmote) -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = ObsidianSurface,
    border = BorderStroke(1.dp, ObsidianBorder),
    modifier = Modifier.fillMaxWidth(),
  ) {
    when {
      isOnline && waitingOpponentAim && (phase == ArenaPhase.AIMING_P1 || phase == ArenaPhase.AIMING_P2) -> {
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 16.dp),
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          CircularProgressIndicator(modifier = Modifier.size(18.dp), color = WaterPrimary, strokeWidth = 2.dp)
          Spacer(modifier = Modifier.width(10.dp))
          Text(strings.waitingOpponentAimLabel, style = MaterialTheme.typography.labelLarge, color = WaterPrimary)
        }
      }
      phase == ArenaPhase.AIMING_P1 || phase == ArenaPhase.AIMING_P2 -> {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          val promptText =
            if (isOnline) "$localName: ${strings.aimP1Prompt}"
            else if (phase == ArenaPhase.AIMING_P1) "$p1Name: ${strings.aimP1Prompt}"
            else "$p2Name: ${strings.aimP2Prompt}"
          Text(
            text = promptText,
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(modifier = Modifier.width(10.dp))
          Button(
            onClick = onConfirmAim,
            colors =
              ButtonDefaults.buttonColors(
                containerColor = Color.Transparent,
                contentColor = Color.White,
              ),
            contentPadding = PaddingValues(0.dp),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.height(48.dp).testTag("launch_ball_button"),
          ) {
            Box(
              modifier =
                Modifier.background(
                  Brush.horizontalGradient(listOf(FirePrimary, WaterCore)),
                  shape = RoundedCornerShape(12.dp),
                )
                  .padding(horizontal = 16.dp, vertical = 12.dp),
              contentAlignment = Alignment.Center,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.RocketLaunch, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(
                  text = if (isOnline) strings.confirmAimButton else strings.launchButton,
                  style = MaterialTheme.typography.labelLarge,
                )
              }
            }
          }
        }
      }
      phase == ArenaPhase.AI_AIMING -> {
        Box(
          modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
          contentAlignment = Alignment.Center,
        ) {
          Text(strings.aiAimingPrompt, style = MaterialTheme.typography.labelLarge, color = WaterPrimary)
        }
      }
      else -> {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = strings.emoteBarLabel,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
          )
          OnlineEmote.entries.forEach { emote ->
            Surface(
              onClick = { onSendEmote(emote) },
              shape = RoundedCornerShape(999.dp),
              color = ObsidianSurfaceElevated,
              border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.45f)),
              modifier = Modifier.height(40.dp).testTag("arena_emote_${emote.id}"),
            ) {
              Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 12.dp)) {
                Text(
                  text = emote.badgeText,
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = GoldAccent,
                  maxLines = 1,
                  softWrap = false,
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StatRow(
  label: String,
  value: String,
  valueColor: Color = TextPrimary,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
    Text(
      text = value,
      style = MaterialTheme.typography.bodyMedium,
      fontWeight = FontWeight.Bold,
      color = valueColor,
    )
  }
}
