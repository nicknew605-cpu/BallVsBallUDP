package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.BallType
import com.example.model.OtaBalanceConfig
import com.example.model.ShopPurchaseResult
import com.example.model.UserProgress
import com.example.ui.components.AnimatedElementBallBadge
import com.example.ui.components.CoinPill
import com.example.ui.components.ElementSkillIconBadge
import com.example.ui.components.GlassArenaCard
import com.example.ui.components.NeonPillBadge
import com.example.ui.components.RarityBadge
import com.example.ui.components.ballAccentColor
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterPrimary
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

@Composable
fun BallVaultScreen(
  strings: GameStrings,
  progress: UserProgress,
  otaBalance: OtaBalanceConfig = OtaBalanceConfig(),
  nowMillis: Long,
  onBuyOrEquipBall: suspend (BallType) -> ShopPurchaseResult,
  onBack: () -> Unit,
) {
  var selectedBall by remember { mutableStateOf(progress.equippedBall) }
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  val owned = selectedBall in progress.purchasedBalls
  val available = progress.isBallAvailable(selectedBall, nowMillis)
  val equipped = progress.equippedBall == selectedBall
  val accent = ballAccentColor(selectedBall)
  val liveOverride = otaBalance.overrideFor(selectedBall)

  Scaffold(
    containerColor = ObsidianBg,
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets.safeDrawing,
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(Brush.verticalGradient(listOf(Color(0xFF0A101E), ObsidianBg)))
          .padding(innerPadding)
    ) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .widthIn(max = 640.dp)
            .align(Alignment.Center)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            IconButton(
              onClick = onBack,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("vault_back_button"),
            ) {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back, tint = TextPrimary)
            }
            Text(
              strings.vaultTitle,
              style = MaterialTheme.typography.titleLarge,
              color = TextPrimary,
              maxLines = 1,
              softWrap = false,
              overflow = TextOverflow.Ellipsis,
            )
          }
          CoinPill(coins = progress.coins, label = strings.coinsLabel)
        }

        Text(strings.vaultSubtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

        // All 6 Balls 2-Column Grid (3 even rows)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          BallType.entries.chunked(2).forEach { rowBalls ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              rowBalls.forEach { ball ->
                val isSelected = selectedBall == ball
                val isUnlocked = progress.isBallAvailable(ball, nowMillis)
                val bAccent = ballAccentColor(ball)
                Surface(
                  onClick = { selectedBall = ball },
                  shape = RoundedCornerShape(16.dp),
                  color = if (isSelected) bAccent.copy(alpha = 0.16f) else ObsidianSurface,
                  border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) bAccent else ObsidianBorder),
                  modifier = Modifier.weight(1f).testTag("vault_ball_${ball.id}"),
                ) {
                  Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                  ) {
                    RarityBadge(rarity = ball.rarity, strings = strings)
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                      AnimatedElementBallBadge(type = ball, size = 46.dp)
                      ElementSkillIconBadge(type = ball, size = 38.dp)
                    }
                    Text(
                      strings.ballName(ball),
                      style = MaterialTheme.typography.titleMedium,
                      color = TextPrimary,
                      maxLines = 1,
                      softWrap = false,
                      overflow = TextOverflow.Ellipsis,
                    )
                    val trialRemMs = progress.ballTrialRemainingMillis(ball, nowMillis)
                    if (ball in progress.purchasedBalls) {
                      Text(strings.ownedBadge, style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess, maxLines = 1, softWrap = false)
                    } else if (trialRemMs > 0L) {
                      Text(
                        "${strings.ballTrialBadgePrefix} ${formatVaultTrialDuration(trialRemMs)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = WaterPrimary,
                        maxLines = 1,
                        softWrap = false,
                      )
                    } else if (isUnlocked) {
                      Text(strings.unlockedTrialLabel, style = MaterialTheme.typography.labelSmall, color = WaterPrimary, maxLines = 1, softWrap = false)
                    } else {
                      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Lock, contentDescription = strings.lockedLabel, tint = GoldAccent, modifier = Modifier.size(13.dp))
                        Text("${ball.price} ${strings.coinsLabel}", style = MaterialTheme.typography.labelSmall, color = GoldAccent, maxLines = 1, softWrap = false)
                      }
                    }
                  }
                }
              }
              if (rowBalls.size == 1) {
                Spacer(modifier = Modifier.weight(1f))
              }
            }
          }
        }

        // Inspector Panel: Live OTA HP/Damage, Passives, Skill 1 & Ultimate
        GlassArenaCard(borderColor = accent.copy(alpha = 0.6f)) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              AnimatedElementBallBadge(type = selectedBall, size = 56.dp)
              ElementSkillIconBadge(type = selectedBall, size = 46.dp)
              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Text(
                    strings.ballName(selectedBall),
                    style = MaterialTheme.typography.titleLarge,
                    color = accent,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                  )
                  RarityBadge(rarity = selectedBall.rarity, strings = strings)
                }
                Text(strings.ballTagline(selectedBall), style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  NeonPillBadge(text = "${liveOverride.hp} HP", color = EmeraldSuccess)
                  NeonPillBadge(text = "DMG ${(liveOverride.damageScale * 100).roundToInt()}%", color = GoldAccent)
                  val selTrialRem = progress.ballTrialRemainingMillis(selectedBall, nowMillis)
                  if (!owned && selTrialRem > 0L) {
                    NeonPillBadge(
                      text = "${strings.ballTrialBadgePrefix} ${formatVaultTrialDuration(selTrialRem)}",
                      color = WaterPrimary,
                    )
                  }
                }
              }
            }

            VaultStatBar(strings.statAttack, selectedBall.attackRating, accent)
            VaultStatBar(strings.statDefense, selectedBall.defenseRating, EmeraldSuccess)
            VaultStatBar(strings.statSpeed, selectedBall.speedRating, GoldAccent)
            VaultStatBar(strings.statControl, selectedBall.controlRating, WaterPrimary)

            Surface(
              shape = RoundedCornerShape(12.dp),
              color = accent.copy(alpha = 0.10f),
              border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text(
                text = strings.ballPassiveDesc(selectedBall),
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary,
                modifier = Modifier.padding(10.dp),
              )
            }

            Text(strings.ballNormalTitle(selectedBall), style = MaterialTheme.typography.labelLarge, color = TextPrimary)
            Text(strings.ballNormalDesc(selectedBall), style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Text(strings.ballUltTitle(selectedBall), style = MaterialTheme.typography.labelLarge, color = GoldAccent)
            Text(strings.ballUltDesc(selectedBall), style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

            Button(
              onClick = {
                scope.launch {
                  when (onBuyOrEquipBall(selectedBall)) {
                    ShopPurchaseResult.SUCCESS -> snackbarHostState.showSnackbar(strings.purchasedSuccess)
                    ShopPurchaseResult.INSUFFICIENT_COINS -> snackbarHostState.showSnackbar(strings.notEnoughCoins)
                    ShopPurchaseResult.ALREADY_OWNED -> Unit
                  }
                }
              },
              enabled = !equipped,
              shape = RoundedCornerShape(14.dp),
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = if (available) accent else GoldAccent,
                  contentColor = Color.Black,
                  disabledContainerColor = ObsidianSurfaceElevated,
                  disabledContentColor = EmeraldSuccess,
                ),
              modifier = Modifier.fillMaxWidth().height(50.dp).testTag("vault_action_button"),
            ) {
              if (equipped) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.equippedLabel, fontWeight = FontWeight.Bold)
              } else if (owned || available) {
                Text(strings.equipButton, fontWeight = FontWeight.Bold)
              } else {
                Text("${strings.buyButton} (${selectedBall.price} ${strings.coinsLabel})", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun VaultStatBar(label: String, rating: Int, color: Color) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Text(text = label, style = MaterialTheme.typography.labelLarge, color = TextSecondary, modifier = Modifier.width(92.dp))
    LinearProgressIndicator(
      progress = { (rating / 100f).coerceIn(0f, 1f) },
      modifier = Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(999.dp)),
      color = color,
      trackColor = ObsidianSurfaceElevated,
    )
    Text(text = "$rating", style = MaterialTheme.typography.labelLarge, color = color, fontWeight = FontWeight.Bold)
  }
}

private fun formatVaultTrialDuration(remMillis: Long): String {
  val totalMins = ((remMillis + 59_999L) / 60_000L).coerceAtLeast(1L)
  val hrs = totalMins / 60L
  val mins = totalMins % 60L
  return if (hrs > 0L) "${hrs}h${mins}m" else "${totalMins}m"
}
