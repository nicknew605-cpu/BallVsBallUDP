package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ArenaDarkColorScheme =
  darkColorScheme(
    primary = FirePrimary,
    onPrimary = TextPrimary,
    primaryContainer = FireGlow,
    onPrimaryContainer = TextPrimary,
    secondary = WaterPrimary,
    onSecondary = ObsidianBg,
    secondaryContainer = WaterCore,
    onSecondaryContainer = TextPrimary,
    tertiary = GoldAccent,
    onTertiary = ObsidianBg,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = ObsidianBorder,
    error = CrimsonDanger,
    onError = TextPrimary,
  )

private val ArenaShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
  )

@Composable
fun BallVsBallTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = ArenaDarkColorScheme,
    typography = AppTypography,
    shapes = ArenaShapes,
    content = content,
  )
}
