package com.example.ui.screens

import android.content.ClipDescription
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.localization.GameStrings
import com.example.model.APP_DISPLAY_VERSION
import com.example.model.APP_VERSION_CODE
import com.example.model.ApkPackageInfo
import com.example.model.BallType
import com.example.model.DEFAULT_GITHUB_REPO
import com.example.model.DEFAULT_V103_RAW_APK_URL
import com.example.model.GitHubUploadState
import com.example.model.OtaAppUpdateConfig
import com.example.model.OtaLiveConfig
import com.example.model.PlayerDirectoryEntry
import com.example.ui.components.AdmVipBadge
import com.example.ui.components.GlassArenaCard
import com.example.ui.components.ballAccentColor
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterPrimary
import com.example.util.AdminLocalPrefs
import com.example.util.AppUpdateManager
import java.util.Locale
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AdminApkDragDropReleaseSection(
  strings: GameStrings,
  draft: OtaLiveConfig,
  uploadState: GitHubUploadState,
  onUpdateDraft: (OtaLiveConfig) -> Unit,
  onUploadAndPublishApk: suspend (
    repo: String,
    token: String,
    apkInfo: ApkPackageInfo,
    updatedConfig: OtaLiveConfig,
  ) -> Result<OtaLiveConfig>,
  onShowMessage: (String) -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val localPrefs = remember(context) { AdminLocalPrefs(context) }

  var githubRepo by remember { mutableStateOf(localPrefs.loadGithubRepo()) }
  var githubToken by remember { mutableStateOf(localPrefs.loadGithubToken()) }
  var showToken by remember { mutableStateOf(false) }
  var parsedApk by remember { mutableStateOf<ApkPackageInfo?>(null) }
  var isDraggingOver by remember { mutableStateOf(false) }

  fun inspectDroppedOrPickedUri(uri: Uri) {
    scope.launch {
      AppUpdateManager.inspectApkUri(context, uri)
        .onSuccess { info ->
          parsedApk = info
          val nextCode =
            if (info.versionCode > BuildConfig.VERSION_CODE) info.versionCode
            else maxOf(draft.appUpdate.latestVersionCode, BuildConfig.VERSION_CODE + 1)
          val nextName = info.versionName.ifBlank { draft.appUpdate.latestVersionName }
          onUpdateDraft(
            draft.copy(
              appUpdate = draft.appUpdate.copy(
                latestVersionCode = nextCode,
                latestVersionName = nextName,
              )
            )
          )
        }
        .onFailure { err ->
          onShowMessage(err.localizedMessage ?: "Invalid APK")
        }
    }
  }

  val openApkLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
      if (uri != null) {
        inspectDroppedOrPickedUri(uri)
      }
    }

  val dragCallback = remember {
    object : DragAndDropTarget {
      override fun onStarted(event: DragAndDropEvent) {
        isDraggingOver = true
      }

      override fun onEnded(event: DragAndDropEvent) {
        isDraggingOver = false
      }

      override fun onExited(event: DragAndDropEvent) {
        isDraggingOver = false
      }

      override fun onDrop(event: DragAndDropEvent): Boolean {
        isDraggingOver = false
        val androidEvent = event.toAndroidDragEvent()
        val clip = androidEvent.clipData ?: return false
        for (i in 0 until clip.itemCount) {
          val uri = clip.getItemAt(i).uri
          if (uri != null) {
            inspectDroppedOrPickedUri(uri)
            return true
          }
        }
        return false
      }
    }
  }

  GlassArenaCard(borderColor = EmeraldSuccess.copy(alpha = 0.55f)) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Text(strings.adminReleaseSection, style = MaterialTheme.typography.titleMedium, color = EmeraldSuccess)
      Text(strings.adminReleaseHint, style = MaterialTheme.typography.bodySmall, color = TextSecondary)

      // Drag-and-Drop Zone + File Picker
      Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isDraggingOver) EmeraldSuccess.copy(alpha = 0.16f) else ObsidianSurfaceElevated,
        border = BorderStroke(if (isDraggingOver) 2.dp else 1.2.dp, if (isDraggingOver) EmeraldSuccess else WaterPrimary.copy(alpha = 0.55f)),
        modifier =
          Modifier.fillMaxWidth()
            .dragAndDropTarget(
              shouldStartDragAndDrop = { event ->
                val desc = event.toAndroidDragEvent().clipDescription
                desc == null ||
                  desc.hasMimeType(ClipDescription.MIMETYPE_TEXT_URILIST) ||
                  desc.hasMimeType("application/vnd.android.package-archive") ||
                  desc.hasMimeType("*/*")
              },
              target = dragCallback,
            ),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Icon(Icons.Default.FileUpload, contentDescription = strings.adminApkDropTitle, tint = EmeraldSuccess, modifier = Modifier.size(30.dp))
          Text(strings.adminApkDropTitle, style = MaterialTheme.typography.labelLarge, color = TextPrimary)
          Text(strings.adminApkDropHint, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
          Button(
            onClick = {
              openApkLauncher.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream", "*/*"))
            },
            colors = ButtonDefaults.buttonColors(containerColor = WaterPrimary, contentColor = Color.Black),
            modifier = Modifier.height(48.dp).testTag("admin_pick_apk_button"),
          ) {
            Text(strings.adminPickApkButton, fontWeight = FontWeight.Bold)
          }

          parsedApk?.let { apk ->
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = EmeraldSuccess.copy(alpha = 0.12f),
              border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f)),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(apk.fileName, style = MaterialTheme.typography.labelLarge, color = EmeraldSuccess)
                Text(
                  text = "v${apk.versionName} (#${apk.versionCode}) • ${String.format(Locale.US, "%.2f MB", apk.sizeMb)}",
                  style = MaterialTheme.typography.labelSmall,
                  color = TextPrimary,
                )
              }
            }
            if (apk.versionCode > 0 && apk.versionCode <= BuildConfig.VERSION_CODE) {
              val otaAlreadyHigher = draft.appUpdate.latestVersionCode > BuildConfig.VERSION_CODE
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = (if (otaAlreadyHigher) GoldAccent else CrimsonDanger).copy(alpha = 0.14f),
                border = BorderStroke(1.dp, if (otaAlreadyHigher) GoldAccent else CrimsonDanger),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth().padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Text(
                    text =
                      if (otaAlreadyHigher) {
                        "OTA Version Code = #${draft.appUpdate.latestVersionCode} (> #${BuildConfig.VERSION_CODE}). Lưu ý: file APK bạn chọn vẫn là #${apk.versionCode} — chỉ bản mới build (#${BuildConfig.VERSION_CODE + 1}+) mới cài đè cho máy đang chạy #${BuildConfig.VERSION_CODE}."
                      } else {
                        strings.adminVersionWarningLow
                      },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (otaAlreadyHigher) GoldAccent else CrimsonDanger,
                    modifier = Modifier.weight(1f),
                  )
                  if (!otaAlreadyHigher) {
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(
                      onClick = {
                        onUpdateDraft(
                          draft.copy(
                            appUpdate = draft.appUpdate.copy(latestVersionCode = BuildConfig.VERSION_CODE + 1)
                          )
                        )
                      },
                      modifier = Modifier.height(40.dp),
                    ) {
                      Text(strings.adminFixVersionCodeButton, color = GoldAccent, style = MaterialTheme.typography.labelSmall)
                    }
                  }
                }
              }
            }
          }
        }
      }

      val normalizedPreview = remember(githubRepo) { AppUpdateManager.normalizeGithubRepoInput(githubRepo) }
      OutlinedTextField(
        value = githubRepo,
        onValueChange = { raw ->
          val trimmed = raw.take(260)
          val nextValue =
            if (trimmed.contains("github.com/", ignoreCase = true) ||
              trimmed.contains("/blob/") ||
              trimmed.contains("/releases/") ||
              trimmed.contains("/tree/")
            ) {
              AppUpdateManager.normalizeGithubRepoInput(trimmed)
            } else {
              trimmed
            }
          githubRepo = nextValue
          localPrefs.saveGithubCredentials(githubRepo, githubToken)
        },
        label = { Text(strings.adminGithubRepoLabel) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("admin_github_repo_input"),
      )
      if (githubRepo.isNotBlank()) {
        val validSlug = normalizedPreview.count { it == '/' } == 1 && !normalizedPreview.startsWith("blob/")
        Text(
          text =
            if (validSlug) "Repo: $normalizedPreview"
            else "Định dạng đúng: ten_tai_khoan/ten_repo (hoặc dán link https://github.com/ten_tai_khoan/ten_repo)",
          style = MaterialTheme.typography.labelSmall,
          color = if (validSlug) EmeraldSuccess else CrimsonDanger,
        )
      }

      OutlinedTextField(
        value = githubToken,
        onValueChange = {
          githubToken = it.take(200)
          localPrefs.saveGithubCredentials(githubRepo, githubToken)
        },
        label = { Text(strings.adminGithubTokenLabel) },
        singleLine = true,
        visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
          IconButton(onClick = { showToken = !showToken }) {
            Icon(
              imageVector = if (showToken) Icons.Default.VisibilityOff else Icons.Default.Visibility,
              contentDescription = "Toggle token",
              tint = TextSecondary,
            )
          }
        },
        modifier = Modifier.fillMaxWidth().testTag("admin_github_token_input"),
      )
      Text(strings.adminGithubTokenHint, style = MaterialTheme.typography.labelSmall, color = TextSecondary)

      when (uploadState) {
        is GitHubUploadState.Uploading -> {
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(uploadState.statusText, style = MaterialTheme.typography.labelSmall, color = WaterPrimary)
            LinearProgressIndicator(
              progress = { (uploadState.progressPct / 100f).coerceIn(0f, 1f) },
              modifier = Modifier.fillMaxWidth().height(7.dp),
              color = EmeraldSuccess,
            )
          }
        }
        is GitHubUploadState.Failed -> {
          Text(uploadState.message, style = MaterialTheme.typography.labelSmall, color = CrimsonDanger)
        }
        is GitHubUploadState.Success -> {
          Text("Uploaded: ${uploadState.tagName}", style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess)
        }
        GitHubUploadState.Idle -> Unit
      }

      Button(
        onClick = {
          val apk = parsedApk
          if (apk == null || githubRepo.isBlank() || githubToken.isBlank()) {
            onShowMessage(strings.adminUploadMissingFields)
            return@Button
          }
          scope.launch {
            localPrefs.saveGithubCredentials(githubRepo, githubToken)
            val safeLatestCode =
              if (draft.appUpdate.latestVersionCode > BuildConfig.VERSION_CODE) draft.appUpdate.latestVersionCode
              else BuildConfig.VERSION_CODE + 1
            val updatedDraft =
              draft.copy(appUpdate = draft.appUpdate.copy(latestVersionCode = safeLatestCode))
            onUploadAndPublishApk(githubRepo, githubToken, apk, updatedDraft)
              .onSuccess { published ->
                onUpdateDraft(published)
                onShowMessage(strings.adminPublishSuccess)
              }
              .onFailure { err ->
                onShowMessage(err.localizedMessage ?: strings.adminPublishError)
              }
          }
        },
        enabled = uploadState !is GitHubUploadState.Uploading,
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("admin_upload_publish_apk_button"),
      ) {
        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(strings.adminUploadPublishButton, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
      }

      // Standard OTA Update Fields (also works directly with Betadrop https://... links)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = draft.appUpdate.latestVersionCode.toString(),
          onValueChange = { raw ->
            val parsed = raw.filter(Char::isDigit).take(6).toIntOrNull() ?: 1
            onUpdateDraft(draft.copy(appUpdate = draft.appUpdate.copy(latestVersionCode = parsed)))
          },
          label = { Text(strings.adminVersionCodeLabel) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("admin_update_version_code_input"),
        )
        OutlinedTextField(
          value = draft.appUpdate.minSupportedVersionCode.toString(),
          onValueChange = { raw ->
            val parsed = raw.filter(Char::isDigit).take(6).toIntOrNull() ?: 1
            onUpdateDraft(draft.copy(appUpdate = draft.appUpdate.copy(minSupportedVersionCode = parsed)))
          },
          label = { Text(strings.adminMinVersionCodeLabel) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("admin_update_min_code_input"),
        )
      }
      OutlinedTextField(
        value = draft.appUpdate.latestVersionName,
        onValueChange = { v -> onUpdateDraft(draft.copy(appUpdate = draft.appUpdate.copy(latestVersionName = v.take(40)))) },
        label = { Text(strings.adminVersionNameLabel) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("admin_update_version_name_input"),
      )
      OutlinedTextField(
        value = draft.appUpdate.downloadUrl,
        onValueChange = { v ->
          val normalized = OtaAppUpdateConfig.normalizeDownloadUrl(v.take(500))
          onUpdateDraft(draft.copy(appUpdate = draft.appUpdate.copy(downloadUrl = normalized)))
        },
        label = { Text(strings.adminDownloadUrlLabel) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("admin_update_url_input"),
      )
      OutlinedButton(
        onClick = {
          githubRepo = DEFAULT_GITHUB_REPO
          localPrefs.saveGithubCredentials(githubRepo, githubToken)
          onUpdateDraft(
            draft.copy(
              appUpdate =
                draft.appUpdate.copy(
                  latestVersionCode = maxOf(draft.appUpdate.latestVersionCode, APP_VERSION_CODE),
                  latestVersionName = APP_DISPLAY_VERSION,
                  downloadUrl = DEFAULT_V103_RAW_APK_URL,
                )
            )
          )
        },
        modifier = Modifier.fillMaxWidth().height(44.dp).testTag("admin_preset_v103_url_button"),
      ) {
        Text(
          text = "Điền sẵn GitHub v1.0.3 ($DEFAULT_GITHUB_REPO)",
          style = MaterialTheme.typography.labelSmall,
          color = WaterPrimary,
        )
      }
      OutlinedTextField(
        value = draft.appUpdate.releaseNotesVi,
        onValueChange = { v -> onUpdateDraft(draft.copy(appUpdate = draft.appUpdate.copy(releaseNotesVi = v.take(500)))) },
        label = { Text(strings.adminReleaseNotesViLabel) },
        maxLines = 3,
        modifier = Modifier.fillMaxWidth().testTag("admin_update_notes_vi_input"),
      )
      OutlinedTextField(
        value = draft.appUpdate.releaseNotesEn,
        onValueChange = { v -> onUpdateDraft(draft.copy(appUpdate = draft.appUpdate.copy(releaseNotesEn = v.take(500)))) },
        label = { Text(strings.adminReleaseNotesEnLabel) },
        maxLines = 3,
        modifier = Modifier.fillMaxWidth().testTag("admin_update_notes_en_input"),
      )
    }
  }
}

@Composable
fun AdminTargetedGiftSection(
  strings: GameStrings,
  onSearchPlayers: suspend (String) -> List<PlayerDirectoryEntry>,
  onSendTargetedGift: suspend (
    targetUid: String,
    coins: Int,
    ball: BallType?,
    trialMinutes: Int,
    message: String,
  ) -> Result<Unit>,
  onShowMessage: (String) -> Unit,
) {
  val scope = rememberCoroutineScope()
  var query by remember { mutableStateOf("") }
  var results by remember { mutableStateOf<List<PlayerDirectoryEntry>>(emptyList()) }
  var selectedPlayer by remember { mutableStateOf<PlayerDirectoryEntry?>(null) }
  var giftCoinsText by remember { mutableStateOf("500") }
  var giftBall by remember { mutableStateOf<BallType?>(null) }
  var isTrialMode by remember { mutableStateOf(false) }
  var trialAmountText by remember { mutableStateOf("60") }
  var trialUnitHours by remember { mutableStateOf(false) }
  var giftMessage by remember { mutableStateOf("") }
  var sending by remember { mutableStateOf(false) }

  GlassArenaCard(borderColor = GoldAccent.copy(alpha = 0.55f)) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = GoldAccent)
        Text(strings.adminGiftSection, style = MaterialTheme.typography.titleMedium, color = GoldAccent)
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        OutlinedTextField(
          value = query,
          onValueChange = { query = it.take(32) },
          label = { Text(strings.adminGiftTargetHint) },
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("admin_gift_search_input"),
        )
        Button(
          onClick = {
            if (query.isNotBlank()) {
              scope.launch { results = onSearchPlayers(query.trim()) }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = WaterPrimary, contentColor = Color.Black),
          modifier = Modifier.height(54.dp).testTag("admin_gift_search_button"),
        ) {
          Icon(Icons.Default.Search, contentDescription = strings.searchButton)
        }
      }

      if (results.isNotEmpty()) {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          results.forEach { p ->
            val picked = selectedPlayer?.uid == p.uid
            FilterChip(
              selected = picked,
              onClick = { selectedPlayer = p },
              label = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  if (p.isAdmin) AdmVipBadge(label = strings.admBadgeLabel)
                  Text("${p.nickname} (${p.playerCode})", maxLines = 1, softWrap = false)
                }
              },
              colors = FilterChipDefaults.filterChipColors(selectedContainerColor = GoldAccent.copy(alpha = 0.28f)),
            )
          }
        }
      }

      selectedPlayer?.let { p ->
        Text(
          text = "Target: ${p.nickname} • ${p.playerCode}",
          style = MaterialTheme.typography.labelLarge,
          color = EmeraldSuccess,
        )
      }

      OutlinedTextField(
        value = giftCoinsText,
        onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) giftCoinsText = it },
        label = { Text(strings.adminCoinsInputLabel) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("admin_gift_coins_input"),
      )

      Text(strings.adminBallSelectLabel, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        FilterChip(
          selected = giftBall == null,
          onClick = { giftBall = null },
          label = { Text("-") },
        )
        BallType.entries.forEach { ball ->
          FilterChip(
            selected = giftBall == ball,
            onClick = { giftBall = ball },
            label = { Text(strings.ballName(ball), maxLines = 1, softWrap = false) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ballAccentColor(ball).copy(alpha = 0.25f)),
          )
        }
      }

      if (giftBall != null) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(strings.adminCodeTrialToggleLabel, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
          Switch(checked = isTrialMode, onCheckedChange = { isTrialMode = it })
        }
        if (isTrialMode) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            OutlinedTextField(
              value = trialAmountText,
              onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) trialAmountText = it },
              label = { Text(strings.adminTrialDurationLabel) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
            FilterChip(
              selected = !trialUnitHours,
              onClick = { trialUnitHours = false },
              label = { Text(strings.adminTrialUnitMinutes) },
            )
            FilterChip(
              selected = trialUnitHours,
              onClick = { trialUnitHours = true },
              label = { Text(strings.adminTrialUnitHours) },
            )
          }
        }
      }

      OutlinedTextField(
        value = giftMessage,
        onValueChange = { giftMessage = it.take(300) },
        label = { Text(strings.adminGiftMessageLabel) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )

      Button(
        onClick = {
          val target = selectedPlayer
          if (target == null) {
            onShowMessage(strings.adminGiftSelectPlayerFirst)
            return@Button
          }
          if (!sending) {
            sending = true
            val coins = (giftCoinsText.toIntOrNull() ?: 0).coerceIn(0, 100000)
            val rawDur = (trialAmountText.toIntOrNull() ?: 60).coerceAtLeast(1)
            val trialMinutes =
              if (giftBall != null && isTrialMode) (if (trialUnitHours) rawDur * 60 else rawDur).coerceIn(1, 43200)
              else 0
            scope.launch {
              onSendTargetedGift(target.uid, coins, giftBall, trialMinutes, giftMessage)
                .onSuccess {
                  onShowMessage(strings.adminGiftSentSuccess)
                  giftMessage = ""
                }
                .onFailure { err ->
                  onShowMessage(err.localizedMessage ?: "Error")
                }
              sending = false
            }
          }
        },
        enabled = !sending,
        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("admin_send_targeted_gift_button"),
      ) {
        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(strings.adminGiftSendButton, fontWeight = FontWeight.Bold)
      }
    }
  }
}
