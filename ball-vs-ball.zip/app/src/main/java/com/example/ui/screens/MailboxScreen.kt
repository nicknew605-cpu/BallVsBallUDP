package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.AppLanguage
import com.example.model.MailboxLetter
import com.example.ui.components.AnimatedElementBallBadge
import com.example.ui.components.GlassArenaCard
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterPrimary
import kotlinx.coroutines.launch

@Composable
fun MailboxScreen(
  strings: GameStrings,
  language: AppLanguage,
  letters: List<MailboxLetter>,
  onClaimLetter: suspend (MailboxLetter) -> Unit,
  onBack: () -> Unit,
) {
  val scope = rememberCoroutineScope()

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Color(0xFF0E1422), ObsidianBg)))
  ) {
    Column(
      modifier =
        Modifier.fillMaxSize()
          .windowInsetsPadding(WindowInsets.safeDrawing)
          .padding(horizontal = 20.dp, vertical = 12.dp)
          .widthIn(max = 640.dp)
          .align(Alignment.Center),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("mailbox_back_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = strings.back,
            tint = TextPrimary,
          )
        }
        Text(
          text = strings.mailboxTitle,
          style = MaterialTheme.typography.titleLarge,
          color = TextPrimary,
        )
      }

      if (letters.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          GlassArenaCard(modifier = Modifier.fillMaxWidth(), borderColor = ObsidianBorder) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(28.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Icon(Icons.Default.MarkEmailUnread, contentDescription = null, tint = WaterPrimary, modifier = Modifier.size(44.dp))
              Text(
                text = strings.mailboxEmpty,
                style = MaterialTheme.typography.bodyLarge,
                color = TextSecondary,
                textAlign = TextAlign.Center,
              )
            }
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          items(letters, key = { it.id }) { letter ->
            val title = if (language == AppLanguage.VI) letter.titleVi.ifBlank { letter.titleEn } else letter.titleEn.ifBlank { letter.titleVi }
            val body = if (language == AppLanguage.VI) letter.bodyVi.ifBlank { letter.bodyEn } else letter.bodyEn.ifBlank { letter.bodyVi }
            val hasReward = letter.rewardCoins > 0 || letter.rewardBall != null

            GlassArenaCard(
              borderColor = if (!letter.claimed && hasReward) GoldAccent.copy(alpha = 0.65f) else ObsidianBorder
            ) {
              Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f),
                  ) {
                    Icon(
                      imageVector = if (letter.claimed) Icons.Default.MarkEmailRead else Icons.Default.MarkEmailUnread,
                      contentDescription = null,
                      tint = if (letter.claimed) TextSecondary else GoldAccent,
                    )
                    Column {
                      Text(text = title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                      Text(text = letter.sender, style = MaterialTheme.typography.labelSmall, color = WaterPrimary)
                    }
                  }
                  if (letter.claimed) {
                    Surface(
                      shape = RoundedCornerShape(999.dp),
                      color = EmeraldSuccess.copy(alpha = 0.14f),
                      border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f)),
                    ) {
                      Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                      ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                        Text(strings.mailboxClaimedBadge, style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess)
                      }
                    }
                  }
                }

                Text(text = body, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

                if (hasReward) {
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth().padding(12.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                      Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                      ) {
                        letter.rewardBall?.let { ball ->
                          AnimatedElementBallBadge(type = ball, size = 40.dp)
                        }
                        Column {
                          Text(strings.mailboxRewardPrefix, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                          val rewardLabel = buildList {
                            letter.rewardBall?.let { add(strings.ballName(it)) }
                            if (letter.rewardCoins > 0) add("+${letter.rewardCoins} ${strings.coinsLabel}")
                          }.joinToString(" • ")
                          Text(text = rewardLabel, style = MaterialTheme.typography.labelLarge, color = GoldAccent)
                        }
                      }

                      if (!letter.claimed) {
                        Button(
                          onClick = { scope.launch { onClaimLetter(letter) } },
                          colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black),
                          shape = RoundedCornerShape(10.dp),
                          modifier = Modifier.height(48.dp).testTag("claim_mail_${letter.id}"),
                        ) {
                          Icon(Icons.Default.CardGiftcard, contentDescription = null, modifier = Modifier.size(16.dp))
                          Spacer(modifier = Modifier.width(6.dp))
                          Text(strings.mailboxClaimButton, fontWeight = FontWeight.Bold)
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
