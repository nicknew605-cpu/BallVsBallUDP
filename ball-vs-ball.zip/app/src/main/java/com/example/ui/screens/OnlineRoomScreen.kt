package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SignalWifi4Bar
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.BallType
import com.example.model.FriendEntry
import com.example.model.MatchmakingUiState
import com.example.model.ONLINE_FT3_TARGET_SCORE
import com.example.model.OnlineRoomPhase
import com.example.model.OnlineRoomState
import com.example.model.RoomChatMessage
import com.example.model.UserProgress
import com.example.ui.components.AdmVipBadge
import com.example.ui.components.ElementSkillIconBadge
import com.example.ui.components.GlassArenaCard
import com.example.ui.components.NeonPillBadge
import com.example.ui.components.ballAccentColor
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThunderPrimary
import com.example.ui.theme.WaterPrimary
import kotlinx.coroutines.launch

@Composable
fun OnlineRoomScreen(
  strings: GameStrings,
  currentUid: String,
  progress: UserProgress,
  nowMillis: Long,
  activeRoom: OnlineRoomState?,
  friends: List<FriendEntry> = emptyList(),
  roomChat: List<RoomChatMessage>,
  roomPingMs: Long,
  isRoomBusy: Boolean,
  matchmakingState: MatchmakingUiState = MatchmakingUiState.Idle,
  onStartQuickMatch: () -> Unit = {},
  onCancelQuickMatch: () -> Unit = {},
  onCreateRoom: suspend () -> Result<OnlineRoomState>,
  onJoinRoom: suspend (String) -> Result<OnlineRoomState>,
  onInviteFriend: suspend (String) -> Result<Unit> = { Result.success(Unit) },
  onToggleReady: suspend (Boolean) -> Result<Unit>,
  onSendChat: suspend (String) -> Unit,
  onSubmitPick3: suspend (String, List<BallType>) -> Result<Unit>,
  onSubmitBan1: suspend (String, BallType) -> Result<Unit>,
  onSubmitFinalPick: suspend (String, BallType) -> Result<Unit>,
  onClaimDisconnectWin: suspend () -> Result<Int>,
  onLeaveRoom: () -> Unit,
  onStartOnlineBattle: (OnlineRoomState) -> Unit,
  onBack: () -> Unit,
) {
  var joinCodeInput by remember { mutableStateOf("") }
  var chatInput by remember { mutableStateOf("") }
  var selectedBan by remember(activeRoom?.phase, activeRoom?.currentRound) { mutableStateOf<BallType?>(null) }
  var selectedFinal by remember(activeRoom?.phase, activeRoom?.currentRound) { mutableStateOf<BallType?>(null) }
  var launchedRoundKey by remember { mutableStateOf<String?>(null) }
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  LaunchedEffect(matchmakingState) {
    if (matchmakingState is MatchmakingUiState.Failed) {
      snackbarHostState.showSnackbar(matchmakingState.message)
    }
  }

  LaunchedEffect(
    activeRoom?.roomCode,
    activeRoom?.currentRound,
    activeRoom?.phase,
    activeRoom?.hostFinalBall,
    activeRoom?.guestFinalBall,
  ) {
    val room = activeRoom ?: run {
      launchedRoundKey = null
      return@LaunchedEffect
    }
    if (room.phase != OnlineRoomPhase.PLAYING) {
      launchedRoundKey = null
      return@LaunchedEffect
    }
    val key = "${room.roomCode}:${room.currentRound}"
    if (room.hostFinalBall != null &&
      room.guestFinalBall != null &&
      launchedRoundKey != key
    ) {
      launchedRoundKey = key
      onStartOnlineBattle(room)
    }
  }

  Scaffold(
    containerColor = ObsidianBg,
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets.safeDrawing,
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(Brush.verticalGradient(listOf(Color(0xFF0A101E), ObsidianBg)))
          .padding(innerPadding)
    ) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .widthIn(max = 640.dp)
            .align(Alignment.Center)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            IconButton(
              onClick = {
                onLeaveRoom()
                onBack()
              },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("online_back_button"),
            ) {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back, tint = TextPrimary)
            }
            Text(
              strings.onlineTitle,
              style = MaterialTheme.typography.titleLarge,
              color = TextPrimary,
              maxLines = 1,
              softWrap = false,
              overflow = TextOverflow.Ellipsis,
            )
          }
          if (activeRoom != null) {
            OutlinedButton(
              onClick = onLeaveRoom,
              modifier = Modifier.height(48.dp).testTag("leave_room_button"),
            ) {
              Text(strings.leaveRoomButton, color = CrimsonDanger, maxLines = 1, softWrap = false)
            }
          }
        }

        if (activeRoom == null) {
          Text(strings.onlineSubtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = EmeraldSuccess.copy(alpha = 0.12f),
            border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.45f)),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(strings.speedRewardNote, style = MaterialTheme.typography.labelLarge, color = EmeraldSuccess)
              Text(strings.loserNoLossNote, style = MaterialTheme.typography.labelSmall, color = GoldAccent)
            }
          }

          GlassArenaCard(borderColor = GoldAccent.copy(alpha = 0.72f)) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(18.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              when (matchmakingState) {
                is MatchmakingUiState.Searching -> {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                  ) {
                    CircularProgressIndicator(
                      color = GoldAccent,
                      modifier = Modifier.size(28.dp),
                      strokeWidth = 3.dp,
                    )
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = "${strings.quickMatchSearching} (${matchmakingState.elapsedSec}s)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent,
                      )
                      Text(
                        text = strings.quickMatchDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                      )
                    }
                  }
                  OutlinedButton(
                    onClick = onCancelQuickMatch,
                    border = BorderStroke(1.dp, CrimsonDanger.copy(alpha = 0.7f)),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("quick_match_cancel_button"),
                  ) {
                    Icon(Icons.Default.Close, contentDescription = null, tint = CrimsonDanger)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.quickMatchCancel, color = CrimsonDanger, fontWeight = FontWeight.Bold)
                  }
                }

                is MatchmakingUiState.Matched -> {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                  ) {
                    CircularProgressIndicator(color = EmeraldSuccess, modifier = Modifier.size(26.dp), strokeWidth = 3.dp)
                    Text(
                      text = strings.quickMatchFound,
                      style = MaterialTheme.typography.titleSmall,
                      fontWeight = FontWeight.Bold,
                      color = EmeraldSuccess,
                    )
                  }
                }

                else -> {
                  Text(strings.quickMatchDesc, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                  Button(
                    onClick = onStartQuickMatch,
                    enabled = !isRoomBusy,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth().height(54.dp).testTag("quick_match_button"),
                  ) {
                    Icon(Icons.Default.Bolt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.quickMatchButton, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }

          GlassArenaCard(borderColor = WaterPrimary.copy(alpha = 0.55f)) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(18.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Button(
                onClick = {
                  scope.launch {
                    onCreateRoom().onFailure { err ->
                      snackbarHostState.showSnackbar(err.localizedMessage ?: "Error")
                    }
                  }
                },
                enabled = !isRoomBusy,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = FirePrimary, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(54.dp).testTag("create_room_button"),
              ) {
                Icon(Icons.Default.AddCircleOutline, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(strings.createRoomButton, fontWeight = FontWeight.Bold)
              }

              OutlinedTextField(
                value = joinCodeInput,
                onValueChange = { joinCodeInput = it.uppercase().take(6) },
                singleLine = true,
                placeholder = { Text(strings.roomCodePlaceholder, color = TextSecondary) },
                modifier = Modifier.fillMaxWidth().testTag("join_room_code_input"),
              )

              Button(
                onClick = {
                  scope.launch {
                    onJoinRoom(joinCodeInput).onFailure { err ->
                      snackbarHostState.showSnackbar(err.localizedMessage ?: "Room error")
                    }
                  }
                },
                enabled = !isRoomBusy && joinCodeInput.length >= 4,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = WaterPrimary, contentColor = Color.Black),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("join_room_button"),
              ) {
                Icon(Icons.Default.Groups, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(strings.joinRoomButton, fontWeight = FontWeight.Bold)
              }
            }
          }
        } else {
          val isHost = activeRoom.isHost(currentUid)
          val myPicks = if (isHost) activeRoom.hostPicks else activeRoom.guestPicks
          val oppPicks = if (isHost) activeRoom.guestPicks else activeRoom.hostPicks
          val oppBannedMyBall = if (isHost) activeRoom.guestBannedBall else activeRoom.hostBannedBall
          val myBannedOppBall = if (isHost) activeRoom.hostBannedBall else activeRoom.guestBannedBall
          val myFinal = if (isHost) activeRoom.hostFinalBall else activeRoom.guestFinalBall
          val myReady = if (isHost) activeRoom.hostReady else activeRoom.guestReady
          val oppReady = if (isHost) activeRoom.guestReady else activeRoom.hostReady
          val oppDisconnected = activeRoom.isOpponentDisconnected(currentUid, nowMillis)

          // Esports Room Scoreboard & Health Header
          GlassArenaCard(borderColor = GoldAccent.copy(alpha = 0.6f)) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text("${strings.roomCodeLabel} ${activeRoom.roomCode}", style = MaterialTheme.typography.titleLarge, color = GoldAccent)
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  val pingColor =
                    when {
                      roomPingMs <= 0L -> TextSecondary
                      roomPingMs < 90L -> EmeraldSuccess
                      roomPingMs < 180L -> GoldAccent
                      else -> CrimsonDanger
                    }
                  Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = pingColor.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, pingColor.copy(alpha = 0.55f)),
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      Icon(Icons.Default.SignalWifi4Bar, contentDescription = null, tint = pingColor, modifier = Modifier.size(13.dp))
                      Text(
                        text = if (roomPingMs > 0) "${strings.pingLabel}: ${roomPingMs}ms" else "${strings.pingLabel}: --",
                        style = MaterialTheme.typography.labelSmall,
                        color = pingColor,
                      )
                    }
                  }
                  NeonPillBadge(
                    text = "${strings.roundSeriesLabel} ${activeRoom.currentRound}",
                    color = WaterPrimary,
                  )
                }
              }

              // Real Player Names + ADM Badges + FT3 Scoreboard (Host vs Guest)
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = ObsidianSurfaceElevated,
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      if (activeRoom.hostIsAdmin) {
                        AdmVipBadge(label = strings.admBadgeLabel)
                      }
                      Text(
                        text = activeRoom.hostName.ifBlank { "Host" },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                    }
                    if (activeRoom.phase == OnlineRoomPhase.WAITING && activeRoom.hostReady) {
                      Text(strings.readyBadge, style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess)
                    }
                  }
                  Text(
                    text = "${activeRoom.hostScore}  :  ${activeRoom.guestScore}  (FT$ONLINE_FT3_TARGET_SCORE)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = GoldAccent,
                  )
                  Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      if (activeRoom.guestIsAdmin) {
                        AdmVipBadge(label = strings.admBadgeLabel)
                      }
                      Text(
                        text = activeRoom.guestName.ifBlank { "..." },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                    }
                    if (activeRoom.phase == OnlineRoomPhase.WAITING && activeRoom.guestUid.isNotBlank()) {
                      Text(
                        text = if (activeRoom.guestReady) strings.readyBadge else if (oppDisconnected) "Offline" else strings.opponentOnlineLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (oppDisconnected) CrimsonDanger else if (activeRoom.guestReady) EmeraldSuccess else WaterPrimary,
                      )
                    }
                  }
                }
              }
            }
          }

          if (oppDisconnected && activeRoom.phase != OnlineRoomPhase.FINISHED) {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = CrimsonDanger.copy(alpha = 0.16f),
              border = BorderStroke(1.dp, CrimsonDanger),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Row(
                  modifier = Modifier.weight(1f),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Icon(Icons.Default.Warning, contentDescription = null, tint = CrimsonDanger)
                  Text(strings.opponentOfflineWarning, style = MaterialTheme.typography.bodyMedium, color = CrimsonDanger)
                }
                Button(
                  onClick = {
                    scope.launch {
                      onClaimDisconnectWin().onSuccess { coins ->
                        snackbarHostState.showSnackbar("+$coins ${strings.coinsLabel}")
                      }
                    }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = CrimsonDanger, contentColor = Color.White),
                  modifier = Modifier.height(48.dp).testTag("claim_disconnect_win_button"),
                ) {
                  Text(strings.claimDisconnectWinButton, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
              }
            }
          }

          when (activeRoom.phase) {
            OnlineRoomPhase.WAITING -> {
              GlassArenaCard {
                Column(
                  modifier = Modifier.fillMaxWidth().padding(18.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  if (activeRoom.guestUid.isBlank()) {
                    CircularProgressIndicator(color = WaterPrimary)
                    Text(strings.waitingOpponentLabel, style = MaterialTheme.typography.bodyLarge, color = TextSecondary, textAlign = TextAlign.Center)

                    if (friends.isNotEmpty()) {
                      Text(strings.inviteFriendButton, style = MaterialTheme.typography.labelLarge, color = GoldAccent)
                      Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                      ) {
                        friends.forEach { friend ->
                          OutlinedButton(
                            onClick = {
                              scope.launch {
                                onInviteFriend(friend.uid)
                                  .onSuccess { snackbarHostState.showSnackbar(strings.inviteSentMsg) }
                                  .onFailure { err -> snackbarHostState.showSnackbar(err.localizedMessage ?: "Error") }
                              }
                            },
                            border = BorderStroke(1.dp, ThunderPrimary.copy(alpha = 0.65f)),
                            modifier = Modifier.height(48.dp).testTag("room_invite_${friend.playerCode}"),
                          ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = strings.inviteFriendButton, tint = ThunderPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            if (friend.isAdmin) {
                              AdmVipBadge(label = strings.admBadgeLabel)
                              Spacer(modifier = Modifier.width(4.dp))
                            }
                            Text(friend.nickname, color = TextPrimary, maxLines = 1, softWrap = false)
                          }
                        }
                      }
                    }
                  } else {
                    Text(strings.waitingReadyLabel, style = MaterialTheme.typography.bodyMedium, color = TextSecondary, textAlign = TextAlign.Center)
                    Button(
                      onClick = {
                        scope.launch {
                          onToggleReady(!myReady).onFailure { err ->
                            snackbarHostState.showSnackbar(err.localizedMessage ?: "Error")
                          }
                        }
                      },
                      enabled = !isRoomBusy,
                      colors =
                        ButtonDefaults.buttonColors(
                          containerColor = if (myReady) ObsidianSurfaceElevated else EmeraldSuccess,
                          contentColor = if (myReady) GoldAccent else Color.Black,
                        ),
                      shape = RoundedCornerShape(14.dp),
                      modifier = Modifier.fillMaxWidth().height(54.dp).testTag("online_ready_button"),
                    ) {
                      Icon(Icons.Default.CheckCircle, contentDescription = null)
                      Spacer(modifier = Modifier.width(8.dp))
                      Text(
                        text = if (myReady) strings.unreadyButton else strings.readyButton,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                      )
                    }
                    if (myReady && !oppReady) {
                      Text(strings.waitingOpponentLabel, style = MaterialTheme.typography.labelLarge, color = GoldAccent)
                    }
                  }
                }
              }
            }

            OnlineRoomPhase.PICK_3 -> {
              GlassArenaCard {
                Column(
                  modifier = Modifier.fillMaxWidth().padding(20.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  CircularProgressIndicator(color = GoldAccent)
                  Text(strings.phasePick3Title, style = MaterialTheme.typography.titleMedium, color = GoldAccent)
                  Text(strings.autoDraftHint, style = MaterialTheme.typography.bodyMedium, color = TextSecondary, textAlign = TextAlign.Center)
                }
              }
            }

            OnlineRoomPhase.BAN_1 -> {
              Text(strings.autoDraftHint, style = MaterialTheme.typography.labelSmall, color = WaterPrimary)
              Text(strings.phaseBan1Title, style = MaterialTheme.typography.titleMedium, color = CrimsonDanger)
              if (myBannedOppBall != null) {
                Text(strings.waitingOpponentLabel, style = MaterialTheme.typography.bodyLarge, color = GoldAccent)
              } else {
                BallGridSelector(
                  balls = oppPicks.distinct(),
                  enabledBalls = oppPicks.toSet(),
                  selectedBalls = setOfNotNull(selectedBan),
                  strings = strings,
                  onToggleBall = { selectedBan = it },
                )
                Button(
                  onClick = {
                    selectedBan?.let { ban ->
                      scope.launch {
                        onSubmitBan1(activeRoom.roomCode, ban).onFailure { err ->
                          snackbarHostState.showSnackbar(err.localizedMessage ?: "Error")
                        }
                      }
                    }
                  },
                  enabled = selectedBan != null && !isRoomBusy,
                  colors = ButtonDefaults.buttonColors(containerColor = CrimsonDanger, contentColor = Color.White),
                  modifier = Modifier.fillMaxWidth().height(52.dp).testTag("online_confirm_ban1_button"),
                ) {
                  Icon(Icons.Default.Block, contentDescription = null)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(strings.banBallButton, fontWeight = FontWeight.Bold)
                }
              }
            }

            OnlineRoomPhase.FINAL_PICK -> {
              Text(strings.phaseFinalPickTitle, style = MaterialTheme.typography.titleMedium, color = EmeraldSuccess)
              val remainingCandidates = myPicks.filter { it != oppBannedMyBall }.ifEmpty { myPicks }
              if (myFinal != null) {
                Text(strings.waitingOpponentLabel, style = MaterialTheme.typography.bodyLarge, color = WaterPrimary)
              } else {
                BallGridSelector(
                  balls = remainingCandidates,
                  enabledBalls = remainingCandidates.toSet(),
                  selectedBalls = setOfNotNull(selectedFinal),
                  strings = strings,
                  onToggleBall = { selectedFinal = it },
                )
                Button(
                  onClick = {
                    selectedFinal?.let { finalBall ->
                      scope.launch {
                        onSubmitFinalPick(activeRoom.roomCode, finalBall).onFailure { err ->
                          snackbarHostState.showSnackbar(err.localizedMessage ?: "Error")
                        }
                      }
                    }
                  },
                  enabled = selectedFinal != null && !isRoomBusy,
                  colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
                  modifier = Modifier.fillMaxWidth().height(52.dp).testTag("online_confirm_final_button"),
                ) {
                  Icon(Icons.Default.PlayArrow, contentDescription = null)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(strings.launchOnlineBattleButton, fontWeight = FontWeight.Bold)
                }
              }
            }

            OnlineRoomPhase.PLAYING -> {
              GlassArenaCard(borderColor = ThunderPrimary.copy(alpha = 0.65f)) {
                Column(
                  modifier = Modifier.fillMaxWidth().padding(18.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  CircularProgressIndicator(color = ThunderPrimary)
                  Text(strings.enteringBattleLabel, style = MaterialTheme.typography.titleMedium, color = ThunderPrimary)
                  Button(
                    onClick = { onStartOnlineBattle(activeRoom) },
                    colors = ButtonDefaults.buttonColors(containerColor = ThunderPrimary, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth().height(52.dp).testTag("online_enter_arena_button"),
                  ) {
                    Text(strings.launchOnlineBattleButton, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }

            OnlineRoomPhase.FINISHED -> {
              val iWon = activeRoom.winnerUid == currentUid
              GlassArenaCard(borderColor = (if (iWon) EmeraldSuccess else CrimsonDanger).copy(alpha = 0.7f)) {
                Column(
                  modifier = Modifier.fillMaxWidth().padding(20.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Text(strings.matchFinishedTitle, style = MaterialTheme.typography.labelLarge, color = GoldAccent)
                  Text(
                    text = if (iWon) strings.winnerP1 else strings.winnerP2,
                    style = MaterialTheme.typography.headlineMedium,
                    color = if (iWon) EmeraldSuccess else CrimsonDanger,
                  )
                  Text(
                    text = "${activeRoom.hostName} ${activeRoom.hostScore} - ${activeRoom.guestScore} ${activeRoom.guestName}",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                  )
                  if (iWon && activeRoom.rewardCoins > 0) {
                    Text(
                      text = "+${activeRoom.rewardCoins} ${strings.coinsLabel}",
                      style = MaterialTheme.typography.titleLarge,
                      color = GoldAccent,
                    )
                  }
                }
              }
            }
          }

          // Unfiltered Real-Time Lobby Chat Panel
          GlassArenaCard(borderColor = ObsidianBorder) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp, max = 148.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                if (roomChat.isEmpty()) {
                  item {
                    Text(strings.chatEmptyHint, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                  }
                } else {
                  items(roomChat, key = { it.id }) { msg ->
                    val isMe = msg.senderUid == currentUid
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                      Text(
                        text = "${msg.senderName}:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isMe) WaterPrimary else GoldAccent,
                      )
                      Text(
                        text = msg.text,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                      )
                    }
                  }
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                OutlinedTextField(
                  value = chatInput,
                  onValueChange = { if (it.length <= 240) chatInput = it },
                  singleLine = true,
                  placeholder = { Text(strings.chatPlaceholder, color = TextSecondary) },
                  modifier = Modifier.weight(1f).testTag("online_chat_input"),
                )
                IconButton(
                  onClick = {
                    val toSend = chatInput.trim()
                    if (toSend.isNotEmpty()) {
                      chatInput = ""
                      scope.launch { onSendChat(toSend) }
                    }
                  },
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("online_send_chat_button"),
                ) {
                  Icon(Icons.AutoMirrored.Filled.Send, contentDescription = strings.sendChatButton, tint = WaterPrimary)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun BallGridSelector(
  balls: List<BallType>,
  enabledBalls: Set<BallType>,
  selectedBalls: Set<BallType>,
  strings: GameStrings,
  onToggleBall: (BallType) -> Unit,
) {
  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    balls.chunked(2).forEach { rowItems ->
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        rowItems.forEach { ball ->
          val enabled = ball in enabledBalls
          val selected = ball in selectedBalls
          val accent = ballAccentColor(ball)
          Surface(
            onClick = { if (enabled) onToggleBall(ball) },
            shape = RoundedCornerShape(14.dp),
            color =
              when {
                selected -> accent.copy(alpha = 0.20f)
                enabled -> ObsidianSurface
                else -> ObsidianSurfaceElevated.copy(alpha = 0.45f)
              },
            border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) accent else ObsidianBorder),
            modifier = Modifier.weight(1f).testTag("online_ball_${ball.id}"),
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              ElementSkillIconBadge(type = ball, size = 40.dp)
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  strings.ballName(ball),
                  style = MaterialTheme.typography.labelLarge,
                  color = if (enabled) TextPrimary else TextSecondary,
                  maxLines = 1,
                  softWrap = false,
                  overflow = TextOverflow.Ellipsis,
                )
                if (!enabled) {
                  Text(strings.lockedLabel, style = MaterialTheme.typography.labelSmall, color = GoldAccent, maxLines = 1, softWrap = false)
                }
              }
            }
          }
        }
        if (rowItems.size == 1) Spacer(modifier = Modifier.weight(1f))
      }
    }
  }
}
