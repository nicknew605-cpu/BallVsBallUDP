package com.example.ui.arena

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import com.example.model.GraphicsQuality

private const val ARENA_DISTORTION_AGSL =
  """
    uniform shader content;
    uniform float time;
    uniform float heatStrength;
    uniform float waterStrength;
    uniform float freezeStrength;
    uniform float2 resolution;

    half4 main(float2 fragCoord) {
        float2 uv = fragCoord / max(resolution, float2(1.0));
        float2 offset = float2(0.0);

        if (heatStrength > 0.001) {
            float waveX = sin(uv.y * 30.0 + time * 15.0) * 6.5 * heatStrength;
            float waveY = cos(uv.x * 24.0 + time * 12.0) * 4.5 * heatStrength;
            offset += float2(waveX, waveY);
        }

        if (waterStrength > 0.001) {
            float ripple = sin((uv.y * 20.0) - time * 13.0) * 7.5 * waterStrength;
            offset += float2(ripple, ripple * 0.45);
        }

        half4 col = content.eval(fragCoord + offset);
        if (heatStrength > 0.01) {
            col.r = min(1.0, col.r + half(0.09 * heatStrength));
            col.g = min(1.0, col.g + half(0.02 * heatStrength));
        }
        if (waterStrength > 0.01) {
            col.b = min(1.0, col.b + half(0.11 * waterStrength));
        }
        if (freezeStrength > 0.01) {
            col.b = min(1.0, col.b + half(0.12 * freezeStrength));
            col.g = min(1.0, col.g + half(0.05 * freezeStrength));
        }
        return col;
    }
"""

@Composable
fun Modifier.arenaPostProcessShader(
  enabled: Boolean,
  quality: GraphicsQuality,
  timeSec: Float,
  heatStrength: Float,
  waterStrength: Float,
  freezeStrength: Float,
): Modifier {
  if (!enabled ||
    quality.tierRank < GraphicsQuality.HIGH.tierRank ||
    Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
    (heatStrength <= 0.01f && waterStrength <= 0.01f && freezeStrength <= 0.01f)
  ) {
    return this
  }

  val shader = remember {
    try {
      RuntimeShader(ARENA_DISTORTION_AGSL)
    } catch (_: Throwable) {
      null
    }
  } ?: return this

  return this.graphicsLayer {
    shader.setFloatUniform("time", timeSec)
    shader.setFloatUniform("heatStrength", heatStrength.coerceIn(0f, 1f))
    shader.setFloatUniform("waterStrength", waterStrength.coerceIn(0f, 1f))
    shader.setFloatUniform("freezeStrength", freezeStrength.coerceIn(0f, 1f))
    shader.setFloatUniform("resolution", size.width, size.height)
    renderEffect = RenderEffect.createRuntimeShaderEffect(shader, "content").asComposeRenderEffect()
  }
}
