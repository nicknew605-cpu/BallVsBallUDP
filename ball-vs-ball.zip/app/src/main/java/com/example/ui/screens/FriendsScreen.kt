package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.FriendEntry
import com.example.model.FriendRequestEntry
import com.example.model.PlayerDirectoryEntry
import com.example.model.UserProgress
import com.example.ui.components.AdmVipBadge
import com.example.ui.components.GlassArenaCard
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThunderPrimary
import com.example.ui.theme.WaterPrimary
import kotlinx.coroutines.launch

@Composable
fun FriendsScreen(
  strings: GameStrings,
  progress: UserProgress,
  isGuestMode: Boolean,
  isAdmin: Boolean,
  friends: List<FriendEntry>,
  incomingRequests: List<FriendRequestEntry>,
  onLinkGoogle: () -> Unit,
  onSearchPlayers: suspend (String) -> List<PlayerDirectoryEntry>,
  onSendFriendRequest: suspend (PlayerDirectoryEntry) -> Result<Unit>,
  onRespondFriendRequest: suspend (FriendRequestEntry, Boolean) -> Result<Unit>,
  onRemoveFriend: suspend (String) -> Unit,
  onInviteFriendBattle: suspend (String) -> Result<Unit>,
  onBack: () -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var searchResults by remember { mutableStateOf<List<PlayerDirectoryEntry>>(emptyList()) }
  var searching by remember { mutableStateOf(false) }
  var sentUids by remember { mutableStateOf<Set<String>>(emptySet()) }

  val clipboard = LocalClipboardManager.current
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val friendUids = remember(friends) { friends.map { it.uid }.toSet() }

  Scaffold(
    containerColor = ObsidianBg,
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets.safeDrawing,
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(Brush.verticalGradient(listOf(Color(0xFF0A101E), ObsidianBg)))
          .padding(innerPadding)
    ) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .widthIn(max = 640.dp)
            .align(Alignment.Center),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(
            onClick = onBack,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("friends_back_button"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back, tint = TextPrimary)
          }
          Text(
            text = strings.friendsTitle,
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        // My Shareable BVB Player ID Card + ADM Badge
        GlassArenaCard(borderColor = WaterPrimary.copy(alpha = 0.55f)) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                if (isAdmin) {
                  AdmVipBadge(label = strings.admBadgeLabel)
                }
                Text(
                  text = progress.nickname,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              Text(
                text = "${strings.playerIdLabel}: ${progress.playerCode.ifBlank { "BVB-SYNC..." }}",
                style = MaterialTheme.typography.labelLarge,
                color = WaterPrimary,
              )
            }
            OutlinedButton(
              onClick = {
                val code = progress.playerCode
                if (code.isNotBlank()) {
                  clipboard.setText(AnnotatedString(code))
                  scope.launch { snackbarHostState.showSnackbar(strings.copiedIdMsg) }
                }
              },
              border = BorderStroke(1.dp, WaterPrimary.copy(alpha = 0.6f)),
              modifier = Modifier.height(48.dp).testTag("copy_player_id_button"),
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = strings.copiedIdMsg, tint = WaterPrimary, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(progress.playerCode.ifBlank { "---" }, color = WaterPrimary, style = MaterialTheme.typography.labelLarge)
            }
          }
        }

        if (isGuestMode) {
          GlassArenaCard(borderColor = FirePrimary.copy(alpha = 0.6f)) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Text(strings.friendsNeedGoogleMsg, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
              Button(
                onClick = onLinkGoogle,
                colors = ButtonDefaults.buttonColors(containerColor = FirePrimary, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("friends_link_google_button"),
              ) {
                Text(strings.authGoogleSignInButton, fontWeight = FontWeight.Bold)
              }
            }
          }
        } else {
          TabRow(
            selectedTabIndex = selectedTab,
            containerColor = ObsidianSurface,
            contentColor = WaterPrimary,
          ) {
            Tab(
              selected = selectedTab == 0,
              onClick = { selectedTab = 0 },
              text = { Text("${strings.friendsTabList} (${friends.size})", maxLines = 1, softWrap = false) },
              modifier = Modifier.testTag("friends_tab_list"),
            )
            Tab(
              selected = selectedTab == 1,
              onClick = { selectedTab = 1 },
              text = {
                if (incomingRequests.isNotEmpty()) {
                  BadgedBox(badge = { Badge { Text("${incomingRequests.size}") } }) {
                    Text(strings.friendsTabRequests, maxLines = 1, softWrap = false)
                  }
                } else {
                  Text(strings.friendsTabRequests, maxLines = 1, softWrap = false)
                }
              },
              modifier = Modifier.testTag("friends_tab_requests"),
            )
            Tab(
              selected = selectedTab == 2,
              onClick = { selectedTab = 2 },
              text = { Text(strings.friendsTabSearch, maxLines = 1, softWrap = false) },
              modifier = Modifier.testTag("friends_tab_search"),
            )
          }

          when (selectedTab) {
            0 -> {
              if (friends.isEmpty()) {
                GlassArenaCard {
                  Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                  ) {
                    Icon(Icons.Default.Group, contentDescription = null, tint = WaterPrimary, modifier = Modifier.size(36.dp))
                    Text(strings.noFriendsHint, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                  }
                }
              } else {
                LazyColumn(
                  modifier = Modifier.weight(1f).fillMaxWidth(),
                  verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  items(friends, key = { it.uid }) { friend ->
                    Surface(
                      shape = RoundedCornerShape(14.dp),
                      color = ObsidianSurface,
                      border = BorderStroke(1.dp, ObsidianBorder),
                      modifier = Modifier.fillMaxWidth(),
                    ) {
                      Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                      ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                          Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                          ) {
                            if (friend.isAdmin) {
                              AdmVipBadge(label = strings.admBadgeLabel)
                            }
                            Text(
                              text = friend.nickname,
                              style = MaterialTheme.typography.titleMedium,
                              color = TextPrimary,
                              maxLines = 1,
                              overflow = TextOverflow.Ellipsis,
                            )
                          }
                          Text(friend.playerCode, style = MaterialTheme.typography.labelSmall, color = WaterPrimary)
                        }
                        Row(
                          verticalAlignment = Alignment.CenterVertically,
                          horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                          Button(
                            onClick = {
                              scope.launch {
                                onInviteFriendBattle(friend.uid)
                                  .onFailure { err -> snackbarHostState.showSnackbar(err.localizedMessage ?: "Error") }
                              }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ThunderPrimary, contentColor = Color.Black),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(48.dp).testTag("invite_friend_${friend.playerCode}"),
                          ) {
                            Icon(Icons.Default.SportsEsports, contentDescription = strings.inviteFriendButton, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.inviteFriendButton, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                          }
                          IconButton(
                            onClick = { scope.launch { onRemoveFriend(friend.uid) } },
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("remove_friend_${friend.playerCode}"),
                          ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = CrimsonDanger)
                          }
                        }
                      }
                    }
                  }
                }
              }
            }

            1 -> {
              if (incomingRequests.isEmpty()) {
                GlassArenaCard {
                  Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(strings.noRequestsHint, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                  }
                }
              } else {
                LazyColumn(
                  modifier = Modifier.weight(1f).fillMaxWidth(),
                  verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  items(incomingRequests, key = { it.id }) { req ->
                    Surface(
                      shape = RoundedCornerShape(14.dp),
                      color = ObsidianSurface,
                      border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.45f)),
                      modifier = Modifier.fillMaxWidth(),
                    ) {
                      Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                      ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                          Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                          ) {
                            if (req.fromIsAdmin) AdmVipBadge(label = strings.admBadgeLabel)
                            Text(req.fromName, style = MaterialTheme.typography.titleMedium, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                          }
                          Text(req.fromCode, style = MaterialTheme.typography.labelSmall, color = WaterPrimary)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                          Button(
                            onClick = {
                              scope.launch { onRespondFriendRequest(req, true) }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
                            modifier = Modifier.height(48.dp).testTag("accept_friend_${req.id}"),
                          ) {
                            Icon(Icons.Default.Check, contentDescription = strings.acceptButton, modifier = Modifier.size(16.dp))
                          }
                          OutlinedButton(
                            onClick = {
                              scope.launch { onRespondFriendRequest(req, false) }
                            },
                            border = BorderStroke(1.dp, CrimsonDanger.copy(alpha = 0.7f)),
                            modifier = Modifier.height(48.dp).testTag("decline_friend_${req.id}"),
                          ) {
                            Icon(Icons.Default.Close, contentDescription = strings.declineButton, tint = CrimsonDanger, modifier = Modifier.size(16.dp))
                          }
                        }
                      }
                    }
                  }
                }
              }
            }

            else -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                OutlinedTextField(
                  value = searchQuery,
                  onValueChange = { searchQuery = it.take(32) },
                  singleLine = true,
                  placeholder = { Text(strings.searchPlayerHint, color = TextSecondary) },
                  modifier = Modifier.weight(1f).testTag("search_player_input"),
                )
                Button(
                  onClick = {
                    val q = searchQuery.trim()
                    if (q.isNotEmpty() && !searching) {
                      searching = true
                      scope.launch {
                        searchResults = onSearchPlayers(q)
                        searching = false
                      }
                    }
                  },
                  enabled = !searching && searchQuery.isNotBlank(),
                  colors = ButtonDefaults.buttonColors(containerColor = WaterPrimary, contentColor = Color.Black),
                  modifier = Modifier.height(54.dp).testTag("search_player_button"),
                ) {
                  if (searching) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
                  } else {
                    Icon(Icons.Default.Search, contentDescription = strings.searchButton)
                  }
                }
              }

              LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                items(searchResults, key = { it.uid }) { target ->
                  val isAlreadyFriend = target.uid in friendUids
                  val isPending = target.uid in sentUids
                  Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth().padding(12.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                      Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                          verticalAlignment = Alignment.CenterVertically,
                          horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                          if (target.isAdmin) AdmVipBadge(label = strings.admBadgeLabel)
                          Text(target.nickname, style = MaterialTheme.typography.titleMedium, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text("${target.playerCode} • W ${target.totalWins}/${target.totalMatches}", style = MaterialTheme.typography.labelSmall, color = WaterPrimary)
                      }
                      Button(
                        onClick = {
                          scope.launch {
                            onSendFriendRequest(target)
                              .onSuccess {
                                sentUids = sentUids + target.uid
                                snackbarHostState.showSnackbar(strings.friendRequestSentMsg)
                              }
                              .onFailure { err ->
                                snackbarHostState.showSnackbar(err.localizedMessage ?: "Error")
                              }
                          }
                        },
                        enabled = !isAlreadyFriend && !isPending,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
                        modifier = Modifier.height(48.dp).testTag("add_friend_${target.playerCode}"),
                      ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                          text =
                            when {
                              isAlreadyFriend -> strings.alreadyFriendsLabel
                              isPending -> strings.pendingLabel
                              else -> strings.sendFriendRequestButton
                            },
                          style = MaterialTheme.typography.labelSmall,
                          fontWeight = FontWeight.Bold,
                          maxLines = 1,
                          softWrap = false,
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
