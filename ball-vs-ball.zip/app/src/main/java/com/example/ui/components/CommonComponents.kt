package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.localization.GameStrings
import com.example.model.ApkUpdateState
import com.example.model.AppLanguage
import com.example.model.BallRarity
import com.example.model.BallType
import com.example.model.CodeRedeemResult
import com.example.model.DailyRewardTier
import com.example.model.GachaSpinResult
import com.example.model.UserProgress
import com.example.ui.theme.AntCore
import com.example.ui.theme.AntGlow
import com.example.ui.theme.AntPrimary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.FireCore
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GroundCore
import com.example.ui.theme.GroundGlow
import com.example.ui.theme.GroundPrimary
import com.example.ui.theme.IceCore
import com.example.ui.theme.IcePrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianGlass
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.RarityCommonColor
import com.example.ui.theme.RarityRareColor
import com.example.ui.theme.RarityUncommonColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThunderCore
import com.example.ui.theme.ThunderPrimary
import com.example.ui.theme.WaterCore
import com.example.ui.theme.WaterPrimary
import com.example.util.ApkExporter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.launch

fun ballAccentColor(type: BallType): Color =
  when (type) {
    BallType.FIRE -> FirePrimary
    BallType.WATER -> WaterPrimary
    BallType.GROUND -> GroundPrimary
    BallType.THUNDER -> ThunderPrimary
    BallType.ICE -> IcePrimary
    BallType.ANT -> AntPrimary
  }

fun ballCoreColor(type: BallType): Color =
  when (type) {
    BallType.FIRE -> FireCore
    BallType.WATER -> WaterCore
    BallType.GROUND -> GroundCore
    BallType.THUNDER -> ThunderCore
    BallType.ICE -> IceCore
    BallType.ANT -> AntCore
  }

@DrawableRes
fun ballSkillIconRes(type: BallType): Int =
  when (type) {
    BallType.FIRE -> R.drawable.img_skill_fire
    BallType.WATER -> R.drawable.img_skill_water
    BallType.GROUND -> R.drawable.img_skill_ground
    BallType.THUNDER -> R.drawable.img_skill_thunder
    BallType.ICE -> R.drawable.img_skill_ice
    BallType.ANT -> R.drawable.img_skill_ant
  }

fun rarityColor(rarity: BallRarity): Color =
  when (rarity) {
    BallRarity.COMMON -> RarityCommonColor
    BallRarity.UNCOMMON -> RarityUncommonColor
    BallRarity.RARE -> RarityRareColor
  }

@Composable
fun GameLogoCutoutBadge(
  size: Dp = 88.dp,
  modifier: Modifier = Modifier,
) {
  Image(
    painter = painterResource(id = R.drawable.img_game_logo_cutout),
    contentDescription = "Ball vs Ball Logo",
    contentScale = ContentScale.Fit,
    modifier = modifier.size(size),
  )
}

@Composable
fun ElementSkillIconBadge(
  type: BallType,
  size: Dp = 44.dp,
  modifier: Modifier = Modifier,
) {
  val accent = ballAccentColor(type)
  Surface(
    modifier = modifier.size(size),
    shape = RoundedCornerShape(12.dp),
    color = ObsidianSurfaceElevated,
    border = BorderStroke(1.2.dp, accent.copy(alpha = 0.72f)),
  ) {
    Box(contentAlignment = Alignment.Center) {
      Image(
        painter = painterResource(id = ballSkillIconRes(type)),
        contentDescription = "${type.id} skill",
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(RoundedCornerShape(11.dp)),
      )
    }
  }
}

@Composable
fun NeonPillBadge(
  text: String,
  color: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(999.dp),
    color = color.copy(alpha = 0.15f),
    border = BorderStroke(1.dp, color.copy(alpha = 0.62f)),
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.Bold,
      color = color,
      maxLines = 1,
      softWrap = false,
      overflow = TextOverflow.Ellipsis,
      modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
    )
  }
}

@Composable
fun RarityBadge(rarity: BallRarity, strings: GameStrings, modifier: Modifier = Modifier) {
  NeonPillBadge(text = strings.rarityName(rarity), color = rarityColor(rarity), modifier = modifier)
}

@Composable
fun AdmVipBadge(
  label: String = "ADM",
  modifier: Modifier = Modifier,
) {
  val transition = rememberInfiniteTransition(label = "adm_badge_glow")
  val pulse by
    transition.animateFloat(
      initialValue = 0.72f,
      targetValue = 1.0f,
      animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
      label = "adm_pulse",
    )

  Surface(
    modifier = modifier.testTag("adm_vip_badge"),
    shape = RoundedCornerShape(999.dp),
    color = Color.Transparent,
    border = BorderStroke(1.2.dp, GoldAccent.copy(alpha = pulse)),
  ) {
    Row(
      modifier =
        Modifier.background(
          Brush.horizontalGradient(
            listOf(Color(0xFFB71C1C), Color(0xFFE65100), Color(0xFFFFB300))
          ),
          shape = RoundedCornerShape(999.dp),
        )
          .padding(horizontal = 8.dp, vertical = 3.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
      Icon(
        imageVector = Icons.Default.Shield,
        contentDescription = label,
        tint = Color.White,
        modifier = Modifier.size(12.dp),
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.ExtraBold,
        color = Color.White,
        maxLines = 1,
        softWrap = false,
      )
    }
  }
}

@Composable
fun CoinPill(coins: Int, label: String, modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier.testTag("coin_pill"),
    shape = RoundedCornerShape(999.dp),
    color = ObsidianSurfaceElevated,
    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.45f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
      Icon(
        imageVector = Icons.Default.MonetizationOn,
        contentDescription = label,
        tint = GoldAccent,
        modifier = Modifier.size(17.dp),
      )
      Text(
        text = "$coins $label",
        style = MaterialTheme.typography.labelLarge,
        color = GoldAccent,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun TanThuCountdownBanner(
  remainingMillis: Long,
  prefix: String,
  modifier: Modifier = Modifier,
) {
  val totalSec = (remainingMillis / 1000L).coerceAtLeast(0L)
  val h = totalSec / 3600L
  val m = (totalSec % 3600L) / 60L
  val s = totalSec % 60L
  val formatted = String.format(Locale.US, "%02d:%02d:%02d", h, m, s)

  Surface(
    modifier = modifier.fillMaxWidth().testTag("tanthu_banner"),
    shape = RoundedCornerShape(14.dp),
    color = EmeraldSuccess.copy(alpha = 0.14f),
    border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.55f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = Icons.Default.Timer,
        contentDescription = prefix,
        tint = EmeraldSuccess,
        modifier = Modifier.size(17.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "$prefix $formatted",
        style = MaterialTheme.typography.labelLarge,
        color = EmeraldSuccess,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun AnimatedElementBallBadge(
  type: BallType,
  size: Dp = 64.dp,
  modifier: Modifier = Modifier,
) {
  val transition = rememberInfiniteTransition(label = "ball_badge")
  val rotation by
    transition.animateFloat(
      initialValue = 0f,
      targetValue = 360f,
      animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
      label = "rot",
    )
  val pulse by
    transition.animateFloat(
      initialValue = 0.90f,
      targetValue = 1.10f,
      animationSpec = infiniteRepeatable(tween(1150, easing = LinearEasing), RepeatMode.Reverse),
      label = "pulse",
    )

  val outer = ballAccentColor(type)
  val core = ballCoreColor(type)

  Canvas(modifier = modifier.size(size)) {
    val r = this.size.minDimension * 0.36f
    val c = Offset(this.size.width * 0.5f, this.size.height * 0.5f)
    drawCircle(
      brush = Brush.radialGradient(listOf(outer.copy(alpha = 0.55f), Color.Transparent), center = c, radius = r * 1.72f * pulse),
      radius = r * 1.72f * pulse,
      center = c,
    )
    drawCircle(
      brush =
        Brush.radialGradient(
          colors = listOf(Color.White, core, outer),
          center = Offset(c.x - r * 0.28f, c.y - r * 0.28f),
          radius = r * 1.25f,
        ),
      radius = r,
      center = c,
    )
    rotate(degrees = if (type == BallType.FIRE || type == BallType.THUNDER || type == BallType.ANT) rotation else -rotation, pivot = c) {
      when (type) {
        BallType.FIRE -> {
          val ir = r * 0.62f
          val path = Path().apply {
            moveTo(c.x, c.y - ir)
            lineTo(c.x + ir * 0.42f, c.y - ir * 0.2f)
            lineTo(c.x + ir, c.y)
            lineTo(c.x + ir * 0.42f, c.y + ir * 0.2f)
            lineTo(c.x, c.y + ir)
            lineTo(c.x - ir * 0.42f, c.y + ir * 0.2f)
            lineTo(c.x - ir, c.y)
            lineTo(c.x - ir * 0.42f, c.y - ir * 0.2f)
            close()
          }
          drawPath(path, color = Color.White.copy(alpha = 0.65f), style = Stroke(width = 2.4f, join = StrokeJoin.Round))
        }
        BallType.WATER -> {
          drawCircle(color = Color.White.copy(alpha = 0.55f), radius = r * 0.5f, center = c, style = Stroke(width = 2.2f))
        }
        BallType.GROUND -> {
          val hex = Path().apply {
            for (i in 0 until 6) {
              val a = i * (PI.toFloat() / 3f)
              val px = c.x + cos(a) * r * 0.58f
              val py = c.y + sin(a) * r * 0.58f
              if (i == 0) moveTo(px, py) else lineTo(px, py)
            }
            close()
          }
          drawPath(hex, color = GroundGlow.copy(alpha = 0.85f), style = Stroke(width = 2.6f, join = StrokeJoin.Round))
        }
        BallType.THUNDER -> {
          val bolt = Path().apply {
            moveTo(c.x + r * 0.14f, c.y - r * 0.56f)
            lineTo(c.x - r * 0.30f, c.y + r * 0.04f)
            lineTo(c.x + r * 0.08f, c.y + r * 0.04f)
            lineTo(c.x - r * 0.14f, c.y + r * 0.56f)
          }
          drawPath(bolt, color = Color.White.copy(alpha = 0.90f), style = Stroke(width = 3.0f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        BallType.ICE -> {
          for (i in 0 until 3) {
            val a = i * (PI.toFloat() / 3f)
            val dx = cos(a) * r * 0.58f
            val dy = sin(a) * r * 0.58f
            drawLine(Color.White.copy(alpha = 0.82f), Offset(c.x - dx, c.y - dy), Offset(c.x + dx, c.y + dy), strokeWidth = 2.2f, cap = StrokeCap.Round)
          }
        }
        BallType.ANT -> {
          drawCircle(color = AntGlow.copy(alpha = 0.85f), radius = r * 0.45f, center = c, style = Stroke(width = 2.2f))
          // Stylized ant antennae / mandibles
          drawLine(Color.White.copy(alpha = 0.88f), Offset(c.x - r * 0.2f, c.y - r * 0.45f), Offset(c.x - r * 0.52f, c.y - r * 0.78f), strokeWidth = 2.4f, cap = StrokeCap.Round)
          drawLine(Color.White.copy(alpha = 0.88f), Offset(c.x + r * 0.2f, c.y - r * 0.45f), Offset(c.x + r * 0.52f, c.y - r * 0.78f), strokeWidth = 2.4f, cap = StrokeCap.Round)
        }
      }
    }
  }
}

@Composable
fun DailyLoginRewardDialog(
  strings: GameStrings,
  language: AppLanguage,
  progress: UserProgress,
  nowMillis: Long,
  onClaimDaily: suspend () -> DailyRewardTier?,
  onDismiss: () -> Unit,
) {
  val scope = rememberCoroutineScope()
  val isClaimable = progress.isDailyClaimable(nowMillis)
  var claiming by remember { mutableStateOf(false) }
  var justClaimedTier by remember { mutableStateOf<DailyRewardTier?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ObsidianSurface,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = GoldAccent)
        Text(
          text = strings.dailyRewardTitle,
          style = MaterialTheme.typography.titleLarge,
          color = GoldAccent,
          maxLines = 1,
          softWrap = false,
          overflow = TextOverflow.Ellipsis,
        )
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(strings.dailyRewardSubtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(
          text = "${strings.dailyRewardStreakLabel}: ${progress.dailyStreak}/7",
          style = MaterialTheme.typography.labelLarge,
          color = WaterPrimary,
        )

        val currentIndex = (progress.dailyStreak % 7).coerceIn(0, 6)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          DailyRewardTier.weekSchedule.chunked(4).forEach { rowTiers ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              rowTiers.forEach { tier ->
                val dayZeroIdx = tier.day - 1
                val isCompleted = dayZeroIdx < (progress.dailyStreak % 7) || (!isClaimable && progress.dailyStreak >= 7 && dayZeroIdx < 7)
                val isNext = isClaimable && dayZeroIdx == currentIndex
                val cardColor =
                  when {
                    isNext -> GoldAccent.copy(alpha = 0.22f)
                    isCompleted -> EmeraldSuccess.copy(alpha = 0.14f)
                    else -> ObsidianSurfaceElevated
                  }
                val borderColor =
                  when {
                    isNext -> GoldAccent
                    isCompleted -> EmeraldSuccess.copy(alpha = 0.5f)
                    else -> ObsidianBorder
                  }
                Surface(
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(12.dp),
                  color = cardColor,
                  border = BorderStroke(if (isNext) 1.6.dp else 1.dp, borderColor),
                ) {
                  Column(
                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                  ) {
                    Text(
                      text = if (language == AppLanguage.VI) tier.labelVi else tier.labelEn,
                      style = MaterialTheme.typography.labelSmall,
                      color = if (isNext) GoldAccent else TextSecondary,
                      maxLines = 1,
                      softWrap = false,
                    )
                    Text(
                      text = "+${tier.coins}",
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                      color = if (isCompleted) EmeraldSuccess else TextPrimary,
                      maxLines = 1,
                      softWrap = false,
                    )
                    if (isCompleted) {
                      Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                    }
                  }
                }
              }
              if (rowTiers.size < 4) {
                repeat(4 - rowTiers.size) { Spacer(modifier = Modifier.weight(1f)) }
              }
            }
          }
        }

        justClaimedTier?.let { tier ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = EmeraldSuccess.copy(alpha = 0.16f),
            border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.55f)),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = "+${tier.coins} ${strings.coinsLabel}!",
              style = MaterialTheme.typography.labelLarge,
              color = EmeraldSuccess,
              textAlign = TextAlign.Center,
              modifier = Modifier.padding(vertical = 8.dp),
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (!claiming && isClaimable) {
            claiming = true
            scope.launch {
              justClaimedTier = onClaimDaily()
              claiming = false
            }
          }
        },
        enabled = isClaimable && !claiming,
        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black),
        modifier = Modifier.height(48.dp).testTag("claim_daily_reward_button"),
      ) {
        if (claiming) {
          CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
        } else {
          Text(
            text = if (isClaimable) strings.dailyRewardClaimButton else strings.dailyRewardClaimedToday,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
          )
        }
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.height(48.dp).testTag("close_daily_reward_button"),
      ) {
        Text(strings.closeButton, color = TextSecondary)
      }
    },
  )
}

@Composable
fun GachaRevealDialog(
  result: GachaSpinResult.Success,
  strings: GameStrings,
  onDismiss: () -> Unit,
) {
  val accent = ballAccentColor(result.pulledBall)
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ObsidianSurface,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = GoldAccent)
        Text(
          text = if (result.triggeredPity) strings.gachaPityTriggered else strings.gachaTitle,
          style = MaterialTheme.typography.titleLarge,
          color = GoldAccent,
        )
      }
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        AnimatedElementBallBadge(type = result.pulledBall, size = 88.dp)
        RarityBadge(rarity = result.pulledBall.rarity, strings = strings)
        Text(
          text = strings.ballName(result.pulledBall),
          style = MaterialTheme.typography.headlineMedium,
          color = accent,
          textAlign = TextAlign.Center,
        )
        Text(
          text = strings.ballTagline(result.pulledBall),
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
          textAlign = TextAlign.Center,
        )
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = (if (result.isNewUnlock) EmeraldSuccess else GoldAccent).copy(alpha = 0.14f),
          border = BorderStroke(1.dp, (if (result.isNewUnlock) EmeraldSuccess else GoldAccent).copy(alpha = 0.5f)),
        ) {
          Text(
            text =
              if (result.isNewUnlock) strings.gachaResultNew
              else "${strings.gachaResultDup} +${result.duplicateRefundCoins} ${strings.coinsLabel}",
            style = MaterialTheme.typography.labelLarge,
            color = if (result.isNewUnlock) EmeraldSuccess else GoldAccent,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black),
        modifier = Modifier.height(48.dp).testTag("gacha_result_ok_button"),
      ) {
        Text(strings.closeButton, style = MaterialTheme.typography.labelLarge)
      }
    },
  )
}

@Composable
fun CodeRedeemDialog(
  strings: GameStrings,
  onDismiss: () -> Unit,
  onRedeem: suspend (String) -> CodeRedeemResult,
  onResultReady: (CodeRedeemResult) -> Unit,
) {
  var codeText by remember { mutableStateOf("") }
  var feedback by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
  var pendingSubmit by remember { mutableStateOf(false) }

  LaunchedEffect(pendingSubmit) {
    if (pendingSubmit) {
      val res = onRedeem(codeText)
      feedback =
        when (res) {
          CodeRedeemResult.SUCCESS_SENT_TO_MAILBOX -> strings.codeSentToMailboxMsg to true
          CodeRedeemResult.SUCCESS_TRIAL_ACTIVATED -> strings.codeSuccessMsg to true
          CodeRedeemResult.ALREADY_REDEEMED -> strings.codeAlreadyRedeemedMsg to false
          CodeRedeemResult.ALREADY_ACTIVE -> strings.codeAlreadyActiveMsg to true
          CodeRedeemResult.EXPIRED_OR_INVALID -> strings.codeExpiredOrInvalidMsg to false
          CodeRedeemResult.INVALID -> strings.codeInvalidMsg to false
        }
      onResultReady(res)
      pendingSubmit = false
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ObsidianSurface,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.CardGiftcard, contentDescription = strings.codeDialogTitle, tint = GoldAccent)
        Text(text = strings.codeDialogTitle, style = MaterialTheme.typography.titleLarge, color = TextPrimary)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = strings.codeDialogDesc, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        OutlinedTextField(
          value = codeText,
          onValueChange = { codeText = it },
          singleLine = true,
          placeholder = { Text(strings.codePlaceholder, color = TextSecondary) },
          modifier = Modifier.fillMaxWidth().testTag("code_input"),
        )
        feedback?.let { (msg, ok) ->
          Text(
            text = msg,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (ok) EmeraldSuccess else MaterialTheme.colorScheme.error,
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { pendingSubmit = true },
        enabled = !pendingSubmit,
        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black),
        modifier = Modifier.height(48.dp).testTag("redeem_code_button"),
      ) {
        Text(strings.redeemButton, style = MaterialTheme.typography.labelLarge)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss, modifier = Modifier.height(48.dp).testTag("close_code_dialog_button")) {
        Text(strings.closeButton, color = TextSecondary)
      }
    },
  )
}

@Composable
fun GlassArenaCard(
  modifier: Modifier = Modifier,
  borderColor: Color = ObsidianBorder,
  content: @Composable () -> Unit,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(18.dp),
    color = ObsidianGlass,
    border = BorderStroke(1.dp, borderColor),
    tonalElevation = 4.dp,
  ) {
    content()
  }
}

@Composable
fun ExportApkDialog(
  strings: GameStrings,
  onDismiss: () -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val apkInfo = remember(context) { ApkExporter.inspectInstalledApk(context) }
  var isExporting by remember { mutableStateOf(false) }
  var statusMessage by remember { mutableStateOf<Pair<String, Boolean>?>(null) }

  val saveDocumentLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.CreateDocument(ApkExporter.APK_MIME_TYPE)
    ) { uri ->
      if (uri != null) {
        isExporting = true
        statusMessage = null
        scope.launch {
          val result = ApkExporter.exportApkToUri(context, uri)
          isExporting = false
          statusMessage =
            if (result.isSuccess) strings.exportApkSuccess to true
            else (result.exceptionOrNull()?.localizedMessage ?: strings.exportApkError) to false
        }
      }
    }

  AlertDialog(
    onDismissRequest = { if (!isExporting) onDismiss() },
    containerColor = ObsidianSurface,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.Android, contentDescription = strings.exportApkDialogTitle, tint = EmeraldSuccess)
        Text(text = strings.exportApkDialogTitle, style = MaterialTheme.typography.titleLarge, color = TextPrimary)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = strings.exportApkDialogDesc, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = ObsidianSurfaceElevated,
          border = BorderStroke(1.dp, ObsidianBorder),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = apkInfo?.fileName ?: ApkExporter.defaultFileName(), style = MaterialTheme.typography.labelLarge, color = WaterPrimary)
            Text(text = apkInfo?.sizeMbFormatted ?: "--", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
          }
        }
        if (isExporting) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = EmeraldSuccess, strokeWidth = 2.dp)
            Text(text = strings.exportApkWorking, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
          }
        }
        statusMessage?.let { (msg, ok) ->
          Text(
            text = msg,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (ok) EmeraldSuccess else MaterialTheme.colorScheme.error,
          )
        }
        Button(
          onClick = { saveDocumentLauncher.launch(ApkExporter.defaultFileName()) },
          enabled = !isExporting && apkInfo != null,
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("export_apk_save_button"),
        ) {
          Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(strings.exportApkSaveDevice, style = MaterialTheme.typography.labelLarge)
        }
        OutlinedButton(
          onClick = {
            isExporting = true
            statusMessage = null
            scope.launch {
              val res = ApkExporter.prepareShareIntent(context, strings.exportApkShare)
              isExporting = false
              res
                .onSuccess { chooserIntent -> context.startActivity(chooserIntent) }
                .onFailure { err -> statusMessage = (err.localizedMessage ?: strings.exportApkError) to false }
            }
          },
          enabled = !isExporting && apkInfo != null,
          border = BorderStroke(1.dp, WaterPrimary.copy(alpha = 0.65f)),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("export_apk_share_button"),
        ) {
          Icon(Icons.Default.Share, contentDescription = null, tint = WaterPrimary, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(strings.exportApkShare, style = MaterialTheme.typography.labelLarge, color = WaterPrimary)
        }
      }
    },
    confirmButton = {},
    dismissButton = {
      TextButton(onClick = onDismiss, enabled = !isExporting, modifier = Modifier.height(48.dp).testTag("close_export_apk_dialog_button")) {
        Text(strings.closeButton, color = TextSecondary)
      }
    },
  )
}

@Composable
fun AppUpdatePromptDialog(
  strings: GameStrings,
  currentVersionName: String,
  currentVersionCode: Int,
  latestVersionName: String,
  latestVersionCode: Int,
  releaseNotes: String,
  downloadUrl: String,
  isMandatory: Boolean,
  updateState: ApkUpdateState = ApkUpdateState.Idle,
  onStartUpdate: () -> Unit = {},
  onOpenInstallPermission: () -> Unit = {},
  onInstallReadyApk: (String) -> Unit = {},
  onDismiss: () -> Unit,
) {
  val context = LocalContext.current
  var linkError by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = { if (!isMandatory && updateState !is ApkUpdateState.Downloading) onDismiss() },
    containerColor = ObsidianSurface,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(Icons.Default.SystemUpdate, contentDescription = strings.updateDialogTitle, tint = GoldAccent)
        Text(
          text = strings.updateDialogTitle,
          style = MaterialTheme.typography.titleLarge,
          color = GoldAccent,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Surface(
            shape = RoundedCornerShape(999.dp),
            color = WaterPrimary.copy(alpha = 0.16f),
            border = BorderStroke(1.dp, WaterPrimary.copy(alpha = 0.55f)),
          ) {
            Text(
              text = "v$currentVersionName (#$currentVersionCode) -> v${latestVersionName.ifBlank { latestVersionCode.toString() }} (#$latestVersionCode)",
              style = MaterialTheme.typography.labelMedium,
              color = WaterPrimary,
              maxLines = 1,
              softWrap = false,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            )
          }

          Surface(
            shape = RoundedCornerShape(999.dp),
            color = (if (isMandatory) FirePrimary else EmeraldSuccess).copy(alpha = 0.16f),
            border = BorderStroke(1.dp, (if (isMandatory) FirePrimary else EmeraldSuccess).copy(alpha = 0.55f)),
          ) {
            Text(
              text = if (isMandatory) strings.updateMandatoryBadge else strings.updateOptionalBadge,
              style = MaterialTheme.typography.labelSmall,
              color = if (isMandatory) FirePrimary else EmeraldSuccess,
              maxLines = 1,
              softWrap = false,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
          }
        }

        if (releaseNotes.isNotBlank()) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = ObsidianSurfaceElevated,
            border = BorderStroke(1.dp, ObsidianBorder),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                text = strings.updateNotesLabel,
                style = MaterialTheme.typography.labelLarge,
                color = TextPrimary,
              )
              Text(
                text = releaseNotes,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
              )
            }
          }
        }

        when (updateState) {
          ApkUpdateState.Idle -> {
            Text(
              text = strings.updatePermissionHint,
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
            )
          }
          is ApkUpdateState.Downloading -> {
            val mbDown = updateState.downloadedBytes / (1024f * 1024f)
            val mbTotal = updateState.totalBytes / (1024f * 1024f)
            val sizeInfo =
              if (updateState.totalBytes > 0L)
                String.format(Locale.US, " (%.1f / %.1f MB)", mbDown, mbTotal)
              else String.format(Locale.US, " (%.1f MB)", mbDown)
            Text(
              text = "${strings.updateDownloadingLabel} ${updateState.progressPct}%$sizeInfo",
              style = MaterialTheme.typography.labelLarge,
              color = WaterPrimary,
            )
            LinearProgressIndicator(
              progress = { (updateState.progressPct / 100f).coerceIn(0f, 1f) },
              modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(999.dp)),
              color = EmeraldSuccess,
              trackColor = ObsidianSurfaceElevated,
            )
          }
          is ApkUpdateState.OpeningWeb -> {
            Text(
              text = strings.updateOpeningBrowserMsg,
              style = MaterialTheme.typography.bodyMedium,
              color = WaterPrimary,
            )
          }
          is ApkUpdateState.NeedsInstallPermission -> {
            Text(
              text = strings.updateInstallPermissionNeeded,
              style = MaterialTheme.typography.bodyMedium,
              color = GoldAccent,
            )
            OutlinedButton(
              onClick = onOpenInstallPermission,
              border = BorderStroke(1.dp, GoldAccent),
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("app_update_permission_button"),
            ) {
              Text(strings.updateOpenSettingsButton, color = GoldAccent, fontWeight = FontWeight.Bold)
            }
          }
          is ApkUpdateState.ReadyToInstall -> {
            Text(
              text = strings.updateReadyInstallButton,
              style = MaterialTheme.typography.labelLarge,
              color = EmeraldSuccess,
            )
          }
          is ApkUpdateState.Failed -> {
            Text(
              text = updateState.message,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.error,
            )
          }
        }

        linkError?.let { err ->
          Text(
            text = err,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
          )
        }
      }
    },
    confirmButton = {
      when (updateState) {
        is ApkUpdateState.Downloading -> {
          Button(
            onClick = {},
            enabled = false,
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
            modifier = Modifier.height(48.dp),
          ) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(6.dp))
            Text("${updateState.progressPct}%", style = MaterialTheme.typography.labelLarge)
          }
        }
        is ApkUpdateState.NeedsInstallPermission -> {
          Button(
            onClick = { onInstallReadyApk(updateState.apkPath) },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
            modifier = Modifier.height(48.dp).testTag("app_update_install_apk_button"),
          ) {
            Text(strings.updateReadyInstallButton, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
          }
        }
        is ApkUpdateState.ReadyToInstall -> {
          Button(
            onClick = { onInstallReadyApk(updateState.apkPath) },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
            modifier = Modifier.height(48.dp).testTag("app_update_install_apk_button"),
          ) {
            Text(strings.updateReadyInstallButton, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
          }
        }
        else -> {
          Button(
            onClick = {
              val trimmed = downloadUrl.trim()
              if (!trimmed.startsWith("https://", ignoreCase = true)) {
                linkError = strings.updateLinkError
              } else {
                linkError = null
                onStartUpdate()
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.Black),
            modifier = Modifier.height(48.dp).testTag("app_update_now_button"),
          ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (updateState is ApkUpdateState.Failed) strings.updateRetryButton else strings.updateNowButton,
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              softWrap = false,
            )
          }
        }
      }
    },
    dismissButton = {
      if (!isMandatory && updateState !is ApkUpdateState.Downloading) {
        TextButton(
          onClick = onDismiss,
          modifier = Modifier.height(48.dp).testTag("app_update_later_button"),
        ) {
          Text(strings.updateLaterButton, color = TextSecondary, maxLines = 1, softWrap = false)
        }
      }
    },
  )
}
