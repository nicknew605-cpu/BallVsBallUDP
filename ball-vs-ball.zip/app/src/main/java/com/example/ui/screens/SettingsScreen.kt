package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.AiDifficulty
import com.example.model.AppLanguage
import com.example.model.GameSettings
import com.example.model.GraphicsQuality
import com.example.ui.components.GlassArenaCard
import com.example.ui.components.NeonPillBadge
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterPrimary
import java.util.Locale
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
  strings: GameStrings,
  settings: GameSettings,
  currentNickname: String,
  isGuestMode: Boolean,
  currentVersionName: String,
  currentVersionCode: Int,
  latestCloudVersionName: String,
  latestCloudVersionCode: Int,
  onCheckUpdates: suspend () -> Boolean,
  onSaveNickname: (String) -> Unit,
  onLinkGoogle: () -> Unit,
  onSignOut: () -> Unit,
  onUpdateSettings: ((GameSettings) -> GameSettings) -> Unit,
  onResetProgress: () -> Unit,
  onBack: () -> Unit,
) {
  var showResetDialog by remember { mutableStateOf(false) }
  var nicknameDraft by remember(currentNickname) { mutableStateOf(currentNickname) }
  var checkingUpdates by remember { mutableStateOf(false) }
  var updateCheckStatus by remember { mutableStateOf<String?>(null) }
  val scope = rememberCoroutineScope()

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Color(0xFF0A101E), ObsidianBg)))
  ) {
    Column(
      modifier =
        Modifier.fillMaxSize()
          .windowInsetsPadding(WindowInsets.safeDrawing)
          .padding(horizontal = 16.dp, vertical = 12.dp)
          .widthIn(max = 640.dp)
          .align(Alignment.Center)
          .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("settings_back_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = strings.back,
            tint = TextPrimary,
          )
        }
        Text(
          text = strings.settingsTitle,
          style = MaterialTheme.typography.titleLarge,
          color = TextPrimary,
        )
      }

      // Account & Nickname Section
      SettingsSectionCard(title = strings.sectionAccount) {
        if (isGuestMode) {
          NeonPillBadge(text = strings.guestModeBadge, color = GoldAccent)
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          OutlinedTextField(
            value = nicknameDraft,
            onValueChange = { if (it.length <= 24) nicknameDraft = it },
            singleLine = true,
            label = { Text(strings.authNicknameLabel) },
            modifier = Modifier.weight(1f).testTag("settings_nickname_input"),
          )
          Button(
            onClick = { onSaveNickname(nicknameDraft) },
            colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black),
            modifier = Modifier.height(52.dp).testTag("settings_save_nickname_button"),
          ) {
            Text(strings.authSaveNicknameButton)
          }
        }

        if (isGuestMode) {
          Button(
            onClick = onLinkGoogle,
            colors = ButtonDefaults.buttonColors(containerColor = FirePrimary, contentColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("settings_link_google_button"),
          ) {
            Icon(Icons.AutoMirrored.Filled.Login, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(strings.linkGoogleButton, maxLines = 1, softWrap = false)
          }
        }

        OutlinedButton(
          onClick = onSignOut,
          border = BorderStroke(1.dp, WaterPrimary.copy(alpha = 0.6f)),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("settings_sign_out_button"),
        ) {
          Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = WaterPrimary)
          Spacer(modifier = Modifier.widthIn(min = 8.dp))
          Text(strings.signOutButton, color = WaterPrimary)
        }
      }

      // Language Section
      SettingsSectionCard(title = strings.sectionLanguage) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          ChoicePill(
            label = strings.languageVi,
            selected = settings.language == AppLanguage.VI,
            testTag = "lang_vi_button",
            modifier = Modifier.weight(1f),
            onClick = { onUpdateSettings { it.copy(language = AppLanguage.VI) } },
          )
          ChoicePill(
            label = strings.languageEn,
            selected = settings.language == AppLanguage.EN,
            testTag = "lang_en_button",
            modifier = Modifier.weight(1f),
            onClick = { onUpdateSettings { it.copy(language = AppLanguage.EN) } },
          )
        }
      }

      // Physics & AI Section
      SettingsSectionCard(title = strings.sectionCombat) {
        Text(strings.aiDifficultyLabel, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          AiDifficulty.entries.forEach { diff ->
            ChoicePill(
              label = strings.difficultyName(diff),
              selected = settings.aiDifficulty == diff,
              testTag = "diff_${diff.id}_button",
              modifier = Modifier.weight(1f),
              onClick = { onUpdateSettings { it.copy(aiDifficulty = diff) } },
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(strings.targetFpsLabel, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          listOf(60, 120).forEach { fps ->
            ChoicePill(
              label = "$fps FPS",
              selected = settings.targetFps == fps,
              testTag = "fps_${fps}_button",
              modifier = Modifier.weight(1f),
              onClick = { onUpdateSettings { it.copy(targetFps = fps) } },
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(strings.gameSpeedLabel, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
          Text(
            text = String.format(Locale.US, "%.2fx", settings.speedMultiplier),
            style = MaterialTheme.typography.labelLarge,
            color = WaterPrimary,
          )
        }
        Slider(
          value = settings.speedMultiplier,
          onValueChange = { v -> onUpdateSettings { it.copy(speedMultiplier = v) } },
          valueRange = 0.8f..1.3f,
          colors = SliderDefaults.colors(thumbColor = WaterPrimary, activeTrackColor = WaterPrimary),
        )
      }

      // Graphics & 4-Tier Quality + Auto Lag-Guard Section
      SettingsSectionCard(title = strings.sectionVisuals) {
        Text(strings.graphicsQualityLabel, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          GraphicsQuality.entries.forEach { tier ->
            ChoicePill(
              label = strings.qualityName(tier),
              selected = settings.graphicsQuality == tier,
              testTag = "quality_${tier.id}_button",
              modifier = Modifier.weight(1f),
              onClick = { onUpdateSettings { it.copy(graphicsQuality = tier) } },
            )
          }
        }

        SettingToggleRow(
          label = strings.autoReduceLagLabel,
          checked = settings.autoReduceLag,
          testTag = "toggle_auto_lag",
          onCheckedChange = { v -> onUpdateSettings { it.copy(autoReduceLag = v) } },
        )
        SettingToggleRow(
          label = strings.bloomShaderLabel,
          checked = settings.bloomAndShadersEnabled,
          testTag = "toggle_bloom",
          onCheckedChange = { v -> onUpdateSettings { it.copy(bloomAndShadersEnabled = v) } },
        )
        SettingToggleRow(
          label = strings.trailsLabel,
          checked = settings.trailsEnabled,
          testTag = "toggle_trails",
          onCheckedChange = { v -> onUpdateSettings { it.copy(trailsEnabled = v) } },
        )
        SettingToggleRow(
          label = strings.shakeLabel,
          checked = settings.screenShakeEnabled,
          testTag = "toggle_shake",
          onCheckedChange = { v -> onUpdateSettings { it.copy(screenShakeEnabled = v) } },
        )
        SettingToggleRow(
          label = strings.hitStopLabel,
          checked = settings.hitStopEnabled,
          testTag = "toggle_hitstop",
          onCheckedChange = { v -> onUpdateSettings { it.copy(hitStopEnabled = v) } },
        )
        SettingToggleRow(
          label = strings.floatingDamageLabel,
          checked = settings.floatingDamageEnabled,
          testTag = "toggle_floating_dmg",
          onCheckedChange = { v -> onUpdateSettings { it.copy(floatingDamageEnabled = v) } },
        )
        SettingToggleRow(
          label = strings.showFpsLabel,
          checked = settings.showFpsCounter,
          testTag = "toggle_show_fps",
          onCheckedChange = { v -> onUpdateSettings { it.copy(showFpsCounter = v) } },
        )
      }

      // Audio Section
      SettingsSectionCard(title = strings.sectionAudio) {
        SettingToggleRow(
          label = strings.sfxLabel,
          checked = settings.sfxEnabled,
          testTag = "toggle_sfx",
          onCheckedChange = { v -> onUpdateSettings { it.copy(sfxEnabled = v) } },
        )
        Text(
          text = "${strings.sfxVolumeLabel}: ${(settings.sfxVolume * 100).toInt()}%",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
        )
        Slider(
          value = settings.sfxVolume,
          enabled = settings.sfxEnabled,
          onValueChange = { v -> onUpdateSettings { it.copy(sfxVolume = v) } },
          colors = SliderDefaults.colors(thumbColor = FirePrimary, activeTrackColor = FirePrimary),
        )

        SettingToggleRow(
          label = strings.musicLabel,
          checked = settings.musicEnabled,
          testTag = "toggle_music",
          onCheckedChange = { v -> onUpdateSettings { it.copy(musicEnabled = v) } },
        )
        Text(
          text = "${strings.musicVolumeLabel}: ${(settings.musicVolume * 100).toInt()}%",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
        )
        Slider(
          value = settings.musicVolume,
          enabled = settings.musicEnabled,
          onValueChange = { v -> onUpdateSettings { it.copy(musicVolume = v) } },
          colors = SliderDefaults.colors(thumbColor = WaterPrimary, activeTrackColor = WaterPrimary),
        )
      }

      // App Version & Updates Section
      SettingsSectionCard(title = strings.sectionAppUpdate) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(strings.currentVersionLabel, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
          Text(
            text = "v$currentVersionName (#$currentVersionCode)",
            style = MaterialTheme.typography.labelLarge,
            color = TextPrimary,
          )
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(strings.latestCloudVersionLabel, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
          Text(
            text = "v${latestCloudVersionName.ifBlank { latestCloudVersionCode.toString() }} (#$latestCloudVersionCode)",
            style = MaterialTheme.typography.labelLarge,
            color = WaterPrimary,
          )
        }
        updateCheckStatus?.let { msg ->
          Text(
            text = msg,
            style = MaterialTheme.typography.bodyMedium,
            color = EmeraldSuccess,
          )
        }
        Button(
          onClick = {
            if (!checkingUpdates) {
              checkingUpdates = true
              updateCheckStatus = null
              scope.launch {
                val hasUpdate = onCheckUpdates()
                checkingUpdates = false
                if (!hasUpdate) {
                  updateCheckStatus = strings.upToDateMsg
                }
              }
            }
          },
          enabled = !checkingUpdates,
          colors = ButtonDefaults.buttonColors(containerColor = WaterPrimary, contentColor = Color.Black),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("settings_check_update_button"),
        ) {
          if (checkingUpdates) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
          } else {
            Icon(Icons.Default.SystemUpdate, contentDescription = null, modifier = Modifier.size(18.dp))
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(strings.checkUpdateButton, style = MaterialTheme.typography.labelLarge, maxLines = 1, softWrap = false)
        }
      }

      // Reset Progress
      OutlinedButton(
        onClick = { showResetDialog = true },
        border = BorderStroke(1.dp, CrimsonDanger.copy(alpha = 0.7f)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("reset_progress_button"),
      ) {
        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = CrimsonDanger)
        Spacer(modifier = Modifier.widthIn(min = 8.dp))
        Text(strings.resetProgressButton, color = CrimsonDanger)
      }

      Spacer(modifier = Modifier.height(12.dp))
    }
  }

  if (showResetDialog) {
    AlertDialog(
      onDismissRequest = { showResetDialog = false },
      containerColor = ObsidianSurface,
      title = { Text(strings.resetConfirmTitle, color = TextPrimary) },
      text = { Text(strings.resetConfirmDesc, color = TextSecondary) },
      confirmButton = {
        Button(
          onClick = {
            onResetProgress()
            showResetDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = CrimsonDanger),
        ) {
          Text(strings.confirmYes, color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetDialog = false }) {
          Text(strings.cancel, color = TextSecondary)
        }
      },
    )
  }
}

@Composable
private fun SettingsSectionCard(
  title: String,
  content: @Composable () -> Unit,
) {
  GlassArenaCard {
    Column(
      modifier = Modifier.fillMaxWidth().padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Text(text = title, style = MaterialTheme.typography.titleMedium, color = WaterPrimary)
      content()
    }
  }
}

@Composable
private fun ChoicePill(
  label: String,
  selected: Boolean,
  testTag: String,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    modifier = modifier.height(48.dp).testTag(testTag),
    shape = RoundedCornerShape(12.dp),
    color = if (selected) WaterPrimary.copy(alpha = 0.2f) else ObsidianBg,
    border = BorderStroke(1.5.dp, if (selected) WaterPrimary else ObsidianBorder),
  ) {
    Box(contentAlignment = Alignment.Center) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelLarge,
        color = if (selected) WaterPrimary else TextSecondary,
        maxLines = 1,
      )
    }
  }
}

@Composable
private fun SettingToggleRow(
  label: String,
  checked: Boolean,
  testTag: String,
  onCheckedChange: (Boolean) -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyLarge,
      color = TextPrimary,
      modifier = Modifier.weight(1f),
    )
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      modifier = Modifier.testTag(testTag),
    )
  }
}
