package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.ApkPackageInfo
import com.example.model.BallType
import com.example.model.GitHubUploadState
import com.example.model.OtaBalanceConfig
import com.example.model.OtaGiftCodeEntry
import com.example.model.OtaLiveConfig
import com.example.model.PlayerDirectoryEntry
import com.example.ui.components.GlassArenaCard
import com.example.ui.components.ballAccentColor
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThunderPrimary
import com.example.ui.theme.WaterPrimary
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

@Composable
fun AdminOtaScreen(
  strings: GameStrings,
  initialConfig: OtaLiveConfig,
  nowMillis: Long,
  uploadState: GitHubUploadState = GitHubUploadState.Idle,
  onPublishOtaConfig: suspend (OtaLiveConfig) -> Result<OtaLiveConfig>,
  onUploadAndPublishApk: suspend (
    repo: String,
    token: String,
    apkInfo: ApkPackageInfo,
    updatedConfig: OtaLiveConfig,
  ) -> Result<OtaLiveConfig> = { _, _, _, cfg -> Result.success(cfg) },
  onSearchPlayers: suspend (String) -> List<PlayerDirectoryEntry> = { emptyList() },
  onSendTargetedGift: suspend (
    targetUid: String,
    coins: Int,
    ball: BallType?,
    trialMinutes: Int,
    message: String,
  ) -> Result<Unit> = { _, _, _, _, _ -> Result.success(Unit) },
  onBack: () -> Unit,
) {
  var draft by remember(initialConfig) { mutableStateOf(initialConfig) }
  var newCodeText by remember { mutableStateOf("") }
  var newCoinsText by remember { mutableStateOf("1000") }
  var selectedBallId by remember { mutableStateOf("") }
  var isTrialCode by remember { mutableStateOf(false) }
  var trialDurationText by remember { mutableStateOf("60") }
  var trialUnitHours by remember { mutableStateOf(false) }
  var expiryChoiceIndex by remember { mutableIntStateOf(2) } // 0=24h, 1=3d, 2=7d, 3=Perm
  var selectedEditBall by remember { mutableStateOf(BallType.FIRE) }
  var publishing by remember { mutableStateOf(false) }

  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  Scaffold(
    containerColor = ObsidianBg,
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets.safeDrawing,
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(Brush.verticalGradient(listOf(Color(0xFF0A101E), ObsidianBg)))
          .padding(innerPadding)
    ) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .widthIn(max = 640.dp)
            .align(Alignment.Center)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(
            onClick = onBack,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("admin_back_button"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back, tint = TextPrimary)
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = strings.adminTitle,
              style = MaterialTheme.typography.titleLarge,
              color = GoldAccent,
              maxLines = 1,
              softWrap = false,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = strings.adminSubtitle,
              style = MaterialTheme.typography.labelSmall,
              color = TextSecondary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }

        // 1. Timed Global Bulletin Section
        GlassArenaCard(borderColor = WaterPrimary.copy(alpha = 0.45f)) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text(strings.adminNoticeSection, style = MaterialTheme.typography.titleMedium, color = WaterPrimary)
            OutlinedTextField(
              value = draft.adminNoticeVi,
              onValueChange = { draft = draft.copy(adminNoticeVi = it.take(300)) },
              label = { Text(strings.adminNoticeViLabel) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("admin_notice_vi_input"),
            )
            OutlinedTextField(
              value = draft.adminNoticeEn,
              onValueChange = { draft = draft.copy(adminNoticeEn = it.take(300)) },
              label = { Text(strings.adminNoticeEnLabel) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("admin_notice_en_input"),
            )
            Text(strings.adminNoticeDurationLabel, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            val durationPresets = listOf(
              strings.adminNotice1h to 3_600_000L,
              strings.adminNotice6h to 6L * 3_600_000L,
              strings.adminNotice24h to 24L * 3_600_000L,
              strings.adminNotice3d to 3L * 86_400_000L,
              strings.adminNotice7d to 7L * 86_400_000L,
              strings.adminNoticePerm to 0L,
            )
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              durationPresets.forEach { (label, offsetMs) ->
                FilterChip(
                  selected =
                    (offsetMs == 0L && draft.adminNoticeExpiresAtMillis == 0L) ||
                      (offsetMs > 0L && draft.adminNoticeExpiresAtMillis > nowMillis &&
                        kotlin.math.abs((draft.adminNoticeExpiresAtMillis - nowMillis) - offsetMs) < 900_000L),
                  onClick = {
                    val nextExpiry = if (offsetMs == 0L) 0L else System.currentTimeMillis() + offsetMs
                    draft = draft.copy(adminNoticeExpiresAtMillis = nextExpiry)
                  },
                  label = { Text(label, maxLines = 1, softWrap = false) },
                  colors = FilterChipDefaults.filterChipColors(selectedContainerColor = WaterPrimary.copy(alpha = 0.25f)),
                )
              }
              FilterChip(
                selected = false,
                onClick = {
                  draft = draft.copy(adminNoticeVi = "", adminNoticeEn = "", adminNoticeExpiresAtMillis = 0L)
                },
                label = { Text(strings.adminNoticeClear, color = CrimsonDanger, maxLines = 1, softWrap = false) },
              )
            }
            if (draft.adminNoticeExpiresAtMillis > nowMillis) {
              val remH = (draft.adminNoticeExpiresAtMillis - nowMillis) / 3_600_000L
              val remM = ((draft.adminNoticeExpiresAtMillis - nowMillis) % 3_600_000L) / 60_000L
              Text(
                text = "${strings.adminNoticeExpiresPrefix}: ${remH}h ${remM}m",
                style = MaterialTheme.typography.labelSmall,
                color = GoldAccent,
              )
            }
          }
        }

        // 2. Per-Ball HP & Damage Tuning (Works for BOTH Offline & Online)
        GlassArenaCard(borderColor = FirePrimary.copy(alpha = 0.50f)) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = strings.adminPerBallSection,
                style = MaterialTheme.typography.titleMedium,
                color = FirePrimary,
                modifier = Modifier.weight(1f),
              )
              TextButton(
                onClick = {
                  draft =
                    draft.copy(
                      balance = draft.balance.copy(ballOverrides = OtaBalanceConfig.defaultBallOverrides())
                    )
                },
              ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp), tint = WaterPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Text(strings.adminResetBallStatsButton, style = MaterialTheme.typography.labelSmall, color = WaterPrimary)
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              BallType.entries.forEach { ball ->
                val bAccent = ballAccentColor(ball)
                FilterChip(
                  selected = selectedEditBall == ball,
                  onClick = { selectedEditBall = ball },
                  label = { Text(strings.ballName(ball), maxLines = 1, softWrap = false) },
                  colors = FilterChipDefaults.filterChipColors(selectedContainerColor = bAccent.copy(alpha = 0.28f)),
                )
              }
            }

            val currentOverride = draft.balance.overrideFor(selectedEditBall)
            val editAccent = ballAccentColor(selectedEditBall)
            OtaSliderRow(
              label = "${strings.ballName(selectedEditBall)} — ${strings.adminPerBallHpLabel}",
              valueText = "${currentOverride.hp} HP",
              value = currentOverride.hp.toFloat(),
              range = 60f..400f,
              color = EmeraldSuccess,
              onValueChange = { v ->
                val snappedHp = ((v / 5f).roundToInt() * 5).coerceIn(60, 400)
                draft =
                  draft.copy(
                    balance =
                      draft.balance.withBallOverride(
                        selectedEditBall,
                        hp = snappedHp,
                        damageScale = currentOverride.damageScale,
                      )
                  )
              },
            )
            OtaSliderRow(
              label = "${strings.ballName(selectedEditBall)} — ${strings.adminPerBallDmgLabel}",
              valueText = String.format(Locale.US, "%.2fx (%d%%)", currentOverride.damageScale, (currentOverride.damageScale * 100).roundToInt()),
              value = currentOverride.damageScale,
              range = 0.4f..2.5f,
              color = editAccent,
              onValueChange = { v ->
                val snappedScale = ((v * 20f).roundToInt() / 20f).coerceIn(0.4f, 2.5f)
                draft =
                  draft.copy(
                    balance =
                      draft.balance.withBallOverride(
                        selectedEditBall,
                        hp = currentOverride.hp,
                        damageScale = snappedScale,
                      )
                  )
              },
            )
          }
        }

        // 3. Giftcode Manager + Add New Code
        GlassArenaCard(borderColor = GoldAccent.copy(alpha = 0.50f)) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text(strings.adminCodesSection, style = MaterialTheme.typography.titleMedium, color = GoldAccent)

            draft.activeCodes.forEach { entry ->
              val isDisabled = draft.disabledCodes.any { it.equals(entry.code, ignoreCase = true) }
              val isExpired = entry.isExpired(nowMillis)
              val statusLabel =
                when {
                  isDisabled -> strings.adminDisabledLabel
                  isExpired -> strings.adminExpiredLabel
                  else -> strings.adminActiveLabel
                }
              val statusColor =
                when {
                  isDisabled || isExpired -> CrimsonDanger
                  else -> EmeraldSuccess
                }

              Surface(
                shape = RoundedCornerShape(12.dp),
                color = ObsidianSurfaceElevated,
                border = BorderStroke(1.dp, statusColor.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                      Text(entry.code, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text(statusLabel, style = MaterialTheme.typography.labelSmall, color = statusColor)
                    }
                    val rewardSummary = buildList {
                      if (entry.rewardCoins > 0) add("+${entry.rewardCoins} ${strings.coinsLabel}")
                      if (entry.rewardBallId.isNotBlank()) add(strings.ballName(BallType.fromId(entry.rewardBallId)))
                      if (entry.isBallTrialCode()) {
                        add("${strings.ballTrialBadgePrefix} ${strings.ballName(BallType.fromId(entry.trialBallId))} (${entry.trialDurationMinutes}m)")
                      }
                      if (entry.isTrial24h) add("Trial 24h")
                    }.joinToString(" • ")
                    Text(rewardSummary.ifBlank { "-" }, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                  }

                  Row {
                    IconButton(
                      onClick = {
                        val updatedDisabled =
                          if (isDisabled) draft.disabledCodes.filterNot { it.equals(entry.code, ignoreCase = true) }
                          else draft.disabledCodes + entry.code
                        draft = draft.copy(disabledCodes = updatedDisabled)
                      },
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Icon(
                        imageVector = if (isDisabled) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = statusLabel,
                        tint = if (isDisabled) TextSecondary else EmeraldSuccess,
                      )
                    }
                    IconButton(
                      onClick = {
                        val isDefault = OtaLiveConfig.defaultCodes().any { it.code.equals(entry.code, ignoreCase = true) }
                        val nextDisabled =
                          if (isDefault && !draft.disabledCodes.any { it.equals(entry.code, ignoreCase = true) }) {
                            draft.disabledCodes + entry.code
                          } else if (!isDefault) {
                            draft.disabledCodes.filterNot { it.equals(entry.code, ignoreCase = true) }
                          } else {
                            draft.disabledCodes
                          }
                        draft =
                          draft.copy(
                            activeCodes = draft.activeCodes.filterNot { it.code.equals(entry.code, ignoreCase = true) },
                            disabledCodes = nextDisabled,
                          )
                      },
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = CrimsonDanger)
                    }
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(strings.adminAddCodeTitle, style = MaterialTheme.typography.labelLarge, color = WaterPrimary)

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              OutlinedTextField(
                value = newCodeText,
                onValueChange = { newCodeText = it.take(24) },
                label = { Text(strings.adminCodeInputLabel) },
                singleLine = true,
                modifier = Modifier.weight(1.4f).testTag("admin_new_code_input"),
              )
              OutlinedTextField(
                value = newCoinsText,
                onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) newCoinsText = it },
                label = { Text(strings.adminCoinsInputLabel) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("admin_new_coins_input"),
              )
            }

            Text(strings.adminBallSelectLabel, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              FilterChip(
                selected = selectedBallId.isEmpty(),
                onClick = {
                  selectedBallId = ""
                  isTrialCode = false
                },
                label = { Text("-", maxLines = 1, softWrap = false) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = GoldAccent.copy(alpha = 0.25f)),
              )
              BallType.entries.forEach { ball ->
                val accent = ballAccentColor(ball)
                FilterChip(
                  selected = selectedBallId == ball.id,
                  onClick = { selectedBallId = ball.id },
                  label = { Text(strings.ballName(ball), maxLines = 1, softWrap = false) },
                  colors = FilterChipDefaults.filterChipColors(selectedContainerColor = accent.copy(alpha = 0.25f)),
                )
              }
            }

            if (selectedBallId.isNotBlank()) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(strings.adminCodeTrialToggleLabel, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                Switch(
                  checked = isTrialCode,
                  onCheckedChange = { isTrialCode = it },
                  modifier = Modifier.testTag("admin_code_trial_switch"),
                )
              }
              if (isTrialCode) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  OutlinedTextField(
                    value = trialDurationText,
                    onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) trialDurationText = it },
                    label = { Text(strings.adminTrialDurationLabel) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f).testTag("admin_code_trial_duration_input"),
                  )
                  FilterChip(
                    selected = !trialUnitHours,
                    onClick = { trialUnitHours = false },
                    label = { Text(strings.adminTrialUnitMinutes) },
                  )
                  FilterChip(
                    selected = trialUnitHours,
                    onClick = { trialUnitHours = true },
                    label = { Text(strings.adminTrialUnitHours) },
                  )
                }
              }
            }

            Text(strings.adminExpiryLabel, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            val expiryLabels = listOf(strings.adminExpiry24h, strings.adminExpiry3d, strings.adminExpiry7d, strings.adminExpiryPerm)
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              expiryLabels.forEachIndexed { idx, label ->
                FilterChip(
                  selected = expiryChoiceIndex == idx,
                  onClick = { expiryChoiceIndex = idx },
                  label = { Text(label, maxLines = 1, softWrap = false) },
                  colors = FilterChipDefaults.filterChipColors(selectedContainerColor = WaterPrimary.copy(alpha = 0.24f)),
                )
              }
            }

            Button(
              onClick = {
                val cleanCode = newCodeText.trim()
                if (cleanCode.isNotEmpty()) {
                  val now = System.currentTimeMillis()
                  val expiresAt =
                    when (expiryChoiceIndex) {
                      0 -> now + 24L * 3600_000L
                      1 -> now + 3L * 24L * 3600_000L
                      2 -> now + 7L * 24L * 3600_000L
                      else -> 0L
                    }
                  val coinsVal = if (isTrialCode && selectedBallId.isNotBlank()) 0 else (newCoinsText.toIntOrNull() ?: 0).coerceIn(0, 100000)
                  val rawDur = (trialDurationText.toIntOrNull() ?: 60).coerceAtLeast(1)
                  val computedTrialMinutes =
                    if (selectedBallId.isNotBlank() && isTrialCode) {
                      (if (trialUnitHours) rawDur * 60 else rawDur).coerceIn(1, 43200)
                    } else 0
                  val newEntry =
                    OtaGiftCodeEntry(
                      code = cleanCode,
                      rewardCoins = coinsVal,
                      rewardBallId = if (computedTrialMinutes > 0) "" else selectedBallId,
                      titleVi = "Qua Admin OTA ($cleanCode)",
                      titleEn = "Admin OTA Gift ($cleanCode)",
                      bodyVi = "Phan thuong dac biet tu Admin Ball vs Ball!",
                      bodyEn = "Special Admin gift from Ball vs Ball!",
                      trialBallId = if (computedTrialMinutes > 0) selectedBallId else "",
                      trialDurationMinutes = computedTrialMinutes,
                      createdAtMillis = now,
                      expiresAtMillis = expiresAt,
                    )
                  val filtered = draft.activeCodes.filterNot { it.code.equals(cleanCode, ignoreCase = true) }
                  draft = draft.copy(activeCodes = listOf(newEntry) + filtered)
                  newCodeText = ""
                }
              },
              enabled = newCodeText.trim().length >= 3,
              colors = ButtonDefaults.buttonColors(containerColor = WaterPrimary, contentColor = Color.Black),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("admin_add_code_button"),
            ) {
              Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(strings.adminAddCodeButton, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
            }
          }
        }

        // 3B. Targeted Gift Sender (Search Player ID/Nickname -> Coins / Ball / Trial)
        AdminTargetedGiftSection(
          strings = strings,
          onSearchPlayers = onSearchPlayers,
          onSendTargetedGift = onSendTargetedGift,
          onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } },
        )

        // 4. Live 2D VFX Tuner
        GlassArenaCard(borderColor = ThunderPrimary.copy(alpha = 0.45f)) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Text(strings.adminVfxSection, style = MaterialTheme.typography.titleMedium, color = ThunderPrimary)
            OtaSliderRow(
              label = "Particle Multiplier",
              valueText = String.format(Locale.US, "%.2fx", draft.vfx.particleMultiplier),
              value = draft.vfx.particleMultiplier,
              range = 0.6f..2.0f,
              color = ThunderPrimary,
              onValueChange = { v -> draft = draft.copy(vfx = draft.vfx.copy(particleMultiplier = v)) },
            )
            OtaSliderRow(
              label = "Glow Intensity",
              valueText = String.format(Locale.US, "%.2fx", draft.vfx.glowIntensity),
              value = draft.vfx.glowIntensity,
              range = 0.6f..2.0f,
              color = WaterPrimary,
              onValueChange = { v -> draft = draft.copy(vfx = draft.vfx.copy(glowIntensity = v)) },
            )
            OtaSliderRow(
              label = "Effect Scale",
              valueText = String.format(Locale.US, "%.2fx", draft.vfx.effectScale),
              value = draft.vfx.effectScale,
              range = 0.8f..1.5f,
              color = FirePrimary,
              onValueChange = { v -> draft = draft.copy(vfx = draft.vfx.copy(effectScale = v)) },
            )
          }
        }

        // 5. Global Skill Balance Tuner
        GlassArenaCard(borderColor = ThunderPrimary.copy(alpha = 0.35f)) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Text(strings.adminBalanceSection, style = MaterialTheme.typography.titleMedium, color = GoldAccent)
            OtaSliderRow(
              label = "Ground Quake CD",
              valueText = String.format(Locale.US, "%.1fs", draft.balance.groundSkill1CooldownSec),
              value = draft.balance.groundSkill1CooldownSec,
              range = 3.0f..15.0f,
              color = GoldAccent,
              onValueChange = { v -> draft = draft.copy(balance = draft.balance.copy(groundSkill1CooldownSec = (v * 2f).roundToInt() / 2f)) },
            )
            OtaSliderRow(
              label = "Thunder Deathbolt %",
              valueText = "${(draft.balance.thunderDeathboltPct * 100).roundToInt()}%",
              value = draft.balance.thunderDeathboltPct,
              range = 0.20f..0.60f,
              color = ThunderPrimary,
              onValueChange = { v -> draft = draft.copy(balance = draft.balance.copy(thunderDeathboltPct = v)) },
            )
            OtaSliderRow(
              label = "Ice Shard Dmg",
              valueText = "${draft.balance.iceShardDamage}",
              value = draft.balance.iceShardDamage.toFloat(),
              range = 3f..10f,
              color = WaterPrimary,
              onValueChange = { v -> draft = draft.copy(balance = draft.balance.copy(iceShardDamage = v.roundToInt())) },
            )
            OtaSliderRow(
              label = "Ice Ky Bang Ha Freeze",
              valueText = String.format(Locale.US, "%.1fs", draft.balance.iceFreezeDurationSec),
              value = draft.balance.iceFreezeDurationSec,
              range = 4.0f..15.0f,
              color = WaterPrimary,
              onValueChange = { v -> draft = draft.copy(balance = draft.balance.copy(iceFreezeDurationSec = (v * 2f).roundToInt() / 2f)) },
            )
            OtaSliderRow(
              label = "Ice Freeze Rage Drain",
              valueText = "-${(draft.balance.iceFreezeRageDrainPct * 100).roundToInt()}%",
              value = draft.balance.iceFreezeRageDrainPct,
              range = 0.20f..1.00f,
              color = WaterPrimary,
              onValueChange = { v -> draft = draft.copy(balance = draft.balance.copy(iceFreezeRageDrainPct = ((v * 20f).roundToInt() / 20f))) },
            )
            OtaSliderRow(
              label = "Ice Post-Freeze Slow",
              valueText = "-${(draft.balance.icePostFreezeSlowPct * 100).roundToInt()}%",
              value = draft.balance.icePostFreezeSlowPct,
              range = 0.15f..0.70f,
              color = WaterPrimary,
              onValueChange = { v -> draft = draft.copy(balance = draft.balance.copy(icePostFreezeSlowPct = ((v * 20f).roundToInt() / 20f))) },
            )
          }
        }

        // 6. App APK Drag-and-Drop / GitHub Release Manager
        AdminApkDragDropReleaseSection(
          strings = strings,
          draft = draft,
          uploadState = uploadState,
          onUpdateDraft = { updated -> draft = updated },
          onUploadAndPublishApk = onUploadAndPublishApk,
          onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } },
        )

        // 7. Publish OTA Live Button
        Button(
          onClick = {
            if (!publishing) {
              publishing = true
              scope.launch {
                val res = onPublishOtaConfig(draft)
                publishing = false
                if (res.isSuccess) {
                  res.getOrNull()?.let { draft = it }
                  snackbarHostState.showSnackbar(strings.adminPublishSuccess)
                } else {
                  snackbarHostState.showSnackbar(res.exceptionOrNull()?.localizedMessage ?: strings.adminPublishError)
                }
              }
            }
          },
          enabled = !publishing,
          colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().height(56.dp).testTag("admin_publish_ota_button"),
        ) {
          if (publishing) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black, strokeWidth = 2.dp)
          } else {
            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(22.dp))
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(strings.adminPublishButton, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
        }
      }
    }
  }
}

@Composable
private fun OtaSliderRow(
  label: String,
  valueText: String,
  value: Float,
  range: ClosedFloatingPointRange<Float>,
  color: Color,
  onValueChange: (Float) -> Unit,
) {
  Column {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
      Text(valueText, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = color)
    }
    Slider(
      value = value.coerceIn(range.start, range.endInclusive),
      onValueChange = onValueChange,
      valueRange = range,
      colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color),
    )
  }
}
