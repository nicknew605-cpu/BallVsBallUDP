package com.example.ui.arena

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.sp
import com.example.engine.ARENA_HEIGHT
import com.example.engine.ARENA_WIDTH
import com.example.engine.ArenaPhase
import com.example.engine.ArenaSnapshot
import com.example.engine.BALL_RADIUS
import com.example.engine.BallEntity
import com.example.engine.CompanionAntBall
import com.example.engine.RoyalAntUnit
import com.example.engine.SoldierAnt
import com.example.model.BallType
import com.example.model.GameSettings
import com.example.model.GraphicsQuality
import com.example.model.OtaVfxConfig
import com.example.ui.theme.AntCore
import com.example.ui.theme.AntGlow
import com.example.ui.theme.AntPrimary
import com.example.ui.theme.ChakraPetchFamily
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.FireCore
import com.example.ui.theme.FireGlow
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GroundCore
import com.example.ui.theme.GroundGlow
import com.example.ui.theme.GroundPrimary
import com.example.ui.theme.IceCore
import com.example.ui.theme.IceGlow
import com.example.ui.theme.IcePrimary
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ThunderCore
import com.example.ui.theme.ThunderGlow
import com.example.ui.theme.ThunderPrimary
import com.example.ui.theme.WaterCore
import com.example.ui.theme.WaterGlow
import com.example.ui.theme.WaterPrimary
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Reusable pre-allocated Path scratchpad so Canvas frame rendering produces zero Path GC churn.
 */
private class ArenaPathPool {
  val workPath = Path()
  val auxPath = Path()
  val crestPath = Path()
  val crownPath = Path()
  val wingPath = Path()
  val boltMainPath = Path()
  val boltBranchPath = Path()
  val foamPath = Path()
}

@Composable
fun ArenaCanvas(
  snapshot: ArenaSnapshot,
  settings: GameSettings,
  effectiveQuality: GraphicsQuality,
  otaVfx: OtaVfxConfig = OtaVfxConfig(),
  onAimAngleChanged: (playerId: Int, angleRad: Float) -> Unit,
  interactivePlayerId: Int? = null,
  modifier: Modifier = Modifier,
) {
  val textMeasurer = rememberTextMeasurer()
  val pathPool = remember { ArenaPathPool() }

  val bloomOn =
    settings.bloomAndShadersEnabled && effectiveQuality.tierRank >= GraphicsQuality.MEDIUM.tierRank
  val highOrUltra = effectiveQuality.tierRank >= GraphicsQuality.HIGH.tierRank
  val isUltra = effectiveQuality == GraphicsQuality.ULTRA

  val glowMul = otaVfx.glowIntensity.coerceIn(0.5f, 2.2f)
  val scaleMul = otaVfx.effectScale.coerceIn(0.7f, 1.6f)
  val vibrancyMul = otaVfx.vibrancyBoost.coerceIn(0.7f, 1.6f)

  val heatStrength =
    if (bloomOn) maxOf((snapshot.heatDistortionTimer / 5f), (snapshot.fireRealmTimer / 15f) * 0.55f).coerceIn(0f, 1f) else 0f
  val waterStrength =
    if (bloomOn) (snapshot.waterRippleTimer / 1.6f).coerceIn(0f, 1f) else 0f
  val freezeStrength =
    if (bloomOn) (snapshot.arenaFreezeTimer / 10.0f).coerceIn(0f, 1f) else 0f

  val targetAimPlayer = when {
    interactivePlayerId != null && (snapshot.phase == ArenaPhase.AIMING_P1 || snapshot.phase == ArenaPhase.AIMING_P2) ->
      interactivePlayerId
    snapshot.phase == ArenaPhase.AIMING_P1 -> 1
    snapshot.phase == ArenaPhase.AIMING_P2 -> 2
    else -> null
  }

  Canvas(
    modifier =
      modifier
        .fillMaxSize()
        .arenaPostProcessShader(
          enabled = bloomOn,
          quality = effectiveQuality,
          timeSec = snapshot.matchElapsedSec,
          heatStrength = heatStrength,
          waterStrength = waterStrength,
          freezeStrength = freezeStrength,
        )
        .pointerInput(snapshot.phase, interactivePlayerId) {
          if (targetAimPlayer != null) {
            val activeBall = if (targetAimPlayer == 1) snapshot.p1 else snapshot.p2
            detectTapGestures { tapOffset ->
              val scale = minOf(size.width / ARENA_WIDTH, size.height / ARENA_HEIGHT)
              val offsetX = (size.width - ARENA_WIDTH * scale) * 0.5f
              val offsetY = (size.height - ARENA_HEIGHT * scale) * 0.5f
              val worldX = (tapOffset.x - offsetX) / scale
              val worldY = (tapOffset.y - offsetY) / scale
              onAimAngleChanged(targetAimPlayer, atan2(worldY - activeBall.y, worldX - activeBall.x))
            }
          }
        }
        .pointerInput(snapshot.phase, interactivePlayerId) {
          if (targetAimPlayer != null) {
            val activeBall = if (targetAimPlayer == 1) snapshot.p1 else snapshot.p2
            detectDragGestures { change, _ ->
              change.consume()
              val scale = minOf(size.width / ARENA_WIDTH, size.height / ARENA_HEIGHT)
              val offsetX = (size.width - ARENA_WIDTH * scale) * 0.5f
              val offsetY = (size.height - ARENA_HEIGHT * scale) * 0.5f
              val worldX = (change.position.x - offsetX) / scale
              val worldY = (change.position.y - offsetY) / scale
              onAimAngleChanged(targetAimPlayer, atan2(worldY - activeBall.y, worldX - activeBall.x))
            }
          }
        }
  ) {
    val scale = minOf(size.width / ARENA_WIDTH, size.height / ARENA_HEIGHT)
    val boxW = ARENA_WIDTH * scale
    val boxH = ARENA_HEIGHT * scale

    val shakeX =
      if (settings.screenShakeEnabled && snapshot.shakeIntensity > 0.2f) {
        (Random.nextFloat() - 0.5f) * snapshot.shakeIntensity * 1.4f
      } else 0f
    val shakeY =
      if (settings.screenShakeEnabled && snapshot.shakeIntensity > 0.2f) {
        (Random.nextFloat() - 0.5f) * snapshot.shakeIntensity * 1.4f
      } else 0f

    val originX = (size.width - boxW) * 0.5f + shakeX
    val originY = (size.height - boxH) * 0.5f + shakeY

    fun toScreen(wx: Float, wy: Float): Offset = Offset(originX + wx * scale, originY + wy * scale)

    // 1. Arena Floor with deep obsidian vignette
    drawRoundRect(
      brush =
        Brush.radialGradient(
          colors = listOf(Color(0xFF172238), ObsidianSurface, ObsidianBg),
          center = Offset(originX + boxW * 0.5f, originY + boxH * 0.5f),
          radius = boxH * 0.72f,
        ),
      topLeft = Offset(originX, originY),
      size = Size(boxW, boxH),
      cornerRadius = CornerRadius(18f * scale, 18f * scale),
    )

    // Tactical Cyber Grid & Core Ring
    val gridColor = Color(0xFF23324E).copy(alpha = if (highOrUltra) 0.54f else 0.35f)
    for (i in 1..4) {
      val gx = originX + (boxW / 5f) * i
      drawLine(gridColor, Offset(gx, originY), Offset(gx, originY + boxH), strokeWidth = 1.2f)
    }
    for (j in 1..6) {
      val gy = originY + (boxH / 7f) * j
      drawLine(gridColor, Offset(originX, gy), Offset(originX + boxW, gy), strokeWidth = 1.2f)
    }
    val arenaCenter = Offset(originX + boxW * 0.5f, originY + boxH * 0.5f)
    drawCircle(
      color = gridColor,
      radius = 128f * scale,
      center = arenaCenter,
      style = Stroke(width = 1.8f * scale),
    )
    if (highOrUltra) {
      drawCircle(
        color = gridColor.copy(alpha = 0.32f),
        radius = 240f * scale,
        center = arenaCenter,
        style = Stroke(width = 1.4f * scale, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f * scale, 10f * scale))),
      )
    }

    // 2A. Fire Fury Map-Wide Scorching Overlay
    if (snapshot.heatDistortionTimer > 0f) {
      val heatAlpha = (snapshot.heatDistortionTimer / 5f).coerceIn(0f, 1f) * vibrancyMul.coerceAtMost(1.35f)
      drawRoundRect(
        brush =
          Brush.radialGradient(
            colors = listOf(
              FireCore.copy(alpha = 0.08f * heatAlpha),
              FirePrimary.copy(alpha = 0.24f * heatAlpha),
              FireGlow.copy(alpha = 0.36f * heatAlpha),
            ),
            center = arenaCenter,
            radius = boxH * 0.65f,
          ),
        topLeft = Offset(originX, originY),
        size = Size(boxW, boxH),
        cornerRadius = CornerRadius(18f * scale, 18f * scale),
      )
      if (highOrUltra) {
        for (hIdx in 0 until 6) {
          val offsetFrac = ((snapshot.matchElapsedSec * 0.9f + hIdx * 0.17f) % 1f)
          val hy = originY + boxH * (1f - offsetFrac)
          val waveOffset = sin(snapshot.matchElapsedSec * 8f + hIdx) * 18f * scale
          drawLine(
            color = FireGlow.copy(alpha = 0.16f * heatAlpha),
            start = Offset(originX + 18f * scale, hy + waveOffset),
            end = Offset(originX + boxW - 18f * scale, hy - waveOffset),
            strokeWidth = 3.5f * scale,
            blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
          )
        }
      }
    }

    // 2A-2. Fire Ball Passive: Realm of Fire Perimeter Wall Flames (15s continuous)
    if (snapshot.fireRealmTimer > 0f) {
      val realmAlpha = (snapshot.fireRealmTimer / 2.5f).coerceIn(0.35f, 1f)
      drawRealmOfFirePerimeter(
        path = pathPool.workPath,
        originX = originX,
        originY = originY,
        boxW = boxW,
        boxH = boxH,
        scale = scale,
        timeSec = snapshot.matchElapsedSec,
        alpha = realmAlpha,
        bloomOn = bloomOn,
        highOrUltra = highOrUltra,
      )
    }

    // 2B. Ground Ball Seismic Fault Fissures
    if (snapshot.quakeFissureTimer > 0f) {
      val qAlpha = (snapshot.quakeFissureTimer / 0.90f).coerceIn(0f, 1f)
      val qOrigin = toScreen(snapshot.quakeOriginX, snapshot.quakeOriginY)
      drawSeismicFissures(
        path = pathPool.workPath,
        shardPath = pathPool.auxPath,
        origin = qOrigin,
        boxW = boxW,
        scale = scale * scaleMul,
        alpha = qAlpha,
        bloomOn = bloomOn,
        highOrUltra = highOrUltra,
      )
    }

    // 2C. Full-Arena Ice Freeze Overlay
    if (snapshot.arenaFreezeTimer > 0f) {
      val freezeAlpha = (snapshot.arenaFreezeTimer / 10.0f).coerceIn(0.28f, 1f)
      drawFullArenaFrostOverlay(
        path = pathPool.workPath,
        diamondPath = pathPool.auxPath,
        originX = originX,
        originY = originY,
        boxW = boxW,
        boxH = boxH,
        center = arenaCenter,
        scale = scale,
        timeSec = snapshot.matchElapsedSec,
        freezeAlpha = freezeAlpha,
        bloomOn = bloomOn,
        highOrUltra = highOrUltra,
      )
    }

    // 3. Box Perimeter Neon Border + outer glow
    val borderColor =
      when {
        snapshot.arenaFreezeTimer > 0f -> IceGlow
        snapshot.fireRealmTimer > 0f || snapshot.heatDistortionTimer > 0f -> FirePrimary
        snapshot.quakeFissureTimer > 0f -> GroundGlow
        snapshot.waterRippleTimer > 0f -> WaterPrimary
        else -> Color(0xFF3E527B)
      }
    if (isUltra || bloomOn) {
      drawRoundRect(
        color = borderColor.copy(alpha = (0.30f * glowMul).coerceAtMost(0.70f)),
        topLeft = Offset(originX - 2f * scale, originY - 2f * scale),
        size = Size(boxW + 4f * scale, boxH + 4f * scale),
        cornerRadius = CornerRadius(20f * scale, 20f * scale),
        style = Stroke(width = 11f * scale),
      )
    }
    drawRoundRect(
      color = borderColor,
      topLeft = Offset(originX, originY),
      size = Size(boxW, boxH),
      cornerRadius = CornerRadius(18f * scale, 18f * scale),
      style = Stroke(width = 4.2f * scale),
    )

    // 4. Water Hydro Vortex Traps
    for (trap in snapshot.hydroTraps) {
      val center = toScreen(trap.x, trap.y)
      val r = trap.radius * scale * scaleMul
      drawCircle(
        brush =
          Brush.radialGradient(
            colors = listOf(
              Color.White.copy(alpha = 0.52f),
              WaterCore.copy(alpha = 0.78f),
              WaterPrimary.copy(alpha = 0.42f),
              Color.Transparent,
            ),
            center = center,
            radius = r * 1.25f,
          ),
        radius = r * 1.25f,
        center = center,
      )
      rotate(degrees = trap.angleDeg, pivot = center) {
        for (ringIdx in 0..2) {
          val factor = 0.88f - ringIdx * 0.24f
          drawArc(
            color = if (ringIdx == 2) Color.White.copy(alpha = 0.90f) else WaterGlow.copy(alpha = 0.85f),
            startAngle = ringIdx * 110f,
            sweepAngle = 215f,
            useCenter = false,
            topLeft = Offset(center.x - r * factor, center.y - r * factor),
            size = Size(r * factor * 2f, r * factor * 2f),
            style = Stroke(width = (4.8f - ringIdx * 1.0f) * scale, cap = StrokeCap.Round),
          )
        }
        if (highOrUltra) {
          for (sp in 0 until 6) {
            val sa = sp * (PI.toFloat() / 3f)
            val dPos = Offset(center.x + cos(sa) * r * 0.94f, center.y + sin(sa) * r * 0.94f)
            drawCircle(color = Color.White.copy(alpha = 0.85f), radius = 3.2f * scale, center = dPos)
          }
        }
      }
    }

    // 5. Tsunami Sweeping Waves
    for (wave in snapshot.tsunamis) {
      val wy = originY + wave.y * scale
      val bandH = 90f * scale * scaleMul
      drawRect(
        brush =
          Brush.verticalGradient(
            colors =
              listOf(
                Color.Transparent,
                WaterCore.copy(alpha = 0.62f),
                WaterPrimary.copy(alpha = 0.92f),
                Color.White.copy(alpha = 0.96f),
                Color.Transparent,
              ),
            startY = wy - bandH,
            endY = wy + bandH,
          ),
        topLeft = Offset(originX, (wy - bandH).coerceAtLeast(originY)),
        size = Size(boxW, bandH * 2f),
      )
      val foamPath = pathPool.foamPath.apply {
        reset()
        val segments = 14
        for (s in 0..segments) {
          val frac = s.toFloat() / segments
          val fx = originX + boxW * frac
          val fy = wy + sin(frac * 6f * PI.toFloat() + snapshot.matchElapsedSec * 12f) * 12f * scale
          if (s == 0) moveTo(fx, fy) else lineTo(fx, fy)
        }
      }
      drawPath(
        path = foamPath,
        color = Color.White.copy(alpha = 0.92f),
        style = Stroke(width = 5.5f * scale, cap = StrokeCap.Round, join = StrokeJoin.Round),
      )
    }

    // 6. Thunder Afterimages
    val maxClonesToDraw =
      when (effectiveQuality) {
        GraphicsQuality.LOW -> 48
        GraphicsQuality.MEDIUM -> 78
        GraphicsQuality.HIGH, GraphicsQuality.ULTRA -> snapshot.afterimages.size
      }
    val cloneStep =
      if (snapshot.afterimages.size > maxClonesToDraw && maxClonesToDraw > 0) {
        (snapshot.afterimages.size / maxClonesToDraw).coerceAtLeast(1)
      } else 1
    var cloneIdx = 0
    while (cloneIdx < snapshot.afterimages.size) {
      val clone = snapshot.afterimages[cloneIdx]
      val cPos = toScreen(clone.x, clone.y)
      val fade = (clone.remainingLife / clone.maxLife.coerceAtLeast(0.1f)).coerceIn(0f, 1f)
      val cr = BALL_RADIUS * scale * 0.50f * scaleMul
      drawCircle(
        color = ThunderPrimary.copy(alpha = (0.28f * fade * glowMul).coerceAtMost(0.75f)),
        radius = cr,
        center = cPos,
        blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
      )
      drawCircle(
        color = ThunderGlow.copy(alpha = 0.62f * fade),
        radius = cr,
        center = cPos,
        style = Stroke(width = 2.2f * scale),
      )
      if (highOrUltra) {
        val zPath = pathPool.workPath.apply {
          reset()
          moveTo(cPos.x + cr * 0.16f, cPos.y - cr * 0.50f)
          lineTo(cPos.x - cr * 0.28f, cPos.y + cr * 0.04f)
          lineTo(cPos.x + cr * 0.10f, cPos.y + cr * 0.04f)
          lineTo(cPos.x - cr * 0.16f, cPos.y + cr * 0.50f)
        }
        drawPath(
          zPath,
          color = Color.White.copy(alpha = 0.68f * fade),
          style = Stroke(width = 1.8f * scale, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
      }
      cloneIdx += cloneStep
    }

    // 7. Fire Ignition Chips & Blazing Plasma Lasers
    for (chip in snapshot.chips) {
      val cPos = toScreen(chip.x, chip.y)
      val fade = (chip.remainingLife / 3f).coerceIn(0.25f, 1f)
      if (bloomOn) {
        drawCircle(
          brush = Brush.radialGradient(listOf(FirePrimary.copy(alpha = (0.65f * fade * glowMul).coerceAtMost(0.95f)), Color.Transparent), center = cPos, radius = 32f * scale * scaleMul),
          radius = 32f * scale * scaleMul,
          center = cPos,
          blendMode = BlendMode.Plus,
        )
      }
      rotate(degrees = snapshot.matchElapsedSec * 160f, pivot = cPos) {
        val diamond = pathPool.workPath.apply {
          reset()
          val r = 13f * scale * scaleMul
          moveTo(cPos.x, cPos.y - r)
          lineTo(cPos.x + r * 0.72f, cPos.y)
          lineTo(cPos.x, cPos.y + r)
          lineTo(cPos.x - r * 0.72f, cPos.y)
          close()
        }
        drawPath(diamond, color = FireCore.copy(alpha = fade))
        drawPath(diamond, color = FireGlow.copy(alpha = fade), style = Stroke(width = 2.0f * scale))
      }
      drawCircle(color = Color.White.copy(alpha = 0.95f * fade), radius = 4.6f * scale, center = cPos)
    }

    for (laser in snapshot.lasers) {
      val pStart = toScreen(laser.x1, laser.y1)
      val pEnd = toScreen(laser.x2, laser.y2)
      val pulse = (laser.remainingLife / 2f).coerceIn(0.2f, 1f)
      if (bloomOn) {
        drawLine(
          color = FireGlow.copy(alpha = (0.55f * pulse * glowMul).coerceAtMost(0.90f)),
          start = pStart,
          end = pEnd,
          strokeWidth = 26f * scale * scaleMul,
          cap = StrokeCap.Round,
          blendMode = BlendMode.Plus,
        )
      }
      drawLine(
        color = FirePrimary.copy(alpha = 0.92f * pulse),
        start = pStart,
        end = pEnd,
        strokeWidth = 11f * scale,
        cap = StrokeCap.Round,
      )
      drawLine(
        color = FireCore.copy(alpha = 0.96f * pulse),
        start = pStart,
        end = pEnd,
        strokeWidth = 6f * scale,
        cap = StrokeCap.Round,
      )
      drawLine(
        color = Color.White.copy(alpha = 0.95f * pulse),
        start = pStart,
        end = pEnd,
        strokeWidth = 2.4f * scale,
        cap = StrokeCap.Round,
      )
    }

    // 8. Aqua Orbs
    for (orb in snapshot.aquaOrbs) {
      val oPos = toScreen(orb.x, orb.y)
      val r = orb.radius * scale * scaleMul
      if (bloomOn) {
        drawCircle(
          brush = Brush.radialGradient(listOf(WaterPrimary.copy(alpha = (0.70f * glowMul).coerceAtMost(0.95f)), Color.Transparent), center = oPos, radius = r * 2.5f),
          radius = r * 2.5f,
          center = oPos,
          blendMode = BlendMode.Plus,
        )
      }
      drawCircle(
        brush = Brush.radialGradient(listOf(Color.White, WaterPrimary, WaterCore), center = Offset(oPos.x - r * 0.25f, oPos.y - r * 0.25f), radius = r * 1.15f),
        radius = r,
        center = oPos,
      )
      if (highOrUltra) {
        drawCircle(color = Color.White.copy(alpha = 0.85f), radius = r * 0.26f, center = Offset(oPos.x - r * 0.35f, oPos.y - r * 0.35f))
      }
    }

    // 9. Crystalline Ice Shards
    for (shard in snapshot.iceShards) {
      val sPos = toScreen(shard.x, shard.y)
      val sr = shard.radius * scale * scaleMul
      val angle = atan2(shard.vy, shard.vx) * (180f / PI.toFloat())
      rotate(degrees = angle, pivot = sPos) {
        val path = pathPool.workPath.apply {
          reset()
          moveTo(sPos.x + sr * 1.85f, sPos.y)
          lineTo(sPos.x - sr * 0.3f, sPos.y - sr * 0.78f)
          lineTo(sPos.x - sr * 1.45f, sPos.y)
          lineTo(sPos.x - sr * 0.3f, sPos.y + sr * 0.78f)
          close()
        }
        if (bloomOn) {
          drawCircle(color = IcePrimary.copy(alpha = (0.42f * glowMul).coerceAtMost(0.85f)), radius = sr * 1.7f, center = sPos, blendMode = BlendMode.Plus)
        }
        drawPath(path, brush = Brush.linearGradient(listOf(IceCore, IceGlow, Color.White), start = Offset(sPos.x - sr, sPos.y), end = Offset(sPos.x + sr * 1.8f, sPos.y)))
        drawPath(path, color = Color.White.copy(alpha = 0.85f), style = Stroke(width = 2.0f * scale, join = StrokeJoin.Round))
        drawLine(Color.White.copy(alpha = 0.95f), Offset(sPos.x - sr * 1.0f, sPos.y), Offset(sPos.x + sr * 1.55f, sPos.y), strokeWidth = 1.6f * scale)
      }
    }

    // 9B. Ant Colony: Queen Buff Tethers, Royal Queen/King 2D Insect Models & Crisp Soldier Ants
    for (royal in snapshot.royalAnts) {
      if (royal.isQueen && highOrUltra) {
        val qPos = toScreen(royal.x, royal.y)
        var linked = 0
        for (ant in snapshot.soldierAnts) {
          if (ant.ownerId == royal.ownerId) {
            val aPos = toScreen(ant.x, ant.y)
            drawLine(
              color = AntGlow.copy(alpha = 0.24f),
              start = qPos,
              end = aPos,
              strokeWidth = 1.6f * scale,
              blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
            )
            linked++
            if (linked >= 12) break
          }
        }
      }
      drawRoyalAntUnit(
        unit = royal,
        crownPath = pathPool.crownPath,
        wingPath = pathPool.wingPath,
        bodyPath = pathPool.auxPath,
        timeSec = snapshot.matchElapsedSec,
        scale = scale,
        bloomOn = bloomOn,
        toScreen = ::toScreen,
      )
    }
    for (ally in snapshot.companionAnts) {
      drawCompanionAntBall(ally, snapshot.matchElapsedSec, scale, bloomOn, ::toScreen)
    }

    val p1Queen = snapshot.side1Balls.any { it.hp > 0f && it.antQueenTimer > 0f }
    val p1King = snapshot.side1Balls.any { it.hp > 0f && it.antKingTimer > 0f }
    val p2Queen = snapshot.side2Balls.any { it.hp > 0f && it.antQueenTimer > 0f }
    val p2King = snapshot.side2Balls.any { it.hp > 0f && it.antKingTimer > 0f }
    val fastAntMode = snapshot.soldierAnts.size > 58 || effectiveQuality == GraphicsQuality.LOW
    for (ant in snapshot.soldierAnts) {
      val queen = if (ant.ownerId == 1) p1Queen else p2Queen
      val king = if (ant.ownerId == 1) p1King else p2King
      val sizeScale = if (queen && king) 1.28f else if (queen) 1.15f else 1.0f
      drawSoldierAnt(
        ant = ant,
        sizeScale = sizeScale,
        hasQueen = queen,
        hasKing = king,
        timeSec = snapshot.matchElapsedSec,
        scale = scale,
        fastMode = fastAntMode,
        toScreen = ::toScreen,
      )
    }

    // 10. Shockwave Rings
    for (ring in snapshot.shockwaves) {
      val pos = toScreen(ring.x, ring.y)
      val alpha = (ring.life / ring.maxLife).coerceIn(0f, 1f)
      drawCircle(
        color = Color(ring.colorArgb).copy(alpha = (alpha * 0.90f * vibrancyMul).coerceAtMost(1f)),
        radius = ring.radius * scale,
        center = pos,
        style = Stroke(width = (10f * alpha + 2.8f) * scale),
        blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
      )
    }

    // 11. Motion Trails for ALL living balls (including Ant Clones #2 & #3)
    if (settings.trailsEnabled && effectiveQuality != GraphicsQuality.LOW) {
      for (b in snapshot.side1Balls) {
        if (b.hp > 0f) drawBallTrail(b, scale, isUltra, bloomOn, ::toScreen)
      }
      for (b in snapshot.side2Balls) {
        if (b.hp > 0f) drawBallTrail(b, scale, isUltra, bloomOn, ::toScreen)
      }
    }

    // 12. ALL Elemental & Ant Balls (Main + Passive 100% HP Ant Clones)
    val alpha = snapshot.interpolationAlpha
    for (b in snapshot.side1Balls) {
      if (b.hp > 0f || snapshot.phase == ArenaPhase.AIMING_P1) {
        drawElementalBall(
          ball = b,
          alpha = alpha,
          scale = scale,
          timeSec = snapshot.matchElapsedSec,
          winnerId = snapshot.winnerId,
          quality = effectiveQuality,
          bloomEnabled = bloomOn,
          glowMul = glowMul,
          scaleMul = scaleMul,
          pathPool = pathPool,
          textMeasurer = textMeasurer,
          toScreen = ::toScreen,
        )
      }
    }
    for (b in snapshot.side2Balls) {
      if (b.hp > 0f || (snapshot.phase != ArenaPhase.FINISHED && snapshot.phase != ArenaPhase.KO_SLOWMO && snapshot.side2Balls.size == 1)) {
        drawElementalBall(
          ball = b,
          alpha = alpha,
          scale = scale,
          timeSec = snapshot.matchElapsedSec,
          winnerId = snapshot.winnerId,
          quality = effectiveQuality,
          bloomEnabled = bloomOn,
          glowMul = glowMul,
          scaleMul = scaleMul,
          pathPool = pathPool,
          textMeasurer = textMeasurer,
          toScreen = ::toScreen,
        )
      }
    }

    // 13. Thunder Deathbolt Sky Lightning
    for (bolt in snapshot.lightningBolts) {
      val target = toScreen(bolt.targetX, bolt.targetY)
      val fade = (bolt.remainingLife / 0.50f).coerceIn(0f, 1f)
      val segments = bolt.jaggedOffsets.size + 1

      drawCircle(
        color = ThunderPrimary.copy(alpha = fade * 0.45f),
        radius = 86f * scale * (1.25f - fade * 0.3f) * scaleMul,
        center = target,
        style = Stroke(width = 4.0f * scale),
        blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
      )
      drawCircle(
        color = Color.White.copy(alpha = fade * 0.78f),
        radius = 42f * scale * fade * scaleMul,
        center = target,
        blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
      )

      val mainPath = pathPool.boltMainPath.apply {
        reset()
        moveTo(target.x, originY)
        bolt.jaggedOffsets.forEachIndexed { idx, offsetX ->
          val t = (idx + 1).toFloat() / segments
          lineTo(target.x + offsetX * scale, originY + (target.y - originY) * t)
        }
        lineTo(target.x, target.y)
      }
      if (highOrUltra && bolt.jaggedOffsets.size >= 4) {
        val branchPath = pathPool.boltBranchPath.apply {
          reset()
          val midT = 0.45f
          val midY = originY + (target.y - originY) * midT
          val midX = target.x + bolt.jaggedOffsets[2] * scale
          moveTo(midX, midY)
          lineTo(midX + 54f * scale, midY + (target.y - midY) * 0.35f)
          lineTo(midX + 26f * scale, midY + (target.y - midY) * 0.65f)
          lineTo(midX + 78f * scale, midY + (target.y - midY) * 0.92f)
        }
        drawPath(branchPath, color = ThunderGlow.copy(alpha = fade * 0.75f), style = Stroke(width = 6f * scale, cap = StrokeCap.Round, join = StrokeJoin.Round))
      }

      if (bloomOn) {
        drawPath(mainPath, color = ThunderGlow.copy(alpha = (fade * 0.72f * glowMul).coerceAtMost(0.95f)), style = Stroke(width = 28f * scale * scaleMul, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Plus)
      }
      drawPath(mainPath, color = ThunderPrimary.copy(alpha = fade), style = Stroke(width = 13f * scale, cap = StrokeCap.Round, join = StrokeJoin.Round))
      drawPath(mainPath, color = Color.White.copy(alpha = fade), style = Stroke(width = 5f * scale, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }

    // 14. Aiming Trajectory Guide (supports simultaneous Online aiming for local player)
    if (targetAimPlayer == 1) {
      drawAimTrajectory(snapshot.p1, scale, ::toScreen)
    } else if (targetAimPlayer == 2) {
      drawAimTrajectory(snapshot.p2, scale, ::toScreen)
    }

    // 15. Particles
    val particleLimit =
      when (effectiveQuality) {
        GraphicsQuality.LOW -> 70
        GraphicsQuality.MEDIUM -> 140
        GraphicsQuality.HIGH, GraphicsQuality.ULTRA -> snapshot.particles.size
      }
    val pStep = if (snapshot.particles.size > particleLimit && particleLimit > 0) (snapshot.particles.size / particleLimit).coerceAtLeast(1) else 1
    var pIdx = 0
    while (pIdx < snapshot.particles.size) {
      val p = snapshot.particles[pIdx]
      val lifeAlpha = (p.life / p.maxLife).coerceIn(0f, 1f)
      drawCircle(
        color = Color(p.colorArgb).copy(alpha = lifeAlpha),
        radius = p.size * scale * (0.4f + 0.6f * lifeAlpha),
        center = toScreen(p.x, p.y),
        blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
      )
      pIdx += pStep
    }

    // 16. Floating Damage Popups
    if (settings.floatingDamageEnabled) {
      for (dmg in snapshot.floatingDamages) {
        val pos = toScreen(dmg.x, dmg.y)
        val lifeAlpha = (dmg.life / dmg.maxLife).coerceIn(0f, 1f)
        drawDamagePopup(textMeasurer, dmg.text, pos, Color(dmg.colorArgb).copy(alpha = lifeAlpha), dmg.isCrit)
      }
    }

    // 17. Live Emote Comic Speech Bubbles over balls
    for (bubble in snapshot.emoteBubbles) {
      val ownerBall = if (bubble.playerId == 1) snapshot.p1 else snapshot.p2
      val fade = (bubble.remainingLife / 0.5f).coerceIn(0f, 1f)
      val bx = ownerBall.x
      val by = (ownerBall.y - BALL_RADIUS - 54f).coerceAtLeast(52f)
      val pos = toScreen(bx, by)
      val badgeW = 104f * scale
      val badgeH = 38f * scale
      drawRoundRect(
        color = Color(0xEE0F172A).copy(alpha = fade),
        topLeft = Offset(pos.x - badgeW * 0.5f, pos.y - badgeH * 0.5f),
        size = Size(badgeW, badgeH),
        cornerRadius = CornerRadius(14f * scale, 14f * scale),
      )
      drawRoundRect(
        color = Color(bubble.colorArgb).copy(alpha = fade),
        topLeft = Offset(pos.x - badgeW * 0.5f, pos.y - badgeH * 0.5f),
        size = Size(badgeW, badgeH),
        cornerRadius = CornerRadius(14f * scale, 14f * scale),
        style = Stroke(width = 2.4f * scale),
      )
      val layout = textMeasurer.measure(
        text = bubble.text,
        style = TextStyle(
          fontFamily = ChakraPetchFamily,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          color = Color.White.copy(alpha = fade),
        ),
      )
      drawText(
        textLayoutResult = layout,
        topLeft = Offset(pos.x - layout.size.width * 0.5f, pos.y - layout.size.height * 0.5f),
      )
    }
  }
}

private fun DrawScope.drawRealmOfFirePerimeter(
  path: Path,
  originX: Float,
  originY: Float,
  boxW: Float,
  boxH: Float,
  scale: Float,
  timeSec: Float,
  alpha: Float,
  bloomOn: Boolean,
  highOrUltra: Boolean,
) {
  val wallGlow = 26f * scale
  val flameTeeth = if (highOrUltra) 18 else 12
  val stepX = boxW / flameTeeth
  val blend = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver
  for (i in 0 until flameTeeth) {
    val fx = originX + i * stepX
    val wave = sin(timeSec * 14f + i * 1.1f) * 8f * scale
    val tipH = (22f + (i % 3) * 10f) * scale + wave
    path.reset()
    path.moveTo(fx, originY)
    path.lineTo(fx + stepX * 0.5f, originY + tipH)
    path.lineTo(fx + stepX, originY)
    path.close()
    drawPath(path, color = FirePrimary.copy(alpha = 0.72f * alpha), blendMode = blend)

    path.reset()
    path.moveTo(fx, originY + boxH)
    path.lineTo(fx + stepX * 0.5f, originY + boxH - tipH)
    path.lineTo(fx + stepX, originY + boxH)
    path.close()
    drawPath(path, color = FirePrimary.copy(alpha = 0.72f * alpha), blendMode = blend)
  }
  val sideTeeth = if (highOrUltra) 22 else 14
  val stepY = boxH / sideTeeth
  for (j in 0 until sideTeeth) {
    val fy = originY + j * stepY
    val wave = cos(timeSec * 13f + j * 1.2f) * 7f * scale
    val tipW = (20f + (j % 3) * 9f) * scale + wave
    path.reset()
    path.moveTo(originX, fy)
    path.lineTo(originX + tipW, fy + stepY * 0.5f)
    path.lineTo(originX, fy + stepY)
    path.close()
    drawPath(path, color = FireGlow.copy(alpha = 0.72f * alpha), blendMode = blend)

    path.reset()
    path.moveTo(originX + boxW, fy)
    path.lineTo(originX + boxW - tipW, fy + stepY * 0.5f)
    path.lineTo(originX + boxW, fy + stepY)
    path.close()
    drawPath(path, color = FireGlow.copy(alpha = 0.72f * alpha), blendMode = blend)
  }
  drawRoundRect(
    color = FireCore.copy(alpha = 0.45f * alpha),
    topLeft = Offset(originX + wallGlow * 0.25f, originY + wallGlow * 0.25f),
    size = Size(boxW - wallGlow * 0.5f, boxH - wallGlow * 0.5f),
    cornerRadius = CornerRadius(16f * scale, 16f * scale),
    style = Stroke(width = 8f * scale),
    blendMode = blend,
  )
}

/**
 * Custom sharp 2D Soldier Ant insect model:
 * venom-striped abdomen, armored thorax, head with compound eyes, antennae, curved mandibles, and 6 jointed legs.
 */
private fun DrawScope.drawSoldierAnt(
  ant: SoldierAnt,
  sizeScale: Float,
  hasQueen: Boolean,
  hasKing: Boolean,
  timeSec: Float,
  scale: Float,
  fastMode: Boolean,
  toScreen: (Float, Float) -> Offset,
) {
  val pos = toScreen(ant.x, ant.y)
  val r = ant.baseRadius * scale * sizeScale
  val deg = ant.angleRad * (180f / PI.toFloat())
  val shellPrimary = when {
    hasQueen && hasKing -> GoldAccent
    hasKing -> CrimsonDanger
    hasQueen -> AntGlow
    else -> AntPrimary
  }
  val shellCore = when {
    hasQueen && hasKing -> Color(0xFFFFF59D)
    hasKing -> GoldAccent
    else -> AntCore
  }
  val outlineColor = Color(0xFF0A140E)

  rotate(degrees = deg, pivot = pos) {
    // 6 jointed scurrying legs (alternating gait)
    val phaseA = sin(timeSec * 26f + ant.id) * r * 0.22f
    val phaseB = -phaseA
    val legStroke = (if (fastMode) 1.9f else 2.4f) * scale
    for (legIdx in -1..1) {
      val baseX = pos.x + legIdx * r * 0.36f
      val swing = if (legIdx == 0) phaseB else phaseA
      val topKnee = Offset(baseX + r * 0.14f, pos.y - r * 0.70f + swing * 0.5f)
      val topFoot = Offset(baseX - r * 0.18f, pos.y - r * 1.12f + swing)
      val botKnee = Offset(baseX + r * 0.14f, pos.y + r * 0.70f - swing * 0.5f)
      val botFoot = Offset(baseX - r * 0.18f, pos.y + r * 1.12f - swing)

      drawLine(shellCore, Offset(baseX, pos.y - r * 0.16f), topKnee, strokeWidth = legStroke, cap = StrokeCap.Round)
      drawLine(shellPrimary, topKnee, topFoot, strokeWidth = legStroke * 0.85f, cap = StrokeCap.Round)
      drawLine(shellCore, Offset(baseX, pos.y + r * 0.16f), botKnee, strokeWidth = legStroke, cap = StrokeCap.Round)
      drawLine(shellPrimary, botKnee, botFoot, strokeWidth = legStroke * 0.85f, cap = StrokeCap.Round)
    }

    // Abdomen (rear gaster oval + glowing venom bands)
    val abdCenter = Offset(pos.x - r * 0.62f, pos.y)
    drawOval(
      color = outlineColor,
      topLeft = Offset(abdCenter.x - r * 0.56f, abdCenter.y - r * 0.42f),
      size = Size(r * 1.12f, r * 0.84f),
    )
    drawOval(
      color = shellPrimary,
      topLeft = Offset(abdCenter.x - r * 0.48f, abdCenter.y - r * 0.35f),
      size = Size(r * 0.96f, r * 0.70f),
    )
    if (!fastMode) {
      drawLine(
        color = shellCore.copy(alpha = 0.88f),
        start = Offset(abdCenter.x - r * 0.12f, abdCenter.y - r * 0.28f),
        end = Offset(abdCenter.x - r * 0.12f, abdCenter.y + r * 0.28f),
        strokeWidth = 2.2f * scale,
        cap = StrokeCap.Round,
      )
      drawLine(
        color = shellCore.copy(alpha = 0.78f),
        start = Offset(abdCenter.x - r * 0.30f, abdCenter.y - r * 0.22f),
        end = Offset(abdCenter.x - r * 0.30f, abdCenter.y + r * 0.22f),
        strokeWidth = 2.0f * scale,
        cap = StrokeCap.Round,
      )
    }

    // Armored Thorax
    drawCircle(color = outlineColor, radius = r * 0.38f, center = pos)
    drawCircle(color = shellCore, radius = r * 0.32f, center = pos)

    // Head Capsule
    val headCenter = Offset(pos.x + r * 0.54f, pos.y)
    drawCircle(color = outlineColor, radius = r * 0.42f, center = headCenter)
    drawCircle(color = shellPrimary, radius = r * 0.36f, center = headCenter)

    // Compound eyes + Antennae
    drawCircle(color = Color.White, radius = r * 0.11f, center = Offset(headCenter.x + r * 0.10f, headCenter.y - r * 0.20f))
    drawCircle(color = Color.White, radius = r * 0.11f, center = Offset(headCenter.x + r * 0.10f, headCenter.y + r * 0.20f))
    if (!fastMode) {
      drawLine(shellCore, Offset(headCenter.x + r * 0.18f, headCenter.y - r * 0.22f), Offset(headCenter.x + r * 0.58f, headCenter.y - r * 0.54f), strokeWidth = 1.6f * scale, cap = StrokeCap.Round)
      drawLine(shellCore, Offset(headCenter.x + r * 0.18f, headCenter.y + r * 0.22f), Offset(headCenter.x + r * 0.58f, headCenter.y + r * 0.54f), strokeWidth = 1.6f * scale, cap = StrokeCap.Round)
    }

    // Sharp White-Gold Razor Mandibles
    val mandibleColor = if (hasKing) GoldAccent else Color.White
    drawLine(mandibleColor, Offset(headCenter.x + r * 0.28f, headCenter.y - r * 0.20f), Offset(headCenter.x + r * 0.68f, headCenter.y - r * 0.06f), strokeWidth = 2.6f * scale, cap = StrokeCap.Round)
    drawLine(mandibleColor, Offset(headCenter.x + r * 0.28f, headCenter.y + r * 0.20f), Offset(headCenter.x + r * 0.68f, headCenter.y + r * 0.06f), strokeWidth = 2.6f * scale, cap = StrokeCap.Round)
  }
}

private fun DrawScope.drawCompanionAntBall(
  ally: CompanionAntBall,
  timeSec: Float,
  scale: Float,
  bloomOn: Boolean,
  toScreen: (Float, Float) -> Offset,
) {
  val c = toScreen(ally.x, ally.y)
  val r = ally.radius * scale
  if (bloomOn) {
    drawCircle(
      brush = Brush.radialGradient(listOf(AntCore.copy(alpha = 0.50f), Color.Transparent), center = c, radius = r * 1.85f),
      radius = r * 1.85f,
      center = c,
      blendMode = BlendMode.Plus,
    )
  }
  drawCircle(
    brush = Brush.radialGradient(listOf(Color.White, AntCore, AntPrimary), center = Offset(c.x - r * 0.25f, c.y - r * 0.25f), radius = r * 1.2f),
    radius = r,
    center = c,
  )
  rotate(degrees = timeSec * 180f, pivot = c) {
    drawCircle(color = AntGlow.copy(alpha = 0.85f), radius = r * 0.56f, center = c, style = Stroke(width = 2.2f * scale))
  }
  val hpPct = (ally.hp / ally.maxHp).coerceIn(0f, 1f)
  drawArc(
    color = AntGlow,
    startAngle = -90f,
    sweepAngle = 360f * hpPct,
    useCenter = false,
    topLeft = Offset(c.x - r * 1.18f, c.y - r * 1.18f),
    size = Size(r * 2.36f, r * 2.36f),
    style = Stroke(width = 2.5f * scale, cap = StrokeCap.Round),
  )
}

/**
 * Crisp 2D Royal Ant Unit models:
 * - Queen Ant: iridescent fluttering double wings, emerald bio-crown, pheromone glow.
 * - King Ant: crimson-gold horned warlord carapace, flaming stag mandibles, royal healing pulse.
 */
private fun DrawScope.drawRoyalAntUnit(
  unit: RoyalAntUnit,
  crownPath: Path,
  wingPath: Path,
  bodyPath: Path,
  timeSec: Float,
  scale: Float,
  bloomOn: Boolean,
  toScreen: (Float, Float) -> Offset,
) {
  val bobY = sin(timeSec * 4.5f + if (unit.isQueen) 0f else 2f) * 10f
  val basePos = toScreen(unit.x, unit.y + bobY)
  val r = 38f * scale
  val auraColor = if (unit.isQueen) AntPrimary else GoldAccent
  val rimColor = if (unit.isQueen) AntGlow else CrimsonDanger
  val fade = (unit.remainingLife / 1.5f).coerceIn(0.55f, 1f)

  if (bloomOn) {
    drawCircle(
      brush = Brush.radialGradient(listOf(auraColor.copy(alpha = 0.48f * fade), Color.Transparent), center = basePos, radius = r * 2.5f),
      radius = r * 2.5f,
      center = basePos,
      blendMode = BlendMode.Plus,
    )
  }

  if (unit.isQueen) {
    // Iridescent Fluttering Queen Wings
    val flutter = sin(timeSec * 22f) * 14f
    for (side in listOf(-1f, 1f)) {
      rotate(degrees = side * (28f + flutter), pivot = basePos) {
        wingPath.reset()
        wingPath.moveTo(basePos.x, basePos.y - r * 0.1f)
        wingPath.cubicTo(
          basePos.x + side * r * 1.35f, basePos.y - r * 1.05f,
          basePos.x + side * r * 1.45f, basePos.y + r * 0.25f,
          basePos.x + side * r * 0.18f, basePos.y + r * 0.35f,
        )
        wingPath.close()
        drawPath(wingPath, color = AntGlow.copy(alpha = 0.42f * fade), blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver)
        drawPath(wingPath, color = Color.White.copy(alpha = 0.78f * fade), style = Stroke(width = 1.8f * scale))
      }
    }
    // Queen Emerald Abdomen & Thorax
    drawOval(
      brush = Brush.radialGradient(listOf(Color.White, AntGlow, AntPrimary), center = basePos, radius = r),
      topLeft = Offset(basePos.x - r * 0.56f, basePos.y - r * 0.35f),
      size = Size(r * 1.12f, r * 0.92f),
    )
    drawCircle(color = AntCore, radius = r * 0.44f, center = Offset(basePos.x, basePos.y - r * 0.35f))
    // Compound eyes
    drawCircle(color = Color(0xFF0A140E), radius = r * 0.11f, center = Offset(basePos.x - r * 0.18f, basePos.y - r * 0.42f))
    drawCircle(color = Color(0xFF0A140E), radius = r * 0.11f, center = Offset(basePos.x + r * 0.18f, basePos.y - r * 0.42f))
  } else {
    // King Ant: Horned Warlord Carapace + Crimson-Gold Pulse Ring
    val pulseRadius = r * (1.28f + 0.18f * sin(timeSec * 8f))
    drawCircle(
      color = AntGlow.copy(alpha = 0.40f * fade),
      radius = pulseRadius,
      center = basePos,
      style = Stroke(width = 3.2f * scale),
      blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
    )
    // Heavy Armored Body
    drawCircle(
      brush = Brush.radialGradient(listOf(Color.White, GoldAccent, CrimsonDanger), center = basePos, radius = r * 0.95f),
      radius = r * 0.74f,
      center = basePos,
    )
    // Twin Curved Warlord Horns
    bodyPath.reset()
    bodyPath.moveTo(basePos.x - r * 0.32f, basePos.y - r * 0.48f)
    bodyPath.quadraticTo(basePos.x - r * 0.85f, basePos.y - r * 1.10f, basePos.x - r * 0.18f, basePos.y - r * 1.25f)
    drawPath(bodyPath, color = GoldAccent, style = Stroke(width = 4.6f * scale, cap = StrokeCap.Round))
    bodyPath.reset()
    bodyPath.moveTo(basePos.x + r * 0.32f, basePos.y - r * 0.48f)
    bodyPath.quadraticTo(basePos.x + r * 0.85f, basePos.y - r * 1.10f, basePos.x + r * 0.18f, basePos.y - r * 1.25f)
    drawPath(bodyPath, color = GoldAccent, style = Stroke(width = 4.6f * scale, cap = StrokeCap.Round))
    // Glowing fierce warlord eyes
    drawCircle(color = Color.White, radius = r * 0.13f, center = Offset(basePos.x - r * 0.24f, basePos.y - r * 0.18f))
    drawCircle(color = Color.White, radius = r * 0.13f, center = Offset(basePos.x + r * 0.24f, basePos.y - r * 0.18f))
  }

  // Royal 3-spike Crown
  crownPath.reset()
  crownPath.moveTo(basePos.x - r * 0.52f, basePos.y - r * 0.58f)
  crownPath.lineTo(basePos.x - r * 0.30f, basePos.y - r * 1.08f)
  crownPath.lineTo(basePos.x, basePos.y - r * 0.74f)
  crownPath.lineTo(basePos.x + r * 0.30f, basePos.y - r * 1.08f)
  crownPath.lineTo(basePos.x + r * 0.52f, basePos.y - r * 0.58f)
  crownPath.close()
  drawPath(crownPath, color = (if (unit.isQueen) AntGlow else GoldAccent).copy(alpha = fade))
  drawPath(crownPath, color = Color.White.copy(alpha = fade), style = Stroke(width = 2.0f * scale, join = StrokeJoin.Round))

  // Remaining lifetime arc
  val lifePct = (unit.remainingLife / unit.maxLife.coerceAtLeast(0.1f)).coerceIn(0f, 1f)
  drawArc(
    color = rimColor.copy(alpha = 0.92f),
    startAngle = -90f,
    sweepAngle = 360f * lifePct,
    useCenter = false,
    topLeft = Offset(basePos.x - r * 1.18f, basePos.y - r * 1.18f),
    size = Size(r * 2.36f, r * 2.36f),
    style = Stroke(width = 3.2f * scale, cap = StrokeCap.Round),
  )
}

private fun DrawScope.drawFullArenaFrostOverlay(
  path: Path,
  diamondPath: Path,
  originX: Float,
  originY: Float,
  boxW: Float,
  boxH: Float,
  center: Offset,
  scale: Float,
  timeSec: Float,
  freezeAlpha: Float,
  bloomOn: Boolean,
  highOrUltra: Boolean,
) {
  drawRoundRect(
    brush =
      Brush.radialGradient(
        colors = listOf(
          IceCore.copy(alpha = freezeAlpha * 0.16f),
          IcePrimary.copy(alpha = freezeAlpha * 0.30f),
          IceGlow.copy(alpha = freezeAlpha * 0.44f),
        ),
        center = center,
        radius = boxH * 0.72f,
      ),
    topLeft = Offset(originX, originY),
    size = Size(boxW, boxH),
    cornerRadius = CornerRadius(18f * scale, 18f * scale),
  )

  val fractureCount = if (highOrUltra) 12 else 7
  for (i in 0 until fractureCount) {
    val angle = (i * (2f * PI.toFloat() / fractureCount)) + 0.25f
    val len1 = boxW * (0.28f + (i % 3) * 0.11f)
    val mid = Offset(center.x + cos(angle) * len1 * 0.52f, center.y + sin(angle) * len1 * 0.52f)
    val end = Offset(
      (center.x + cos(angle + 0.12f) * len1).coerceIn(originX + 8f * scale, originX + boxW - 8f * scale),
      (center.y + sin(angle + 0.12f) * len1 * 1.15f).coerceIn(originY + 8f * scale, originY + boxH - 8f * scale),
    )
    drawLine(
      color = IceGlow.copy(alpha = freezeAlpha * 0.62f),
      start = center,
      end = mid,
      strokeWidth = 3.0f * scale,
      cap = StrokeCap.Round,
      blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
    )
    drawLine(
      color = Color.White.copy(alpha = freezeAlpha * 0.75f),
      start = mid,
      end = end,
      strokeWidth = 1.9f * scale,
      cap = StrokeCap.Round,
    )
    if (highOrUltra) {
      val forkAngle = angle - 0.42f
      val forkEnd = Offset(
        (mid.x + cos(forkAngle) * len1 * 0.40f).coerceIn(originX + 8f * scale, originX + boxW - 8f * scale),
        (mid.y + sin(forkAngle) * len1 * 0.40f).coerceIn(originY + 8f * scale, originY + boxH - 8f * scale),
      )
      drawLine(
        color = IceGlow.copy(alpha = freezeAlpha * 0.52f),
        start = mid,
        end = forkEnd,
        strokeWidth = 1.6f * scale,
        cap = StrokeCap.Round,
      )
    }
  }

  val teethH = if (highOrUltra) 12 else 8
  val stepX = boxW / teethH
  for (k in 0 until teethH) {
    val tx = originX + k * stepX
    val spikeLen = (24f + (k % 3) * 14f) * scale
    path.reset()
    path.moveTo(tx, originY)
    path.lineTo(tx + stepX * 0.5f, originY + spikeLen)
    path.lineTo(tx + stepX, originY)
    path.close()
    drawPath(path, color = IceGlow.copy(alpha = freezeAlpha * 0.52f))
    drawPath(path, color = Color.White.copy(alpha = freezeAlpha * 0.72f), style = Stroke(width = 1.5f * scale))

    path.reset()
    path.moveTo(tx, originY + boxH)
    path.lineTo(tx + stepX * 0.5f, originY + boxH - spikeLen)
    path.lineTo(tx + stepX, originY + boxH)
    path.close()
    drawPath(path, color = IceGlow.copy(alpha = freezeAlpha * 0.52f))
    drawPath(path, color = Color.White.copy(alpha = freezeAlpha * 0.72f), style = Stroke(width = 1.5f * scale))
  }

  if (highOrUltra) {
    val hexRadius = 158f * scale * (0.95f + 0.05f * sin(timeSec * 3.5f))
    path.reset()
    for (h in 0 until 6) {
      val ha = h * (PI.toFloat() / 3f) + timeSec * 0.25f
      val hx = center.x + cos(ha) * hexRadius
      val hy = center.y + sin(ha) * hexRadius
      if (h == 0) path.moveTo(hx, hy) else path.lineTo(hx, hy)
    }
    path.close()
    drawPath(
      path = path,
      color = IceGlow.copy(alpha = freezeAlpha * 0.44f),
      style = Stroke(width = 2.4f * scale, join = StrokeJoin.Round),
      blendMode = if (bloomOn) BlendMode.Plus else BlendMode.SrcOver,
    )

    for (c in 0 until 14) {
      val driftX = ((c * 0.137f + timeSec * (0.04f + (c % 3) * 0.015f)) % 0.88f) + 0.06f
      val driftY = ((c * 0.219f + timeSec * (0.08f + (c % 4) * 0.02f)) % 0.88f) + 0.06f
      val cx = originX + boxW * driftX
      val cy = originY + boxH * driftY
      val pulse = 0.72f + 0.28f * sin(timeSec * 6f + c)
      val dr = (7.5f + (c % 3) * 2.5f) * scale * pulse
      diamondPath.reset()
      diamondPath.moveTo(cx, cy - dr)
      diamondPath.lineTo(cx + dr * 0.65f, cy)
      diamondPath.lineTo(cx, cy + dr)
      diamondPath.lineTo(cx - dr * 0.65f, cy)
      diamondPath.close()
      drawPath(diamondPath, color = Color.White.copy(alpha = freezeAlpha * 0.78f))
    }
  }
}

private fun DrawScope.drawSeismicFissures(
  path: Path,
  shardPath: Path,
  origin: Offset,
  boxW: Float,
  scale: Float,
  alpha: Float,
  bloomOn: Boolean,
  highOrUltra: Boolean,
) {
  val rays = if (highOrUltra) 9 else 6
  for (i in 0 until rays) {
    val angle = i * (2f * PI.toFloat() / rays) + 0.18f
    val reach = boxW * (0.36f + (i % 3) * 0.14f)
    val p1 = Offset(origin.x + cos(angle) * reach * 0.35f, origin.y + sin(angle) * reach * 0.35f)
    val p2 = Offset(origin.x + cos(angle + 0.14f) * reach * 0.68f, origin.y + sin(angle + 0.14f) * reach * 0.68f)
    val p3 = Offset(origin.x + cos(angle - 0.08f) * reach, origin.y + sin(angle - 0.08f) * reach)

    path.reset()
    path.moveTo(origin.x, origin.y)
    path.lineTo(p1.x, p1.y)
    path.lineTo(p2.x, p2.y)
    path.lineTo(p3.x, p3.y)
    if (bloomOn) {
      drawPath(
        path = path,
        color = GroundPrimary.copy(alpha = alpha * 0.55f),
        style = Stroke(width = 14f * scale, cap = StrokeCap.Round, join = StrokeJoin.Miter),
        blendMode = BlendMode.Plus,
      )
    }
    drawPath(
      path = path,
      color = GroundGlow.copy(alpha = alpha * 0.92f),
      style = Stroke(width = 4.2f * scale, cap = StrokeCap.Round, join = StrokeJoin.Miter),
    )
    if (highOrUltra) {
      shardPath.reset()
      shardPath.moveTo(p1.x, p1.y - 12f * scale * alpha)
      shardPath.lineTo(p1.x + 8f * scale, p1.y + 5f * scale)
      shardPath.lineTo(p1.x - 8f * scale, p1.y + 5f * scale)
      shardPath.close()
      drawPath(shardPath, color = GroundCore.copy(alpha = alpha * 0.90f))
      drawPath(shardPath, color = GroundGlow.copy(alpha = alpha * 0.95f), style = Stroke(width = 1.6f * scale))
    }
  }
}

private fun ballPalette(type: BallType): Triple<Color, Color, Color> =
  when (type) {
    BallType.FIRE -> Triple(FirePrimary, FireCore, FireGlow)
    BallType.WATER -> Triple(WaterPrimary, WaterCore, WaterGlow)
    BallType.GROUND -> Triple(GroundPrimary, GroundCore, GroundGlow)
    BallType.THUNDER -> Triple(ThunderPrimary, ThunderCore, ThunderGlow)
    BallType.ICE -> Triple(IcePrimary, IceCore, IceGlow)
    BallType.ANT -> Triple(AntPrimary, AntCore, AntGlow)
  }

private fun DrawScope.drawBallTrail(
  ball: BallEntity,
  scale: Float,
  isUltra: Boolean,
  bloomOn: Boolean,
  toScreen: (Float, Float) -> Offset,
) {
  val (outer, core, _) = ballPalette(ball.type)
  val count = ball.trail.size
  ball.trail.forEachIndexed { idx, pt ->
    val t = (idx + 1).toFloat() / count.coerceAtLeast(1)
    val c = toScreen(pt.x, pt.y)
    drawCircle(
      color = (if (idx % 2 == 0) outer else core).copy(alpha = t * (if (isUltra) 0.42f else 0.28f)),
      radius = BALL_RADIUS * scale * (0.30f + 0.68f * t),
      center = c,
      blendMode = if (isUltra && bloomOn) BlendMode.Plus else BlendMode.SrcOver,
    )
  }
}

private fun DrawScope.drawElementalBall(
  ball: BallEntity,
  alpha: Float,
  scale: Float,
  timeSec: Float,
  winnerId: Int,
  quality: GraphicsQuality,
  bloomEnabled: Boolean,
  glowMul: Float,
  scaleMul: Float,
  pathPool: ArenaPathPool,
  textMeasurer: TextMeasurer,
  toScreen: (Float, Float) -> Offset,
) {
  val wx = ball.prevX + (ball.x - ball.prevX) * alpha
  val wy = ball.prevY + (ball.y - ball.prevY) * alpha
  val center = toScreen(wx, wy)
  val r = BALL_RADIUS * scale
  val (outerColor, coreColor, glowColor) = ballPalette(ball.type)
  val highDetail = quality.tierRank >= GraphicsQuality.HIGH.tierRank
  val ultraDetail = quality == GraphicsQuality.ULTRA

  // 1. Ambient Elemental Aura / Corona
  if (bloomEnabled) {
    val rageBoost = 1f + (ball.rage / 100f) * 0.45f
    val auraRadius = r * (if (ultraDetail) 2.55f else 2.15f) * rageBoost * scaleMul
    drawCircle(
      brush = Brush.radialGradient(
        listOf(
          outerColor.copy(alpha = (0.65f * glowMul).coerceAtMost(0.95f)),
          glowColor.copy(alpha = (0.24f * glowMul).coerceAtMost(0.52f)),
          Color.Transparent,
        ),
        center = center,
        radius = auraRadius,
      ),
      radius = auraRadius,
      center = center,
      blendMode = BlendMode.Plus,
    )
  }

  // 2. Signature Outer Elemental Status Auras
  if (ball.earthArmorTimer > 0f) {
    val plates = 8
    for (p in 0 until plates) {
      val ang = (timeSec * 150f + p * (360f / plates))
      drawArc(
        color = GroundGlow,
        startAngle = ang,
        sweepAngle = 32f,
        useCenter = false,
        topLeft = Offset(center.x - r * 1.40f * scaleMul, center.y - r * 1.40f * scaleMul),
        size = Size(r * 2.80f * scaleMul, r * 2.80f * scaleMul),
        style = Stroke(width = 7.5f * scale, cap = StrokeCap.Round),
      )
    }
    rotate(degrees = -timeSec * 85f, pivot = center) {
      val shieldHex = pathPool.workPath.apply {
        reset()
        for (i in 0 until 8) {
          val a = i * (PI.toFloat() / 4f)
          val px = center.x + cos(a) * r * 1.32f
          val py = center.y + sin(a) * r * 1.32f
          if (i == 0) moveTo(px, py) else lineTo(px, py)
        }
        close()
      }
      drawPath(shieldHex, color = GroundPrimary.copy(alpha = 0.25f))
      drawPath(shieldHex, color = GroundGlow.copy(alpha = 0.85f), style = Stroke(width = 2.6f * scale))
    }
  }
  if (ball.burnTimer > 0f || ball.soulBurnTimer > 0f) {
    drawCircle(color = FireGlow.copy(alpha = 0.90f), radius = r * 1.28f, center = center, style = Stroke(width = 4.6f * scale))
  }
  if (ball.venomTimer > 0f || ball.antSlowStacks.isNotEmpty()) {
    drawCircle(color = AntCore.copy(alpha = 0.86f), radius = r * 1.32f, center = center, style = Stroke(width = 3.8f * scale))
  }
  if (ball.soakTimer > 0f) {
    drawCircle(color = WaterGlow.copy(alpha = 0.80f), radius = r * 1.24f, center = center, style = Stroke(width = 3.8f * scale))
  }
  if (ball.postFreezeSlowTimer > 0f && ball.frozenTimer <= 0f) {
    drawCircle(
      color = IceGlow.copy(alpha = 0.88f),
      radius = r * 1.30f,
      center = center,
      style = Stroke(width = 4.0f * scale, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f * scale, 6f * scale))),
    )
  }
  if (ball.silenceTimer > 0f) {
    drawCircle(color = ThunderPrimary.copy(alpha = 0.90f), radius = r * 1.28f, center = center, style = Stroke(width = 3.8f * scale))
  }

  // Rotating Halo Geometry (Max VFX across all 6 balls)
  if (highDetail) {
    when (ball.type) {
      BallType.FIRE -> {
        rotate(degrees = ball.rotationDeg * 0.9f, pivot = center) {
          for (k in 0 until 8) {
            val a = k * (PI.toFloat() / 4f)
            val tip = Offset(center.x + cos(a) * r * 1.38f, center.y + sin(a) * r * 1.38f)
            val left = Offset(center.x + cos(a - 0.14f) * r * 1.02f, center.y + sin(a - 0.14f) * r * 1.02f)
            val right = Offset(center.x + cos(a + 0.14f) * r * 1.02f, center.y + sin(a + 0.14f) * r * 1.02f)
            pathPool.workPath.apply {
              reset()
              moveTo(tip.x, tip.y); lineTo(left.x, left.y); lineTo(right.x, right.y); close()
            }
            drawPath(pathPool.workPath, color = FirePrimary.copy(alpha = 0.72f), blendMode = if (bloomEnabled) BlendMode.Plus else BlendMode.SrcOver)
          }
        }
      }
      BallType.WATER -> {
        rotate(degrees = -timeSec * 125f, pivot = center) {
          drawArc(
            color = WaterGlow.copy(alpha = 0.78f),
            startAngle = 10f, sweepAngle = 125f, useCenter = false,
            topLeft = Offset(center.x - r * 1.26f, center.y - r * 1.26f),
            size = Size(r * 2.52f, r * 2.52f),
            style = Stroke(width = 4.0f * scale, cap = StrokeCap.Round),
          )
          drawArc(
            color = Color.White.copy(alpha = 0.65f),
            startAngle = 190f, sweepAngle = 115f, useCenter = false,
            topLeft = Offset(center.x - r * 1.26f, center.y - r * 1.26f),
            size = Size(r * 2.52f, r * 2.52f),
            style = Stroke(width = 2.8f * scale, cap = StrokeCap.Round),
          )
          for (d in 0 until 3) {
            val da = d * (2f * PI.toFloat() / 3f)
            drawCircle(color = WaterGlow, radius = r * 0.10f, center = Offset(center.x + cos(da) * r * 1.34f, center.y + sin(da) * r * 1.34f))
          }
        }
      }
      BallType.GROUND -> {
        rotate(degrees = timeSec * 70f, pivot = center) {
          for (k in 0 until 4) {
            val a = k * (PI.toFloat() / 2f)
            val bx = center.x + cos(a) * r * 1.34f
            val by = center.y + sin(a) * r * 1.34f
            drawCircle(color = GroundCore, radius = r * 0.17f, center = Offset(bx, by))
            drawCircle(color = GroundGlow, radius = r * 0.17f, center = Offset(bx, by), style = Stroke(width = 1.8f * scale))
          }
        }
      }
      BallType.THUNDER -> {
        rotate(degrees = timeSec * 280f, pivot = center) {
          drawArc(
            color = ThunderGlow.copy(alpha = 0.90f),
            startAngle = 0f, sweepAngle = 82f, useCenter = false,
            topLeft = Offset(center.x - r * 1.30f, center.y - r * 1.30f),
            size = Size(r * 2.60f, r * 2.60f),
            style = Stroke(width = 3.8f * scale, cap = StrokeCap.Round),
          )
          drawArc(
            color = Color.White.copy(alpha = 0.85f),
            startAngle = 180f, sweepAngle = 82f, useCenter = false,
            topLeft = Offset(center.x - r * 1.30f, center.y - r * 1.30f),
            size = Size(r * 2.60f, r * 2.60f),
            style = Stroke(width = 3.2f * scale, cap = StrokeCap.Round),
          )
        }
      }
      BallType.ICE -> {
        rotate(degrees = -timeSec * 55f, pivot = center) {
          drawCircle(
            color = IceGlow.copy(alpha = 0.55f),
            radius = r * 1.24f,
            center = center,
            style = Stroke(width = 2.4f * scale, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f * scale, 7f * scale))),
          )
        }
      }
      BallType.ANT -> {
        rotate(degrees = timeSec * 105f, pivot = center) {
          for (k in 0 until 6) {
            val a = k * (PI.toFloat() / 3f)
            val px = center.x + cos(a) * r * 1.32f
            val py = center.y + sin(a) * r * 1.32f
            drawCircle(color = AntGlow.copy(alpha = 0.90f), radius = r * 0.12f, center = Offset(px, py))
          }
        }
      }
    }
  }

  // 3. Main Glass/Energy Sphere Core
  drawCircle(
    brush =
      Brush.radialGradient(
        colors =
          if (ball.flashTimer > 0f) listOf(Color.White, Color.White, outerColor)
          else listOf(Color.White, coreColor, outerColor),
        center = Offset(center.x - r * 0.28f, center.y - r * 0.28f),
        radius = r * 1.28f,
      ),
    radius = r,
    center = center,
  )

  // 4. Custom Elemental Inner Core Crest
  rotate(degrees = ball.rotationDeg * 0.4f, pivot = center) {
    when (ball.type) {
      BallType.FIRE -> {
        pathPool.crestPath.apply {
          reset()
          moveTo(center.x, center.y - r * 0.64f)
          lineTo(center.x + r * 0.28f, center.y - r * 0.14f)
          lineTo(center.x + r * 0.64f, center.y)
          lineTo(center.x + r * 0.28f, center.y + r * 0.14f)
          lineTo(center.x, center.y + r * 0.64f)
          lineTo(center.x - r * 0.28f, center.y + r * 0.14f)
          lineTo(center.x - r * 0.64f, center.y)
          lineTo(center.x - r * 0.28f, center.y - r * 0.14f)
          close()
        }
        drawPath(pathPool.crestPath, color = Color.White.copy(alpha = 0.38f), style = Stroke(width = 2.4f * scale, join = StrokeJoin.Round))
      }
      BallType.WATER -> {
        drawCircle(color = Color.White.copy(alpha = 0.36f), radius = r * 0.56f, center = center, style = Stroke(width = 2.4f * scale))
      }
      BallType.GROUND -> {
        pathPool.crestPath.apply {
          reset()
          for (i in 0 until 6) {
            val a = i * (PI.toFloat() / 3f)
            val px = center.x + cos(a) * r * 0.60f
            val py = center.y + sin(a) * r * 0.60f
            if (i == 0) moveTo(px, py) else lineTo(px, py)
          }
          close()
        }
        drawPath(pathPool.crestPath, color = GroundGlow.copy(alpha = 0.55f), style = Stroke(width = 2.6f * scale, join = StrokeJoin.Round))
      }
      BallType.THUNDER -> {
        drawCircle(color = ThunderGlow.copy(alpha = 0.48f), radius = r * 0.64f, center = center, style = Stroke(width = 2.4f * scale))
      }
      BallType.ICE -> {
        for (i in 0 until 3) {
          val a = i * (PI.toFloat() / 3f)
          val dx = cos(a) * r * 0.60f
          val dy = sin(a) * r * 0.60f
          drawLine(
            color = Color.White.copy(alpha = 0.44f),
            start = Offset(center.x - dx, center.y - dy),
            end = Offset(center.x + dx, center.y + dy),
            strokeWidth = 2.0f * scale,
            cap = StrokeCap.Round,
          )
        }
      }
      BallType.ANT -> {
        pathPool.crestPath.apply {
          reset()
          for (i in 0 until 6) {
            val a = i * (PI.toFloat() / 3f) + 0.52f
            val px = center.x + cos(a) * r * 0.64f
            val py = center.y + sin(a) * r * 0.64f
            if (i == 0) moveTo(px, py) else lineTo(px, py)
          }
          close()
        }
        drawPath(pathPool.crestPath, color = AntGlow.copy(alpha = 0.72f), style = Stroke(width = 2.5f * scale, join = StrokeJoin.Round))
      }
    }
  }

  // 4B. Procedural Ball Facial Expression
  drawBallExpression(ball = ball, winnerId = winnerId, center = center, r = r, scale = scale)

  // Specular gloss + Rim
  if (highDetail) {
    drawCircle(
      color = Color.White.copy(alpha = 0.36f),
      radius = r * 0.20f,
      center = Offset(center.x - r * 0.38f, center.y - r * 0.38f),
    )
  }
  drawCircle(
    color = if (ball.id == 1) Color.White.copy(alpha = 0.90f) else glowColor.copy(alpha = 0.94f),
    radius = r,
    center = center,
    style = Stroke(width = 3.0f * scale),
  )

  // 4C. Multi-Ball Ant Clone Indicator (#2 / #3) + Live HP Ring
  if (ball.cloneIndex > 1 || (ball.type == BallType.ANT && ball.hp > 0f && ball.hp < ball.maxHp)) {
    val hpFrac = (ball.hp / ball.maxHp.coerceAtLeast(1f)).coerceIn(0f, 1f)
    if (ball.cloneIndex > 1) {
      drawArc(
        color = AntGlow.copy(alpha = 0.92f),
        startAngle = -90f,
        sweepAngle = 360f * hpFrac,
        useCenter = false,
        topLeft = Offset(center.x - r * 1.15f, center.y - r * 1.15f),
        size = Size(r * 2.30f, r * 2.30f),
        style = Stroke(width = 3.2f * scale, cap = StrokeCap.Round),
      )
      val badgeLabel = "#${ball.cloneIndex}"
      val badgePos = Offset(center.x, center.y - r - 16f * scale)
      drawRoundRect(
        color = Color(0xEE0F172A),
        topLeft = Offset(badgePos.x - 16f * scale, badgePos.y - 10f * scale),
        size = Size(32f * scale, 20f * scale),
        cornerRadius = CornerRadius(7f * scale, 7f * scale),
      )
      val layout = textMeasurer.measure(
        text = badgeLabel,
        style = TextStyle(
          fontFamily = ChakraPetchFamily,
          fontWeight = FontWeight.Bold,
          fontSize = 10.sp,
          color = AntGlow,
        ),
      )
      drawText(
        textLayoutResult = layout,
        topLeft = Offset(badgePos.x - layout.size.width * 0.5f, badgePos.y - layout.size.height * 0.5f),
      )
    }
  }

  // 5. Frozen Octagonal Crystal Block + Jagged Ice Spike Cage + Thaw Countdown Arc
  if (ball.frozenTimer > 0f) {
    val cageFrac = (ball.frozenTimer / 10.0f).coerceIn(0f, 1f)
    val cagePulse = (0.45f + 0.55f * cageFrac).coerceIn(0.35f, 1f)
    val spikeCount = if (highDetail) 12 else 8
    drawCircle(
      brush = Brush.radialGradient(
        listOf(Color.White.copy(alpha = 0.44f * cagePulse), IceGlow.copy(alpha = 0.58f * cagePulse), IcePrimary.copy(alpha = 0.74f * cagePulse)),
        center = center,
        radius = r * 1.22f,
      ),
      radius = r * 1.18f,
      center = center,
    )
    // Translucent faceted octagonal ice prism around ball
    pathPool.auxPath.apply {
      reset()
      for (i in 0 until 8) {
        val a = i * (PI.toFloat() / 4f) + 0.2f
        val px = center.x + cos(a) * r * 1.24f
        val py = center.y + sin(a) * r * 1.24f
        if (i == 0) moveTo(px, py) else lineTo(px, py)
      }
      close()
    }
    drawPath(pathPool.auxPath, color = IceCore.copy(alpha = 0.34f * cagePulse))
    drawPath(pathPool.auxPath, color = Color.White.copy(alpha = 0.85f * cagePulse), style = Stroke(width = 2.4f * scale, join = StrokeJoin.Round))

    for (s in 0 until spikeCount) {
      val a = s * (2f * PI.toFloat() / spikeCount) + 0.15f
      val spikeReach = r * (if (s % 2 == 0) 1.76f else 1.48f) * scaleMul
      val baseHalfAngle = 0.24f
      val tip = Offset(center.x + cos(a) * spikeReach, center.y + sin(a) * spikeReach)
      val baseL = Offset(center.x + cos(a - baseHalfAngle) * r * 0.86f, center.y + sin(a - baseHalfAngle) * r * 0.86f)
      val baseR = Offset(center.x + cos(a + baseHalfAngle) * r * 0.86f, center.y + sin(a + baseHalfAngle) * r * 0.86f)

      val spikePath = pathPool.workPath.apply {
        reset()
        moveTo(tip.x, tip.y); lineTo(baseL.x, baseL.y); lineTo(baseR.x, baseR.y); close()
      }
      drawPath(
        path = spikePath,
        brush = Brush.linearGradient(
          colors = listOf(Color.White.copy(alpha = 0.94f * cagePulse), IceGlow.copy(alpha = 0.80f * cagePulse), IceCore.copy(alpha = 0.68f * cagePulse)),
          start = tip,
          end = center,
        ),
      )
      drawPath(
        path = spikePath,
        color = Color.White.copy(alpha = 0.90f * cagePulse),
        style = Stroke(width = 1.8f * scale, join = StrokeJoin.Round),
      )
    }

    drawArc(
      color = IceGlow.copy(alpha = 0.95f),
      startAngle = -90f,
      sweepAngle = 360f * cageFrac,
      useCenter = false,
      topLeft = Offset(center.x - r * 1.40f, center.y - r * 1.40f),
      size = Size(r * 2.80f, r * 2.80f),
      style = Stroke(width = 3.6f * scale, cap = StrokeCap.Round),
    )
  }

  // 6. Ground Ball Overhead Seismic Charge Gauge
  if (ball.seismicChargingTimer > 0f) {
    val pct = (1f - ball.seismicChargingTimer / 1.6f).coerceIn(0f, 1f)
    val barW = r * 2.3f
    val barH = 12f * scale
    val barTopLeft = Offset(center.x - barW * 0.5f, center.y - r - 26f * scale)
    drawRoundRect(Color(0xFF1A2233), topLeft = barTopLeft, size = Size(barW, barH), cornerRadius = CornerRadius(6f * scale))
    drawRoundRect(
      Brush.horizontalGradient(listOf(GroundPrimary, GroundGlow)),
      topLeft = barTopLeft,
      size = Size(barW * pct, barH),
      cornerRadius = CornerRadius(6f * scale),
    )
  }

  // 7. Ice Ball Orbiting Crystalline Shards
  if (ball.type == BallType.ICE && ball.orbitingShards > 0) {
    for (i in 0 until ball.orbitingShards) {
      val a = timeSec * 4.5f + i * (2f * PI.toFloat() / 5f)
      val sx = center.x + cos(a) * (r * 1.44f)
      val sy = center.y + sin(a) * (r * 1.44f)
      val sr = 9.5f * scale * scaleMul
      rotate(degrees = a * (180f / PI.toFloat()) + 90f, pivot = Offset(sx, sy)) {
        val diamond = pathPool.workPath.apply {
          reset()
          moveTo(sx, sy - sr); lineTo(sx + sr * 0.62f, sy); lineTo(sx, sy + sr); lineTo(sx - sr * 0.62f, sy); close()
        }
        drawPath(diamond, color = IceGlow)
        drawPath(diamond, color = Color.White, style = Stroke(width = 1.5f * scale))
      }
    }
  }
}

private fun DrawScope.drawBallExpression(
  ball: BallEntity,
  winnerId: Int,
  center: Offset,
  r: Float,
  scale: Float,
) {
  val eyeY = center.y - r * 0.12f
  val eyeDx = r * 0.28f
  val eyeDark = Color(0xFF0A0F1D)
  val isHurt = ball.flashTimer > 0f || ball.burnTimer > 0f || ball.soulBurnTimer > 0f || ball.trappedTimer > 0f || ball.venomTimer > 0f
  val isWon = winnerId == ball.id
  val isUltReady = ball.rage >= 85f || ball.earthArmorTimer > 0f || ball.antQueenTimer > 0f || ball.antKingTimer > 0f

  when {
    ball.frozenTimer > 0f -> {
      val s = r * 0.11f
      for (side in listOf(-1f, 1f)) {
        val ex = center.x + side * eyeDx
        drawLine(eyeDark, Offset(ex - s, eyeY - s), Offset(ex + s, eyeY + s), strokeWidth = 2.6f * scale, cap = StrokeCap.Round)
        drawLine(eyeDark, Offset(ex - s, eyeY + s), Offset(ex + s, eyeY - s), strokeWidth = 2.6f * scale, cap = StrokeCap.Round)
      }
      drawLine(eyeDark, Offset(center.x - r * 0.20f, center.y + r * 0.30f), Offset(center.x + r * 0.20f, center.y + r * 0.30f), strokeWidth = 2.6f * scale, cap = StrokeCap.Round)
    }
    isHurt -> {
      val s = r * 0.13f
      drawLine(eyeDark, Offset(center.x - eyeDx - s, eyeY - s * 0.7f), Offset(center.x - eyeDx + s * 0.5f, eyeY), strokeWidth = 2.8f * scale, cap = StrokeCap.Round)
      drawLine(eyeDark, Offset(center.x - eyeDx - s, eyeY + s * 0.7f), Offset(center.x - eyeDx + s * 0.5f, eyeY), strokeWidth = 2.8f * scale, cap = StrokeCap.Round)
      drawLine(eyeDark, Offset(center.x + eyeDx + s, eyeY - s * 0.7f), Offset(center.x + eyeDx - s * 0.5f, eyeY), strokeWidth = 2.8f * scale, cap = StrokeCap.Round)
      drawLine(eyeDark, Offset(center.x + eyeDx + s, eyeY + s * 0.7f), Offset(center.x + eyeDx - s * 0.5f, eyeY), strokeWidth = 2.8f * scale, cap = StrokeCap.Round)
      drawCircle(color = eyeDark, radius = r * 0.13f, center = Offset(center.x, center.y + r * 0.28f))
    }
    isWon -> {
      drawArc(eyeDark, startAngle = 190f, sweepAngle = 160f, useCenter = false, topLeft = Offset(center.x - eyeDx - r * 0.12f, eyeY - r * 0.10f), size = Size(r * 0.24f, r * 0.22f), style = Stroke(width = 3.0f * scale, cap = StrokeCap.Round))
      drawArc(eyeDark, startAngle = 190f, sweepAngle = 160f, useCenter = false, topLeft = Offset(center.x + eyeDx - r * 0.12f, eyeY - r * 0.10f), size = Size(r * 0.24f, r * 0.22f), style = Stroke(width = 3.0f * scale, cap = StrokeCap.Round))
      drawArc(eyeDark, startAngle = 15f, sweepAngle = 150f, useCenter = false, topLeft = Offset(center.x - r * 0.20f, center.y + r * 0.10f), size = Size(r * 0.40f, r * 0.28f), style = Stroke(width = 3.0f * scale, cap = StrokeCap.Round))
    }
    else -> {
      val pupilColor = if (isUltReady) Color.White else eyeDark
      drawCircle(color = eyeDark, radius = r * 0.13f, center = Offset(center.x - eyeDx, eyeY))
      drawCircle(color = eyeDark, radius = r * 0.13f, center = Offset(center.x + eyeDx, eyeY))
      drawCircle(color = if (isUltReady) GoldAccent else Color.White, radius = r * 0.055f, center = Offset(center.x - eyeDx + r * 0.03f, eyeY - r * 0.03f))
      drawCircle(color = if (isUltReady) GoldAccent else Color.White, radius = r * 0.055f, center = Offset(center.x + eyeDx + r * 0.03f, eyeY - r * 0.03f))
      drawLine(pupilColor, Offset(center.x - eyeDx - r * 0.14f, eyeY - r * 0.20f), Offset(center.x - eyeDx + r * 0.12f, eyeY - r * 0.12f), strokeWidth = 2.6f * scale, cap = StrokeCap.Round)
      drawLine(pupilColor, Offset(center.x + eyeDx + r * 0.14f, eyeY - r * 0.20f), Offset(center.x + eyeDx - r * 0.12f, eyeY - r * 0.12f), strokeWidth = 2.6f * scale, cap = StrokeCap.Round)
      drawArc(eyeDark, startAngle = 15f, sweepAngle = 150f, useCenter = false, topLeft = Offset(center.x - r * 0.16f, center.y + r * 0.16f), size = Size(r * 0.32f, r * 0.20f), style = Stroke(width = 2.5f * scale, cap = StrokeCap.Round))
    }
  }
}

private fun DrawScope.drawAimTrajectory(
  ball: BallEntity,
  scale: Float,
  toScreen: (Float, Float) -> Offset,
) {
  val start = toScreen(ball.x, ball.y)
  val length = 270f * scale
  val end = Offset(start.x + cos(ball.aimAngleRad) * length, start.y + sin(ball.aimAngleRad) * length)
  val (_, _, guideColor) = ballPalette(ball.type)
  drawLine(
    color = guideColor,
    start = start,
    end = end,
    strokeWidth = 5.5f * scale,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f * scale, 12f * scale), 0f),
    cap = StrokeCap.Round,
  )
  drawCircle(color = guideColor, radius = 11f * scale, center = end)
  drawCircle(color = Color.White, radius = 5f * scale, center = end)
}

private fun DrawScope.drawDamagePopup(
  textMeasurer: TextMeasurer,
  text: String,
  pos: Offset,
  color: Color,
  isCrit: Boolean,
) {
  val layoutResult =
    textMeasurer.measure(
      text = text,
      style =
        TextStyle(
          fontFamily = ChakraPetchFamily,
          fontWeight = FontWeight.Bold,
          fontSize = if (isCrit) 21.sp else 16.sp,
          color = color,
        ),
    )
  drawText(
    textLayoutResult = layoutResult,
    topLeft = Offset(pos.x - layoutResult.size.width * 0.5f, pos.y - layoutResult.size.height * 0.5f),
  )
}
