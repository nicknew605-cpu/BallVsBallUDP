package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.AppLanguage
import com.example.model.BallType
import com.example.model.CodeRedeemResult
import com.example.model.DailyRewardTier
import com.example.model.UserProgress
import com.example.ui.components.AdmVipBadge
import com.example.ui.components.AnimatedElementBallBadge
import com.example.ui.components.CodeRedeemDialog
import com.example.ui.components.CoinPill
import com.example.ui.components.DailyLoginRewardDialog
import com.example.ui.components.ExportApkDialog
import com.example.ui.components.GameLogoCutoutBadge
import com.example.ui.components.TanThuCountdownBanner
import com.example.ui.components.ballAccentColor
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.FireGlow
import com.example.ui.theme.FirePrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianGlass
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.RarityUncommonColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ThunderPrimary
import com.example.ui.theme.WaterCore
import com.example.ui.theme.WaterPrimary
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MenuScreen(
  strings: GameStrings,
  language: AppLanguage,
  progress: UserProgress,
  nowMillis: Long,
  unreadMailCount: Int,
  otaCloudSynced: Boolean,
  isGuestMode: Boolean,
  isAdmin: Boolean = false,
  adminNotice: String = "",
  adminNoticeRemainingMillis: Long = 0L,
  onStartClick: () -> Unit,
  onOnline1v1Click: () -> Unit,
  onLinkGoogleClick: (navigateToOnline: Boolean) -> Unit,
  onVaultClick: () -> Unit,
  onMailboxClick: () -> Unit,
  onShopClick: () -> Unit,
  onFriendsClick: () -> Unit = {},
  pendingFriendRequestsCount: Int = 0,
  onSettingsClick: () -> Unit,
  onAdminOtaClick: () -> Unit = {},
  onClaimDailyReward: suspend () -> DailyRewardTier?,
  onRedeemCode: suspend (String) -> CodeRedeemResult,
) {
  var showCodeDialog by remember { mutableStateOf(false) }
  var showExportApkDialog by remember { mutableStateOf(false) }
  var showDailyDialog by remember { mutableStateOf(false) }
  var showGoogleOnlineDialog by remember { mutableStateOf(false) }
  var animTime by remember { mutableLongStateOf(0L) }

  val dailyClaimable = progress.isDailyClaimable(nowMillis)

  LaunchedEffect(Unit) {
    val startNanos = System.nanoTime()
    while (true) {
      withFrameNanos { frameNanos -> animTime = (frameNanos - startNanos) / 1_000_000L }
    }
  }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.verticalGradient(listOf(Color(0xFF0A101E), ObsidianBg, Color(0xFF05070B)))
        )
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val t = animTime / 1000f
      val balls = BallType.entries
      for (i in 0 until 20) {
        val color = ballAccentColor(balls[i % balls.size])
        val angle = t * (0.35f + (i % 5) * 0.08f) + i * 1.1f
        val x = size.width * (0.10f + 0.80f * ((i * 37 % 100) / 100f)) + cos(angle) * 28f
        val y = size.height * (0.10f + 0.80f * ((i * 53 % 100) / 100f)) + sin(angle) * 32f
        drawCircle(
          color = color.copy(alpha = 0.14f),
          radius = (5f + (i % 4) * 4.5f),
          center = Offset(x, y),
        )
      }
    }

    Column(
      modifier =
        Modifier.fillMaxSize()
          .windowInsetsPadding(WindowInsets.safeDrawing)
          .padding(horizontal = 16.dp, vertical = 12.dp)
          .widthIn(max = 580.dp)
          .align(Alignment.Center)
          .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      // Top Esports Header Bar
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        CoinPill(coins = progress.coins, label = strings.coinsLabel)

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          if (isAdmin) {
            AdmVipBadge(label = strings.admBadgeLabel)
          }
          Surface(
            shape = RoundedCornerShape(999.dp),
            color = ObsidianSurfaceElevated,
            border = BorderStroke(1.dp, if (isAdmin) GoldAccent.copy(alpha = 0.65f) else ObsidianBorder),
          ) {
            Text(
              text = "${progress.nickname} • W ${progress.totalWins}/${progress.totalMatches}",
              style = MaterialTheme.typography.labelLarge,
              color = TextPrimary,
              maxLines = 1,
              softWrap = false,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
            )
          }
        }
      }

      // Status Pills Row (Version, ID, Sync / Guest Mode, Admin)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Surface(
            shape = RoundedCornerShape(999.dp),
            color = RarityUncommonColor.copy(alpha = 0.14f),
            border = BorderStroke(1.dp, RarityUncommonColor.copy(alpha = 0.48f)),
          ) {
            Text(
              text = strings.versionBadge,
              style = MaterialTheme.typography.labelSmall,
              color = RarityUncommonColor,
              maxLines = 1,
              softWrap = false,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            )
          }
          if (progress.playerCode.isNotBlank()) {
            Surface(
              shape = RoundedCornerShape(999.dp),
              color = WaterPrimary.copy(alpha = 0.12f),
              border = BorderStroke(1.dp, WaterPrimary.copy(alpha = 0.45f)),
            ) {
              Text(
                text = progress.playerCode,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = WaterPrimary,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              )
            }
          }
        }

        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (isGuestMode) {
            Surface(
              onClick = { onLinkGoogleClick(false) },
              shape = RoundedCornerShape(999.dp),
              color = WaterPrimary.copy(alpha = 0.14f),
              border = BorderStroke(1.dp, WaterPrimary.copy(alpha = 0.6f)),
              modifier = Modifier.testTag("menu_link_google_button"),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
              ) {
                Icon(Icons.AutoMirrored.Filled.Login, contentDescription = null, tint = WaterPrimary, modifier = Modifier.size(13.dp))
                Text(
                  text = strings.linkGoogleButton,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = WaterPrimary,
                  maxLines = 1,
                  softWrap = false,
                )
              }
            }
          } else {
            Surface(
              shape = RoundedCornerShape(999.dp),
              color = (if (otaCloudSynced) EmeraldSuccess else GoldAccent).copy(alpha = 0.12f),
              border = BorderStroke(1.dp, (if (otaCloudSynced) EmeraldSuccess else GoldAccent).copy(alpha = 0.45f)),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
              ) {
                Icon(
                  Icons.Default.CloudDone,
                  contentDescription = null,
                  tint = if (otaCloudSynced) EmeraldSuccess else GoldAccent,
                  modifier = Modifier.size(13.dp),
                )
                Text(
                  text = if (otaCloudSynced) strings.loadingOtaCloudSynced else strings.loadingOtaOffline,
                  style = MaterialTheme.typography.labelSmall,
                  color = if (otaCloudSynced) EmeraldSuccess else GoldAccent,
                  maxLines = 1,
                  softWrap = false,
                )
              }
            }
          }

          if (isAdmin) {
            Surface(
              onClick = onAdminOtaClick,
              shape = RoundedCornerShape(999.dp),
              color = GoldAccent.copy(alpha = 0.18f),
              border = BorderStroke(1.dp, GoldAccent),
              modifier = Modifier.testTag("menu_admin_ota_button"),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                Icon(Icons.Default.AdminPanelSettings, contentDescription = strings.adminButton, tint = GoldAccent, modifier = Modifier.size(14.dp))
                Text(
                  text = strings.adminButton,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = GoldAccent,
                  maxLines = 1,
                  softWrap = false,
                )
              }
            }
          }
        }
      }

      if (adminNotice.isNotBlank()) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = ThunderPrimary.copy(alpha = 0.12f),
          border = BorderStroke(1.dp, ThunderPrimary.copy(alpha = 0.50f)),
          modifier = Modifier.fillMaxWidth().testTag("menu_admin_notice_banner"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(Icons.Default.Campaign, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(18.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = adminNotice,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
              )
              if (adminNoticeRemainingMillis > 0L) {
                val hrs = adminNoticeRemainingMillis / 3_600_000L
                val mins = (adminNoticeRemainingMillis % 3_600_000L) / 60_000L
                Text(
                  text = "${strings.adminNoticeExpiresPrefix}: ${String.format(Locale.US, "%dh %02dm", hrs, mins)}",
                  style = MaterialTheme.typography.labelSmall,
                  color = GoldAccent,
                )
              }
            }
          }
        }
      }

      if (progress.isTanThuActive(nowMillis)) {
        TanThuCountdownBanner(
          remainingMillis = progress.tanThuRemainingMillis(nowMillis),
          prefix = strings.tanThuBannerPrefix,
        )
      }

      // Esports Hero Card with Transparent PNG Cutout
      Surface(
        shape = RoundedCornerShape(22.dp),
        color = ObsidianGlass,
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(vertical = 15.dp, horizontal = 14.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            AnimatedElementBallBadge(type = progress.equippedBall, size = 54.dp)
            GameLogoCutoutBadge(size = 86.dp)
            AnimatedElementBallBadge(
              type = if (progress.equippedBall == BallType.ANT) BallType.THUNDER else BallType.ANT,
              size = 54.dp,
            )
          }
          Text(
            text = strings.appTitle,
            style = MaterialTheme.typography.displayLarge,
            color = TextPrimary,
            textAlign = TextAlign.Center,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = strings.subtitle,
            style = MaterialTheme.typography.labelLarge,
            color = WaterPrimary,
            textAlign = TextAlign.Center,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      // Primary 2-Column Combat Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = onStartClick,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
          contentPadding = PaddingValues(0.dp),
          modifier = Modifier.weight(1f).height(56.dp).testTag("menu_start_button"),
        ) {
          Box(
            modifier =
              Modifier.fillMaxSize()
                .background(
                  Brush.horizontalGradient(listOf(FireGlow, FirePrimary, WaterCore)),
                  shape = RoundedCornerShape(16.dp),
                )
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = strings.startButton, tint = Color.White, modifier = Modifier.size(22.dp))
              Text(
                text = strings.startButton,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }

        Button(
          onClick = {
            if (isGuestMode) showGoogleOnlineDialog = true
            else onOnline1v1Click()
          },
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = ThunderPrimary, contentColor = Color.Black),
          contentPadding = PaddingValues(horizontal = 10.dp),
          modifier = Modifier.weight(1f).height(56.dp).testTag("menu_online_1v1_button"),
        ) {
          Icon(Icons.Default.Groups, contentDescription = strings.online1v1Button, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = strings.online1v1Button,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      // Compact 2-Column Menu Grid
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MenuGridTile(
          title = strings.vaultButton,
          icon = Icons.Default.Inventory2,
          accent = RarityUncommonColor,
          testTag = "menu_vault_button",
          modifier = Modifier.weight(1f),
          onClick = onVaultClick,
        )
        MenuGridTile(
          title = strings.shopButton,
          icon = Icons.Default.Casino,
          accent = WaterPrimary,
          testTag = "menu_shop_button",
          modifier = Modifier.weight(1f),
          onClick = onShopClick,
        )
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MenuGridTile(
          title = strings.dailyRewardButton,
          icon = Icons.Default.CalendarMonth,
          accent = GoldAccent,
          badgeCount = if (dailyClaimable) 1 else 0,
          testTag = "menu_daily_reward_button",
          modifier = Modifier.weight(1f),
          onClick = { showDailyDialog = true },
        )
        MenuGridTile(
          title = strings.mailboxButton,
          icon = Icons.Default.Mail,
          accent = ThunderPrimary,
          badgeCount = unreadMailCount,
          testTag = "menu_mailbox_button",
          modifier = Modifier.weight(1f),
          onClick = onMailboxClick,
        )
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MenuGridTile(
          title = strings.codeButton,
          icon = Icons.Default.CardGiftcard,
          accent = FirePrimary,
          testTag = "menu_code_button",
          modifier = Modifier.weight(1f),
          onClick = { showCodeDialog = true },
        )
        MenuGridTile(
          title = strings.settingsButton,
          icon = Icons.Default.Settings,
          accent = TextPrimary,
          testTag = "menu_settings_button",
          modifier = Modifier.weight(1f),
          onClick = onSettingsClick,
        )
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MenuGridTile(
          title = strings.friendsButton,
          icon = Icons.Default.Group,
          accent = WaterPrimary,
          badgeCount = pendingFriendRequestsCount,
          testTag = "menu_friends_button",
          modifier = Modifier.weight(1f),
          onClick = onFriendsClick,
        )
        MenuGridTile(
          title = strings.exportApkButton,
          icon = Icons.Default.Android,
          accent = EmeraldSuccess,
          testTag = "menu_export_apk_button",
          modifier = Modifier.weight(1f),
          onClick = { showExportApkDialog = true },
        )
      }
    }
  }

  if (showDailyDialog) {
    DailyLoginRewardDialog(
      strings = strings,
      language = language,
      progress = progress,
      nowMillis = nowMillis,
      onClaimDaily = onClaimDailyReward,
      onDismiss = { showDailyDialog = false },
    )
  }

  if (showCodeDialog) {
    CodeRedeemDialog(
      strings = strings,
      onDismiss = { showCodeDialog = false },
      onRedeem = onRedeemCode,
      onResultReady = {},
    )
  }

  if (showExportApkDialog) {
    ExportApkDialog(
      strings = strings,
      onDismiss = { showExportApkDialog = false },
    )
  }

  if (showGoogleOnlineDialog) {
    AlertDialog(
      onDismissRequest = { showGoogleOnlineDialog = false },
      containerColor = ObsidianSurface,
      title = { Text(strings.online1v1Button, color = GoldAccent) },
      text = { Text(strings.onlineRequiresGoogleMsg, color = TextSecondary) },
      confirmButton = {
        Button(
          onClick = {
            showGoogleOnlineDialog = false
            onLinkGoogleClick(true)
          },
          colors = ButtonDefaults.buttonColors(containerColor = FirePrimary, contentColor = Color.White),
          modifier = Modifier.height(48.dp),
        ) {
          Icon(Icons.AutoMirrored.Filled.Login, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(strings.authGoogleSignInButton, maxLines = 1, softWrap = false)
        }
      },
      dismissButton = {
        TextButton(onClick = { showGoogleOnlineDialog = false }, modifier = Modifier.height(48.dp)) {
          Text(strings.cancel, color = TextSecondary)
        }
      },
    )
  }
}

@Composable
private fun MenuGridTile(
  title: String,
  icon: ImageVector,
  accent: Color,
  testTag: String,
  badgeCount: Int = 0,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(16.dp),
    color = ObsidianSurface,
    border = BorderStroke(1.dp, accent.copy(alpha = 0.42f)),
    tonalElevation = 4.dp,
    modifier = modifier.height(66.dp).testTag(testTag),
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.Center,
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      if (badgeCount > 0) {
        BadgedBox(badge = { Badge { Text("$badgeCount") } }) {
          Icon(imageVector = icon, contentDescription = title, tint = accent, modifier = Modifier.size(21.dp))
        }
      } else {
        Icon(imageVector = icon, contentDescription = title, tint = accent, modifier = Modifier.size(21.dp))
      }
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = TextPrimary,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
      )
    }
  }
}
