package com.example.data.cloud

import android.content.Context
import com.example.R
import com.example.model.ADMIN_OWNER_EMAIL
import com.example.model.BallType
import com.example.model.MatchmakingTicketEntry
import com.example.model.ONLINE_FT3_TARGET_SCORE
import com.example.model.OnlineEmote
import com.example.model.OnlineRoomPhase
import com.example.model.OnlineRoomState
import com.example.model.OtaBalanceConfig
import com.example.model.RoomChatMessage
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlin.random.Random
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class OnlineRoomRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    Firebase.auth,
  )

  private fun requireUserId(): String =
    auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before using 1vs1 Online.")

  private fun generateRoomCode(): String {
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return buildString {
      repeat(6) { append(chars[Random.nextInt(chars.length)]) }
    }
  }

  fun dealRandom3Balls(ownedBalls: Set<BallType>): List<BallType> {
    val pool = ownedBalls.ifEmpty { setOf(BallType.FIRE) }.toList()
    if (pool.size >= 3) {
      return pool.shuffled().take(3)
    }
    return List(3) { idx -> pool[idx % pool.size] }
  }

  private fun isCurrentUserAdmin(): Boolean =
    auth.currentUser?.email.equals(ADMIN_OWNER_EMAIL, ignoreCase = true)

  suspend fun createRoom(
    hostNickname: String,
    customRoomCode: String? = null,
    balanceSnapshot: OtaBalanceConfig = OtaBalanceConfig(),
  ): OnlineRoomState {
    val uid = requireUserId()
    val hostIsAdmin = isCurrentUserAdmin()
    val roomCode = customRoomCode?.trim()?.uppercase()?.takeIf { it.isNotBlank() } ?: generateRoomCode()
    val seed = Random.nextLong(100_000L, 999_999_999L)
    val now = System.currentTimeMillis()
    val docRef = db.collection("rooms").document(roomCode)
    val payload = OnlineRoomDoc.createMap(uid, hostNickname, seed, balanceSnapshot, hostIsAdmin, now)
    return try {
      docRef.set(payload).await()
      OnlineRoomState(
        roomCode = roomCode,
        hostUid = uid,
        hostName = hostNickname.trim().ifBlank { "Host" }.take(24),
        guestUid = "",
        guestName = "",
        phase = OnlineRoomPhase.WAITING,
        hostPicks = emptyList(),
        guestPicks = emptyList(),
        hostBannedBall = null,
        guestBannedBall = null,
        hostFinalBall = null,
        guestFinalBall = null,
        seed = seed,
        winnerUid = "",
        matchDurationSec = 0f,
        rewardCoins = 0,
        hostReady = false,
        guestReady = false,
        hostScore = 0,
        guestScore = 0,
        currentRound = 1,
        hostLastHeartbeatMs = now,
        guestLastHeartbeatMs = 0L,
        hostIsAdmin = hostIsAdmin,
        guestIsAdmin = false,
        hostAimRad = -99.0,
        guestAimRad = -99.0,
        balanceSnapshot = balanceSnapshot,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
      throw e
    }
  }

  suspend fun joinRoom(
    roomCodeInput: String,
    guestNickname: String,
    autoReady: Boolean = false,
  ): OnlineRoomState {
    val uid = requireUserId()
    val guestIsAdmin = isCurrentUserAdmin()
    val roomCode = roomCodeInput.trim().uppercase()
    require(roomCode.matches(Regex("^[A-Z0-9_-]{3,32}$"))) { "Invalid room code" }
    val docRef = db.collection("rooms").document(roomCode)
    val now = System.currentTimeMillis()
    return try {
      db.runTransaction { tx ->
        val snapshot = tx.get(docRef)
        if (!snapshot.exists()) {
          throw IllegalStateException("Room not found")
        }
        val existing = snapshot.toObject(OnlineRoomDoc::class.java)
          ?: throw IllegalStateException("Invalid room data")
        if (existing.hostUid == uid || existing.guestUid == uid) {
          return@runTransaction existing.toDomain(roomCode)
        }
        if (existing.guestUid.isNotBlank()) {
          throw IllegalStateException("Room is already full")
        }
        if (existing.status != OnlineRoomPhase.WAITING.wireValue) {
          throw IllegalStateException("Match already in progress")
        }
        val cleanName = guestNickname.trim().ifBlank { "Guest" }.take(24)
        val nextGuestReady = autoReady
        val nextStatus =
          if (autoReady && existing.hostReady) OnlineRoomPhase.PICK_3.wireValue
          else existing.status
        tx.update(
          docRef,
          mapOf(
            "guestUid" to uid,
            "guestName" to cleanName,
            "guestReady" to nextGuestReady,
            "guestIsAdmin" to guestIsAdmin,
            "guestLastHeartbeatMs" to now,
            "status" to nextStatus,
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
        existing.copy(
          guestUid = uid,
          guestName = cleanName,
          guestReady = nextGuestReady,
          guestIsAdmin = guestIsAdmin,
          guestLastHeartbeatMs = now,
          status = nextStatus,
        ).toDomain(roomCode)
      }.await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
      throw e
    }
  }

  fun observeRoom(roomCode: String): Flow<OnlineRoomState?> = flow {
    val uid = requireUserId()
    val docRef = db.collection("rooms").document(roomCode.trim().uppercase())
    emitAll(
      docRef.snapshots()
        .map { snapshot ->
          if (!snapshot.exists()) null
          else snapshot.toObject(OnlineRoomDoc::class.java)?.toDomain(snapshot.id)
        }
        .catch { error ->
          val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val exceptionToLog = firestoreError ?: (error as? Exception)
          if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path, auth)
          }
          throw error
        }
    )
  }

  fun observeRoomChat(roomCode: String): Flow<List<RoomChatMessage>> = flow {
    val uid = requireUserId()
    val normalized = roomCode.trim().uppercase()
    val chatRef = db.collection("rooms").document(normalized).collection("messages")
    emitAll(
      chatRef
        .orderBy("createdAt", Query.Direction.ASCENDING)
        .limitToLast(60)
        .snapshots()
        .map { querySnapshot ->
          querySnapshot
            .toObjects(RoomChatMessageDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .map { it.toDomain() }
        }
        .catch { error ->
          val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val exceptionToLog = firestoreError ?: (error as? Exception)
          if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, OperationType.LIST, chatRef.path, auth)
          }
          throw error
        }
    )
  }

  suspend fun sendChatMessage(roomCode: String, senderName: String, text: String) {
    val uid = requireUserId()
    val cleaned = text.trim().take(300)
    if (cleaned.isBlank()) return
    val normalized = roomCode.trim().uppercase()
    val msgId = "m_${System.currentTimeMillis()}_${Random.nextInt(1000, 9999)}"
    val msgRef = db.collection("rooms").document(normalized).collection("messages").document(msgId)
    try {
      msgRef.set(
        mapOf(
          "senderUid" to uid,
          "senderName" to senderName.trim().ifBlank { "Player" }.take(24),
          "text" to cleaned,
          "createdAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, msgRef.path, auth)
      throw e
    }
  }

  suspend fun setReady(
    room: OnlineRoomState,
    ready: Boolean,
    myOwnedBalls: Set<BallType>,
    activeBalance: OtaBalanceConfig? = null,
  ) {
    val uid = requireUserId()
    val docRef = db.collection("rooms").document(room.roomCode)
    val dealtIds = if (ready) dealRandom3Balls(myOwnedBalls).map { it.id } else emptyList()
    val now = System.currentTimeMillis()
    try {
      db.runTransaction { tx ->
        val snap = tx.get(docRef)
        val live = snap.toObject(OnlineRoomDoc::class.java) ?: return@runTransaction
        if (live.status != OnlineRoomPhase.WAITING.wireValue) return@runTransaction
        val amHost = live.hostUid == uid
        if (!amHost && live.guestUid != uid) return@runTransaction

        val newHostReady = if (amHost) ready else live.hostReady
        val newGuestReady = if (!amHost) ready else live.guestReady
        val newHostPicks = if (amHost) dealtIds else live.hostPicks
        val newGuestPicks = if (!amHost) dealtIds else live.guestPicks

        val updates = mutableMapOf<String, Any>(
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        if (amHost) {
          updates["hostReady"] = ready
          updates["hostPicks"] = dealtIds
          updates["hostLastHeartbeatMs"] = now
          if (activeBalance != null) {
            updates["balanceSnapshot"] = OnlineRoomDoc.balanceToMap(activeBalance)
          }
        } else {
          updates["guestReady"] = ready
          updates["guestPicks"] = dealtIds
          updates["guestLastHeartbeatMs"] = now
        }

        if (live.guestUid.isNotBlank() && newHostReady && newGuestReady) {
          updates["status"] =
            if (newHostPicks.size == 3 && newGuestPicks.size == 3) {
              OnlineRoomPhase.BAN_1.wireValue
            } else {
              OnlineRoomPhase.PICK_3.wireValue
            }
          updates["hostBannedBall"] = ""
          updates["guestBannedBall"] = ""
          updates["hostFinalBall"] = ""
          updates["guestFinalBall"] = ""
          updates["hostAimRad"] = -99.0
          updates["guestAimRad"] = -99.0
        }
        tx.update(docRef, updates)
      }.await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
      throw e
    }
  }

  suspend fun pingHeartbeat(room: OnlineRoomState): Long {
    val uid = auth.currentUser?.uid ?: return -1L
    val docRef = db.collection("rooms").document(room.roomCode)
    val startNs = System.nanoTime()
    val now = System.currentTimeMillis()
    val field = if (room.isHost(uid)) "hostLastHeartbeatMs" else "guestLastHeartbeatMs"
    return try {
      docRef.update(
        mapOf(
          field to now,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      ((System.nanoTime() - startNs) / 1_000_000L).coerceIn(1L, 9999L)
    } catch (_: Exception) {
      -1L
    }
  }

  suspend fun sendEmote(room: OnlineRoomState, emote: OnlineEmote) {
    val uid = auth.currentUser?.uid ?: return
    val docRef = db.collection("rooms").document(room.roomCode)
    val now = System.currentTimeMillis()
    val updates =
      if (room.isHost(uid)) {
        mapOf(
          "hostEmote" to emote.id,
          "hostEmoteAtMs" to now,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      } else {
        mapOf(
          "guestEmote" to emote.id,
          "guestEmoteAtMs" to now,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      }
    runCatching { docRef.update(updates).await() }
  }

  suspend fun submitPick3(room: OnlineRoomState, picks: List<BallType>) {
    val uid = requireUserId()
    val pickIds = picks.take(3).map { it.id }
    if (pickIds.size != 3) return
    val docRef = db.collection("rooms").document(room.roomCode)
    try {
      db.runTransaction { tx ->
        val live = tx.get(docRef).toObject(OnlineRoomDoc::class.java) ?: return@runTransaction
        if (live.status != OnlineRoomPhase.PICK_3.wireValue) return@runTransaction
        val amHost = live.hostUid == uid
        if (!amHost && live.guestUid != uid) return@runTransaction

        val existingMine = if (amHost) live.hostPicks else live.guestPicks
        if (existingMine.size == 3) {
          // Even if my picks are already set, check if opponent also has 3 and phase stalled
          if (live.hostPicks.size == 3 && live.guestPicks.size == 3) {
            tx.update(
              docRef,
              mapOf(
                "status" to OnlineRoomPhase.BAN_1.wireValue,
                "hostBannedBall" to "",
                "guestBannedBall" to "",
                "hostFinalBall" to "",
                "guestFinalBall" to "",
                "hostAimRad" to -99.0,
                "guestAimRad" to -99.0,
                "updatedAt" to FieldValue.serverTimestamp(),
              ),
            )
          }
          return@runTransaction
        }

        val newHostPicks = if (amHost) pickIds else live.hostPicks
        val newGuestPicks = if (!amHost) pickIds else live.guestPicks
        val updates = mutableMapOf<String, Any>(
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        updates[if (amHost) "hostPicks" else "guestPicks"] = pickIds
        if (newHostPicks.size == 3 && newGuestPicks.size == 3) {
          updates["status"] = OnlineRoomPhase.BAN_1.wireValue
          updates["hostBannedBall"] = ""
          updates["guestBannedBall"] = ""
          updates["hostFinalBall"] = ""
          updates["guestFinalBall"] = ""
          updates["hostAimRad"] = -99.0
          updates["guestAimRad"] = -99.0
        }
        tx.update(docRef, updates)
      }.await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
      throw e
    }
  }

  suspend fun submitBan1(room: OnlineRoomState, bannedOpponentBall: BallType) {
    val uid = requireUserId()
    val docRef = db.collection("rooms").document(room.roomCode)
    try {
      db.runTransaction { tx ->
        val live = tx.get(docRef).toObject(OnlineRoomDoc::class.java) ?: return@runTransaction
        if (live.status != OnlineRoomPhase.BAN_1.wireValue) return@runTransaction
        val amHost = live.hostUid == uid
        if (!amHost && live.guestUid != uid) return@runTransaction

        val newHostBan = if (amHost) bannedOpponentBall.id else live.hostBannedBall
        val newGuestBan = if (!amHost) bannedOpponentBall.id else live.guestBannedBall
        val updates = mutableMapOf<String, Any>(
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        updates[if (amHost) "hostBannedBall" else "guestBannedBall"] = bannedOpponentBall.id
        if (newHostBan.isNotBlank() && newGuestBan.isNotBlank()) {
          updates["status"] = OnlineRoomPhase.FINAL_PICK.wireValue
        }
        tx.update(docRef, updates)
      }.await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
      throw e
    }
  }

  suspend fun submitFinalBall(room: OnlineRoomState, finalBall: BallType) {
    val uid = requireUserId()
    val docRef = db.collection("rooms").document(room.roomCode)
    try {
      db.runTransaction { tx ->
        val live = tx.get(docRef).toObject(OnlineRoomDoc::class.java) ?: return@runTransaction
        if (live.status != OnlineRoomPhase.FINAL_PICK.wireValue) return@runTransaction
        val amHost = live.hostUid == uid
        if (!amHost && live.guestUid != uid) return@runTransaction

        val bannedAgainstMe = if (amHost) live.guestBannedBall else live.hostBannedBall
        val myPicks = if (amHost) live.hostPicks else live.guestPicks
        val resolvedId =
          if (finalBall.id == bannedAgainstMe) {
            myPicks.firstOrNull { it != bannedAgainstMe } ?: finalBall.id
          } else {
            finalBall.id
          }

        val newHostFinal = if (amHost) resolvedId else live.hostFinalBall
        val newGuestFinal = if (!amHost) resolvedId else live.guestFinalBall
        val updates = mutableMapOf<String, Any>(
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        updates[if (amHost) "hostFinalBall" else "guestFinalBall"] = resolvedId
        if (newHostFinal.isNotBlank() && newGuestFinal.isNotBlank()) {
          updates["status"] = OnlineRoomPhase.PLAYING.wireValue
          updates["hostAimRad"] = -99.0
          updates["guestAimRad"] = -99.0
          updates["matchDurationSec"] = 0.0
        }
        tx.update(docRef, updates)
      }.await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
      throw e
    }
  }

  suspend fun submitAimAngle(
    roomCode: String,
    expectedRound: Int,
    angleRad: Double,
  ) {
    val uid = requireUserId()
    val clamped = angleRad.coerceIn(-Math.PI, Math.PI)
    val docRef = db.collection("rooms").document(roomCode.trim().uppercase())
    try {
      db.runTransaction { tx ->
        val live = tx.get(docRef).toObject(OnlineRoomDoc::class.java) ?: return@runTransaction
        if (live.status != OnlineRoomPhase.PLAYING.wireValue) return@runTransaction
        if (live.currentRound.toInt() != expectedRound) return@runTransaction
        val amHost = live.hostUid == uid
        if (!amHost && live.guestUid != uid) return@runTransaction

        val field = if (amHost) "hostAimRad" else "guestAimRad"
        val currentVal = if (amHost) live.hostAimRad else live.guestAimRad
        if (currentVal > -10.0 && currentVal < 10.0) return@runTransaction

        tx.update(
          docRef,
          mapOf(
            field to clamped,
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      }.await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      if (auth.currentUser?.uid == uid) {
        handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
      }
    }
  }

  suspend fun forceDefaultMissingAim(
    roomCode: String,
    expectedRound: Int,
    targetHost: Boolean,
    fallbackAngleRad: Double,
  ) {
    val uid = auth.currentUser?.uid ?: return
    val clamped = fallbackAngleRad.coerceIn(-Math.PI, Math.PI)
    val docRef = db.collection("rooms").document(roomCode.trim().uppercase())
    runCatching {
      db.runTransaction { tx ->
        val live = tx.get(docRef).toObject(OnlineRoomDoc::class.java) ?: return@runTransaction
        if (live.status != OnlineRoomPhase.PLAYING.wireValue) return@runTransaction
        if (live.currentRound.toInt() != expectedRound) return@runTransaction
        if (live.hostUid != uid && live.guestUid != uid) return@runTransaction

        val field = if (targetHost) "hostAimRad" else "guestAimRad"
        val currentVal = if (targetHost) live.hostAimRad else live.guestAimRad
        if (currentVal > -10.0 && currentVal < 10.0) return@runTransaction

        tx.update(
          docRef,
          mapOf(
            field to clamped,
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      }.await()
    }
  }

  /**
   * Self-healing phase check: if concurrent client updates somehow left both players' selections
   * populated while `status` did not advance, atomically move `status` forward inside a transaction.
   */
  suspend fun reconcileRoomPhase(roomCode: String) {
    val uid = auth.currentUser?.uid ?: return
    val docRef = db.collection("rooms").document(roomCode.trim().uppercase())
    runCatching {
      db.runTransaction { tx ->
        val live = tx.get(docRef).toObject(OnlineRoomDoc::class.java) ?: return@runTransaction
        if (live.hostUid != uid && live.guestUid != uid) return@runTransaction
        when (OnlineRoomPhase.fromWire(live.status)) {
          OnlineRoomPhase.WAITING -> {
            if (live.guestUid.isNotBlank() && live.hostReady && live.guestReady) {
              val nextStatus =
                if (live.hostPicks.size == 3 && live.guestPicks.size == 3) {
                  OnlineRoomPhase.BAN_1.wireValue
                } else {
                  OnlineRoomPhase.PICK_3.wireValue
                }
              tx.update(
                docRef,
                mapOf(
                  "status" to nextStatus,
                  "hostBannedBall" to "",
                  "guestBannedBall" to "",
                  "hostFinalBall" to "",
                  "guestFinalBall" to "",
                  "hostAimRad" to -99.0,
                  "guestAimRad" to -99.0,
                  "updatedAt" to FieldValue.serverTimestamp(),
                ),
              )
            }
          }

          OnlineRoomPhase.PICK_3 -> {
            if (live.hostPicks.size == 3 && live.guestPicks.size == 3) {
              tx.update(
                docRef,
                mapOf(
                  "status" to OnlineRoomPhase.BAN_1.wireValue,
                  "hostBannedBall" to "",
                  "guestBannedBall" to "",
                  "hostFinalBall" to "",
                  "guestFinalBall" to "",
                  "hostAimRad" to -99.0,
                  "guestAimRad" to -99.0,
                  "updatedAt" to FieldValue.serverTimestamp(),
                ),
              )
            }
          }

          OnlineRoomPhase.BAN_1 -> {
            if (live.hostBannedBall.isNotBlank() && live.guestBannedBall.isNotBlank()) {
              tx.update(
                docRef,
                mapOf(
                  "status" to OnlineRoomPhase.FINAL_PICK.wireValue,
                  "updatedAt" to FieldValue.serverTimestamp(),
                ),
              )
            }
          }

          OnlineRoomPhase.FINAL_PICK -> {
            if (live.hostFinalBall.isNotBlank() && live.guestFinalBall.isNotBlank()) {
              tx.update(
                docRef,
                mapOf(
                  "status" to OnlineRoomPhase.PLAYING.wireValue,
                  "hostAimRad" to -99.0,
                  "guestAimRad" to -99.0,
                  "matchDurationSec" to 0.0,
                  "updatedAt" to FieldValue.serverTimestamp(),
                ),
              )
            }
          }

          OnlineRoomPhase.PLAYING, OnlineRoomPhase.FINISHED -> Unit
        }
      }.await()
    }
  }

  suspend fun reportRoundFinished(
    roomCode: String,
    roundWinnerUid: String,
    roundDurationSec: Float,
    rewardCoinsIfSeriesEnds: Int,
    expectedRound: Int? = null,
  ): OnlineRoomState? {
    val uid = requireUserId()
    val docRef = db.collection("rooms").document(roomCode)
    return try {
      db.runTransaction { tx ->
        val current = tx.get(docRef).toObject(OnlineRoomDoc::class.java) ?: return@runTransaction null
        if (current.status == OnlineRoomPhase.FINISHED.wireValue) return@runTransaction current.toDomain(roomCode)
        if (current.status != OnlineRoomPhase.PLAYING.wireValue) return@runTransaction current.toDomain(roomCode)
        if (expectedRound != null && current.currentRound.toInt() != expectedRound) {
          return@runTransaction current.toDomain(roomCode)
        }

        val hostWonRound = roundWinnerUid == current.hostUid
        val nextHostScore = (current.hostScore + if (hostWonRound) 1L else 0L).coerceIn(0L, 5L)
        val nextGuestScore = (current.guestScore + if (!hostWonRound) 1L else 0L).coerceIn(0L, 5L)
        val seriesFinished =
          nextHostScore >= ONLINE_FT3_TARGET_SCORE || nextGuestScore >= ONLINE_FT3_TARGET_SCORE

        if (seriesFinished) {
          val seriesWinner = if (nextHostScore >= nextGuestScore) current.hostUid else current.guestUid
          val clampedDur = roundDurationSec.toDouble().coerceIn(0.0, 600.0)
          val clampedCoins = rewardCoinsIfSeriesEnds.coerceIn(0, 2000).toLong()
          tx.update(
            docRef,
            mapOf(
              "hostScore" to nextHostScore,
              "guestScore" to nextGuestScore,
              "status" to OnlineRoomPhase.FINISHED.wireValue,
              "winnerUid" to seriesWinner,
              "matchDurationSec" to clampedDur,
              "rewardCoins" to clampedCoins,
              "updatedAt" to FieldValue.serverTimestamp(),
            ),
          )
          current.copy(
            hostScore = nextHostScore,
            guestScore = nextGuestScore,
            status = OnlineRoomPhase.FINISHED.wireValue,
            winnerUid = seriesWinner,
            matchDurationSec = clampedDur,
            rewardCoins = clampedCoins,
          ).toDomain(roomCode)
        } else {
          val nextRound = (current.currentRound + 1L).coerceAtMost(9L)
          val nextSeed = Random.nextLong(100_000L, 999_999_999L)
          tx.update(
            docRef,
            mapOf(
              "hostScore" to nextHostScore,
              "guestScore" to nextGuestScore,
              "currentRound" to nextRound,
              "status" to OnlineRoomPhase.PICK_3.wireValue,
              "hostPicks" to emptyList<String>(),
              "guestPicks" to emptyList<String>(),
              "hostBannedBall" to "",
              "guestBannedBall" to "",
              "hostFinalBall" to "",
              "guestFinalBall" to "",
              "hostAimRad" to -99.0,
              "guestAimRad" to -99.0,
              "seed" to nextSeed,
              "updatedAt" to FieldValue.serverTimestamp(),
            ),
          )
          current.copy(
            hostScore = nextHostScore,
            guestScore = nextGuestScore,
            currentRound = nextRound,
            status = OnlineRoomPhase.PICK_3.wireValue,
            hostPicks = emptyList(),
            guestPicks = emptyList(),
            hostBannedBall = "",
            guestBannedBall = "",
            hostFinalBall = "",
            guestFinalBall = "",
            hostAimRad = -99.0,
            guestAimRad = -99.0,
            seed = nextSeed,
          ).toDomain(roomCode)
        }
      }.await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      if (auth.currentUser?.uid == uid) {
        handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
      }
      null
    }
  }

  suspend fun reportMatchFinished(
    roomCode: String,
    winnerUid: String,
    matchDurationSec: Float,
    rewardCoins: Int,
  ) {
    val uid = requireUserId()
    val docRef = db.collection("rooms").document(roomCode)
    try {
      db.runTransaction { tx ->
        val current = tx.get(docRef).toObject(OnlineRoomDoc::class.java) ?: return@runTransaction
        if (current.status == OnlineRoomPhase.FINISHED.wireValue) return@runTransaction
        tx.update(
          docRef,
          mapOf(
            "status" to OnlineRoomPhase.FINISHED.wireValue,
            "winnerUid" to winnerUid,
            "matchDurationSec" to matchDurationSec.toDouble().coerceIn(0.0, 600.0),
            "rewardCoins" to rewardCoins.coerceIn(0, 2000).toLong(),
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      }.await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      if (auth.currentUser?.uid == uid) {
        handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
      }
    }
  }

  suspend fun deleteRoom(roomCode: String) {
    val uid = requireUserId()
    val docRef = db.collection("rooms").document(roomCode)
    try {
      docRef.delete().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      if (auth.currentUser?.uid == uid) {
        handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
      }
    }
  }

  // --- Quick Random 1vs1 Matchmaking ---

  suspend fun enqueueWaitingTicket(nickname: String) {
    val uid = requireUserId()
    val docRef = db.collection("matchmaking_queue").document(uid)
    val now = System.currentTimeMillis()
    runCatching { docRef.delete().await() }
    val payload = mapOf(
      "uid" to uid,
      "nickname" to nickname.trim().ifBlank { "Challenger" }.take(24),
      "isAdmin" to isCurrentUserAdmin(),
      "status" to "waiting",
      "roomCode" to "",
      "matchedWithUid" to "",
      "heartbeatMs" to now,
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
      throw e
    }
  }

  suspend fun refreshWaitingTicketHeartbeat(nickname: String) {
    val uid = auth.currentUser?.uid ?: return
    val docRef = db.collection("matchmaking_queue").document(uid)
    runCatching {
      docRef.update(
        mapOf(
          "nickname" to nickname.trim().ifBlank { "Challenger" }.take(24),
          "isAdmin" to isCurrentUserAdmin(),
          "heartbeatMs" to System.currentTimeMillis(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    }
  }

  suspend fun cancelMatchmakingTicket() {
    val uid = auth.currentUser?.uid ?: return
    runCatching { db.collection("matchmaking_queue").document(uid).delete().await() }
  }

  fun observeMyMatchmakingTicket(): Flow<MatchmakingTicketEntry?> = flow {
    val uid = requireUserId()
    val docRef = db.collection("matchmaking_queue").document(uid)
    emitAll(
      docRef.snapshots()
        .map { snap ->
          if (!snap.exists()) null
          else snap.toObject(MatchmakingTicketDoc::class.java)?.toDomain()
        }
        .catch { error ->
          val fsEx = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
          if (fsEx == null && error is CancellationException) throw error
          if (fsEx != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(fsEx, OperationType.GET, docRef.path, auth)
          }
          throw error
        }
    )
  }

  /**
   * Finds a live waiting opponent (filtered with heartbeat freshness <= 30s) and atomically
   * creates a quick-match FT3 room with `hostReady = true` while marking their ticket `matched`.
   * When [respectTieBreaker] is true, only claims candidates whose UID is > myUid so two
   * simultaneous searchers don't both create separate rooms.
   */
  suspend fun findAndClaimWaitingOpponent(
    myNickname: String,
    balanceSnapshot: OtaBalanceConfig,
    respectTieBreaker: Boolean = false,
  ): OnlineRoomState? {
    val myUid = requireUserId()
    val hostIsAdmin = isCurrentUserAdmin()
    val cleanHostName = myNickname.trim().ifBlank { "Host" }.take(24)
    val now = System.currentTimeMillis()
    val waitingDocs =
      try {
        db.collection("matchmaking_queue")
          .whereEqualTo("status", "waiting")
          .limit(12)
          .get()
          .await()
          .toObjects(MatchmakingTicketDoc::class.java)
          .map { it.toDomain() }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        handleFirestoreError(e, OperationType.LIST, "matchmaking_queue", auth)
        return null
      }

    val candidates =
      waitingDocs
        .filter { ticket ->
          ticket.uid.isNotBlank() &&
            ticket.uid != myUid &&
            ticket.status == "waiting" &&
            (ticket.heartbeatMs <= 0L || (now - ticket.heartbeatMs) <= 30_000L) &&
            (!respectTieBreaker || myUid < ticket.uid)
        }
        .sortedByDescending { it.heartbeatMs }

    for (candidate in candidates) {
      val roomCode = "QM${generateRoomCode().take(4)}"
      val seed = Random.nextLong(100_000L, 999_999_999L)
      val roomRef = db.collection("rooms").document(roomCode)
      val ticketRef = db.collection("matchmaking_queue").document(candidate.uid)
      val roomPayload =
        OnlineRoomDoc.createMap(
          hostUid = myUid,
          hostName = cleanHostName,
          seed = seed,
          balance = balanceSnapshot,
          hostIsAdmin = hostIsAdmin,
          nowMillis = now,
          hostReady = true,
        )

      val claimed =
        runCatching {
          db.runTransaction { tx ->
            val snap = tx.get(ticketRef)
            val live = snap.toObject(MatchmakingTicketDoc::class.java) ?: return@runTransaction false
            if (live.status != "waiting") return@runTransaction false
            tx.set(roomRef, roomPayload)
            tx.update(
              ticketRef,
              mapOf(
                "status" to "matched",
                "roomCode" to roomCode,
                "matchedWithUid" to myUid,
                "updatedAt" to FieldValue.serverTimestamp(),
              ),
            )
            true
          }.await()
        }.getOrDefault(false)

      if (claimed) {
        cancelMatchmakingTicket()
        return OnlineRoomState(
          roomCode = roomCode,
          hostUid = myUid,
          hostName = cleanHostName,
          guestUid = "",
          guestName = "",
          phase = OnlineRoomPhase.WAITING,
          hostPicks = emptyList(),
          guestPicks = emptyList(),
          hostBannedBall = null,
          guestBannedBall = null,
          hostFinalBall = null,
          guestFinalBall = null,
          seed = seed,
          winnerUid = "",
          matchDurationSec = 0f,
          rewardCoins = 0,
          hostReady = true,
          guestReady = false,
          hostScore = 0,
          guestScore = 0,
          currentRound = 1,
          hostLastHeartbeatMs = now,
          guestLastHeartbeatMs = 0L,
          hostIsAdmin = hostIsAdmin,
          guestIsAdmin = false,
          hostAimRad = -99.0,
          guestAimRad = -99.0,
          balanceSnapshot = balanceSnapshot,
        )
      }
    }
    return null
  }
}

