package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AiDifficulty
import com.example.model.AppLanguage
import com.example.model.BallRarity
import com.example.model.BallType
import com.example.model.CodeRedeemResult
import com.example.model.DailyRewardTier
import com.example.model.GACHA_PITY_THRESHOLD
import com.example.model.GACHA_SPIN_COST
import com.example.model.GachaSpinResult
import com.example.model.GameSettings
import com.example.model.GraphicsQuality
import com.example.model.KillEffectType
import com.example.model.MailboxLetter
import com.example.model.OtaGiftCodeEntry
import com.example.model.OtaLiveConfig
import com.example.model.ShopPurchaseResult
import com.example.model.TAIDZ_CODE
import com.example.model.TAN_THU_CODE
import com.example.model.UserProgress
import com.example.security.SecureVault
import kotlin.random.Random
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.gameDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "bvb_hct_store")

sealed interface CodeProcessOutcome {
  data class Result(
    val status: CodeRedeemResult,
    val grantedTrial24h: Boolean = false,
    val grantedTrialBall: BallType? = null,
    val grantedTrialMinutes: Int = 0,
    val letterToSend: MailboxLetter? = null,
    val canonicalCode: String = "",
  ) : CodeProcessOutcome
}

class GamePreferencesRepository(private val context: Context) {

  private object Keys {
    val SEALED_VAULT = stringPreferencesKey("sealed_vault_v1")
    val GUEST_MODE_ACTIVE = booleanPreferencesKey("guest_mode_active")

    // Legacy v1.0 keys (migrated once into AES-GCM vault and cleared)
    val LEGACY_COINS = intPreferencesKey("coins")
    val LEGACY_BALLS = stringSetPreferencesKey("purchased_balls")
    val LEGACY_EFFECTS = stringSetPreferencesKey("purchased_kill_effects")
    val LEGACY_EQUIPPED_BALL = stringPreferencesKey("equipped_ball")
    val LEGACY_EQUIPPED_EFFECT = stringPreferencesKey("equipped_kill_effect")
    val LEGACY_TAN_THU = longPreferencesKey("tan_thu_activated_at")
    val LEGACY_WINS = intPreferencesKey("total_wins")
    val LEGACY_MATCHES = intPreferencesKey("total_matches")

    // Non-sensitive gameplay settings
    val LANGUAGE = stringPreferencesKey("language")
    val TARGET_FPS = intPreferencesKey("target_fps")
    val AI_DIFFICULTY = stringPreferencesKey("ai_difficulty")
    val SFX_ENABLED = booleanPreferencesKey("sfx_enabled")
    val MUSIC_ENABLED = booleanPreferencesKey("music_enabled")
    val SFX_VOLUME = floatPreferencesKey("sfx_volume")
    val MUSIC_VOLUME = floatPreferencesKey("music_volume")
    val BLOOM_SHADERS = booleanPreferencesKey("bloom_shaders")
    val TRAILS = booleanPreferencesKey("trails")
    val SCREEN_SHAKE = booleanPreferencesKey("screen_shake")
    val HIT_STOP = booleanPreferencesKey("hit_stop")
    val FLOATING_DAMAGE = booleanPreferencesKey("floating_damage")
    val SPEED_MULTIPLIER = floatPreferencesKey("speed_multiplier")
    val SHOW_FPS = booleanPreferencesKey("show_fps")
    val GRAPHICS_QUALITY = stringPreferencesKey("graphics_quality")
    val AUTO_REDUCE_LAG = booleanPreferencesKey("auto_reduce_lag")
  }

  val isGuestSessionFlow: Flow<Boolean> =
    context.gameDataStore.data.map { prefs -> prefs[Keys.GUEST_MODE_ACTIVE] ?: false }

  val userProgressFlow: Flow<UserProgress> =
    context.gameDataStore.data.map { prefs ->
      val unsealed = SecureVault.unseal(context, prefs[Keys.SEALED_VAULT])
      val rawProgress = unsealed ?: readLegacyOrDefault(prefs)
      val now = System.currentTimeMillis()
      rawProgress.copy(
        equippedBall =
          if (rawProgress.isBallAvailable(rawProgress.equippedBall, now)) rawProgress.equippedBall
          else BallType.FIRE,
        equippedKillEffect =
          if (rawProgress.isKillEffectAvailable(rawProgress.equippedKillEffect, now))
            rawProgress.equippedKillEffect
          else KillEffectType.DEFAULT_BURST,
      )
    }

  private fun readLegacyOrDefault(prefs: Preferences): UserProgress {
    val hasLegacy = prefs[Keys.LEGACY_COINS] != null || prefs[Keys.LEGACY_BALLS] != null
    if (!hasLegacy) return UserProgress()
    val balls =
      (prefs[Keys.LEGACY_BALLS] ?: setOf(BallType.FIRE.id))
        .map { BallType.fromId(it) }
        .toSet() + BallType.FIRE
    val effects =
      (prefs[Keys.LEGACY_EFFECTS] ?: setOf(KillEffectType.DEFAULT_BURST.id))
        .map { KillEffectType.fromId(it) }
        .toSet() + KillEffectType.DEFAULT_BURST
    return UserProgress(
      coins = prefs[Keys.LEGACY_COINS] ?: 160,
      purchasedBalls = balls,
      purchasedKillEffects = effects,
      equippedBall = BallType.fromId(prefs[Keys.LEGACY_EQUIPPED_BALL]),
      equippedKillEffect = KillEffectType.fromId(prefs[Keys.LEGACY_EQUIPPED_EFFECT]),
      tanThuActivatedAtMillis = prefs[Keys.LEGACY_TAN_THU] ?: 0L,
      totalWins = prefs[Keys.LEGACY_WINS] ?: 0,
      totalMatches = prefs[Keys.LEGACY_MATCHES] ?: 0,
    )
  }

  val gameSettingsFlow: Flow<GameSettings> =
    context.gameDataStore.data.map { prefs ->
      GameSettings(
        language = AppLanguage.fromCode(prefs[Keys.LANGUAGE]),
        targetFps = prefs[Keys.TARGET_FPS] ?: 120,
        aiDifficulty = AiDifficulty.fromId(prefs[Keys.AI_DIFFICULTY]),
        sfxEnabled = prefs[Keys.SFX_ENABLED] ?: true,
        musicEnabled = prefs[Keys.MUSIC_ENABLED] ?: true,
        sfxVolume = prefs[Keys.SFX_VOLUME] ?: 0.85f,
        musicVolume = prefs[Keys.MUSIC_VOLUME] ?: 0.55f,
        bloomAndShadersEnabled = prefs[Keys.BLOOM_SHADERS] ?: true,
        trailsEnabled = prefs[Keys.TRAILS] ?: true,
        screenShakeEnabled = prefs[Keys.SCREEN_SHAKE] ?: true,
        hitStopEnabled = prefs[Keys.HIT_STOP] ?: true,
        floatingDamageEnabled = prefs[Keys.FLOATING_DAMAGE] ?: true,
        speedMultiplier = prefs[Keys.SPEED_MULTIPLIER] ?: 1.0f,
        showFpsCounter = prefs[Keys.SHOW_FPS] ?: false,
        graphicsQuality = GraphicsQuality.fromId(prefs[Keys.GRAPHICS_QUALITY]),
        autoReduceLag = prefs[Keys.AUTO_REDUCE_LAG] ?: true,
      )
    }

  private suspend fun saveProgressVault(transform: (UserProgress) -> UserProgress): UserProgress {
    var result = UserProgress()
    context.gameDataStore.edit { prefs ->
      val current = SecureVault.unseal(context, prefs[Keys.SEALED_VAULT]) ?: readLegacyOrDefault(prefs)
      val updated = transform(current)
      result = updated
      prefs[Keys.SEALED_VAULT] = SecureVault.seal(context, updated)
      prefs.remove(Keys.LEGACY_COINS)
      prefs.remove(Keys.LEGACY_BALLS)
      prefs.remove(Keys.LEGACY_EFFECTS)
      prefs.remove(Keys.LEGACY_EQUIPPED_BALL)
      prefs.remove(Keys.LEGACY_EQUIPPED_EFFECT)
      prefs.remove(Keys.LEGACY_TAN_THU)
      prefs.remove(Keys.LEGACY_WINS)
      prefs.remove(Keys.LEGACY_MATCHES)
    }
    return result
  }

  suspend fun ensureVaultInitialized() {
    val prefs = context.gameDataStore.data.first()
    if (prefs[Keys.SEALED_VAULT] == null) {
      saveProgressVault { it }
    }
  }

  suspend fun setGuestSession(active: Boolean, nickname: String? = null): UserProgress {
    context.gameDataStore.edit { prefs ->
      prefs[Keys.GUEST_MODE_ACTIVE] = active
    }
    if (!nickname.isNullOrBlank()) {
      return setNickname(nickname)
    }
    return userProgressFlow.first()
  }

  suspend fun applySyncedProgress(cloudProgress: UserProgress): UserProgress {
    return saveProgressVault { cloudProgress }
  }

  suspend fun setNickname(rawName: String): UserProgress {
    val sanitized = rawName.trim().take(24).ifBlank { "Challenger" }
    return saveProgressVault { it.copy(nickname = sanitized) }
  }

  suspend fun ensurePlayerCode(uidSeed: String? = null): UserProgress {
    val current = userProgressFlow.first()
    if (current.playerCode.isNotBlank()) return current
    val generated = generatePlayerCode(uidSeed)
    return saveProgressVault { p ->
      if (p.playerCode.isNotBlank()) p else p.copy(playerCode = generated)
    }
  }

  suspend fun checkAndReconcileTanThuExpiration(nowMillis: Long = System.currentTimeMillis()) {
    val current = userProgressFlow.first()
    val hasExpiredTanThu = current.tanThuActivatedAtMillis > 0L && !current.isTanThuActive(nowMillis)
    val activeTrials = current.ballTrials.filterValues { it > nowMillis }
    val hasExpiredTrial = activeTrials.size != current.ballTrials.size
    if (hasExpiredTanThu || hasExpiredTrial) {
      saveProgressVault { p ->
        val prunedTrials = p.ballTrials.filterValues { it > nowMillis }
        val next = p.copy(
          tanThuActivatedAtMillis = if (hasExpiredTanThu) 0L else p.tanThuActivatedAtMillis,
          ballTrials = prunedTrials,
        )
        next.copy(
          equippedBall =
            if (next.isBallAvailable(next.equippedBall, nowMillis)) next.equippedBall
            else BallType.FIRE,
          equippedKillEffect =
            if (next.isKillEffectAvailable(next.equippedKillEffect, nowMillis))
              next.equippedKillEffect
            else KillEffectType.DEFAULT_BURST,
        )
      }
    }
  }

  suspend fun claimDailyLoginReward(nowMillis: Long = System.currentTimeMillis()): DailyRewardTier? {
    val current = userProgressFlow.first()
    if (!current.isDailyClaimable(nowMillis)) return null
    val todayEpochDay = UserProgress.currentEpochDay(nowMillis)
    val isConsecutive =
      current.lastDailyClaimEpochDay == 0L || todayEpochDay <= current.lastDailyClaimEpochDay + 1L
    val effectiveStreak = if (isConsecutive) current.dailyStreak else 0
    val tier = DailyRewardTier.tierForNextClaim(effectiveStreak)
    saveProgressVault { p ->
      p.copy(
        coins = (p.coins + tier.coins).coerceAtLeast(0),
        dailyStreak = (effectiveStreak % 7) + 1,
        lastDailyClaimEpochDay = todayEpochDay,
      )
    }
    return tier
  }

  suspend fun processGiftCode(
    rawCode: String,
    otaConfig: OtaLiveConfig,
    nowMillis: Long = System.currentTimeMillis(),
  ): CodeProcessOutcome.Result {
    val trimmed = rawCode.trim()
    if (trimmed.isBlank()) return CodeProcessOutcome.Result(CodeRedeemResult.EXPIRED_OR_INVALID)

    val disabledSet = otaConfig.disabledCodes.map { it.lowercase() }.toSet()
    val allCodes: List<OtaGiftCodeEntry> =
      (otaConfig.activeCodes + OtaLiveConfig.defaultCodes())
        .distinctBy { it.code.lowercase() }
        .filter { it.code.lowercase() !in disabledSet }

    val matched = allCodes.firstOrNull { it.code.equals(trimmed, ignoreCase = true) }
      ?: return CodeProcessOutcome.Result(CodeRedeemResult.EXPIRED_OR_INVALID)

    if (matched.isExpired(nowMillis)) {
      return CodeProcessOutcome.Result(CodeRedeemResult.EXPIRED_OR_INVALID)
    }

    val canonical = matched.code.uppercase()
    val current = userProgressFlow.first()

    if (canonical in current.redeemedCodes && !matched.isTrial24h && !matched.code.equals(TAN_THU_CODE, ignoreCase = true)) {
      return CodeProcessOutcome.Result(CodeRedeemResult.ALREADY_REDEEMED)
    }

    if (matched.isTrial24h || matched.code.equals(TAN_THU_CODE, ignoreCase = true)) {
      if (current.isTanThuActive(nowMillis)) {
        return CodeProcessOutcome.Result(CodeRedeemResult.ALREADY_ACTIVE)
      }
      saveProgressVault { p ->
        p.copy(
          tanThuActivatedAtMillis = nowMillis,
          redeemedCodes = p.redeemedCodes + canonical,
        )
      }
      return CodeProcessOutcome.Result(
        status = CodeRedeemResult.SUCCESS_TRIAL_ACTIVATED,
        grantedTrial24h = true,
        canonicalCode = canonical,
      )
    }

    if (matched.isBallTrialCode()) {
      val trialBall = BallType.fromId(matched.trialBallId)
      val durationMin = matched.trialDurationMinutes.coerceIn(1, 30 * 24 * 60)
      val durationMs = durationMin * 60_000L
      saveProgressVault { p ->
        val baseStart = maxOf(nowMillis, p.ballTrials[trialBall.id] ?: 0L)
        val nextTrials = p.ballTrials + (trialBall.id to (baseStart + durationMs))
        p.copy(
          ballTrials = nextTrials,
          equippedBall = trialBall,
          redeemedCodes = p.redeemedCodes + canonical,
        )
      }
      return CodeProcessOutcome.Result(
        status = CodeRedeemResult.SUCCESS_TRIAL_ACTIVATED,
        grantedTrialBall = trialBall,
        grantedTrialMinutes = durationMin,
        canonicalCode = canonical,
      )
    }

    val rewardBall = matched.rewardBallId.takeIf { it.isNotBlank() }?.let { BallType.fromId(it) }
    val titleVi = matched.titleVi.ifBlank { "Quà Giftcode ${matched.code}" }
    val titleEn = matched.titleEn.ifBlank { "Giftcode Reward ${matched.code}" }
    val bodyVi = matched.bodyVi.ifBlank {
      if (matched.code.equals(TAIDZ_CODE, ignoreCase = true)) {
        "Nhận ngay Thunder Ball miễn phí vĩnh viễn!"
      } else {
        "Bạn đã kích hoạt thành công mã quà tặng ${matched.code}."
      }
    }
    val bodyEn = matched.bodyEn.ifBlank {
      if (matched.code.equals(TAIDZ_CODE, ignoreCase = true)) {
        "Claim your free permanent Thunder Ball!"
      } else {
        "Giftcode ${matched.code} redeemed successfully."
      }
    }

    saveProgressVault { p ->
      p.copy(redeemedCodes = p.redeemedCodes + canonical)
    }

    val letter = MailboxLetter(
      id = "code_${canonical.lowercase().replace(Regex("[^a-z0-9_-]"), "_")}",
      sender = "Ball vs Ball Admin",
      titleVi = titleVi,
      titleEn = titleEn,
      bodyVi = bodyVi,
      bodyEn = bodyEn,
      rewardCoins = matched.rewardCoins,
      rewardBall = rewardBall,
      sourceCode = canonical,
      claimed = false,
      createdAtMillis = nowMillis,
    )

    return CodeProcessOutcome.Result(
      status = CodeRedeemResult.SUCCESS_SENT_TO_MAILBOX,
      letterToSend = letter,
      canonicalCode = canonical,
    )
  }

  suspend fun claimMailboxReward(
    letter: MailboxLetter,
    nowMillis: Long = System.currentTimeMillis(),
  ): UserProgress {
    return saveProgressVault { p ->
      val nextCoins = (p.coins + letter.rewardCoins).coerceAtLeast(0)
      val isTimedTrial = letter.rewardBall != null && letter.trialMinutes > 0
      val nextBalls =
        if (letter.rewardBall != null && !isTimedTrial) p.purchasedBalls + letter.rewardBall
        else p.purchasedBalls
      val nextTrials =
        if (isTimedTrial && letter.rewardBall != null) {
          val baseStart = maxOf(nowMillis, p.ballTrials[letter.rewardBall.id] ?: 0L)
          p.ballTrials + (letter.rewardBall.id to (baseStart + letter.trialMinutes * 60_000L))
        } else {
          p.ballTrials
        }
      val nextEquipped =
        if (letter.rewardBall != null && letter.rewardBall !in p.purchasedBalls) {
          letter.rewardBall
        } else {
          p.equippedBall
        }
      p.copy(
        coins = nextCoins,
        purchasedBalls = nextBalls,
        ballTrials = nextTrials,
        equippedBall = nextEquipped,
      )
    }
  }

  suspend fun buyOrEquipBall(ball: BallType): ShopPurchaseResult {
    val now = System.currentTimeMillis()
    val current = userProgressFlow.first()
    if (current.isBallAvailable(ball, now)) {
      saveProgressVault { it.copy(equippedBall = ball) }
      return ShopPurchaseResult.ALREADY_OWNED
    }
    if (current.coins < ball.price) {
      return ShopPurchaseResult.INSUFFICIENT_COINS
    }
    saveProgressVault { p ->
      p.copy(
        coins = (p.coins - ball.price).coerceAtLeast(0),
        purchasedBalls = p.purchasedBalls + ball,
        equippedBall = ball,
      )
    }
    return ShopPurchaseResult.SUCCESS
  }

  suspend fun buyOrEquipKillEffect(effect: KillEffectType): ShopPurchaseResult {
    val now = System.currentTimeMillis()
    val current = userProgressFlow.first()
    if (current.isKillEffectAvailable(effect, now)) {
      saveProgressVault { it.copy(equippedKillEffect = effect) }
      return ShopPurchaseResult.ALREADY_OWNED
    }
    if (current.coins < effect.price) {
      return ShopPurchaseResult.INSUFFICIENT_COINS
    }
    saveProgressVault { p ->
      p.copy(
        coins = (p.coins - effect.price).coerceAtLeast(0),
        purchasedKillEffects = p.purchasedKillEffects + effect,
        equippedKillEffect = effect,
      )
    }
    return ShopPurchaseResult.SUCCESS
  }

  suspend fun spinGacha(spinCost: Int = GACHA_SPIN_COST): GachaSpinResult {
    val current = userProgressFlow.first()
    if (current.coins < spinCost) {
      return GachaSpinResult.InsufficientCoins
    }

    val nextPityAttempt = current.gachaPityCount + 1
    val triggeredPity = nextPityAttempt >= GACHA_PITY_THRESHOLD
    val roll = Random.nextFloat()

    val rarePool = BallType.entries.filter { it.rarity == BallRarity.RARE }
    val uncommonPool = BallType.entries.filter { it.rarity == BallRarity.UNCOMMON }
    val commonPool = BallType.entries.filter { it.rarity == BallRarity.COMMON }

    val pulledBall: BallType =
      when {
        (triggeredPity && roll < 0.35f) || (!triggeredPity && roll < 0.08f) -> {
          val unownedRare = rarePool.filter { it !in current.purchasedBalls }
          if (unownedRare.isNotEmpty()) unownedRare.random() else rarePool.random()
        }
        triggeredPity || roll < 0.30f -> {
          val unownedUncommon = uncommonPool.filter { it !in current.purchasedBalls }
          if (unownedUncommon.isNotEmpty() && (triggeredPity || Random.nextFloat() < 0.72f)) {
            unownedUncommon.random()
          } else {
            uncommonPool.random()
          }
        }
        else -> {
          val unownedCommon = commonPool.filter { it !in current.purchasedBalls }
          if (unownedCommon.isNotEmpty() && Random.nextFloat() < 0.65f) {
            unownedCommon.random()
          } else {
            commonPool.random()
          }
        }
      }

    val isNew = pulledBall !in current.purchasedBalls
    val refund =
      if (!isNew) {
        when (pulledBall.rarity) {
          BallRarity.RARE -> 360
          BallRarity.UNCOMMON -> 180
          BallRarity.COMMON -> 60
        }
      } else {
        0
      }

    val updatedPity =
      if (pulledBall.rarity == BallRarity.RARE || pulledBall.rarity == BallRarity.UNCOMMON) {
        0
      } else {
        nextPityAttempt.coerceAtMost(9)
      }

    saveProgressVault { p ->
      val nextCoins = (p.coins - spinCost + refund).coerceAtLeast(0)
      p.copy(
        coins = nextCoins,
        purchasedBalls = p.purchasedBalls + pulledBall,
        equippedBall = if (isNew) pulledBall else p.equippedBall,
        gachaPityCount = updatedPity,
        totalSpins = p.totalSpins + 1,
      )
    }

    return GachaSpinResult.Success(
      pulledBall = pulledBall,
      isNewUnlock = isNew,
      duplicateRefundCoins = refund,
      triggeredPity = triggeredPity,
      newPityCount = updatedPity,
    )
  }

  suspend fun recordMatchResult(coinsEarned: Int, playerWon: Boolean): UserProgress {
    return saveProgressVault { p ->
      p.copy(
        coins = (p.coins + coinsEarned).coerceAtLeast(0),
        totalMatches = p.totalMatches + 1,
        totalWins = if (playerWon) p.totalWins + 1 else p.totalWins,
      )
    }
  }

  suspend fun updateSettings(transform: (GameSettings) -> GameSettings) {
    val current = gameSettingsFlow.first()
    val updated = transform(current)
    context.gameDataStore.edit { prefs ->
      prefs[Keys.LANGUAGE] = updated.language.code
      prefs[Keys.TARGET_FPS] = updated.targetFps
      prefs[Keys.AI_DIFFICULTY] = updated.aiDifficulty.id
      prefs[Keys.SFX_ENABLED] = updated.sfxEnabled
      prefs[Keys.MUSIC_ENABLED] = updated.musicEnabled
      prefs[Keys.SFX_VOLUME] = updated.sfxVolume
      prefs[Keys.MUSIC_VOLUME] = updated.musicVolume
      prefs[Keys.BLOOM_SHADERS] = updated.bloomAndShadersEnabled
      prefs[Keys.TRAILS] = updated.trailsEnabled
      prefs[Keys.SCREEN_SHAKE] = updated.screenShakeEnabled
      prefs[Keys.HIT_STOP] = updated.hitStopEnabled
      prefs[Keys.FLOATING_DAMAGE] = updated.floatingDamageEnabled
      prefs[Keys.SPEED_MULTIPLIER] = updated.speedMultiplier
      prefs[Keys.SHOW_FPS] = updated.showFpsCounter
      prefs[Keys.GRAPHICS_QUALITY] = updated.graphicsQuality.id
      prefs[Keys.AUTO_REDUCE_LAG] = updated.autoReduceLag
    }
  }

  suspend fun resetProgress(): UserProgress {
    return saveProgressVault { UserProgress(nickname = it.nickname, playerCode = it.playerCode) }
  }

  companion object {
    private const val CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    fun generatePlayerCode(uidSeed: String? = null): String {
      if (!uidSeed.isNullOrBlank()) {
        val hash = uidSeed.hashCode().toUInt()
        val chars = CharArray(6) { idx ->
          val shift = (hash shr (idx * 5)) % CODE_ALPHABET.length.toUInt()
          CODE_ALPHABET[shift.toInt()]
        }
        return "BVB-${String(chars)}"
      }
      val chars = CharArray(6) { CODE_ALPHABET[Random.nextInt(CODE_ALPHABET.length)] }
      return "BVB-${String(chars)}"
    }
  }
}
