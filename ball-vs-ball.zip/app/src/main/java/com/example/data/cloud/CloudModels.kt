package com.example.data.cloud

import com.example.model.BallBalanceOverride
import com.example.model.BallType
import com.example.model.FriendEntry
import com.example.model.FriendRequestEntry
import com.example.model.KillEffectType
import com.example.model.MailboxLetter
import com.example.model.OnlineEmote
import com.example.model.OnlineRoomPhase
import com.example.model.OnlineRoomState
import com.example.model.OtaBalanceConfig
import com.example.model.PlayerDirectoryEntry
import com.example.model.RoomChatMessage
import com.example.model.RoomInviteEntry
import com.example.model.UserProgress
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfileDoc(
  val userId: String = "",
  val nickname: String = "Challenger",
  val coins: Long = 160L,
  val purchasedBalls: List<String> = listOf(BallType.FIRE.id),
  val purchasedKillEffects: List<String> = listOf(KillEffectType.DEFAULT_BURST.id),
  val equippedBall: String = BallType.FIRE.id,
  val equippedKillEffect: String = KillEffectType.DEFAULT_BURST.id,
  val tanThuActivatedAtMillis: Long = 0L,
  val totalWins: Long = 0L,
  val totalMatches: Long = 0L,
  val gachaPityCount: Long = 0L,
  val totalSpins: Long = 0L,
  val redeemedCodes: List<String> = emptyList(),
  val dailyStreak: Long = 0L,
  val lastDailyClaimEpochDay: Long = 0L,
  val playerCode: String = "",
  val ballTrials: Map<String, Long> = emptyMap(),
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun toUserProgress(): UserProgress {
    val balls =
      purchasedBalls.map { BallType.fromId(it) }.toSet() + BallType.FIRE
    val effects =
      purchasedKillEffects.map { KillEffectType.fromId(it) }.toSet() + KillEffectType.DEFAULT_BURST
    return UserProgress(
      nickname = nickname.ifBlank { "Challenger" },
      coins = coins.toInt().coerceAtLeast(0),
      purchasedBalls = balls,
      purchasedKillEffects = effects,
      equippedBall = BallType.fromId(equippedBall),
      equippedKillEffect = KillEffectType.fromId(equippedKillEffect),
      tanThuActivatedAtMillis = tanThuActivatedAtMillis.coerceAtLeast(0L),
      totalWins = totalWins.toInt().coerceAtLeast(0),
      totalMatches = totalMatches.toInt().coerceAtLeast(0),
      gachaPityCount = gachaPityCount.toInt().coerceIn(0, 9),
      totalSpins = totalSpins.toInt().coerceAtLeast(0),
      redeemedCodes = redeemedCodes.toSet(),
      dailyStreak = dailyStreak.toInt().coerceAtLeast(0),
      lastDailyClaimEpochDay = lastDailyClaimEpochDay.coerceAtLeast(0L),
      playerCode = playerCode.take(16),
      ballTrials = ballTrials.filterValues { it > 0L },
    )
  }

  companion object {
    fun createMap(uid: String, progress: UserProgress): Map<String, Any> = mapOf(
      "userId" to uid,
      "nickname" to progress.nickname.trim().ifBlank { "Challenger" }.take(24),
      "coins" to progress.coins.coerceAtLeast(0).toLong(),
      "purchasedBalls" to (progress.purchasedBalls + BallType.FIRE).map { it.id },
      "purchasedKillEffects" to
        (progress.purchasedKillEffects + KillEffectType.DEFAULT_BURST).map { it.id },
      "equippedBall" to progress.equippedBall.id,
      "equippedKillEffect" to progress.equippedKillEffect.id,
      "tanThuActivatedAtMillis" to progress.tanThuActivatedAtMillis.coerceAtLeast(0L),
      "totalWins" to progress.totalWins.coerceAtLeast(0).toLong(),
      "totalMatches" to progress.totalMatches.coerceAtLeast(0).toLong(),
      "gachaPityCount" to progress.gachaPityCount.coerceIn(0, 10).toLong(),
      "totalSpins" to progress.totalSpins.coerceAtLeast(0).toLong(),
      "redeemedCodes" to progress.redeemedCodes.take(64),
      "dailyStreak" to progress.dailyStreak.coerceIn(0, 3650).toLong(),
      "lastDailyClaimEpochDay" to progress.lastDailyClaimEpochDay.coerceAtLeast(0L),
      "playerCode" to progress.playerCode.take(16),
      "ballTrials" to progress.ballTrials.filterValues { it > 0L },
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )

    fun updateMap(progress: UserProgress): Map<String, Any> = mapOf(
      "nickname" to progress.nickname.trim().ifBlank { "Challenger" }.take(24),
      "coins" to progress.coins.coerceAtLeast(0).toLong(),
      "purchasedBalls" to (progress.purchasedBalls + BallType.FIRE).map { it.id },
      "purchasedKillEffects" to
        (progress.purchasedKillEffects + KillEffectType.DEFAULT_BURST).map { it.id },
      "equippedBall" to progress.equippedBall.id,
      "equippedKillEffect" to progress.equippedKillEffect.id,
      "tanThuActivatedAtMillis" to progress.tanThuActivatedAtMillis.coerceAtLeast(0L),
      "totalWins" to progress.totalWins.coerceAtLeast(0).toLong(),
      "totalMatches" to progress.totalMatches.coerceAtLeast(0).toLong(),
      "gachaPityCount" to progress.gachaPityCount.coerceIn(0, 10).toLong(),
      "totalSpins" to progress.totalSpins.coerceAtLeast(0).toLong(),
      "redeemedCodes" to progress.redeemedCodes.take(64),
      "dailyStreak" to progress.dailyStreak.coerceIn(0, 3650).toLong(),
      "lastDailyClaimEpochDay" to progress.lastDailyClaimEpochDay.coerceAtLeast(0L),
      "playerCode" to progress.playerCode.take(16),
      "ballTrials" to progress.ballTrials.filterValues { it > 0L },
      "updatedAt" to FieldValue.serverTimestamp(),
    )
  }
}

@IgnoreExtraProperties
data class MailboxDoc(
  @DocumentId val id: String = "",
  val sender: String = "System",
  val titleVi: String = "",
  val titleEn: String = "",
  val bodyVi: String = "",
  val bodyEn: String = "",
  val rewardCoins: Long = 0L,
  val rewardBallId: String = "",
  val trialMinutes: Long = 0L,
  val sourceCode: String = "",
  val claimed: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun toDomain(): MailboxLetter =
    MailboxLetter(
      id = id,
      sender = sender,
      titleVi = titleVi,
      titleEn = titleEn,
      bodyVi = bodyVi,
      bodyEn = bodyEn,
      rewardCoins = rewardCoins.toInt().coerceAtLeast(0),
      rewardBall = rewardBallId.takeIf { it.isNotBlank() }?.let { BallType.fromId(it) },
      sourceCode = sourceCode,
      claimed = claimed,
      createdAtMillis = (createdAt ?: updatedAt)?.toDate()?.time ?: 0L,
      trialMinutes = trialMinutes.toInt().coerceAtLeast(0),
    )

  fun toCreateMap(): Map<String, Any> = mapOf(
    "sender" to sender.ifBlank { "System" }.take(40),
    "titleVi" to titleVi.ifBlank { "Thong bao" }.take(120),
    "titleEn" to titleEn.ifBlank { "Notice" }.take(120),
    "bodyVi" to bodyVi.ifBlank { "-" }.take(500),
    "bodyEn" to bodyEn.ifBlank { "-" }.take(500),
    "rewardCoins" to rewardCoins.coerceIn(0L, 100000L),
    "rewardBallId" to rewardBallId.take(32),
    "trialMinutes" to trialMinutes.coerceIn(0L, 43200L),
    "sourceCode" to sourceCode.take(40),
    "claimed" to claimed,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp(),
  )
}

@IgnoreExtraProperties
data class RoomChatMessageDoc(
  @DocumentId val id: String = "",
  val senderUid: String = "",
  val senderName: String = "",
  val text: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
) {
  fun toDomain(): RoomChatMessage =
    RoomChatMessage(
      id = id,
      senderUid = senderUid,
      senderName = senderName.ifBlank { "Player" },
      text = text,
      sentAtMillis = createdAt?.toDate()?.time ?: System.currentTimeMillis(),
    )
}

@IgnoreExtraProperties
data class OnlineRoomDoc(
  @DocumentId val id: String = "",
  val hostUid: String = "",
  val hostName: String = "",
  val guestUid: String = "",
  val guestName: String = "",
  val status: String = OnlineRoomPhase.WAITING.wireValue,
  val hostPicks: List<String> = emptyList(),
  val guestPicks: List<String> = emptyList(),
  val hostBannedBall: String = "",
  val guestBannedBall: String = "",
  val hostFinalBall: String = "",
  val guestFinalBall: String = "",
  val seed: Long = 0L,
  val winnerUid: String = "",
  val matchDurationSec: Double = 0.0,
  val rewardCoins: Long = 0L,
  val hostReady: Boolean = false,
  val guestReady: Boolean = false,
  val hostScore: Long = 0L,
  val guestScore: Long = 0L,
  val currentRound: Long = 1L,
  val hostLastHeartbeatMs: Long = 0L,
  val guestLastHeartbeatMs: Long = 0L,
  val hostEmote: String = "",
  val guestEmote: String = "",
  val hostEmoteAtMs: Long = 0L,
  val guestEmoteAtMs: Long = 0L,
  val hostIsAdmin: Boolean = false,
  val guestIsAdmin: Boolean = false,
  val hostAimRad: Double = -99.0,
  val guestAimRad: Double = -99.0,
  val balanceSnapshot: Map<String, Any>? = null,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun toDomain(roomCode: String = id): OnlineRoomState =
    OnlineRoomState(
      roomCode = roomCode,
      hostUid = hostUid,
      hostName = hostName,
      guestUid = guestUid,
      guestName = guestName,
      phase = OnlineRoomPhase.fromWire(status),
      hostPicks = hostPicks.map { BallType.fromId(it) },
      guestPicks = guestPicks.map { BallType.fromId(it) },
      hostBannedBall = hostBannedBall.takeIf { it.isNotBlank() }?.let { BallType.fromId(it) },
      guestBannedBall = guestBannedBall.takeIf { it.isNotBlank() }?.let { BallType.fromId(it) },
      hostFinalBall = hostFinalBall.takeIf { it.isNotBlank() }?.let { BallType.fromId(it) },
      guestFinalBall = guestFinalBall.takeIf { it.isNotBlank() }?.let { BallType.fromId(it) },
      seed = seed,
      winnerUid = winnerUid,
      matchDurationSec = matchDurationSec.toFloat(),
      rewardCoins = rewardCoins.toInt().coerceAtLeast(0),
      hostReady = hostReady,
      guestReady = guestReady,
      hostScore = hostScore.toInt().coerceIn(0, 5),
      guestScore = guestScore.toInt().coerceIn(0, 5),
      currentRound = currentRound.toInt().coerceIn(1, 9),
      hostLastHeartbeatMs = hostLastHeartbeatMs.coerceAtLeast(0L),
      guestLastHeartbeatMs = guestLastHeartbeatMs.coerceAtLeast(0L),
      hostEmote = OnlineEmote.fromId(hostEmote),
      guestEmote = OnlineEmote.fromId(guestEmote),
      hostEmoteAtMs = hostEmoteAtMs.coerceAtLeast(0L),
      guestEmoteAtMs = guestEmoteAtMs.coerceAtLeast(0L),
      hostIsAdmin = hostIsAdmin,
      guestIsAdmin = guestIsAdmin,
      hostAimRad = hostAimRad,
      guestAimRad = guestAimRad,
      balanceSnapshot = parseBalanceMap(balanceSnapshot),
    )

  companion object {
    fun balanceToMap(balance: OtaBalanceConfig): Map<String, Any> {
      val ballOverridesMap = BallType.entries.associate { type ->
        val ov = balance.overrideFor(type)
        type.id to mapOf(
          "hp" to ov.hp.coerceIn(60, 400),
          "damageScale" to ov.damageScale.toDouble().coerceIn(0.4, 2.5),
        )
      }
      return mapOf(
        "thunderDeathboltPct" to balance.thunderDeathboltPct.toDouble(),
        "thunderAfterimageDurationSec" to balance.thunderAfterimageDurationSec.toDouble(),
        "iceShardSpawnIntervalSec" to balance.iceShardSpawnIntervalSec.toDouble(),
        "iceShardDamage" to balance.iceShardDamage,
        "iceFreezeDurationSec" to balance.iceFreezeDurationSec.toDouble(),
        "iceFreezeRageDrainPct" to balance.iceFreezeRageDrainPct.toDouble(),
        "icePostFreezeSlowPct" to balance.icePostFreezeSlowPct.toDouble(),
        "groundSkill1CooldownSec" to balance.groundSkill1CooldownSec.toDouble(),
        "groundSkill1Damage" to balance.groundSkill1Damage.toDouble(),
        "groundChargeReduction" to balance.groundChargeReduction.toDouble(),
        "groundArmorAllReduction" to balance.groundArmorAllReduction.toDouble(),
        "groundArmorDurationSec" to balance.groundArmorDurationSec.toDouble(),
        "groundArmorCooldownSec" to balance.groundArmorCooldownSec.toDouble(),
        "antRegenIntervalSec" to balance.antRegenIntervalSec.toDouble(),
        "antMaxRegens" to balance.antMaxRegens,
        "antSkill1CooldownSec" to balance.antSkill1CooldownSec.toDouble(),
        "ballOverrides" to ballOverridesMap,
      )
    }

    fun parseBalanceMap(balMap: Map<*, *>?): OtaBalanceConfig {
      if (balMap == null) return OtaBalanceConfig()
      val rawBalls = balMap["ballOverrides"] as? Map<*, *>
      val defaultMap = OtaBalanceConfig.defaultBallOverrides()
      val overrides = BallType.entries.associate { type ->
        val entry = rawBalls?.get(type.id) as? Map<*, *>
        val fallback = defaultMap[type.id] ?: BallBalanceOverride(hp = type.baseHp, damageScale = 1.0f)
        val hp = ((entry?.get("hp") as? Number)?.toInt() ?: fallback.hp).coerceIn(60, 400)
        val dmg = ((entry?.get("damageScale") as? Number)?.toFloat() ?: fallback.damageScale).coerceIn(0.4f, 2.5f)
        type.id to BallBalanceOverride(hp = hp, damageScale = dmg)
      }
      return OtaBalanceConfig(
        thunderDeathboltPct = ((balMap["thunderDeathboltPct"] as? Number)?.toFloat() ?: 0.32f).coerceIn(0.15f, 0.70f),
        thunderAfterimageDurationSec = ((balMap["thunderAfterimageDurationSec"] as? Number)?.toFloat() ?: 3.5f).coerceIn(1.5f, 6.0f),
        iceShardSpawnIntervalSec = ((balMap["iceShardSpawnIntervalSec"] as? Number)?.toFloat() ?: 0.68f).coerceIn(0.35f, 1.5f),
        iceShardDamage = ((balMap["iceShardDamage"] as? Number)?.toInt() ?: 6).coerceIn(2, 15),
        iceFreezeDurationSec = ((balMap["iceFreezeDurationSec"] as? Number)?.toFloat() ?: 10.0f).coerceIn(3f, 15f),
        iceFreezeRageDrainPct = ((balMap["iceFreezeRageDrainPct"] as? Number)?.toFloat() ?: 0.70f).coerceIn(0.1f, 1.0f),
        icePostFreezeSlowPct = ((balMap["icePostFreezeSlowPct"] as? Number)?.toFloat() ?: 0.40f).coerceIn(0.1f, 0.75f),
        groundSkill1CooldownSec = ((balMap["groundSkill1CooldownSec"] as? Number)?.toFloat() ?: 5.0f).coerceIn(3f, 25f),
        groundSkill1Damage = ((balMap["groundSkill1Damage"] as? Number)?.toFloat() ?: 12f).coerceIn(5f, 25f),
        groundChargeReduction = ((balMap["groundChargeReduction"] as? Number)?.toFloat() ?: 0.10f).coerceIn(0.05f, 0.40f),
        groundArmorAllReduction = ((balMap["groundArmorAllReduction"] as? Number)?.toFloat() ?: 0.30f).coerceIn(0.15f, 0.65f),
        groundArmorDurationSec = ((balMap["groundArmorDurationSec"] as? Number)?.toFloat() ?: 5.0f).coerceIn(2f, 8f),
        groundArmorCooldownSec = ((balMap["groundArmorCooldownSec"] as? Number)?.toFloat() ?: 18.0f).coerceIn(10f, 30f),
        antRegenIntervalSec = ((balMap["antRegenIntervalSec"] as? Number)?.toFloat() ?: 16.0f).coerceIn(8f, 30f),
        antMaxRegens = ((balMap["antMaxRegens"] as? Number)?.toInt() ?: 3).coerceIn(1, 6),
        antSkill1CooldownSec = ((balMap["antSkill1CooldownSec"] as? Number)?.toFloat() ?: 8.0f).coerceIn(4f, 18f),
        ballOverrides = overrides,
      )
    }

    fun createMap(
      hostUid: String,
      hostName: String,
      seed: Long,
      balance: OtaBalanceConfig = OtaBalanceConfig(),
      hostIsAdmin: Boolean = false,
      nowMillis: Long = System.currentTimeMillis(),
      hostReady: Boolean = false,
    ): Map<String, Any> = mapOf(
      "hostUid" to hostUid,
      "hostName" to hostName.trim().ifBlank { "Host" }.take(24),
      "guestUid" to "",
      "guestName" to "",
      "status" to OnlineRoomPhase.WAITING.wireValue,
      "hostPicks" to emptyList<String>(),
      "guestPicks" to emptyList<String>(),
      "hostBannedBall" to "",
      "guestBannedBall" to "",
      "hostFinalBall" to "",
      "guestFinalBall" to "",
      "seed" to seed,
      "winnerUid" to "",
      "matchDurationSec" to 0.0,
      "rewardCoins" to 0L,
      "hostReady" to hostReady,
      "guestReady" to false,
      "hostScore" to 0L,
      "guestScore" to 0L,
      "currentRound" to 1L,
      "hostLastHeartbeatMs" to nowMillis,
      "guestLastHeartbeatMs" to 0L,
      "hostEmote" to "",
      "guestEmote" to "",
      "hostEmoteAtMs" to 0L,
      "guestEmoteAtMs" to 0L,
      "hostIsAdmin" to hostIsAdmin,
      "guestIsAdmin" to false,
      "hostAimRad" to -99.0,
      "guestAimRad" to -99.0,
      "balanceSnapshot" to balanceToMap(balance),
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )
  }
}

@IgnoreExtraProperties
data class PlayerDirectoryDoc(
  @DocumentId val id: String = "",
  val uid: String = "",
  val playerCode: String = "",
  val nickname: String = "",
  val nicknameLower: String = "",
  val totalWins: Long = 0L,
  val totalMatches: Long = 0L,
  @get:PropertyName("isAdmin") @field:PropertyName("isAdmin")
  val isAdmin: Boolean = false,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun toDomain(): PlayerDirectoryEntry =
    PlayerDirectoryEntry(
      uid = uid.ifBlank { id },
      playerCode = playerCode,
      nickname = nickname.ifBlank { "Challenger" },
      totalWins = totalWins.toInt().coerceAtLeast(0),
      totalMatches = totalMatches.toInt().coerceAtLeast(0),
      isAdmin = isAdmin,
      updatedAtMillis = updatedAt?.toDate()?.time ?: 0L,
    )
}

@IgnoreExtraProperties
data class FriendRequestDoc(
  @DocumentId val id: String = "",
  val fromUid: String = "",
  val fromCode: String = "",
  val fromName: String = "",
  val fromIsAdmin: Boolean = false,
  val toUid: String = "",
  val toCode: String = "",
  val toName: String = "",
  val status: String = "pending",
  @ServerTimestamp val createdAt: Timestamp? = null,
) {
  fun toDomain(): FriendRequestEntry =
    FriendRequestEntry(
      id = id,
      fromUid = fromUid,
      fromCode = fromCode,
      fromName = fromName,
      fromIsAdmin = fromIsAdmin,
      toUid = toUid,
      toCode = toCode,
      toName = toName,
      status = status,
      createdAtMillis = createdAt?.toDate()?.time ?: 0L,
    )
}

@IgnoreExtraProperties
data class FriendDoc(
  @DocumentId val id: String = "",
  val uid: String = "",
  val playerCode: String = "",
  val nickname: String = "",
  @get:PropertyName("isAdmin") @field:PropertyName("isAdmin")
  val isAdmin: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
) {
  fun toDomain(): FriendEntry =
    FriendEntry(
      uid = uid.ifBlank { id },
      playerCode = playerCode,
      nickname = nickname.ifBlank { "Friend" },
      isAdmin = isAdmin,
      addedAtMillis = createdAt?.toDate()?.time ?: 0L,
    )
}

@IgnoreExtraProperties
data class RoomInviteDoc(
  @DocumentId val id: String = "",
  val roomCode: String = "",
  val fromUid: String = "",
  val fromName: String = "",
  val fromIsAdmin: Boolean = false,
  val toUid: String = "",
  val status: String = "pending",
  val expiresAtMillis: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
) {
  fun toDomain(): RoomInviteEntry =
    RoomInviteEntry(
      id = id,
      roomCode = roomCode,
      fromUid = fromUid,
      fromName = fromName,
      fromIsAdmin = fromIsAdmin,
      toUid = toUid,
      status = status,
      createdAtMillis = createdAt?.toDate()?.time ?: 0L,
      expiresAtMillis = expiresAtMillis,
    )
}

@IgnoreExtraProperties
data class MatchmakingTicketDoc(
  @DocumentId val id: String = "",
  val uid: String = "",
  val nickname: String = "",
  @get:PropertyName("isAdmin") @field:PropertyName("isAdmin")
  val isAdmin: Boolean = false,
  val status: String = "waiting",
  val roomCode: String = "",
  val matchedWithUid: String = "",
  val heartbeatMs: Long = 0L,
) {
  fun toDomain(): com.example.model.MatchmakingTicketEntry =
    com.example.model.MatchmakingTicketEntry(
      uid = uid.ifBlank { id },
      nickname = nickname.ifBlank { "Player" },
      isAdmin = isAdmin,
      status = status,
      roomCode = roomCode,
      matchedWithUid = matchedWithUid,
      heartbeatMs = heartbeatMs.coerceAtLeast(0L),
    )
}

