package com.example.data.cloud

import android.content.Context
import com.example.R
import com.example.data.GamePreferencesRepository
import com.example.model.ADMIN_OWNER_EMAIL
import com.example.model.APP_DISPLAY_VERSION
import com.example.model.APP_VERSION_CODE
import com.example.model.BallType
import com.example.model.FriendEntry
import com.example.model.FriendRequestEntry
import com.example.model.GACHA_SPIN_COST
import com.example.model.KillEffectType
import com.example.model.MailboxLetter
import com.example.model.OtaAppUpdateConfig
import com.example.model.OtaBalanceConfig
import com.example.model.OtaGiftCodeEntry
import com.example.model.OtaLiveConfig
import com.example.model.OtaVfxConfig
import com.example.model.PlayerDirectoryEntry
import com.example.model.RoomInviteEntry
import com.example.model.UserProgress
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class CloudGameRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    Firebase.auth,
  )

  fun isAdminAccount(): Boolean =
    auth.currentUser?.email.equals(ADMIN_OWNER_EMAIL, ignoreCase = true)

  private fun requireUserId(): String =
    auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

  suspend fun ensureOrLoadUserProfile(
    fallbackLocalProgress: UserProgress,
    mergeFromGuest: Boolean = false,
  ): UserProgress {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid)
    return try {
      val snapshot = docRef.get().await()
      if (snapshot.exists()) {
        val doc = snapshot.toObject(UserProfileDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        val rawCloud = doc?.toUserProgress() ?: fallbackLocalProgress
        val ensCode = rawCloud.playerCode.ifBlank {
          fallbackLocalProgress.playerCode.ifBlank { GamePreferencesRepository.generatePlayerCode(uid) }
        }
        val cloud = if (rawCloud.playerCode.isBlank()) rawCloud.copy(playerCode = ensCode) else rawCloud
        if (!mergeFromGuest) {
          if (rawCloud.playerCode.isBlank()) {
            runCatching { docRef.update(UserProfileDoc.updateMap(cloud)).await() }
          }
          runCatching { syncPlayerDirectory(cloud) }
          return cloud
        }

        val guestExtraCoins = (fallbackLocalProgress.coins - 160).coerceAtLeast(0)
        val merged = cloud.copy(
          coins = (cloud.coins + guestExtraCoins).coerceAtLeast(0),
          purchasedBalls = cloud.purchasedBalls + fallbackLocalProgress.purchasedBalls + BallType.FIRE,
          purchasedKillEffects =
            cloud.purchasedKillEffects + fallbackLocalProgress.purchasedKillEffects + KillEffectType.DEFAULT_BURST,
          redeemedCodes = cloud.redeemedCodes + fallbackLocalProgress.redeemedCodes,
          totalMatches = cloud.totalMatches + fallbackLocalProgress.totalMatches,
          totalWins = cloud.totalWins + fallbackLocalProgress.totalWins,
          dailyStreak = maxOf(cloud.dailyStreak, fallbackLocalProgress.dailyStreak),
          lastDailyClaimEpochDay = maxOf(cloud.lastDailyClaimEpochDay, fallbackLocalProgress.lastDailyClaimEpochDay),
          playerCode = ensCode,
          ballTrials = cloud.ballTrials + fallbackLocalProgress.ballTrials,
        )
        if (merged != cloud || rawCloud.playerCode.isBlank()) {
          docRef.update(UserProfileDoc.updateMap(merged)).await()
        }
        runCatching { syncPlayerDirectory(merged) }
        merged
      } else {
        val defaultName =
          fallbackLocalProgress.nickname.takeIf { it.isNotBlank() && it != "Challenger" }
            ?: auth.currentUser?.displayName?.trim()?.takeIf { it.length >= 2 }?.take(24)
            ?: "Challenger"
        val ensCode = fallbackLocalProgress.playerCode.ifBlank {
          GamePreferencesRepository.generatePlayerCode(uid)
        }
        val seeded = fallbackLocalProgress.copy(nickname = defaultName, playerCode = ensCode)
        docRef.set(UserProfileDoc.createMap(uid, seeded)).await()
        runCatching { syncPlayerDirectory(seeded) }
        seedInitialReleaseNoticeIfMissing(uid)
        seeded
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, docRef.path, auth)
      throw e
    }
  }

  private suspend fun seedInitialReleaseNoticeIfMissing(uid: String) {
    val mailRef = db.collection("users").document(uid).collection("mailbox").document("welcome_v103_beta")
    runCatching {
      if (!mailRef.get().await().exists()) {
        mailRef.set(
          MailboxDoc(
            sender = "Ball vs Ball Admin",
            titleVi = "Chao mung 1.0.3 Beta - Ky Bang Ha & Ghep Nhanh!",
            titleEn = "Welcome 1.0.3 Beta - Absolute Zero & Quick Match!",
            bodyVi = "Ice Ball dai tu Ky Bang Ha 10s, can bang 6 bong ngang co, VFX/Am thanh moi va Ghep Ngau Nhien 1vs1 Online!",
            bodyEn = "Enjoy 10s Absolute Zero Ice Ball, 6-ball balance parity, upgraded VFX/Audio & Quick 1vs1 Matchmaking!",
            rewardCoins = 120L,
            rewardBallId = "",
            sourceCode = "SYSTEM_V103_BETA",
            claimed = false,
          ).toCreateMap()
        ).await()
      }
    }
  }

  fun observeUserProfile(): Flow<UserProgress> = flow {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid)
    emitAll(
      docRef.snapshots()
        .map { snapshot ->
          val doc = snapshot.toObject(UserProfileDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          doc?.toUserProgress() ?: UserProgress()
        }
        .catch { error ->
          val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val exceptionToLog = firestoreError ?: (error as? Exception)
          if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path, auth)
          }
          throw error
        }
    )
  }

  suspend fun saveUserProgress(progress: UserProgress) {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid)
    try {
      docRef.update(UserProfileDoc.updateMap(progress)).await()
      runCatching { syncPlayerDirectory(progress) }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
      throw e
    }
  }

  fun observeMailbox(): Flow<List<MailboxLetter>> = flow {
    val uid = requireUserId()
    val path = "users/$uid/mailbox"
    emitAll(
      db.collection("users").document(uid).collection("mailbox")
        .orderBy("createdAt", Query.Direction.DESCENDING)
        .snapshots()
        .map { querySnapshot ->
          querySnapshot
            .toObjects(MailboxDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .map { it.toDomain() }
        }
        .catch { error ->
          val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val exceptionToLog = firestoreError ?: (error as? Exception)
          if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, OperationType.LIST, path, auth)
          }
          throw error
        }
    )
  }

  suspend fun sendMailboxReward(
    mailId: String,
    sender: String,
    titleVi: String,
    titleEn: String,
    bodyVi: String,
    bodyEn: String,
    rewardCoins: Int,
    rewardBall: BallType?,
    sourceCode: String,
  ) {
    val uid = requireUserId()
    val mailRef = db.collection("users").document(uid).collection("mailbox").document(mailId)
    val payload = MailboxDoc(
      sender = sender,
      titleVi = titleVi,
      titleEn = titleEn,
      bodyVi = bodyVi,
      bodyEn = bodyEn,
      rewardCoins = rewardCoins.toLong(),
      rewardBallId = rewardBall?.id.orEmpty(),
      sourceCode = sourceCode,
      claimed = false,
    ).toCreateMap()
    try {
      mailRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, mailRef.path, auth)
      throw e
    }
  }

  suspend fun markMailClaimed(mailId: String) {
    val uid = requireUserId()
    val mailRef = db.collection("users").document(uid).collection("mailbox").document(mailId)
    try {
      mailRef.update(
        mapOf(
          "claimed" to true,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, mailRef.path, auth)
      throw e
    }
  }

  private fun parseOtaSnapshot(snapshot: DocumentSnapshot): OtaLiveConfig {
    if (!snapshot.exists()) return OtaLiveConfig(syncedFromCloud = true)
    val configVersion = (snapshot.getLong("configVersion") ?: 105L).toInt()
    val gachaCost = (snapshot.getLong("gachaSpinCost") ?: GACHA_SPIN_COST.toLong()).toInt().coerceAtLeast(10)
    @Suppress("UNCHECKED_CAST")
    val rawCodes = snapshot.get("activeCodes") as? List<*> ?: emptyList<Any>()
    val parsedCodes = rawCodes.mapNotNull { item ->
      when (item) {
        is Map<*, *> -> {
          val code = (item["code"] as? String)?.trim().orEmpty()
          if (code.isBlank()) null
          else OtaGiftCodeEntry(
            code = code,
            rewardCoins = (item["rewardCoins"] as? Number)?.toInt() ?: 0,
            rewardBallId = (item["rewardBallId"] as? String).orEmpty(),
            titleVi = (item["titleVi"] as? String).orEmpty(),
            titleEn = (item["titleEn"] as? String).orEmpty(),
            bodyVi = (item["bodyVi"] as? String).orEmpty(),
            bodyEn = (item["bodyEn"] as? String).orEmpty(),
            isTrial24h = (item["isTrial24h"] as? Boolean) ?: false,
            trialBallId = (item["trialBallId"] as? String).orEmpty(),
            trialDurationMinutes = (item["trialDurationMinutes"] as? Number)?.toInt() ?: 0,
            createdAtMillis = (item["createdAtMillis"] as? Number)?.toLong() ?: 0L,
            expiresAtMillis = (item["expiresAtMillis"] as? Number)?.toLong() ?: 0L,
          )
        }
        is String -> OtaGiftCodeEntry(code = item.trim())
        else -> null
      }
    }.ifEmpty { OtaLiveConfig.defaultCodes() }

    @Suppress("UNCHECKED_CAST")
    val disabledCodes = (snapshot.get("disabledCodes") as? List<*>)
      ?.mapNotNull { (it as? String)?.trim()?.takeIf { s -> s.isNotEmpty() } }
      .orEmpty()

    @Suppress("UNCHECKED_CAST")
    val balMap = snapshot.get("balanceOverrides") as? Map<*, *>
    val balance = OnlineRoomDoc.parseBalanceMap(balMap)

    @Suppress("UNCHECKED_CAST")
    val vfxMap = snapshot.get("vfxOverrides") as? Map<*, *>
    val vfx = if (vfxMap != null) {
      OtaVfxConfig(
        particleMultiplier = ((vfxMap["particleMultiplier"] as? Number)?.toFloat() ?: 1.28f).coerceIn(0.5f, 2.2f),
        glowIntensity = ((vfxMap["glowIntensity"] as? Number)?.toFloat() ?: 1.30f).coerceIn(0.5f, 2.2f),
        effectScale = ((vfxMap["effectScale"] as? Number)?.toFloat() ?: 1.10f).coerceIn(0.7f, 1.6f),
        vibrancyBoost = ((vfxMap["vibrancyBoost"] as? Number)?.toFloat() ?: 1.15f).coerceIn(0.7f, 1.6f),
      )
    } else {
      OtaVfxConfig()
    }

    @Suppress("UNCHECKED_CAST")
    val appUpdMap = snapshot.get("appUpdate") as? Map<*, *>
    val appUpdate = if (appUpdMap != null) {
      val rawUrl = OtaAppUpdateConfig.normalizeDownloadUrl(
        (appUpdMap["downloadUrl"] as? String).orEmpty()
      ).take(500)
      val safeUrl = if (OtaAppUpdateConfig.isSafeHttpsUrl(rawUrl)) rawUrl else ""
      OtaAppUpdateConfig(
        latestVersionCode = ((appUpdMap["latestVersionCode"] as? Number)?.toInt() ?: APP_VERSION_CODE).coerceIn(1, 999999),
        latestVersionName = (appUpdMap["latestVersionName"] as? String)?.trim().orEmpty().take(40).ifBlank { APP_DISPLAY_VERSION },
        minSupportedVersionCode = ((appUpdMap["minSupportedVersionCode"] as? Number)?.toInt() ?: APP_VERSION_CODE).coerceIn(1, 999999),
        downloadUrl = safeUrl,
        releaseNotesVi = (appUpdMap["releaseNotesVi"] as? String).orEmpty().take(500),
        releaseNotesEn = (appUpdMap["releaseNotesEn"] as? String).orEmpty().take(500),
      )
    } else {
      OtaAppUpdateConfig()
    }

    val adminNoticeVi = (snapshot.getString("adminNoticeVi") ?: "").take(300)
    val adminNoticeEn = (snapshot.getString("adminNoticeEn") ?: "").take(300)
    val adminNoticeExpiresAtMillis =
      (snapshot.getLong("adminNoticeExpiresAtMillis") ?: 0L).coerceAtLeast(0L)

    return OtaLiveConfig(
      configVersion = configVersion,
      gachaSpinCost = gachaCost,
      activeCodes = parsedCodes,
      disabledCodes = disabledCodes,
      balance = balance,
      vfx = vfx,
      appUpdate = appUpdate,
      adminNoticeVi = adminNoticeVi,
      adminNoticeEn = adminNoticeEn,
      adminNoticeExpiresAtMillis = adminNoticeExpiresAtMillis,
      syncedFromCloud = true,
    )
  }

  suspend fun fetchOtaLiveConfig(): OtaLiveConfig {
    auth.currentUser?.uid ?: return OtaLiveConfig(syncedFromCloud = false)
    val docRef = db.collection("ota_config").document("live")
    return try {
      val snapshot = docRef.get().await()
      parseOtaSnapshot(snapshot)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, docRef.path, auth)
      OtaLiveConfig(syncedFromCloud = false)
    }
  }

  fun observeOtaLiveConfig(): Flow<OtaLiveConfig> = flow {
    val uid = requireUserId()
    val docRef = db.collection("ota_config").document("live")
    emitAll(
      docRef.snapshots()
        .map { snapshot -> parseOtaSnapshot(snapshot) }
        .catch { error ->
          val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val exceptionToLog = firestoreError ?: (error as? Exception)
          if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path, auth)
          }
          throw error
        }
    )
  }

  suspend fun saveOtaLiveConfig(config: OtaLiveConfig): OtaLiveConfig {
    requireUserId()
    check(isAdminAccount()) { "Only verified Admin ($ADMIN_OWNER_EMAIL) may publish OTA updates." }
    val docRef = db.collection("ota_config").document("live")
    val nextVersion = (config.configVersion + 1).coerceAtLeast(106)
    val codesPayload = config.activeCodes.take(40).map { entry ->
      mapOf(
        "code" to entry.code.trim(),
        "rewardCoins" to entry.rewardCoins.coerceIn(0, 100000),
        "rewardBallId" to entry.rewardBallId,
        "titleVi" to entry.titleVi.take(120),
        "titleEn" to entry.titleEn.take(120),
        "bodyVi" to entry.bodyVi.take(400),
        "bodyEn" to entry.bodyEn.take(400),
        "isTrial24h" to entry.isTrial24h,
        "trialBallId" to entry.trialBallId,
        "trialDurationMinutes" to entry.trialDurationMinutes.coerceIn(0, 43200),
        "createdAtMillis" to entry.createdAtMillis,
        "expiresAtMillis" to entry.expiresAtMillis,
      )
    }
    val payload = mapOf(
      "configVersion" to nextVersion,
      "gachaSpinCost" to config.gachaSpinCost.coerceIn(10, 5000),
      "activeCodes" to codesPayload,
      "disabledCodes" to config.disabledCodes.take(40),
      "balanceOverrides" to OnlineRoomDoc.balanceToMap(config.balance),
      "vfxOverrides" to mapOf(
        "particleMultiplier" to config.vfx.particleMultiplier.toDouble(),
        "glowIntensity" to config.vfx.glowIntensity.toDouble(),
        "effectScale" to config.vfx.effectScale.toDouble(),
        "vibrancyBoost" to config.vfx.vibrancyBoost.toDouble(),
      ),
      "appUpdate" to mapOf(
        "latestVersionCode" to config.appUpdate.latestVersionCode.coerceIn(1, 999999),
        "latestVersionName" to config.appUpdate.latestVersionName.trim().take(40),
        "minSupportedVersionCode" to config.appUpdate.minSupportedVersionCode.coerceIn(1, 999999),
        "downloadUrl" to OtaAppUpdateConfig.normalizeDownloadUrl(config.appUpdate.downloadUrl).let {
          if (OtaAppUpdateConfig.isSafeHttpsUrl(it)) it.take(500) else ""
        },
        "releaseNotesVi" to config.appUpdate.releaseNotesVi.take(500),
        "releaseNotesEn" to config.appUpdate.releaseNotesEn.take(500),
      ),
      "adminNoticeVi" to config.adminNoticeVi.take(300),
      "adminNoticeEn" to config.adminNoticeEn.take(300),
      "adminNoticeExpiresAtMillis" to config.adminNoticeExpiresAtMillis.coerceAtLeast(0L),
      "updatedAt" to FieldValue.serverTimestamp(),
    )
    return try {
      docRef.set(payload).await()
      config.copy(configVersion = nextVersion, syncedFromCloud = true)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
      throw e
    }
  }

  // --- Player Directory, Targeted Admin Gifting, Friends & Room Invites ---

  suspend fun syncPlayerDirectory(progress: UserProgress) {
    val uid = auth.currentUser?.uid ?: return
    val code = progress.playerCode.ifBlank { GamePreferencesRepository.generatePlayerCode(uid) }
    val nickname = progress.nickname.trim().ifBlank { "Challenger" }.take(24)
    val docRef = db.collection("player_directory").document(uid)
    val payload = mapOf(
      "uid" to uid,
      "playerCode" to code.uppercase().take(16),
      "nickname" to nickname,
      "nicknameLower" to nickname.lowercase(),
      "totalWins" to progress.totalWins.coerceAtLeast(0).toLong(),
      "totalMatches" to progress.totalMatches.coerceAtLeast(0).toLong(),
      "isAdmin" to isAdminAccount(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )
    try {
      docRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
    }
  }

  suspend fun searchPlayers(rawQuery: String): List<PlayerDirectoryEntry> {
    requireUserId()
    val queryText = rawQuery.trim()
    if (queryText.isBlank()) return emptyList()
    val dirRef = db.collection("player_directory")
    return try {
      val upperCode = queryText.uppercase()
      val lowerName = queryText.lowercase()
      val byCode =
        dirRef
          .whereGreaterThanOrEqualTo("playerCode", upperCode)
          .whereLessThanOrEqualTo("playerCode", upperCode + "\uf8ff")
          .limit(15)
          .get()
          .await()
          .toObjects(PlayerDirectoryDoc::class.java)
      val byName =
        dirRef
          .whereGreaterThanOrEqualTo("nicknameLower", lowerName)
          .whereLessThanOrEqualTo("nicknameLower", lowerName + "\uf8ff")
          .limit(15)
          .get()
          .await()
          .toObjects(PlayerDirectoryDoc::class.java)
      (byCode + byName)
        .map { it.toDomain() }
        .distinctBy { it.uid }
        .take(25)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.LIST, dirRef.path, auth)
      emptyList()
    }
  }

  suspend fun sendTargetedGiftToPlayer(
    targetUid: String,
    rewardCoins: Int,
    rewardBall: BallType?,
    trialMinutes: Int,
    customMessageVi: String,
    customMessageEn: String,
  ) {
    requireUserId()
    check(isAdminAccount()) { "Only verified Admin ($ADMIN_OWNER_EMAIL) may send targeted player gifts." }
    require(targetUid.isNotBlank()) { "Target UID is required" }
    val mailId = "adm_${System.currentTimeMillis()}_${(1000..9999).random()}"
    val mailRef = db.collection("users").document(targetUid).collection("mailbox").document(mailId)
    val cleanBall = rewardBall?.id.orEmpty()
    val cleanTrial = if (rewardBall != null) trialMinutes.coerceIn(0, 43200) else 0
    val titleVi =
      if (cleanTrial > 0 && rewardBall != null) "Qua Admin: Dung thu ${rewardBall.id.uppercase()}"
      else "Qua Tang Tu Admin"
    val titleEn =
      if (cleanTrial > 0 && rewardBall != null) "Admin Gift: ${rewardBall.id.uppercase()} Trial"
      else "Special Gift From Admin"
    val defaultVi = buildString {
      if (rewardCoins > 0) append("+$rewardCoins Xu ")
      if (rewardBall != null) {
        if (cleanTrial > 0) append("• ${rewardBall.id.uppercase()} (${cleanTrial} phut)")
        else append("• ${rewardBall.id.uppercase()} vinh vien")
      }
    }.ifBlank { "Qua dac biet tu Admin!" }
    val defaultEn = buildString {
      if (rewardCoins > 0) append("+$rewardCoins Coins ")
      if (rewardBall != null) {
        if (cleanTrial > 0) append("• ${rewardBall.id.uppercase()} (${cleanTrial}m trial)")
        else append("• ${rewardBall.id.uppercase()} permanent")
      }
    }.ifBlank { "Special gift from Admin!" }

    val payload = MailboxDoc(
      sender = "Admin (${ADMIN_OWNER_EMAIL.substringBefore('@')})",
      titleVi = titleVi,
      titleEn = titleEn,
      bodyVi = customMessageVi.trim().ifBlank { defaultVi }.take(500),
      bodyEn = customMessageEn.trim().ifBlank { defaultEn }.take(500),
      rewardCoins = rewardCoins.coerceIn(0, 100000).toLong(),
      rewardBallId = cleanBall,
      trialMinutes = cleanTrial.toLong(),
      sourceCode = "ADMIN_DIRECT_GIFT",
      claimed = false,
    ).toCreateMap()
    try {
      mailRef.set(payload).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, mailRef.path, auth)
      throw e
    }
  }

  private fun sortedFriendRequestId(uidA: String, uidB: String): String =
    if (uidA < uidB) "${uidA}_${uidB}" else "${uidB}_${uidA}"

  suspend fun sendFriendRequest(myProgress: UserProgress, target: PlayerDirectoryEntry) {
    val myUid = requireUserId()
    require(target.uid != myUid) { "Cannot add yourself as a friend." }
    val reqId = sortedFriendRequestId(myUid, target.uid)
    val reqRef = db.collection("friend_requests").document(reqId)
    val myCode = myProgress.playerCode.ifBlank { GamePreferencesRepository.generatePlayerCode(myUid) }
    try {
      val existingSnap = reqRef.get().await()
      if (existingSnap.exists()) {
        val status = existingSnap.getString("status") ?: ""
        if (status == "pending" || status == "accepted") return
        reqRef.delete().await()
      }
      reqRef.set(
        mapOf(
          "fromUid" to myUid,
          "fromCode" to myCode.take(16),
          "fromName" to myProgress.nickname.trim().ifBlank { "Challenger" }.take(24),
          "fromIsAdmin" to isAdminAccount(),
          "toUid" to target.uid,
          "toCode" to target.playerCode.take(16),
          "toName" to target.nickname.trim().ifBlank { "Player" }.take(24),
          "status" to "pending",
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, reqRef.path, auth)
      throw e
    }
  }

  suspend fun respondFriendRequest(
    request: FriendRequestEntry,
    accept: Boolean,
    myProgress: UserProgress,
  ) {
    val myUid = requireUserId()
    if (request.toUid != myUid) return
    val reqRef = db.collection("friend_requests").document(request.id)
    try {
      reqRef.update(
        mapOf(
          "status" to if (accept) "accepted" else "declined",
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      if (accept) {
        val myCode = myProgress.playerCode.ifBlank { GamePreferencesRepository.generatePlayerCode(myUid) }
        val myName = myProgress.nickname.trim().ifBlank { "Challenger" }.take(24)
        // Add mutual friend entries
        db.collection("users").document(myUid).collection("friends").document(request.fromUid).set(
          mapOf(
            "uid" to request.fromUid,
            "playerCode" to request.fromCode.take(16),
            "nickname" to request.fromName.take(24),
            "isAdmin" to request.fromIsAdmin,
            "createdAt" to FieldValue.serverTimestamp(),
          )
        ).await()
        db.collection("users").document(request.fromUid).collection("friends").document(myUid).set(
          mapOf(
            "uid" to myUid,
            "playerCode" to myCode.take(16),
            "nickname" to myName,
            "isAdmin" to isAdminAccount(),
            "createdAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, reqRef.path, auth)
      throw e
    }
  }

  suspend fun removeFriend(friendUid: String) {
    val myUid = requireUserId()
    runCatching {
      db.collection("users").document(myUid).collection("friends").document(friendUid).delete().await()
    }
    runCatching {
      db.collection("users").document(friendUid).collection("friends").document(myUid).delete().await()
    }
  }

  fun observeFriends(): Flow<List<FriendEntry>> = flow {
    val uid = requireUserId()
    val path = "users/$uid/friends"
    emitAll(
      db.collection("users").document(uid).collection("friends")
        .orderBy("createdAt", Query.Direction.DESCENDING)
        .limit(80)
        .snapshots()
        .map { snap -> snap.toObjects(FriendDoc::class.java).map { it.toDomain() } }
        .catch { error ->
          val fsEx = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
          if (fsEx == null && error is CancellationException) throw error
          if (fsEx != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(fsEx, OperationType.LIST, path, auth)
          }
          throw error
        }
    )
  }

  fun observeIncomingFriendRequests(): Flow<List<FriendRequestEntry>> = flow {
    val uid = requireUserId()
    emitAll(
      db.collection("friend_requests")
        .whereEqualTo("toUid", uid)
        .whereEqualTo("status", "pending")
        .limit(40)
        .snapshots()
        .map { snap -> snap.toObjects(FriendRequestDoc::class.java).map { it.toDomain() } }
        .catch { error ->
          val fsEx = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
          if (fsEx == null && error is CancellationException) throw error
          if (fsEx != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(fsEx, OperationType.LIST, "friend_requests", auth)
          }
          throw error
        }
    )
  }

  suspend fun sendRoomInvite(roomCode: String, myName: String, toUid: String) {
    val myUid = requireUserId()
    require(toUid != myUid)
    val inviteId = "inv_${System.currentTimeMillis()}_${(1000..9999).random()}"
    val ref = db.collection("room_invites").document(inviteId)
    val expiresAt = System.currentTimeMillis() + 5L * 60_000L
    try {
      ref.set(
        mapOf(
          "roomCode" to roomCode.trim().uppercase().take(32),
          "fromUid" to myUid,
          "fromName" to myName.trim().ifBlank { "Challenger" }.take(24),
          "fromIsAdmin" to isAdminAccount(),
          "toUid" to toUid,
          "status" to "pending",
          "expiresAtMillis" to expiresAt,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
      throw e
    }
  }

  fun observeIncomingRoomInvites(): Flow<List<RoomInviteEntry>> = flow {
    val uid = requireUserId()
    emitAll(
      db.collection("room_invites")
        .whereEqualTo("toUid", uid)
        .whereEqualTo("status", "pending")
        .limit(15)
        .snapshots()
        .map { snap ->
          val now = System.currentTimeMillis()
          snap.toObjects(RoomInviteDoc::class.java)
            .map { it.toDomain() }
            .filter { it.isValid(now) }
            .sortedByDescending { it.createdAtMillis }
        }
        .catch { error ->
          val fsEx = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
          if (fsEx == null && error is CancellationException) throw error
          if (fsEx != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(fsEx, OperationType.LIST, "room_invites", auth)
          }
          throw error
        }
    )
  }

  suspend fun respondRoomInvite(inviteId: String, accept: Boolean) {
    requireUserId()
    val ref = db.collection("room_invites").document(inviteId)
    runCatching {
      ref.update(
        mapOf(
          "status" to if (accept) "accepted" else "declined",
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    }
  }
}
