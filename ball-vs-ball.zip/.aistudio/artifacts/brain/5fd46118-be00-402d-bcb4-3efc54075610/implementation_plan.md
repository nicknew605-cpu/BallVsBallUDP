# Ball vs Ball — Kế Hoạch Nâng Cấp v1.0.3 Beta

Phiên bản **1.0.3 Beta** (`versionCode = 7`, `versionName = "1.0.3-beta"`) bổ sung chế độ **Ghép ngẫu nhiên** ngay trong mục **1vs1 Online** dành riêng cho cộng đồng nhỏ ghép cặp tức thì, đại tu chiêu cuối **Kỷ Băng Hà** của Ice Ball, cân bằng lại toàn bộ **6 bóng** theo hướng đối kháng công bằng, làm mới hoàn toàn **VFX 2D & Âm thanh nổi**, và cấu hình sẵn liên kết cập nhật GitHub `nicknew605-cpu/BallVsBallUDP`.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Tóm tắt 4 lựa chọn đã chốt cùng bạn và lưu ý bảo mật quan trọng cho GitHub Token.

- **Confirmed Decision 1 — Nộ Kỷ Băng Hà (Ice Ball)**: Đóng băng toàn bộ kẻ địch tại chỗ suốt **10 giây** kèm trừ **70% thanh nộ** hiện có của địch ngay lập tức (hồi chiêu **20 giây**); trong thời gian này Ice Ball vẫn tự do di chuyển, va chạm và bắn mảnh băng (**6 sát thương**, tốc độ tạo mảnh nhanh hơn). Hết 10 giây đóng băng, kẻ địch chịu tiếp **làm chậm 40%** trong 4 giây.
- **Confirmed Decision 2 — Ghép Ngẫu Nhiên (Quick Matchmaking)**: Đặt ngay trong màn hình **1vs1 Online**; ngay khi 2 người bấm ghép cùng lúc (hoặc khi có sẵn người đang chờ), hệ thống lập tức đưa cả 2 vào thẳng luồng **Cấm/Chọn FT3** chuẩn xác.
- **Confirmed Decision 3 — Cân Bằng 6 Bóng Ngang Cơ**: Điều chỉnh chỉ số và cơ chế khắc chế chéo giữa tất cả 6 bóng (Fire, Water, Ground, Thunder, Ice, Ant) để mọi kèo đấu đều công bằng, có cách hóa giải lẫn nhau.
- **Confirmed Decision 4 — Auto-Update v1.0.3 Beta & Bảo Mật Token**: Điền sẵn repo `nicknew605-cpu/BallVsBallUDP` và đường dẫn mặc định bản v1.0.3 Raw/Release trong cấu hình Admin/OTA. **Không nhúng GitHub Personal Token vào mã nguồn APK** vì APK có thể bị dịch ngược làm lộ quyền ghi repo — bạn nên **thu hồi/tạo lại token** vừa gửi trong khung chat rồi dán trực tiếp tại mục Admin trên thiết bị của bạn (lưu riêng cục bộ, không chia sẻ).

---

## 1. Overview & Core Concept

- **Mục tiêu trải nghiệm**: Biến chế độ Online từ việc phải đọc mã phòng thủ công sang trải nghiệm **1 chạm ghép trận tức thì** với bạn bè, kết hợp đấu trường v1.0.3 Beta rực rỡ hiệu ứng băng giá/nguyên tố, âm thanh dứt khoát và nhịp độ cân bằng sâu sắc.
- **Đối tượng chính**: Nhóm người chơi bạn bè (2–10 người online cùng lúc) cần ghép trận nhanh không chờ đợi và Admin phát hành cập nhật 1 chạm qua GitHub Releases / GitHub Raw.

---

## 2. User Experience & Visual Design

### A. Luồng Ghép Ngẫu Nhiên trong 1vs1 Online
1. Người chơi bấm **1VS1 ONLINE** ở Sảnh chính -> thấy ngay thẻ **Ghép Ngẫu Nhiên Nhanh** nổi bật phía trên phần Tạo/Vào phòng theo mã.
2. Bấm **Ghép Ngẫu Nhiên**: thẻ chuyển sang trạng thái quét trực tiếp kèm bộ đếm giây, hiệu ứng radar neon và nút **Hủy Ghép**.
3. Nếu đã có người khác đang tìm trận (nhịp tim hoạt động trong vòng 25 giây gần nhất): cả hai khớp cặp trong `< 1 giây`, tự phát âm báo tìm thấy trận và chuyển đồng thời vào phòng Cấm/Chọn FT3.
4. Nếu chưa có ai đang tìm: thiết bị giữ vị trí chờ trên hàng đợi với nhịp tim 3 giây/lần; ngay khi người thứ hai bấm Ghép Ngẫu Nhiên, cả hai lập tức vào cùng phòng.

### B. Thẩm Mỹ, VFX 2D & Âm Thanh v1.0.3 Beta
- **Hiệu ứng Kỷ Băng Hà toàn sân**:
  - Khi kích hoạt, luồng sóng băng nổ tung từ Ice Ball kèm viền tinh thể tuyết bao phủ 4 cạnh sân, nền sân chuyển sắc xanh băng sâu thẳm trong suốt **10 giây**.
  - Bóng địch bị bọc trong khối tinh thể băng đa giác 3D giả lập kèm vết nứt và vòng cung đếm ngược thời gian rã băng; khi vừa rã băng xong, bóng địch mang vòng sương lạnh báo hiệu **giảm 40% tốc độ**.
- **Nâng cấp VFX toàn bộ 6 Bóng (giữ ổn định 60/120Hz)**:
  - **Fire**: Vệt sao băng rực cháy đa lớp + vòng lửa địa ngục khắc ấn kháng hồi máu.
  - **Water**: Vòng xoáy thủy áp gợn sóng + thủy lao pha lê phát sáng.
  - **Ground**: Mảnh vỡ thạch anh nổi khối khi dậm chấn + khiên giáp đá vàng ánh kim miễn khống chế.
  - **Thunder**: Tia chớp đa nhánh sắc cạnh + bóng ma điện tím mượt mà.
  - **Ice**: Mảnh băng xoay quanh quỹ đạo phát sáng rực hơn khi Overdrive + vệt bụi tuyết lấp lánh.
  - **Ant**: Hào quang Kiến Hậu/Vua sắc nét + đường dẫn pheromone cho đội quân kiến lính 2D.
- **Âm thanh nổi 44.1kHz**: Nâng cấp bộ tổng hợp âm cho tiếng vỡ băng Kỷ Băng Hà (sub-bass + tiếng kính băng tách), tiếng mảnh băng 6 sát thương thanh gọn, âm báo tìm thấy trận ghép ngẫu nhiên, và bộ cân bằng giới hạn biên độ tránh rè loa khi nhiều hiệu ứng nổ cùng lúc.

---

## 3. Key Product Decisions & Balance Tuning

### Bảng Cân Bằng 6 Bóng Ngang Cơ (v1.0.3 Beta)
| Bóng | Máu & Hệ số DMG | Cơ chế / Khắc chế chiến thuật |
| :--- | :--- | :--- |
| **Fire Ball** | **125 HP** • **1.05x** | Bào máu theo thời gian + vết bỏng giúp **giảm 35% hiệu quả hồi máu** của Ant King & Water; lưới laser dọn lính/tế bào cực nhanh. |
| **Water Ball** | **130 HP** • **1.00x** | Thủy lao khống chế diện vừa phải, sóng thần hất văng phá góc bắn, hồi phục nhẹ theo điểm cộng dồn Thủy Triều. |
| **Ground Ball** | **145 HP** • **1.00x** | **Giáp Đất (5s, CD 18s) miễn nhiễm 100% đóng băng Kỷ Băng Hà & làm chậm** — là khắc tinh cứng của Ice & Ant; địa chấn 12 DMG quét sạch kiến lính quanh mình. |
| **Thunder Ball** | **115 HP** • **1.05x** | Cơ động cao nhất sân; Đột Tử Sét (**32% máu**) xuyên giáp, kết liễu gọn các bóng trâu máu hoặc phân thân. |
| **Ice Ball** | **120 HP** • **1.00x** | Mảnh băng tăng lên **6 sát thương** & tạo nhanh hơn (**0.68s**); **Kỷ Băng Hà đóng băng 10s + trừ 70% nộ + làm chậm 40% sau băng (CD 20s)**. |
| **Ant Ball** | **120 HP** • **1.00x** | Sinh thêm Ant Ball hoàn chỉnh (tối đa **3 bóng**, chu kỳ **16s**); Kiến lính nhanh, tồn tại vĩnh viễn tới khi cắn trúng, nhưng máu gốc về mức 120 HP để đối thủ kịp dồn sát thương đầu trận. |

- **Lý do thiết kế**: Thay vì để một bóng áp đảo tuyệt đối, Ground Ball có **Miễn Khống Chế** phá 10s Kỷ Băng Hà của Ice; Fire có **Giảm Hồi Máu & Laser** dọn đàn kiến của Ant; Ice có **Trừ 70% Nộ & Đóng Băng** kìm chân Thunder/Fire/Ant; Water & Thunder giữ tốc độ xoay chuyển linh hoạt. Tất cả thông số vẫn đồng bộ qua `balanceSnapshot` trong phòng Online nên 2 máy luôn cân bằng giống hệt nhau.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    Ball vs Ball v1.0.3 Beta Architecture                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  [1vs1 Online Hub]                                                      │
│   ├─► Nút "Ghép Ngẫu Nhiên"                                             │
│   │      ├─► Quét `matchmaking_queue` (waiting, heartbeat < 25s)       │
│   │      ├─► Có đối thủ -> Transaction: Tạo Room + Gán matched + RoomId│
│   │      └─► Chưa có    -> Ghi Ticket chờ + Heartbeat 3s               │
│   │                         └─► Listener thấy matched -> Auto Join Room │
│   └─► Tạo / Nhập mã phòng -> Luồng Cấm/Chọn FT3 & Đồng bộ góc bắn       │
│                                                                         │
│  [Battle Physics Engine (120Hz Lockstep)]                               │
│   ├─► Balance Snapshot (6 bóng ngang cơ, 10s Freeze, 6 dmg shards)     │
│   ├─► Ice Absolute Zero: enemy.rage *= 0.30, frozen = 10s, postSlow 40% │
│   └─► Render Pipeline: ArenaPathPool + Ice Lattice + Pheromone VFX      │
│                                                                         │
│  [OTA & Admin GitHub Updater]                                           │
│   ├─► Repo mặc định: nicknew605-cpu/BallVsBallUDP                       │
│   ├─► Link v1.0.3 chuẩn hóa: /blob/ -> /raw/ tự động tải % 1 chạm       │
│   └─► Token: Nhập & lưu riêng cục bộ trên máy Admin (Zero Hardcode)     │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Ánh xạ Luồng Dữ Liệu & Quy Tắc Bảo Mật
- **Hàng đợi Ghép Ngẫu Nhiên (`matchmaking_queue/{userId}`)**:
  - Người dùng chỉ tạo/sửa được ticket mang UID của chính mình khi tìm trận hoặc hủy tìm trận.
  - Người dùng khác đã đăng nhập chỉ được chuyển một ticket đang `"waiting"` sang `"matched"` kèm `roomCode` hợp lệ nếu ghi nhận đúng giao dịch ghép cặp (không được cướp hoặc sửa ticket đã `"matched"`).
  - Sau khi sửa luật bảo mật Firestore, toàn bộ kịch bản hợp lệ và truy cập trái phép sẽ được kiểm thử qua bộ test tự động trước khi deploy live.
- **Tự động chuyển đổi Link & OTA v1.0.3 Beta**:
  - Hỗ trợ tự động chuyển link GitHub dạng `/blob/` (như link bạn cung cấp) sang đường dẫn tải trực tiếp `/raw/` khi phát hành hoặc khi người chơi bấm cập nhật, đảm bảo tải APK kèm thanh `%` hoạt động trơn tru.
