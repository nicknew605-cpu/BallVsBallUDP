const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const serverTimestamp = () => new Date(Date.now() - 1000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_001";
const BOB_UID = "bob_uid_002";
const CHARLIE_UID = "charlie_uid_003";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validUserPayload(uid) {
  return {
    userId: uid,
    nickname: "PlayerOne",
    coins: 160,
    purchasedBalls: ["fire"],
    purchasedKillEffects: ["default_burst"],
    equippedBall: "fire",
    equippedKillEffect: "default_burst",
    tanThuActivatedAtMillis: 0,
    totalWins: 0,
    totalMatches: 0,
    gachaPityCount: 0,
    totalSpins: 0,
    redeemedCodes: [],
    dailyStreak: 0,
    lastDailyClaimEpochDay: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

function validMailPayload() {
  return {
    sender: "Admin",
    titleVi: "Qua den bu TaiDz-111",
    titleEn: "TaiDz-111 Compensation",
    bodyVi: "Nhan mien phi Thunder Ball vinh vien.",
    bodyEn: "Claim free permanent Thunder Ball.",
    rewardCoins: 0,
    rewardBallId: "thunder",
    sourceCode: "TaiDz-111",
    claimed: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

function validRoomPayload(hostUid) {
  return {
    hostUid,
    hostName: "Alice",
    guestUid: "",
    guestName: "",
    status: "waiting",
    hostPicks: [],
    guestPicks: [],
    hostBannedBall: "",
    guestBannedBall: "",
    hostFinalBall: "",
    guestFinalBall: "",
    seed: 123456,
    winnerUid: "",
    matchDurationSec: 0,
    rewardCoins: 0,
    hostReady: false,
    guestReady: false,
    hostScore: 0,
    guestScore: 0,
    currentRound: 1,
    hostLastHeartbeatMs: Date.now(),
    guestLastHeartbeatMs: 0,
    hostEmote: "",
    guestEmote: "",
    hostEmoteAtMs: 0,
    guestEmoteAtMs: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write users, ota_config, or rooms", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("ota_config").doc("live").get());
  await assertFails(unauthDb.collection("rooms").doc("AB12CD").get());
  await assertFails(unauthDb.collection("rooms").get());
});

test("Authenticated user can create, read, and update own profile, but cannot access Bob's", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      nickname: "AlicePro",
      coins: 500,
      dailyStreak: 3,
      lastDailyClaimEpochDay: 20400,
      updatedAt: serverTimestamp(),
    })
  );

  // Cross-user isolation
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ coins: 9999, updatedAt: serverTimestamp() }));

  // Ghost field rejection (Shadow update test)
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: serverTimestamp(),
    })
  );
});

test("Mailbox: owner can create, list, and claim once; cannot unclaim or spoof another user", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  const mailRef = aliceDb.collection("users").doc(ALICE_UID).collection("mailbox").doc("mail_taidz");
  await assertSucceeds(mailRef.set(validMailPayload()));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("mailbox").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("mailbox").get());

  // Claim once succeeds
  await assertSucceeds(mailRef.update({ claimed: true, updatedAt: serverTimestamp() }));
  // Cannot claim again or tamper reward
  await assertFails(mailRef.update({ claimed: false, updatedAt: serverTimestamp() }));
  await assertFails(mailRef.update({ rewardCoins: 99999, updatedAt: serverTimestamp() }));
});

test("OTA config: authenticated user can get live doc, cannot list/write; verified Admin can publish timed notices and per-ball stats", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("ota_config").doc("live").set({
      configVersion: 104,
      gachaSpinCost: 120,
      activeCodes: [{ code: "TriAn", rewardCoins: 5000 }],
      disabledCodes: [],
      updatedAt: serverTimestamp(),
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com" }).firestore();
  const adminDb = testEnv.authenticatedContext("admin_uid", { email: "nicknew605@gmail.com" }).firestore();

  await assertSucceeds(aliceDb.collection("ota_config").doc("live").get());
  await assertFails(aliceDb.collection("ota_config").get());
  await assertFails(
    aliceDb.collection("ota_config").doc("live").set({
      configVersion: 99,
      gachaSpinCost: 120,
      activeCodes: [],
      updatedAt: serverTimestamp(),
    })
  );

  await assertSucceeds(
    adminDb.collection("ota_config").doc("live").set({
      configVersion: 105,
      gachaSpinCost: 120,
      activeCodes: [{ code: "TriAn", rewardCoins: 5000, expiresAtMillis: Date.now() + 86400000 }],
      disabledCodes: [],
      balanceOverrides: {
        groundSkill1Damage: 10,
        groundChargeReduction: 0.10,
        groundArmorAllReduction: 0.30,
        ballOverrides: {
          ant: { hp: 150, damageScale: 1.25 },
          ground: { hp: 125, damageScale: 0.95 },
        },
      },
      vfxOverrides: { particleMultiplier: 1.5, glowIntensity: 1.4, effectScale: 1.15, vibrancyBoost: 1.2 },
      appUpdate: {
        latestVersionCode: 5,
        latestVersionName: "1.0.2-release",
        minSupportedVersionCode: 5,
        downloadUrl: "https://github.com/hct/ballvsball/releases/download/v1.0.2/app.apk",
        releaseNotesVi: "Ban cap nhat 1.0.2 Release",
        releaseNotesEn: "1.0.2 Release",
      },
      adminNoticeVi: "Su kien Tri An 5000 Xu!",
      adminNoticeEn: "Appreciation Event 5000 Coins!",
      adminNoticeExpiresAtMillis: Date.now() + 3600_000,
      updatedAt: serverTimestamp(),
    })
  );

  await assertFails(
    adminDb.collection("ota_config").doc("live").set({
      configVersion: 106,
      gachaSpinCost: 120,
      activeCodes: [],
      appUpdate: { latestVersionCode: -1 },
      updatedAt: serverTimestamp(),
    })
  );
});

test("Online 1vs1 room: ready lobby, unfiltered chat, auto-3/ban-1/FT3 series, and terminal lock enforced", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  const roomId = "ROOM01";
  await assertSucceeds(aliceDb.collection("rooms").doc(roomId).set(validRoomPayload(ALICE_UID)));

  // Bob joins waiting lobby
  await assertSucceeds(
    bobDb.collection("rooms").doc(roomId).update({
      guestUid: BOB_UID,
      guestName: "Bob",
      guestReady: false,
      guestLastHeartbeatMs: Date.now(),
      updatedAt: serverTimestamp(),
    })
  );

  // Charlie cannot hijack or modify room
  await assertFails(
    charlieDb.collection("rooms").doc(roomId).update({
      guestUid: CHARLIE_UID,
      guestName: "Charlie",
      status: "pick_3",
      updatedAt: serverTimestamp(),
    })
  );

  // Unfiltered chat between Alice & Bob works; Charlie is denied
  await assertSucceeds(
    aliceDb.collection("rooms").doc(roomId).collection("messages").doc("msg_1").set({
      senderUid: ALICE_UID,
      senderName: "Alice",
      text: "San sang chien thoi nao!",
      createdAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    bobDb.collection("rooms").doc(roomId).collection("messages").doc("msg_2").set({
      senderUid: BOB_UID,
      senderName: "Bob",
      text: "Ok luon gg!",
      createdAt: serverTimestamp(),
    })
  );
  await assertSucceeds(aliceDb.collection("rooms").doc(roomId).collection("messages").get());
  await assertFails(charlieDb.collection("rooms").doc(roomId).collection("messages").get());
  await assertFails(
    charlieDb.collection("rooms").doc(roomId).collection("messages").doc("msg_3").set({
      senderUid: CHARLIE_UID,
      senderName: "Charlie",
      text: "Spam",
      createdAt: serverTimestamp(),
    })
  );

  // Both toggle Ready & system deals 3 balls -> Ban 1 -> Final -> Playing -> FT3 round progression -> Finished
  await assertSucceeds(
    aliceDb.collection("rooms").doc(roomId).update({
      hostReady: true,
      hostPicks: ["fire", "water", "ant"],
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    bobDb.collection("rooms").doc(roomId).update({
      guestReady: true,
      guestPicks: ["ground", "ice", "thunder"],
      status: "ban_1",
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("rooms").doc(roomId).update({
      hostBannedBall: "ice",
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    bobDb.collection("rooms").doc(roomId).update({
      guestBannedBall: "water",
      status: "final_pick",
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("rooms").doc(roomId).update({
      hostFinalBall: "ant",
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    bobDb.collection("rooms").doc(roomId).update({
      guestFinalBall: "thunder",
      status: "playing",
      hostAimRad: -99,
      guestAimRad: -99,
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("rooms").doc(roomId).update({
      hostAimRad: -1.15,
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    bobDb.collection("rooms").doc(roomId).update({
      guestAimRad: 1.35,
      updatedAt: serverTimestamp(),
    })
  );

  // Round 1 point scored -> advances to round 2 pick_3
  await assertSucceeds(
    aliceDb.collection("rooms").doc(roomId).update({
      hostScore: 1,
      guestScore: 0,
      currentRound: 2,
      status: "pick_3",
      hostPicks: [],
      guestPicks: [],
      hostBannedBall: "",
      guestBannedBall: "",
      hostFinalBall: "",
      guestFinalBall: "",
      seed: 654321,
      updatedAt: serverTimestamp(),
    })
  );

  // Emote + series finish (3 points)
  await assertSucceeds(
    bobDb.collection("rooms").doc(roomId).update({
      guestEmote: "gg",
      guestEmoteAtMs: Date.now(),
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("rooms").doc(roomId).update({
      hostScore: 3,
      status: "finished",
      winnerUid: ALICE_UID,
      matchDurationSec: 18.5,
      rewardCoins: 180,
      updatedAt: serverTimestamp(),
    })
  );

  // Terminal state locking: cannot modify after finished
  await assertFails(
    bobDb.collection("rooms").doc(roomId).update({
      winnerUid: BOB_UID,
      updatedAt: serverTimestamp(),
    })
  );
});

test("Player Directory & ADM badge: non-admin cannot spoof isAdmin, admin can deliver targeted gift to Bob's mailbox", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com" }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com" }).firestore();
  const adminDb = testEnv.authenticatedContext("admin_uid", { email: "nicknew605@gmail.com" }).firestore();

  // Regular user can write own directory entry with isAdmin: false
  await assertSucceeds(
    aliceDb.collection("player_directory").doc(ALICE_UID).set({
      uid: ALICE_UID,
      playerCode: "BVB-ALICE1",
      nickname: "Alice",
      nicknameLower: "alice",
      totalWins: 2,
      totalMatches: 4,
      isAdmin: false,
      updatedAt: serverTimestamp(),
    })
  );

  // Regular user cannot spoof isAdmin: true
  await assertFails(
    aliceDb.collection("player_directory").doc(ALICE_UID).set({
      uid: ALICE_UID,
      playerCode: "BVB-ALICE1",
      nickname: "Alice",
      nicknameLower: "alice",
      isAdmin: true,
      updatedAt: serverTimestamp(),
    })
  );

  // Admin can set isAdmin: true
  await assertSucceeds(
    adminDb.collection("player_directory").doc("admin_uid").set({
      uid: "admin_uid",
      playerCode: "BVB-ADMIN1",
      nickname: "HCTAdmin",
      nicknameLower: "hctadmin",
      isAdmin: true,
      updatedAt: serverTimestamp(),
    })
  );

  // Regular user Alice CANNOT send a gift directly into Bob's mailbox
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("mailbox").doc("spoof_gift").set(validMailPayload())
  );

  // Verified Admin CAN deliver a targeted gift into Bob's mailbox
  await assertSucceeds(
    adminDb.collection("users").doc(BOB_UID).collection("mailbox").doc("adm_gift_1").set({
      ...validMailPayload(),
      rewardCoins: 1500,
      rewardBallId: "ant",
      trialMinutes: 120,
      sourceCode: "ADMIN_DIRECT_GIFT",
    })
  );
  await assertSucceeds(bobDb.collection("users").doc(BOB_UID).collection("mailbox").get());
});

test("Friends, Friend Requests, and Room Invites enforce participant isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  const reqId = `${ALICE_UID}_${BOB_UID}`;
  await assertSucceeds(
    aliceDb.collection("friend_requests").doc(reqId).set({
      fromUid: ALICE_UID,
      fromCode: "BVB-ALICE1",
      fromName: "Alice",
      fromIsAdmin: false,
      toUid: BOB_UID,
      toCode: "BVB-BOB002",
      toName: "Bob",
      status: "pending",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Charlie cannot accept Alice -> Bob request
  await assertFails(
    charlieDb.collection("friend_requests").doc(reqId).update({
      status: "accepted",
      updatedAt: serverTimestamp(),
    })
  );

  // Bob accepts and adds mutual friend docs
  await assertSucceeds(
    bobDb.collection("friend_requests").doc(reqId).update({
      status: "accepted",
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    bobDb.collection("users").doc(ALICE_UID).collection("friends").doc(BOB_UID).set({
      uid: BOB_UID,
      playerCode: "BVB-BOB002",
      nickname: "Bob",
      isAdmin: false,
      createdAt: serverTimestamp(),
    })
  );

  // Room Invite from Alice to Bob succeeds; Charlie cannot steal/respond
  const invId = "inv_room_1";
  await assertSucceeds(
    aliceDb.collection("room_invites").doc(invId).set({
      roomCode: "ROOM99",
      fromUid: ALICE_UID,
      fromName: "Alice",
      fromIsAdmin: false,
      toUid: BOB_UID,
      status: "pending",
      expiresAtMillis: Date.now() + 300000,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );
  await assertFails(
    charlieDb.collection("room_invites").doc(invId).update({
      status: "accepted",
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    bobDb.collection("room_invites").doc(invId).update({
      status: "accepted",
      updatedAt: serverTimestamp(),
    })
  );
});

test("Quick Matchmaking Queue: waiting ticket creation, atomic room claim, query isolation, and anti-hijack rules", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  // Alice creates a waiting ticket
  await assertSucceeds(
    aliceDb.collection("matchmaking_queue").doc(ALICE_UID).set({
      uid: ALICE_UID,
      nickname: "Alice",
      isAdmin: false,
      status: "waiting",
      roomCode: "",
      matchedWithUid: "",
      heartbeatMs: Date.now(),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Alice cannot spoof isAdmin: true
  await assertFails(
    aliceDb.collection("matchmaking_queue").doc(ALICE_UID).update({
      isAdmin: true,
      heartbeatMs: Date.now(),
      updatedAt: serverTimestamp(),
    })
  );

  // Bob can query waiting tickets, but unqualified collection scan fails
  await assertSucceeds(bobDb.collection("matchmaking_queue").where("status", "==", "waiting").get());
  await assertFails(bobDb.collection("matchmaking_queue").get());

  // Claiming Alice's ticket WITHOUT creating the room atomically fails
  await assertFails(
    bobDb.collection("matchmaking_queue").doc(ALICE_UID).update({
      status: "matched",
      roomCode: "QM9999",
      matchedWithUid: BOB_UID,
      updatedAt: serverTimestamp(),
    })
  );

  // Atomic batch: Bob creates room QM8888 AND marks Alice's waiting ticket matched
  const batch = bobDb.batch();
  batch.set(bobDb.collection("rooms").doc("QM8888"), {
    ...validRoomPayload(BOB_UID),
    hostName: "Bob",
    hostReady: true,
  });
  batch.update(aliceDb.doc ? bobDb.collection("matchmaking_queue").doc(ALICE_UID) : bobDb.collection("matchmaking_queue").doc(ALICE_UID), {
    status: "matched",
    roomCode: "QM8888",
    matchedWithUid: BOB_UID,
    updatedAt: serverTimestamp(),
  });
  await assertSucceeds(batch.commit());

  // Charlie cannot hijack Alice's already-matched ticket
  await assertFails(
    charlieDb.collection("matchmaking_queue").doc(ALICE_UID).update({
      status: "matched",
      roomCode: "QM7777",
      matchedWithUid: CHARLIE_UID,
      updatedAt: serverTimestamp(),
    })
  );

  // Alice can delete her own ticket once matched/cancelled; Charlie cannot
  await assertFails(charlieDb.collection("matchmaking_queue").doc(ALICE_UID).delete());
  await assertSucceeds(aliceDb.collection("matchmaking_queue").doc(ALICE_UID).delete());
});

